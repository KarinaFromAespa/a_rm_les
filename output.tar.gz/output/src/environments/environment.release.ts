export const environment = {
  production: true,
  apiUrl: '%@apiUrl@%',
  umbraco: {
    cdnUrl: 'https://cdn.umbraco.io/content',
    graphQLServerUrl: 'https://graphql.umbraco.io',
    previewUrl: 'https://preview.umbraco.io/content',
    projectAlias: '%@umbracoProjectAlias@%',
    apiVersion: '2.2'
  },
  reCaptchaSiteKey: '%@reCaptchaSiteKey@%',
  alternateReCaptchaSiteKey: '%@alternateReCaptchaSiteKey@%',
  applicationInsightsConnectionString: '%@applicationInsightsConnectionString@%',
  liveUpdateUrl: '%@liveUpdateUrl@%',
  clientVersion: '%@clientVersion@%',
  xsrfClientCookieName: '%@xsrfClientCookieName@%'
};
