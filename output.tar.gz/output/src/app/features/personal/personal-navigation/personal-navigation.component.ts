import { DOCUMENT } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ILink, IPage, IPageLink, LinkType } from 'src/app/core/models/site.response';
import { SiteService } from 'src/app/core/services/site.service';
import { NavigationComponent } from 'src/app/shared/components/navigation/navigation.component';

@Component({
  selector: 'air-personal-navigation',
  templateUrl: './personal-navigation.component.html',
  standalone: false
})
export class PersonalNavigationComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChildren(NavigationComponent, { read: ElementRef }) navigationElements: QueryList<ElementRef>;
  @ViewChild('personalNavigationMobileTrigger') set content(content: Element) {
    this.personalNavigationMobileTrigger = content;
  }
  personalNavigationMobileTrigger: Element;

  isVisible: boolean;
  personalMenuLinks: ILink[] = [];
  activeLinkListItemLabel?: string;
  userEventSource = UserEventSource.heroMenu;

  destroy$ = new Subject();

  constructor(
    @Inject(DOCUMENT) private document: HTMLDocument,
    private siteService: SiteService,
    private router: Router,
    private translateService: TranslateService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.isVisible = !!data;
      this.personalMenuLinks = data?.personalMenuLinks ? (ObjectHelper.deepCopy(data.personalMenuLinks) as ILink[]) : [];
      void this.addLogoutButton();
    });
  }

  ngAfterViewInit(): void {
    this.personalMenuLinks.forEach((menu) => {
      menu.links.forEach((link: IPageLink) => {
        const [page] = ObjectHelper.wrapFieldToArray(link?.page);

        const url = (link?.url || page?.url || page?._url) ?? '';
        const isActive = this.router.url.startsWith(url.replace(/\/$/, ''));

        if (!isActive) {
          return;
        }

        this.activeLinkListItemLabel = link.label || (link.page as IPage).title;
      });
    });

    this.cdRef.detectChanges();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async addLogoutButton(): Promise<void> {
    const logoutLabel = (await this.translateService.get('general.label.logout').toPromise()) as string;
    this.personalMenuLinks[0]?.links.push({
      contentTypeAlias: LinkType.pageLink,
      label: logoutLabel,
      icon: 'ui-logout',
      url: this.router.createUrlTree(['logout']).toString()
    } as IPageLink);
  }
}
