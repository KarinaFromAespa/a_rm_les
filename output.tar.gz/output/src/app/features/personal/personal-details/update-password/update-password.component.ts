import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormType } from 'src/app/core/constants/form.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion, IFormContentBlock } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormSection, IPasswordControl, IRepeatControl } from 'src/app/core/models/form.model';
import { PasswordLoginRequest } from 'src/app/core/models/login.request';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { TokenService } from 'src/app/core/services/token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { IFormContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { IUserEmailAddress } from 'src/app/features/password-reset/password-reset.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { UpdatePasswordRequest } from './update-password.model';

@Component({
  selector: 'air-update-password',
  templateUrl: './update-password.component.html',
  standalone: false
})
export class UpdatePasswordComponent extends BaseFormComponent<UpdatePasswordRequest> implements IFormContentBlockComponent, OnInit {
  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    protected reCaptchaService: ReCaptchaService,
    protected route: Router,
    private tokenService: TokenService,
    private userService: UserService,
    private translateService: TranslateService
  ) {
    super(userEventService, platformHelper, toastService, reCaptchaService);
  }

  className = 'update-password';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IFormContentBlock;

  ngOnInit(): void {
    this.form = [
      {
        controls: [
          {
            type: FormType.password,
            label: this.translateService.instant('user.label.old_password') as string,
            name: 'currentPassword',
            enableShowPassword: true,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.password.required') as string
              },
              {
                validator: FormValidatorType.pattern(FormRegex.password.getRegExp()),
                errorMessage: this.translateService.instant('account.error.password.invalid') as string
              }
            ],
            autocomplete: 'current-password'
          } as IPasswordControl,
          {
            type: FormType.repeat,
            label: this.translateService.instant('user.label.new_password') as string,
            name: 'newPassword',
            controlType: FormType.password,
            fullWidth: true,
            showValidationChecklist: true,
            enableShowPassword: true,
            validationChecklistTitle: `${this.translateService.instant('account.label.password_requirements') as string}`,
            repeatControlLabel: this.translateService.instant('user.label.repeat_new_password') as string,
            repeatErrorMessage: this.translateService.instant('account.error.password.repeat') as string,
            repeatChecklistMessage: this.translateService.instant('account.error.password.identical') as string,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.password.required') as string,
                hideFromChecklist: true
              },
              {
                validator: FormValidatorType.pattern(FormRegex.symbols.getRegExp()),
                errorMessage: this.translateService.instant('account.error.password.invalid_special_chars') as string,
                hideFromChecklist: true
              },
              {
                validator: FormValidatorType.minLength(10),
                errorMessage: this.translateService.instant('account.error.password.min_length') as string
              },
              {
                validator: FormValidatorType.maxLength(60),
                errorMessage: this.translateService.instant('account.error.password.max_length') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneUppercase),
                errorMessage: this.translateService.instant('account.error.password.uppercase') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneLowercase),
                errorMessage: this.translateService.instant('account.error.password.lowercase') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneDigit),
                errorMessage: this.translateService.instant('account.error.password.number') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneSymbol),
                errorMessage: this.translateService.instant('account.error.password.symbols') as string
              }
            ],
            autocomplete: 'new-password'
          } as IRepeatControl
        ]
      } as IFormSection
    ];
  }

  async submitValues(values: UpdatePasswordRequest): Promise<void> {
    if (!this.formComponent.form.dirty) {
      return;
    }

    const newPasswordRepeatControlName = 'newPassword_repeat';
    delete values[newPasswordRepeatControlName];

    this.isSubmitting = true;
    await this.userService
      .updatePassword(Object.assign(new UpdatePasswordRequest(), values))
      .then(async (response: IUserEmailAddress) => {
        // Do login
        const loginRequest = new PasswordLoginRequest(response.emailAddress ?? '', values.newPassword);
        await this.reCaptchaService
          .verify(
            ReCaptchaAction.createPasswordLoginToken,
            loginRequest,
            this.tokenService.createPasswordLoginToken.bind(this.tokenService)
          )
          .finally(() => {
            this.pushUserSuccessEvent();

            void this.route.navigate([this.content.successPage?._url]);
          });
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }
}
