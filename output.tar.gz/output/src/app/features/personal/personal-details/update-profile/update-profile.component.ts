import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AsyncValidatorFn } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { map, merge } from 'rxjs';
import { FormFieldName, FormType, FormValidatorTypeKeys, Gender, verifyControlSuffix } from 'src/app/core/constants/form.constants';
import { AuthorizationLevel } from 'src/app/core/constants/user.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { VerificationHelper } from 'src/app/core/helpers/verification.helper';
import { ContentBlockRegion, IUpdateProfileContentBlock } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormSection, IRepeatControl, ISelectControl, ITextControl } from 'src/app/core/models/form.model';
import { IUserProfileFormValues, UserProfile } from 'src/app/core/models/user.model';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { IFormContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { VerificationCodeMessageType } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { UpdateUserProfile } from '../../../../core/models/user.model';

@Component({
  selector: 'air-update-profile',
  templateUrl: './update-profile.component.html',
  providers: [DatePipe],
  standalone: false
})
export class UpdateProfileComponent extends BaseFormComponent<IUserProfileFormValues> implements OnInit, IFormContentBlockComponent {
  currentUserProfile: UserProfile;
  className = 'update-profile';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IUpdateProfileContentBlock;
  loading: boolean;

  formValues: IUserProfileFormValues;
  verificationCompleted?: boolean;

  get isDisabled(): boolean {
    return super.formDisabled || !this.formComponent?.form || this.formComponent?.form.pristine ? true : false;
  }

  get enableVerificationCodes(): boolean {
    return !this.verificationCompleted;
  }

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    protected reCaptchaService: ReCaptchaService,
    private translateService: TranslateService,
    private userService: UserService,
    private refreshTokenService: RefreshTokenService,
    private datePipe: DatePipe,
    private userHelper: UserHelper,
    private verificationHelper: VerificationHelper,
    private modalLoginHelper: ModalLoginHelper,
    private route: ActivatedRoute
  ) {
    super(userEventService, platformHelper, toastService, reCaptchaService);
  }

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe((params) => {
      this.verificationCompleted = params.verified === 'true';
    });

    this.createProfileForm();
    this.loading = true;
    try {
      this.currentUserProfile = await this.userService.getUserProfile();
      void this.userHelper.updateCurrentUser(this.currentUserProfile);
    } catch {
    } finally {
      this.loading = false;
    }
    this.updateProfileFormValues();
  }

  createProfileForm(): void {
    this.form = [
      {
        title: this.translateService.instant('account.label.your_email'),
        hidden: this.verificationCompleted,
        controls: [
          {
            type: FormType.email,
            label: this.translateService.instant('account.label.email'),
            name: FormFieldName.emailAddress,
            autocomplete: 'email',
            description:
              this.enableVerificationCodes && this.content?.emailVerificationNotice?.length ? this.content.emailVerificationNotice : null,
            value: '',
            verify: this.enableVerificationCodes,
            verifyLabel: this.translateService.instant('account.label.verify_email'),
            runValidatorsSequentially: true,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.email.required')
              },
              {
                validator: FormValidatorType.email,
                errorMessage: this.translateService.instant('account.error.email.invalid')
              }
            ],
            asyncValidators: [
              {
                validator: this.checkUserExistenceValidator(this.userHelper.emailAddress)
              }
            ]
          } as IRepeatControl
        ]
      } as IFormSection,
      {
        title: this.translateService.instant('account.label.your_information'),
        isGrid: true,
        controls: [
          {
            type: FormType.select,
            label: this.translateService.instant('account.label.title'),
            name: FormFieldName.gender,
            placeholder: this.translateService.instant('account.label.choose_title'),
            value: undefined,
            containerClass: 'col-6 col-3--sm col-4--sm',
            options: [
              { text: this.translateService.instant('account.label.title_male'), value: Gender.male },
              { text: this.translateService.instant('account.label.title_female'), value: Gender.female },
              { text: this.translateService.instant('account.label.title_neutral'), value: Gender.neutral }
            ]
          } as ISelectControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.first_name'),
            name: FormFieldName.firstName,
            autocomplete: 'given-name',
            value: '',
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.first_name.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.humanName.getRegExp()),
                errorMessage: this.translateService.instant('account.error.first_name.invalid')
              }
            ]
          } as ITextControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.last_name'),
            name: FormFieldName.lastName,
            autocomplete: 'family-name',
            value: '',
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.last_name.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.humanName.getRegExp()),
                errorMessage: this.translateService.instant('account.error.last_name.invalid')
              }
            ]
          } as ITextControl,
          {
            type: FormType.date,
            label: this.translateService.instant('account.label.birth_date'),
            name: FormFieldName.birthDate,
            autocomplete: 'bday',
            value: '',
            placeholder: this.translateService.instant('account.label.birth_date_placeholder'),
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.birth_date.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.date.getRegExp()),
                errorMessage: this.translateService.instant('account.error.birth_date.invalid')
              },
              {
                validator: FormValidatorType.birthDateWithMinimumAge, // Checks birth year
                errorMessage: this.translateService.instant('account.error.birth_date.invalid')
              }
            ]
          } as ITextControl,
          {
            type: FormType.phoneNumber,
            hidden: this.verificationCompleted,
            label: this.translateService.instant('account.label.phone_number'),
            name: FormFieldName.phoneNumber,
            autocomplete: 'tel',
            value: '',
            description:
              this.enableVerificationCodes && this.content?.phoneVerificationNotice?.length ? this.content.phoneVerificationNotice : null,
            verify: this.enableVerificationCodes,
            verifyLabel: this.translateService.instant('account.label.verify_phone'),
            runValidatorsSequentially: true,
            validators: [
              {
                validator: FormValidatorType.pattern(FormRegex.phoneNumber.getRegExp()),
                errorMessage: this.translateService.instant('account.error.phone_number.invalid')
              }
            ],
            asyncValidators: [
              {
                validator: this.checkPhoneNumberExistenceValidator()
              }
            ]
          } as ITextControl
        ]
      } as IFormSection,
      {
        title: this.translateService.instant('account.label.your_address'),
        isGrid: true,
        controls: [
          {
            type: FormType.postalCode,
            label: this.translateService.instant('account.label.postal_code'),
            name: FormFieldName.postalCode,
            autocomplete: 'postal-code',
            asyncValidators: [
              {
                validator: FormValidatorType.wrapValidators([
                  FormValidatorType.required,
                  FormValidatorType.pattern(FormRegex.postalCode.getRegExp()),
                  FormValidatorType.addressSuggestion(
                    this.reCaptchaService.verify.bind(this.reCaptchaService),
                    this.userService.getAddressSuggestion.bind(this.userService),
                    false
                  )
                ]),
                errorMessages: {
                  [FormValidatorTypeKeys.required]: this.translateService.instant('account.error.postal_code.required'),
                  [FormValidatorTypeKeys.pattern]: this.translateService.instant('account.error.postal_code.invalid'),
                  [FormValidatorTypeKeys.getAddressSuggestion]: this.content.addressInvalidNotice
                }
              }
            ],
            containerClass: 'col-4 col-2--md col-4--sm'
          } as ITextControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.house_number'),
            name: FormFieldName.houseNumber,
            autocomplete: 'empty',
            asyncValidators: [
              {
                validator: FormValidatorType.wrapValidators([
                  FormValidatorType.required,
                  FormValidatorType.pattern(FormRegex.houseNumber.getRegExp()),
                  FormValidatorType.addressSuggestion(
                    this.reCaptchaService.verify.bind(this.reCaptchaService),
                    this.userService.getAddressSuggestion.bind(this.userService),
                    false
                  )
                ]),
                errorMessages: {
                  [FormValidatorTypeKeys.required]: this.translateService.instant('account.error.house_number.required'),
                  [FormValidatorTypeKeys.pattern]: this.translateService.instant('account.error.house_number.invalid')
                }
              }
            ],
            containerClass: 'col-4 col-2--md col-2--sm'
          } as ITextControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.house_number_supplement'),
            name: FormFieldName.houseNumberSupplement,
            autocomplete: 'empty',
            disabled: true,
            value: '',
            validators: [
              {
                validator: FormValidatorType.pattern(FormRegex.houseNumberSupplement.getRegExp()),
                errorMessage: this.translateService.instant('account.error.house_number_supplement.invalid')
              }
            ],
            containerClass: 'col-4 col-2--md col-2--sm'
          } as ITextControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.street_name'),
            name: FormFieldName.streetName,
            autocomplete: 'address-line1',
            disabled: true,
            value: '',
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.street_name.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
                errorMessage: this.translateService.instant('account.error.street_name.invalid')
              }
            ]
          } as ITextControl,
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.city'),
            name: FormFieldName.city,
            autocomplete: 'address-level2',
            disabled: true,
            value: '',
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.city.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
                errorMessage: this.translateService.instant('account.error.city.invalid')
              }
            ]
          } as ITextControl,
          {
            type: FormType.date,
            label: this.translateService.instant('account.label.address_change_date'),
            name: FormFieldName.addressChangeDate,
            value: '',
            placeholder: this.translateService.instant('account.label.birth_date_placeholder'),
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.address_change_date.required')
              },
              {
                validator: FormValidatorType.pattern(FormRegex.date.getRegExp()),
                errorMessage: this.translateService.instant('account.error.address_change_date.invalid')
              }
            ]
          } as ITextControl
        ]
      } as IFormSection
    ] as IFormSection[];

    this.createVerificationControls();
    this.createAddressControls();
  }

  async submitValues(values: IUserProfileFormValues): Promise<void> {
    this.formValues = values;
    if (this.verificationCompleted) {
      this.formValues.emailAddress = this.currentUserProfile.emailAddress;
      this.formValues.phoneNumber = this.currentUserProfile.phoneNumber;
    }

    this.isSubmitting = true;

    if (!this.userHelper.requiresPasswordLogin && this.userHelper.currentAuthorizationLevel !== AuthorizationLevel.twoFactor) {
      return await this.modalLoginHelper.triggerTwoFactorModal(
        this.userEventSource,
        () => (this.isSubmitting = false),
        () => this.continueSubmit()
      );
    }

    await this.continueSubmit();
  }

  private async continueSubmit(): Promise<void> {
    // check if additional verification is needed
    const verifyEmailControlName = FormFieldName.emailAddress + verifyControlSuffix;
    const verifyPhoneControlName = FormFieldName.phoneNumber + verifyControlSuffix;

    const verifyEmailAddress =
      !!this.formValues.emailAddress?.length &&
      !this.formValues[verifyEmailControlName] &&
      this.formValues.emailAddress !== this.verificationHelper.verifiedEmailAddress;
    const verifyPhoneNumber =
      !!this.formValues.phoneNumber?.length &&
      !this.formValues[verifyPhoneControlName] &&
      this.formValues.phoneNumber !== this.verificationHelper.verifiedPhoneNumber;

    // submit form and finish the process immediately
    if (!this.enableVerificationCodes || (!verifyEmailAddress && !verifyPhoneNumber)) {
      await this.updateUserProfile();
      return;
    }

    // show email address verification modal before submit form
    if (verifyEmailAddress) {
      await this.triggerVerificationModal(VerificationCodeMessageType.email, verifyPhoneNumber);
    }
    // show phone number verification modal before submit form
    else if (verifyPhoneNumber) {
      await this.triggerVerificationModal(VerificationCodeMessageType.sms);
    }
    this.isSubmitting = false;
  }

  private async triggerVerificationModal(
    verificationCodeMessageType: VerificationCodeMessageType,
    keepOpenAfterVerify = false
  ): Promise<void> {
    return await this.verificationHelper.triggerVerificationModal({
      verifyType: verificationCodeMessageType,
      emailAddress: this.formValues.emailAddress,
      phoneNumber: this.formValues.phoneNumber,
      keepOpenAfterVerify,
      verifyCallback: this.updateUserProfile.bind(this) as () => Promise<void>,
      closeCallback: () => (this.isSubmitting = false)
    });
  }

  private async updateUserProfile(): Promise<void> {
    const request = new UpdateUserProfile(this.formValues);

    await this.userService
      .updateUserProfile(request)
      .then(async () => {
        // Note: await refresh() to update UserHelper.emailAddress to prevent issues in check-user-existence (excludeCurrent)
        const userPromise = this.refreshTokenService.refresh(this.userEventSource);
        const profilePromise = this.userService.getUserProfile().then((profile) => (this.currentUserProfile = profile));
        await Promise.all([userPromise, profilePromise]);

        this.updateProfileFormValues();
        this.formComponent.form.markAsPristine();

        if (this.verificationCompleted) {
          this.userHelper.profileCompleted$.next();
        } else {
          this.pushUserSuccessEvent();
          void this.showToast(ToastType.success, this.content.successText);
        }
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  private updateProfileFormValues(): void {
    if (!this.formComponent?.form || !this.currentUserProfile) {
      return;
    }

    this.updateExistenceValidators();

    this.formComponent.form.patchValue({
      [FormFieldName.emailAddress]: this.currentUserProfile.emailAddress,
      [FormFieldName.gender]: this.currentUserProfile.gender,
      [FormFieldName.firstName]: this.currentUserProfile.firstName,
      [FormFieldName.lastName]: this.currentUserProfile.lastName,
      [FormFieldName.birthDate]: this.datePipe.transform(this.currentUserProfile.birthDate, 'dd-MM-yyyy'),
      [FormFieldName.phoneNumber]: this.currentUserProfile.phoneNumber,
      [FormFieldName.postalCode]: this.currentUserProfile.postalCode,
      [FormFieldName.houseNumber]: this.currentUserProfile.houseNumber,
      [FormFieldName.houseNumberSupplement]: this.currentUserProfile.houseNumberSupplement,
      [FormFieldName.streetName]: this.currentUserProfile.streetName,
      [FormFieldName.city]: this.currentUserProfile.city,
      [FormFieldName.addressChangeDate]: this.datePipe.transform(this.currentUserProfile.addressChangeDate, 'dd-MM-yyyy')
    });

    this.updateVerificationControls();
    this.updateAddressControls();
  }

  private createVerificationControls(): void {
    this.verificationHelper.initialize({ content: this.content, userEventSource: this.userEventSource });
    this.verificationHelper.emailAddressVerificationCode$.subscribe((verificationCode) => {
      if (this.formValues) {
        this.formValues.emailAddressVerificationCode = verificationCode;
      }
    });
    this.verificationHelper.phoneNumberVerificationCode$.subscribe((verificationCode) => {
      if (this.formValues) {
        this.formValues.phoneNumberVerificationCode = verificationCode;
      }
    });
  }

  private updateVerificationControls(): void {
    if (this.enableVerificationCodes) {
      // Update verify form values
      const verifyEmailControlName = FormFieldName.emailAddress + verifyControlSuffix;
      const verifyPhoneControlName = FormFieldName.phoneNumber + verifyControlSuffix;
      this.formComponent.form.patchValue({
        [verifyEmailControlName]: true,
        [verifyPhoneControlName]: this.currentUserProfile.isPhoneNumberVerified
      });

      // Update verification values
      this.verificationHelper.patchValues(
        this.currentUserProfile.emailAddress,
        this.currentUserProfile.phoneNumber,
        this.currentUserProfile.isPhoneNumberVerified
      );
    }
  }

  private createAddressControls(): void {
    setTimeout(() => {
      const postalCode$ = this.formComponent.form.controls[FormFieldName.postalCode].valueChanges.pipe(
        map((x) => (x ?? '') === (this.currentUserProfile?.postalCode ?? ''))
      );
      const houseNumber$ = this.formComponent.form.controls[FormFieldName.houseNumber].valueChanges.pipe(
        map((x) => (x ?? '') === (this.currentUserProfile?.houseNumber ?? ''))
      );
      const houseNumberSupplement$ = this.formComponent.form.controls[FormFieldName.houseNumberSupplement].valueChanges.pipe(
        map((x) => (x ?? '') === (this.currentUserProfile?.houseNumberSupplement ?? ''))
      );

      merge(postalCode$, houseNumber$, houseNumberSupplement$).subscribe((equals) => {
        if (!this.currentUserProfile?.postalCode || !this.currentUserProfile?.houseNumber) {
          return;
        }

        const addressChangeControl = this.form.flatMap((x) => x.controls).find((y) => y.name === FormFieldName.addressChangeDate);
        if (!equals) {
          if (addressChangeControl) {
            addressChangeControl.hidden = false;
          }

          return;
        }

        const postalCode = this.formComponent.form.controls[FormFieldName.postalCode].value;
        const houseNumber = this.formComponent.form.controls[FormFieldName.houseNumber].value;
        const houseNumberSupplement = this.formComponent.form.controls[FormFieldName.houseNumberSupplement].value;

        if (
          postalCode === this.currentUserProfile.postalCode &&
          houseNumber === this.currentUserProfile.houseNumber &&
          (houseNumberSupplement ?? '') === (this.currentUserProfile?.houseNumberSupplement ?? '')
        ) {
          if (addressChangeControl) {
            addressChangeControl.hidden = true;
          }
          this.formComponent.form.controls[FormFieldName.addressChangeDate].reset();
        }
      });
    }, 0);
  }

  private updateAddressControls(): void {
    const addressChangeControl = this.form.flatMap((x) => x.controls).find((y) => y.name === FormFieldName.addressChangeDate);
    if (this.currentUserProfile.addressChangeDate) {
      this.formComponent.form.controls[FormFieldName.postalCode].disable();
      this.formComponent.form.controls[FormFieldName.houseNumber].disable();
      this.formComponent.form.controls[FormFieldName.houseNumberSupplement].disable();
      this.formComponent.form.controls[FormFieldName.streetName].disable();
      this.formComponent.form.controls[FormFieldName.city].disable();
      this.formComponent.form.controls[FormFieldName.addressChangeDate].disable();

      if (addressChangeControl) {
        addressChangeControl.description = this.content.addressChangeNotice;
        addressChangeControl.showOnlyDescription = true;
      }
    } else {
      if (addressChangeControl) {
        addressChangeControl.hidden = true;
        addressChangeControl.description = this.content.addressChangeDateNotice;
        addressChangeControl.showOnlyDescription = false;
      }
    }
  }

  private updateExistenceValidators(): void {
    this.formComponent.form.controls[FormFieldName.emailAddress].setAsyncValidators([
      this.checkUserExistenceValidator(this.currentUserProfile.emailAddress).getValidator() as AsyncValidatorFn
    ]);
    this.formComponent.form.controls[FormFieldName.phoneNumber].setAsyncValidators([
      this.checkPhoneNumberExistenceValidator(this.currentUserProfile.phoneNumber).getValidator() as AsyncValidatorFn
    ]);
  }

  private checkUserExistenceValidator(exclude?: string) {
    return FormValidatorType.checkUserExistence(
      this.reCaptchaService.verify.bind(this.reCaptchaService),
      this.userService.checkUserExistence.bind(this.userService),
      exclude
    );
  }

  private checkPhoneNumberExistenceValidator(exclude?: string) {
    return FormValidatorType.checkPhoneNumberExistence(
      this.reCaptchaService.verify.bind(this.reCaptchaService),
      this.userService.checkPhoneNumberExistence.bind(this.userService),
      exclude
    );
  }
}
