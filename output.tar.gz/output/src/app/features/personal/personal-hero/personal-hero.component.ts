import { Component, Input, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IUserLoginData } from 'src/app/core/models/login.response';

@Component({
  selector: 'air-personal-hero',
  templateUrl: './personal-hero.component.html',
  standalone: false
})
export class PersonalHeroComponent implements OnInit {
  @Input() title: string;

  currentUser?: IUserLoginData;

  constructor(
    private userHelper: UserHelper,
    private translateService: TranslateService,
    private titleService: Title
  ) {}

  ngOnInit(): void {
    this.currentUser = this.userHelper.currentUser ? (this.userHelper.currentUser as IUserLoginData) : undefined;

    if (!this.title) {
      const title = `${this.translateService.instant('personal.label.overview') as string}`;
      this.titleService.setTitle(`${title} - ${this.translateService.instant('general.label.air_miles') as string}`);
    }
  }
}
