import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalRef } from '../modal/modal-ref';
import { PersonalHeroComponent } from './personal-hero/personal-hero.component';
import { PersonalNavigationComponent } from './personal-navigation/personal-navigation.component';

@NgModule({
  declarations: [PersonalNavigationComponent, PersonalHeroComponent],
  imports: [CommonModule, RouterModule, SharedModule],
  providers: [ModalRef],
  exports: [PersonalNavigationComponent, PersonalHeroComponent]
})
export class PersonalModule {}
