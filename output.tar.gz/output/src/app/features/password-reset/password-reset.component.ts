import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormType } from 'src/app/core/constants/form.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormSection, IRepeatControl } from 'src/app/core/models/form.model';
import { PasswordLoginRequest } from 'src/app/core/models/login.request';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { TokenService } from 'src/app/core/services/token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { BaseFormComponent } from '../form/base-form.component';
import { IPasswordResetForm, IUserEmailAddress, PasswordResetRequest, PasswordResetTokenValidationRequest } from './password-reset.model';

@Component({
  selector: 'air-password-reset',
  templateUrl: './password-reset.component.html',
  standalone: false
})
export class PasswordResetComponent extends BaseFormComponent<PasswordResetRequest> implements IContentBlockComponent, OnInit, OnDestroy {
  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected reCaptchaService: ReCaptchaService,
    private tokenService: TokenService,
    private userService: UserService,
    private translateService: TranslateService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    super(userEventService, platformHelper, undefined, reCaptchaService);
  }

  className = 'password-reset';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IPasswordResetForm;
  token?: string;
  loading: boolean;

  async ngOnInit(): Promise<void> {
    super.ngOnInit();
    this.createForm();

    this.token = this.route.snapshot.queryParamMap.get('token') ?? undefined;

    this.loading = true;
    await super.waitForReCaptcha();
    if (this.token) {
      await this.checkPasswordResetToken(this.token);
    }
    this.loading = false;
  }

  createForm(): void {
    this.form = [
      {
        controls: [
          {
            type: FormType.repeat,
            label: this.translateService.instant('user.label.new_password') as string,
            name: 'password',
            controlType: FormType.password,
            fullWidth: true,
            showValidationChecklist: true,
            enableShowPassword: true,
            description: `<p class="form__mandatory-label">${
              this.translateService.instant('general.label.mandatory_fields') as string
            }</p>`,
            validationChecklistTitle: `${this.translateService.instant('account.label.password_requirements') as string}`,
            repeatControlLabel: this.translateService.instant('user.label.repeat_new_password') as string,
            repeatErrorMessage: this.translateService.instant('account.error.password.repeat') as string,
            repeatChecklistMessage: this.translateService.instant('account.error.password.identical') as string,
            validators: [
              {
                validator: FormValidatorType.required
              },
              {
                validator: FormValidatorType.pattern(FormRegex.symbols.getRegExp()),
                errorMessage: this.translateService.instant('account.error.password.invalid_special_chars') as string,
                hideFromChecklist: true
              },
              {
                validator: FormValidatorType.minLength(10),
                errorMessage: this.translateService.instant('account.error.password.min_length') as string
              },
              {
                validator: FormValidatorType.maxLength(60),
                errorMessage: this.translateService.instant('account.error.password.max_length') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneUppercase),
                errorMessage: this.translateService.instant('account.error.password.uppercase') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneLowercase),
                errorMessage: this.translateService.instant('account.error.password.lowercase') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneDigit),
                errorMessage: this.translateService.instant('account.error.password.number') as string
              },
              {
                validator: FormValidatorType.multiPattern(FormRegex.atLeastOneSymbol),
                errorMessage: this.translateService.instant('account.error.password.symbols') as string
              }
            ],
            autocomplete: 'new-password'
          } as IRepeatControl
        ]
      } as IFormSection
    ];
  }

  private async checkPasswordResetToken(token: string): Promise<void> {
    await this.reCaptchaService
      .verify<
        void,
        PasswordResetTokenValidationRequest
      >(ReCaptchaAction.resetPasswordTokenValidation, new PasswordResetTokenValidationRequest(token), this.userService.checkPasswordResetToken.bind(this.userService))
      .catch(() => {
        return;
      });
  }

  async submitValues(values: PasswordResetRequest): Promise<void> {
    this.isSubmitting = true;
    values.token = this.token ?? '';
    await this.reCaptchaService
      .verify<IUserEmailAddress, PasswordResetRequest>(
        ReCaptchaAction.resetPassword,
        new PasswordResetRequest(values.token, values.password),
        this.userService.resetPassword.bind(this.userService)
      )
      .then(async (response: IUserEmailAddress) => {
        // Do login
        const request = new PasswordLoginRequest(response?.emailAddress ?? '', values.password);
        await this.reCaptchaService
          .verify(ReCaptchaAction.createPasswordLoginToken, request, this.tokenService.createPasswordLoginToken.bind(this.tokenService))
          .finally(() => {
            this.pushUserSuccessEvent();

            void this.router.navigate([this.content.successPage._url]);
          });
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }
}
