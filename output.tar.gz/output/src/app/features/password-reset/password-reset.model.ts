import { IFormContentBlock } from 'src/app/core/models/content.model';
import { IReCaptchaRequest } from 'src/app/core/models/reCaptcha.request';
import { IPage } from 'src/app/core/models/site.response';

export class PasswordResetTokenValidationRequest implements IReCaptchaRequest {
  constructor(token: string) {
    this.token = token;
  }

  reCaptchaToken: string;
  token: string;
}

export class PasswordResetRequest implements IReCaptchaRequest {
  constructor(token: string, password: string) {
    this.token = token;
    this.password = password;
  }

  reCaptchaToken: string;
  token: string;
  password: string;
}

export interface IUserEmailAddress {
  emailAddress: string;
}

export interface IPasswordResetForm extends IFormContentBlock {
  successPage: IPage;
}
