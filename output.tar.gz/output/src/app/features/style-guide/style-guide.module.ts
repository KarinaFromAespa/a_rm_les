import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { StyleGuideRoutingModule } from './style-guide-routing.module';
import { StyleGuideComponent } from './style-guide.component';

@NgModule({
  declarations: [StyleGuideComponent],
  imports: [CommonModule, StyleGuideRoutingModule, SharedModule],
  exports: [StyleGuideComponent]
})
export class StyleGuideModule {}
