import { AfterViewInit, Component } from '@angular/core';
import { ModalOptions } from 'src/app/features/modal/modal.model';
import { ModalService } from 'src/app/features/modal/modal.service';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';

@Component({
  selector: 'air-style-guide',
  templateUrl: './style-guide.component.html',
  standalone: false
})
export class StyleGuideComponent implements AfterViewInit {
  buttonIsLoading: boolean;

  constructor(
    private toastService: ToastService,
    private modalService: ModalService
  ) {}

  ngAfterViewInit(): void {
    this.showToast();
    this.toggleButtonLoading();
  }

  showToast(): void {
    setTimeout(() => {
      const toastOptions = new ToastOptions({
        title: 'An error toast',
        type: ToastType.error,
        message: 'Some toast message, error type. Click the button to retrigger all the toasts.',
        keepAfterRouteChange: true
      });
      toastOptions.addAction({
        text: 'Click to show again.',
        action: () => this.showToast(),
        closeAfterAction: true
      });
      this.toastService.show(toastOptions);
    }, 3000);

    setTimeout(() => {
      const toastOptions = new ToastOptions({
        title: 'Success toast!',
        type: ToastType.success,
        message: `An automatically closing success toast. The loading indicator shows when buttonIsLoading is true.
        On this page it syncs with the button loaders. No action attached.`,
        keepAfterRouteChange: true,
        autoClose: true
      });
      this.toastService.show(toastOptions);
    }, 2000);

    setTimeout(() => {
      const toastOptions = new ToastOptions({
        title: 'A default toast with some buttons',
        message: 'A toast message, action added with a loading state.',
        keepAfterRouteChange: true
      });
      toastOptions.addAction({
        text: 'A loading button',
        action: () => {},
        isLoading: true
      });
      toastOptions.addAction({
        text: 'A non-loading primary button',
        buttonClass: 'button--primary',
        isCancel: true
      });
      this.toastService.show(toastOptions);
    }, 1000);
  }

  toggleButtonLoading(): void {
    setTimeout(() => {
      setInterval(() => {
        this.buttonIsLoading = !this.buttonIsLoading;
      }, 2000);
    }, 500);
  }

  openModal(): void {
    const modalOptions = new ModalOptions({
      title: 'Modal title',
      message: 'Modal message'
    });
    modalOptions.addAction({ text: 'Annuleren', isCancel: true });
    modalOptions.addAction({
      text: 'OK',
      action: () => {
        console.log('OK button clicked');
      },
      closeAfterAction: true
    });
    this.modalService.open(modalOptions);
  }
}
