import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { RecaptchaModule } from 'ng-recaptcha-2';
import { RecaptchaFallbackComponent } from 'src/app/shared/components/recaptcha-fallback/recaptcha-fallback.component';
import { DragAndDropDirective } from 'src/app/shared/directives/drag-and-drop.directive';
import { InternalInnerHtmlDirectiveModule } from 'src/app/shared/directives/internal-inner-html.directive';
import { CheckboxControlComponent } from './controls/checkbox-control/checkbox-control.component';
import { FileControlComponent } from './controls/file-control/file-control.component';
import { NumericControlComponent } from './controls/numeric-control/numeric-control.component';
import { PasswordControlComponent } from './controls/password-control/password-control.component';
import { RadioControlComponent } from './controls/radio-control/radio-control.component';
import { RepeatControlComponent } from './controls/repeat-control/repeat-control.component';
import { SelectControlComponent } from './controls/select-control/select-control.component';
import { TextControlComponent } from './controls/text-control/text-control.component';
import { TextareaControlComponent } from './controls/textarea-control/textarea-control.component';
import { FormControlComponent } from './form-control/form-control.component';
import { FormComponent } from './form.component';

@NgModule({
  declarations: [
    FormComponent,
    FormControlComponent,
    TextControlComponent,
    PasswordControlComponent,
    RepeatControlComponent,
    RadioControlComponent,
    SelectControlComponent,
    CheckboxControlComponent,
    TextareaControlComponent,
    NumericControlComponent,
    FileControlComponent,
    DragAndDropDirective,
    RecaptchaFallbackComponent
  ],
  imports: [CommonModule, ReactiveFormsModule, TranslateModule, InternalInnerHtmlDirectiveModule, RecaptchaModule],
  exports: [FormComponent, FormControlComponent, RecaptchaFallbackComponent]
})
export class FormModule {}
