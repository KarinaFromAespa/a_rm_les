import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { FormHelper } from 'src/app/core/helpers/form.helper';
import { IFormControl, IFormState, IFormValidator } from 'src/app/core/models/form.model';
import { UserEventService } from 'src/app/core/services/user-event.service';

@Component({
  template: '',
  standalone: false
})
export class BaseFormControlComponent<T = IFormControl> implements OnInit, OnDestroy {
  @Input() control: IFormControl;
  @Input() group: UntypedFormGroup;
  @Input() formState: IFormState;
  @Input() userEventSource: string;

  constructor(protected userEventService: UserEventService) {}

  readonly formType = FormType;
  destroy$ = new Subject();
  controlValidators: IFormValidator[] = [];
  config: T;

  formControl?: AbstractControl;

  get isRequired(): boolean {
    return this.hasValidator('required');
  }

  hasValidator(key: string): boolean {
    return this.controlValidators?.findIndex((x: IFormValidator) => x.validator.getKey() === key) > -1;
  }

  getErrorMessages(formControl?: AbstractControl | null, onlyHidden = false): void {
    if (formControl) {
      const result = FormHelper.getHtmlErrorMessages(
        formControl,
        this.controlValidators.filter((x) => !onlyHidden || x.hideFromChecklist)
      );

      this.control.errorMessages = result.withoutHtml;
      this.control.htmlErrorMessages = result.withHtml;
    }
  }

  hasError(key: string): boolean {
    return !!this.formControl?.hasError(key);
  }

  ngOnInit(): void {
    this.config = this.control as unknown as T;
    if (this.control) {
      this.formControl = this.group.get(this.control.name) ?? undefined;
    }

    if (this.control?.validators) {
      this.controlValidators = this.control.validators;
    }

    if (this.control?.asyncValidators) {
      this.controlValidators = this.controlValidators.concat(this.control.asyncValidators);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  protected pushUserEvent(action: UserEventAction, label?: string, value?: string): void {
    if (this.userEventSource) {
      this.userEventService.pushEvent(this.userEventSource, action, label, value);
    }
  }
}
