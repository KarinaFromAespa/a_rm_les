import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { FormFieldName, FormType, FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IUploadedFile } from 'src/app/core/models/file.model';
import { FormValidityStatus, IFormValidationError, IRepeatControl } from 'src/app/core/models/form.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { LoginModalComponent } from 'src/app/shared/modals/login-modal/login-modal.component';
import { CardStatus } from '../../content-blocks/registration-form/card-status.model';
import { ModalLoginHelper } from '../../modal/modal-login.helper';
import { BaseFormControlComponent } from './base-form-control.component';

@Component({
  selector: 'air-form-control',
  templateUrl: './form-control.component.html',
  standalone: false
})
export class FormControlComponent extends BaseFormControlComponent implements OnInit, OnDestroy {
  @Input() showMandatory: boolean;
  @Output() files = new EventEmitter<IUploadedFile[]>();
  @Output() filesBusy = new EventEmitter<boolean>();

  formValidatorTypeKeys = FormValidatorTypeKeys;
  cardStatus = CardStatus;
  repeatControl: IRepeatControl;
  formRepeatControl: AbstractControl;

  checkCardStatusError?: IFormValidationError;
  checkPhoneNumberExistenceError?: IFormValidationError;
  checkUserExistenceError?: IFormValidationError;

  get isLoggedIn(): boolean {
    return this.userHelper.isLoggedIn;
  }

  get isHidden(): boolean {
    return !!(
      this.control.hidden ||
      (this.control.showWhen &&
        this.group.get(this.control.showWhen.controlName) &&
        this.group.get(this.control.showWhen.controlName)?.value !== this.control.showWhen.value)
    );
  }

  constructor(
    protected userEventService: UserEventService,
    private userHelper: UserHelper,
    private modalLoginHelper: ModalLoginHelper
  ) {
    super(userEventService);
  }

  ngOnInit(): void {
    super.ngOnInit();

    if (this.hasValidator(FormValidatorTypeKeys.checkCardStatus)) {
      this.checkCardStatusError = {
        error: false
      } as IFormValidationError;
    }

    if (this.hasValidator(FormValidatorTypeKeys.checkPhoneNumberExistence)) {
      this.checkPhoneNumberExistenceError = {
        error: false
      } as IFormValidationError;
    }

    if (this.hasValidator(FormValidatorTypeKeys.checkUserExistence)) {
      this.checkUserExistenceError = {
        error: false
      } as IFormValidationError;
    }

    this.showMandatory = this.control && this.showMandatory && this.hasValidator(FormValidatorTypeKeys.required);

    if (this.control.type === FormType.repeat) {
      this.repeatControl = this.control as IRepeatControl;
    }

    this.formControl?.statusChanges.pipe(takeUntil(this.destroy$)).subscribe((status) => {
      this.control.errorMessages = [];
      this.control.htmlErrorMessages = [];

      if (this.checkCardStatusError) {
        const hasCardStatusCheckError = !!this.formControl?.hasError(FormValidatorTypeKeys.checkCardStatus);
        if (this.checkCardStatusError.error !== hasCardStatusCheckError) {
          this.checkCardStatusError.error = hasCardStatusCheckError;
          this.checkCardStatusError.response = hasCardStatusCheckError
            ? this.formControl?.getError(FormValidatorTypeKeys.checkCardStatus)
            : null;
        }
      }

      if (this.checkPhoneNumberExistenceError) {
        this.checkPhoneNumberExistenceError.error = !!this.formControl?.hasError(FormValidatorTypeKeys.checkPhoneNumberExistence);
      }

      if (this.checkUserExistenceError) {
        this.checkUserExistenceError.error = !!this.formControl?.hasError(FormValidatorTypeKeys.checkUserExistence);
      }

      if (this.control?.type === FormType.repeat) {
        return;
      }

      switch (status) {
        case FormValidityStatus.invalid:
          this.control.hasError = this.formControl?.dirty || this.formState.submitted;
          this.control.isValid = false;
          this.getErrorMessages(this.formControl);
          break;
        case FormValidityStatus.valid:
          this.control.hasError = false;
          this.control.isValid = this.formControl?.dirty || this.formState.submitted;
          break;
        default:
          this.control.hasError = false;
          this.control.isValid = false;
          break;
      }
    });

    if (this.control?.showWhen) {
      const showWhenControl = this.group.get(this.control.showWhen.controlName);
      if (!showWhenControl) {
        return;
      }

      if (this.controlValidators?.length > 0) {
        if (this.control.showWhen.value === showWhenControl.value) {
          setTimeout(() => {
            this.formControl?.setValidators(this.control.validators?.map((x) => x.validator.getValidator()) ?? null);
            this.formControl?.setAsyncValidators(
              this.control.asyncValidators?.map((x) => x.validator.getValidator() as AsyncValidatorFn) ?? null
            );
            this.formControl?.updateValueAndValidity();
          });
        }

        showWhenControl.valueChanges.pipe(takeUntil(this.destroy$)).subscribe((showWhenValue) => {
          if (this.control.showWhen?.value === showWhenValue) {
            this.formControl?.setValidators(this.control.validators?.map((x) => x.validator.getValidator()) ?? null);
            this.formControl?.setAsyncValidators(
              this.control.asyncValidators?.map((x) => x.validator.getValidator() as AsyncValidatorFn) ?? null
            );
          } else {
            this.formControl?.clearValidators();
          }
          this.formControl?.updateValueAndValidity();
        });
      }
    }

    if (this.control.disabled) {
      this.formControl?.disable();
    }
  }

  openLoginModal(): void {
    void this.modalLoginHelper.triggerPasswordLoginModal(this.userEventSource, this.formControl?.value);
  }

  openPrefilledPasswordResetModal(formValidatorKey: FormValidatorTypeKeys): void {
    void this.modalLoginHelper.triggerPasswordResetModal({
      preValues: {
        [formValidatorKey === FormValidatorTypeKeys.checkUserExistence ? FormFieldName.emailAddress : FormFieldName.cardNumber]:
          this.formControl?.value
      },
      userEventSource: this.userEventSource
    });
  }

  openPasswordResetModal(): void {
    void this.modalLoginHelper.triggerPasswordResetModal({
      prevModal: LoginModalComponent,
      userEventSource: this.userEventSource
    });
  }

  setFiles(files: IUploadedFile[]): void {
    this.files.emit(files);
  }

  setFilesBusy(value: boolean): void {
    this.filesBusy.emit(value);
  }
}
