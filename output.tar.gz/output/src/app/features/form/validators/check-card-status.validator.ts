import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { CardStatus, CardStatusCheckRequest, ICardStatusCheckResponse } from '../../content-blocks/registration-form/card-status.model';

export const checkCardStatusValidator =
  (
    verifyFn: (
      action: string,
      request: CardStatusCheckRequest,
      callback: (request: CardStatusCheckRequest) => Promise<ICardStatusCheckResponse>
    ) => Promise<ICardStatusCheckResponse>,
    checkCardStatusFn: (request: CardStatusCheckRequest) => Promise<ICardStatusCheckResponse>
  ) =>
  async (control: AbstractControl): Promise<ValidationErrors | null> => {
    const cardNumber = control.value as string;

    if (!cardNumber) {
      return null;
    }

    const result: ValidationErrors | null = (await verifyFn(
      ReCaptchaAction.checkCardStatus,
      {
        cardNumber,
        reCaptchaToken: ''
      } as CardStatusCheckRequest,
      checkCardStatusFn
    )
      .then((response) =>
        response.cardStatus !== CardStatus.hasNoAccount ? { [FormValidatorTypeKeys.checkCardStatus]: response.cardStatus } : null
      )
      .catch(() => null)) as ValidationErrors | null;
    return result;
  };
