import { HttpErrorResponse } from '@angular/common/http';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormFieldName, FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { IAddressSuggestion, PostalCodeCheckRequest } from '../../content-blocks/registration-form/address.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';

export const addressSuggestionValidator =
  (
    verifyFn: (
      action: string,
      request: PostalCodeCheckRequest,
      callback: (request: PostalCodeCheckRequest) => Promise<IAddressSuggestion>
    ) => Promise<IAddressSuggestion>,
    checkPostalCodeFn: (request: PostalCodeCheckRequest) => Promise<IAddressSuggestion>,
    suppressErrors: boolean
  ) =>
  async (control: AbstractControl): Promise<ValidationErrors | null> => {
    const formControls = control.parent?.controls;
    const postalCodeControl = formControls ? (formControls[FormFieldName.postalCode] as AbstractControl) : null;
    const houseNumberControl = formControls ? (formControls[FormFieldName.houseNumber] as AbstractControl) : null;
    const houseNumberSupplementControl = formControls ? (formControls[FormFieldName.houseNumberSupplement] as AbstractControl) : null;
    const streetControl = formControls ? (formControls[FormFieldName.streetName] as AbstractControl) : null;
    const cityControl = formControls ? (formControls[FormFieldName.city] as AbstractControl) : null;

    if (
      !postalCodeControl?.value ||
      !houseNumberControl?.value ||
      (!postalCodeControl.dirty && !houseNumberControl.dirty) ||
      postalCodeControl?.isInvalidWithoutSpecifiedKeys([FormValidatorTypeKeys.getAddressSuggestion]) ||
      houseNumberControl?.isInvalidWithoutSpecifiedKeys([FormValidatorTypeKeys.getAddressSuggestion]) ||
      houseNumberSupplementControl?.invalid
    ) {
      if (postalCodeControl?.errors) {
        delete postalCodeControl.errors[FormValidatorTypeKeys.getAddressSuggestion];
        postalCodeControl.setErrors(postalCodeControl.errors);
        postalCodeControl.updateValueWithSpecifiedValidators([
          FormValidatorType.required,
          FormValidatorType.pattern(FormRegex.postalCode.getRegExp())
        ]);
      }

      if (houseNumberControl?.errors) {
        delete houseNumberControl.errors[FormValidatorTypeKeys.getAddressSuggestion];
        houseNumberControl.setErrors(houseNumberControl.errors);
        houseNumberControl.updateValueWithSpecifiedValidators([
          FormValidatorType.required,
          FormValidatorType.pattern(FormRegex.houseNumber.getRegExp())
        ]);
      }

      houseNumberSupplementControl?.setValue(null);
      streetControl?.setValue(null);
      cityControl?.setValue(null);
      houseNumberSupplementControl?.disable();
      streetControl?.disable();
      cityControl?.disable();

      return null;
    }

    const request = {
      postalCode: postalCodeControl?.value ?? '',
      houseNumber: houseNumberControl?.value ?? '',
      reCaptchaToken: ''
    } as PostalCodeCheckRequest;

    const promise = verifyFn(ReCaptchaAction.getAddressSuggestion, request, checkPostalCodeFn);

    const result: ValidationErrors | null = (await promise
      .then((response) => {
        if (response?.streetName && response.city) {
          streetControl?.setValue(response.streetName);
          cityControl?.setValue(response.city);

          streetControl?.disable();
          cityControl?.disable();
        } else {
          streetControl?.enable();
          cityControl?.enable();
        }

        houseNumberSupplementControl?.enable();
        return null;
      })
      .catch((e: HttpErrorResponse) => {
        if (!suppressErrors && e.status === 404) {
          const error = { [FormValidatorTypeKeys.getAddressSuggestion]: true };

          postalCodeControl.markAsDirty();
          houseNumberControl.markAsDirty();
          postalCodeControl?.setErrors(error);
          houseNumberControl?.setErrors(error);

          houseNumberSupplementControl?.setValue(null);
          streetControl?.setValue(null);
          cityControl?.setValue(null);
          houseNumberSupplementControl?.disable();
          streetControl?.disable();
          cityControl?.disable();

          return error;
        }

        houseNumberSupplementControl?.enable();
        streetControl?.enable();
        cityControl?.enable();

        return null;
      })) as ValidationErrors | null;

    if (!result) {
      if (control !== postalCodeControl && postalCodeControl.errors?.[FormValidatorTypeKeys.getAddressSuggestion]) {
        postalCodeControl.updateValueWithSpecifiedValidators([
          FormValidatorType.required,
          FormValidatorType.pattern(FormRegex.postalCode.getRegExp())
        ]);
      }
      if (control !== houseNumberControl && houseNumberControl.errors?.[FormValidatorTypeKeys.getAddressSuggestion]) {
        houseNumberControl.updateValueWithSpecifiedValidators([
          FormValidatorType.required,
          FormValidatorType.pattern(FormRegex.houseNumber.getRegExp())
        ]);
      }
    }

    return result;
  };
