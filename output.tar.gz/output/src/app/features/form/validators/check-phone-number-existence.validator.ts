import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import {
  IUserExistenceCheckResponse,
  UserPhoneNumberExistenceCheckRequest
} from '../../content-blocks/registration-form/user-existence.model';

export const createCheckPhoneNumberExistenceValidator =
  (
    verifyFn: (
      action: string,
      request: UserPhoneNumberExistenceCheckRequest,
      callback: (request: UserPhoneNumberExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>
    ) => Promise<IUserExistenceCheckResponse>,
    createCheckPhoneNumberExistenceValidatorFn: (request: UserPhoneNumberExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>,
    exclude?: string
  ) =>
  async (control: AbstractControl): Promise<ValidationErrors | null> => {
    const value: string = control.value as string;
    if (!value) {
      return null;
    }

    const result: ValidationErrors | null = (await verifyFn(
      ReCaptchaAction.checkUserExistence,
      { phoneNumber: value, reCaptchaToken: '', exclude } as UserPhoneNumberExistenceCheckRequest,
      createCheckPhoneNumberExistenceValidatorFn
    )
      .then((userExistenceResponse) =>
        userExistenceResponse.userExists ? { [FormValidatorTypeKeys.checkPhoneNumberExistence]: true } : null
      )
      .catch(() => null)) as ValidationErrors | null;
    return result;
  };
