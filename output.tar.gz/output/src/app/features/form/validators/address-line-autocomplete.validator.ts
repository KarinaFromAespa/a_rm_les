import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormFieldName } from 'src/app/core/constants/form.constants';

export const addressLineAutoComplete =
  () =>
  async (control: AbstractControl): Promise<ValidationErrors | null> => {
    const formControls = control.parent?.controls;
    const houseNumberControl = formControls ? (formControls[FormFieldName.houseNumber] as AbstractControl) : null;
    const houseNumberSupplementControl = formControls ? (formControls[FormFieldName.houseNumberSupplement] as AbstractControl) : null;
    const streetControl = formControls ? (formControls[FormFieldName.streetName] as AbstractControl) : null;

    //Only handle when street name is not touched and house number and supplement are empty
    if (streetControl?.touched || houseNumberControl?.value || houseNumberSupplementControl?.value) {
      return null;
    }

    const addressLineValue = streetControl?.value as string;
    const houseNumber = addressLineValue.match(/(\d+)(\D*)$/);
    if (houseNumber?.[1]) {
      houseNumberControl?.setValue(houseNumber?.[1].trim());
      houseNumberControl?.markAsDirty();
      if (houseNumber?.[2]) {
        houseNumberSupplementControl?.setValue(houseNumber?.[2].trim());
        houseNumberSupplementControl?.markAsDirty();
      }
      streetControl?.setValue(addressLineValue.replace(houseNumber?.[0], '').trim());
    } else {
      streetControl?.setValue(addressLineValue.trim());
    }

    return null;
  };
