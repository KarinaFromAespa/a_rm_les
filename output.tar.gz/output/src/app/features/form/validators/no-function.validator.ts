import { ValidationErrors } from '@angular/forms';

export const createNoFunctionValidator = () => (): ValidationErrors | null => {
  return null;
};
