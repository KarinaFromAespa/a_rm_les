import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';

export const createPasswordRequirementValidator =
  () =>
  (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null;
    }

    //Perform validation in a timeout, otherwise control errors has previous state
    setTimeout(() => {
      const hasError =
        !!control.errors?.pattern_atLeastOneUppercase ||
        !!control.errors?.pattern_atLeastOneDigit ||
        !!control.errors?.pattern_passwordSymbols ||
        !!control.errors?.pattern_atLeastOneLowercase ||
        !!control.errors?.minLength ||
        !!control.errors?.maxLength;
      if (hasError) {
        control.setErrors({ [FormValidatorTypeKeys.passwordRequirements]: hasError });
      }
    });

    return null;
  };
