import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { FormRegex } from 'src/app/core/models/form-validator.model';

export const createMultiPatternValidator =
  (formRegex: FormRegex) =>
  (control: AbstractControl): ValidationErrors | null => {
    const value: string = control.value as string;
    return formRegex.test(value) ? null : { [`${FormValidatorTypeKeys.pattern}_${formRegex.getKey()}`]: true };
  };
