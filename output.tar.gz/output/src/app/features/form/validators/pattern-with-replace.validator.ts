import { AbstractControl, ValidationErrors, Validators } from '@angular/forms';

export const createPatternWithReplaceValidator =
  (pattern: RegExp, replacementPattern: RegExp, replacement: string) =>
  (control: AbstractControl): ValidationErrors | null => {
    if (control.value && control.value.match(replacementPattern)) {
      control.setValue(control.value.replace(replacementPattern, replacement), { emitEvent: false });
    }

    return Validators.pattern(pattern)(control);
  };
