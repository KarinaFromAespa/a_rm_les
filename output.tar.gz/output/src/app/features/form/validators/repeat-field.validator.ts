import { UntypedFormGroup, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys, repeatControlSuffix } from 'src/app/core/constants/form.constants';

export const createRepeatFieldValidator = (group: UntypedFormGroup, controlName: string) => (): ValidationErrors | null => {
  const repeatControl = group.get(controlName + repeatControlSuffix);
  const mainControl = group.get(controlName);
  const value = mainControl?.value;
  const repeatValue = repeatControl?.value;

  if ((mainControl?.dirty && !value) || value !== repeatValue) {
    repeatControl?.setErrors({ [FormValidatorTypeKeys.repeat]: true });
  } else {
    repeatControl?.setErrors(null);
  }
  return null;
};
