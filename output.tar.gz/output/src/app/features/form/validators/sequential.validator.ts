import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const createSequentialValidator =
  (validators: ValidatorFn[]): ValidatorFn =>
  (c: AbstractControl): ValidationErrors | null => {
    for (const validator of validators) {
      const result = validator(c);
      if (result !== null) {
        return result;
      }
    }
    return null;
  };
