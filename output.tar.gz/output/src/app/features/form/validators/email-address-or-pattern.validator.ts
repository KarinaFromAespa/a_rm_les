import { AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';

export const createEmailAddressOrPatternValidator =
  (pattern: RegExp) =>
  (control: AbstractControl): ValidationErrors | null => {
    const emailAddressValidation = Validators.email(control);
    const patternValidation = Validators.pattern(pattern)(control);

    const emailAddressIsValid = !emailAddressValidation || !Object.keys(emailAddressValidation)?.length;
    const patternIsValid = !patternValidation || !Object.keys(patternValidation)?.length;

    return !emailAddressIsValid && !patternIsValid ? { [`${FormValidatorTypeKeys.emailAddressOrPattern}`]: true } : null;
  };
