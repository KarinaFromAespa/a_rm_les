import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { IUserExistenceCheckResponse, UserExistenceCheckRequest } from '../../content-blocks/registration-form/user-existence.model';

export const createCheckUserExistenceValidator =
  (
    verifyFn: (
      action: string,
      request: UserExistenceCheckRequest,
      callback: (request: UserExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>
    ) => Promise<IUserExistenceCheckResponse>,
    createCheckUserExistenceValidatorFn: (request: UserExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>,
    exclude?: string
  ) =>
  async (control: AbstractControl): Promise<ValidationErrors | null> => {
    const value: string = control.value as string;
    if (!value) {
      return null;
    }

    const result: ValidationErrors | null = (await verifyFn(
      ReCaptchaAction.checkUserExistence,
      { emailAddress: value, reCaptchaToken: '', exclude } as UserExistenceCheckRequest,
      createCheckUserExistenceValidatorFn
    )
      .then((userExistenceResponse) => (userExistenceResponse.userExists ? { [FormValidatorTypeKeys.checkUserExistence]: true } : null))
      .catch(() => null)) as ValidationErrors | null;
    return result;
  };
