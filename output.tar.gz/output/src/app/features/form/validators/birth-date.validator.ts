import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';

export const createBirthDateValidator =
  (minimumAgeInYears: number, maximumAgeInYears: number) =>
  (control: AbstractControl): ValidationErrors | null => {
    const value: string = control.value as string;
    // Display invalid date error message
    const error = { [FormValidatorTypeKeys.pattern]: true };

    if (!value) {
      return null;
    }

    const dateParts = value.split('-');
    // Try to convert to date
    if (dateParts.length !== 3) {
      return error;
    }

    const day = +dateParts[0];
    const month = +dateParts[1] - 1;
    const date = new Date(+dateParts[2], month, day);

    if (isNaN(date.getTime()) || date.getMonth() !== month || date.getDate() !== day) {
      return error;
    }

    // Check min and max year
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    //Minimum 16 years old
    currentDate.setFullYear(currentYear - minimumAgeInYears);
    const birthYear = date.getUTCFullYear();
    // Check if too young
    if (date > currentDate) {
      return { [FormValidatorTypeKeys.birthDate]: true };
    }
    if (birthYear <= currentYear - maximumAgeInYears) {
      return error;
    }

    return null;
  };
