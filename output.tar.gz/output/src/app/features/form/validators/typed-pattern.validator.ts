import { AbstractControl, ValidationErrors } from '@angular/forms';
import { FormRegex } from 'src/app/core/models/form-validator.model';

export const createTypedPatternValidator =
  (key: string, formRegex: FormRegex) =>
  (control: AbstractControl): ValidationErrors | null => {
    const value: string = control.value as string;
    return formRegex.test(value) ? null : { [key]: true };
  };
