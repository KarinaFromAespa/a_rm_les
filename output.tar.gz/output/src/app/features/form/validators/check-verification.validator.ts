import { AbstractControl, UntypedFormGroup, ValidationErrors } from '@angular/forms';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';

export const createCheckVerificationValidator =
  (group: UntypedFormGroup, controlName: string) =>
  (verifyControl: AbstractControl): ValidationErrors | null => {
    const mainControl = group.controls[controlName];

    const value = verifyControl.value as boolean;
    return !(mainControl.value as string)?.length || (value !== true && value !== false)
      ? null
      : { [FormValidatorTypeKeys.verification]: value === false };

    // The following is applied ([rule] -> [verifyControl.errors] -> [implementation]):
    // - mainControl is empty (optional fields) -> return NULL -> hides verification
    // - verifyControl value is NULL or undefined -> return NULL -> hides verification
    // - verifyControl value is True -> return { 'verification': false } -> shows verified
    // - verifyControl value is False -> return { 'verification': true } -> shows unverified
  };
