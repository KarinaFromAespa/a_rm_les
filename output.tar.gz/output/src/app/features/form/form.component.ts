import { DOCUMENT } from '@angular/common';
import {
  AfterViewChecked,
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { AsyncValidatorFn, NgForm, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { distinctUntilChanged, filter, first } from 'rxjs/operators';
import { FormHelper } from 'src/app/core/helpers/form.helper';
import { IUploadedFile } from 'src/app/core/models/file.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { RecaptchaFallbackComponent } from 'src/app/shared/components/recaptcha-fallback/recaptcha-fallback.component';
import { FormType, FormValidatorTypeKeys, repeatControlSuffix, verifyControlSuffix } from '../../core/constants/form.constants';
import { FormValidatorType } from '../../core/models/form-validator.model';
import { FormValidityStatus, IFormControl, IFormSection, IFormState, IPasswordControl, IRepeatControl } from '../../core/models/form.model';
import { ToastOptions, ToastType } from '../toasts/toast.model';
import { ToastService } from '../toasts/toast.service';
import { createSequentialValidator } from './validators/sequential.validator';

@Component({
  selector: 'air-form',
  templateUrl: './form.component.html',
  standalone: false
})
export class FormComponent implements OnChanges, AfterViewChecked {
  @ViewChild('reCaptchaFallback')
  reCaptchaFallbackComponent?: RecaptchaFallbackComponent;
  @ViewChild('formElement')
  formElement?: ElementRef<HTMLFormElement>;

  @Input() controls: IFormSection[] = [];
  @Input() showMandatory = false;
  @Input() showValidFields = false;
  @Input() showInvalidToast = false;
  @Input() disabled = false;
  @Input() triggerValidation = false;
  @Input() alternateReCaptchaActions: ReCaptchaAction[] = [];
  @Input() userEventSource: string;

  @Output() files = new EventEmitter<IUploadedFile[]>();
  @Output() submitted = new EventEmitter();
  @Output() typingStarted = new EventEmitter<string>();
  @Output() formError = new EventEmitter<{ label?: string; value?: string }>();

  @ViewChild('formInstance') formInstance: NgForm;

  form: UntypedFormGroup;
  formState: IFormState = { submitted: false };
  sectionClasses = [];
  updateOnChangeTypes: FormType[] = [FormType.checkbox, FormType.radio, FormType.select];

  get enableAlternateReCaptcha(): boolean {
    return this.alternateReCaptchaActions.some((x) => this.reCaptchaService?.enableAlternateReCaptcha?.[x]);
  }

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private translateService: TranslateService,
    private reCaptchaService?: ReCaptchaService
  ) {}

  ngAfterViewChecked(): void {
    if (this.form && !this.formState.submitted && this.triggerValidation) {
      this.submit(true);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    // @ts-expect-error isFirstChange is always true because it is a method (found when implementing strict null)
    if (changes.controls?.currentValue && changes.controls.isFirstChange) {
      this.form = this.createGroup();
    }
  }

  reset(): void {
    this.form.reset();
    this.controls?.forEach((section) => {
      section.controls.forEach((control) => {
        if (!control.name?.length) {
          return;
        }
        const formControl = this.form.get(control.name);
        formControl?.setErrors(null);
        formControl?.reset();
        formControl?.setValue(control.value);
        control.hasError = false;
        control.isValid = false;

        if (control.type === FormType.password) {
          const passwordControl = control as IPasswordControl;
          passwordControl.passwordControl.type = FormType.password;
        } else if (control.type === FormType.repeat) {
          const repeatControl = control as IRepeatControl;
          const repeatFormControl = this.form.get(control.name + repeatControlSuffix);
          repeatFormControl?.setErrors(null);
          repeatFormControl?.reset();
          if (repeatControl.mainControl) {
            repeatControl.mainControl.hasError = false;
            repeatControl.mainControl.isValid = false;
          }
          if (repeatControl.repeatControl) {
            repeatControl.repeatControl.hasError = false;
            repeatControl.repeatControl.isValid = false;
          }
          repeatFormControl?.setValue(control.value);
          if (repeatControl.showValidationChecklist) {
            repeatControl.validators?.forEach((validator) => {
              validator.hasError = true;
            });
            repeatControl.asyncValidators?.forEach((validator) => {
              validator.hasError = true;
            });
          }
        }
      });
    });
    this.formState.submitted = false;
  }

  onKeyDown(e: KeyboardEvent): void {
    const targetElementName = (e.target as HTMLElement).tagName.toLowerCase();
    if (e.key === 'Enter' && !(targetElementName === 'button' || targetElementName === 'a')) {
      e.preventDefault();
      return;
    }
  }

  onKeyUp(e: KeyboardEvent): void {
    const targetElement = e.target as HTMLElement;
    if (e.key === 'Enter' && (targetElement.classList.contains('button-link') || targetElement.tagName.toLowerCase() === 'a')) {
      return;
    }

    if (e.key === 'Enter' && !this.disabled) {
      e.preventDefault();
      setTimeout(() => {
        const activeElement = this.document.activeElement;
        (activeElement as HTMLElement)?.blur();
        this.submit();
      });
      return;
    }

    this.form.markAsDirty();
    const targetInput = e.target as HTMLInputElement;
    const control = this.getControlByName(targetInput.id);

    if (control && !control.typingStarted) {
      control.typingStarted = true;
      this.typingStarted?.emit(control.label);
    }
  }

  setFiles(files: IUploadedFile[]): void {
    this.files.emit(files);
  }

  setFilesBusy(value: boolean): void {
    this.disabled = value;
  }

  protected getControlByName(controlName: string): IFormControl | undefined {
    return this.controls
      .map((s) => s.controls)
      .reduce((a, b) => a.concat(b), [])
      .find((c) => c.name === controlName);
  }

  private createGroup(): UntypedFormGroup {
    const group = this.fb.group({}, { updateOn: 'blur' }); // validate on blur
    const groupValidators: ValidatorFn[] = [];

    this.controls?.forEach((section) => {
      section.additionalClass = section.additionalClass ? section.additionalClass : '';
      section.additionalClass += section.isGrid ? ' grid grid--no-spacing' : '';
      section.controls.forEach((control) => {
        if (!control.name?.length) {
          return;
        }
        let controlValidators: (ValidatorFn | AsyncValidatorFn)[] = [];
        let repeatControl: IRepeatControl;
        if (control.type === FormType.repeat) {
          repeatControl = control as IRepeatControl;
        }

        if (control.validators) {
          controlValidators = control.validators
            .filter((x) => x.validator.getValidator()) // Allow for empty validators
            .map((x) => {
              if (repeatControl?.showValidationChecklist) {
                x.hasError = true;
              }
              return x.validator.getValidator();
            });
          if (control.runValidatorsSequentially) {
            controlValidators = [createSequentialValidator(controlValidators)];
          }
        }

        const formControl = this.fb.control(control.value ?? '', {
          validators: !control.showWhen ? controlValidators : null,
          asyncValidators:
            !control.showWhen && control.asyncValidators
              ? control.asyncValidators
                  .filter((x) => x.validator.getValidator()) // Allow for empty validators
                  .map((x) => {
                    if (repeatControl?.showValidationChecklist) {
                      x.hasError = true;
                    }
                    return x.validator.getValidator() as AsyncValidatorFn;
                  })
              : null,
          updateOn: control.updateOn ? control.updateOn : this.updateOnChangeTypes.indexOf(control.type) > -1 ? 'change' : 'blur'
        });
        group.addControl(control.name, formControl);

        // Add form control for "repeat" field
        let repeatFormControl: UntypedFormControl | null = null;
        if (control.type === FormType.repeat) {
          repeatFormControl = this.fb.control(control.value ?? '', { updateOn: 'blur' });
          groupValidators.push(FormValidatorType.repeat(group, control.name).getValidator());
          group.addControl(control.name + repeatControlSuffix, repeatFormControl);
        }

        // Add form control for "verify" field
        if (control.verify) {
          const verifyControl = this.fb.control(false, { updateOn: 'change' });
          const verifyControlName =
            control.type === FormType.repeat
              ? control.name + repeatControlSuffix + verifyControlSuffix
              : control.name + verifyControlSuffix;

          verifyControl.setValidators(FormValidatorType.checkVerification(group, control.name).getValidator());
          group.addControl(verifyControlName, verifyControl);

          // Reset "verified" value to false on main control changes (unless empty for optional fields)
          formControl.valueChanges.pipe(distinctUntilChanged()).subscribe((value: string) => {
            verifyControl.setValue(!value?.length);
            verifyControl.updateValueAndValidity();
          });
        }
      });
    });

    group.setValidators(groupValidators);
    group.updateValueAndValidity();
    return group;
  }

  submit(preventInvalidAction = false): void {
    if (this.form.pending) {
      // Wait until validation is finished to submit
      this.form.statusChanges
        .pipe(
          filter((x) => x !== FormValidityStatus.pending),
          first()
        )
        .subscribe(() => {
          this.checkFormValidity(preventInvalidAction);
        });
    } else {
      this.checkFormValidity(preventInvalidAction);
    }
  }

  onSubmitInvalid(): void {
    this.toastService.show({
      title: this.translateService.instant('account.error.attention') as string,
      type: ToastType.error,
      message: this.translateService.instant('account.error.not_all_fields_correctly_filled') as string,
      content: undefined,
      keepAfterRouteChange: false,
      autoClose: true
    } as ToastOptions);
  }

  checkActiveFormValidity(): boolean {
    if (this.checkControlsValidity()) {
      return true;
    }

    this.controls
      .filter((x) => !x.hidden)
      .forEach((section) => {
        section.controls.filter((x) => !x.hidden).forEach((control) => this.setFormControlErrors(control));
      });

    return false;
  }

  private checkFormValidity(preventInvalidAction): void {
    this.formState.submitted = true;
    if (this.checkControlsValidity()) {
      this.submitted.emit(this.form.getRawValue());
    } else {
      this.controls.forEach((section) => {
        section.controls.forEach((control) => this.setFormControlErrors(control));
      });

      this.reCaptchaFallbackComponent?.onSubmit();

      if (this.showInvalidToast && !preventInvalidAction) {
        this.onSubmitInvalid();
      }
    }
  }

  private setFormControlErrors(control: IFormControl): boolean {
    if (!control.name?.length) {
      return true;
    }

    const formControl = this.form.get(control.name);
    formControl?.markAsDirty();

    if (control.type === FormType.repeat) {
      const repeatControl = control as IRepeatControl;
      if (!repeatControl || !repeatControl.mainControl || !repeatControl.repeatControl) {
        return true;
      }

      repeatControl.mainControl.hasError = !!formControl?.errors;
      repeatControl.mainControl.isValid = !repeatControl.mainControl.hasError;

      const repeatFormControl = this.form.get(control.name + repeatControlSuffix);
      repeatControl.repeatControl.hasError = repeatControl.mainControl.hasError || !!repeatFormControl?.errors;
      if (repeatControl.repeatControl.hasError && !repeatFormControl?.hasError(FormValidatorTypeKeys.repeat)) {
        repeatFormControl?.setErrors({ [FormValidatorTypeKeys.repeat]: true });
      }

      repeatControl.repeatControl.isValid = !repeatControl.repeatControl.hasError;
      if (repeatControl.mainControl.hasError) {
        const result = FormHelper.getHtmlErrorMessages(
          formControl,
          (control.validators ? control.validators : [])
            .concat(control.asyncValidators ?? [])
            .filter((x) => !repeatControl.showValidationChecklist || x.hideFromChecklist)
        );
        control.errorMessages = result.withoutHtml;
        control.htmlErrorMessages = result.withHtml;

        let errorMessages = '';
        if (!repeatControl.showValidationChecklist) {
          errorMessages = (control.errorMessages ?? []).concat(control.htmlErrorMessages ?? []).join(', ');
        } else {
          const unfilteredResult = FormHelper.getHtmlErrorMessages(
            formControl,
            (control.validators ? control.validators : []).concat(control.asyncValidators ?? [])
          );
          errorMessages = (unfilteredResult.withoutHtml ?? []).concat(unfilteredResult.withHtml ?? []).join(', ');
        }

        this.formError?.emit({ label: control.label, value: errorMessages });
        return true;
      }

      return false;
    }

    control.hasError = !!formControl?.errors;
    control.isValid = !formControl?.errors;
    if (control.hasError) {
      const result = FormHelper.getHtmlErrorMessages(
        formControl,
        (control.validators ? control.validators : []).concat(control.asyncValidators ?? [])
      );

      control.errorMessages = result.withoutHtml;
      control.htmlErrorMessages = result.withHtml;

      const errorMessages = (control.errorMessages ?? []).concat(control.htmlErrorMessages ?? []).join(', ');
      this.formError?.emit({ label: control.label, value: errorMessages });
      return true;
    }

    return false;
  }

  private checkControlsValidity(): boolean {
    // Validate alternate re-captcha if available
    if (this.enableAlternateReCaptcha && !this.reCaptchaService?.alternateReCaptchaToken) {
      return false;
    }

    // Check if there is any errors while ignoring the verification controls
    return !this.controls
      .filter((s) => !s.hidden)
      .some((s) =>
        s.controls
          .filter((c) => !c.hidden)
          .some((c) => {
            const formControl = this.form.get(c.name);
            const formRepeatControl = this.form.get(c.name + repeatControlSuffix);

            return formControl?.errors || formRepeatControl?.errors;
          })
      );
  }
}
