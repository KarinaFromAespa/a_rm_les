import { AfterViewInit, Component, OnDestroy, OnInit, Optional, ViewChild } from '@angular/core';
import { Keyboard } from '@capacitor/keyboard';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { IText } from 'src/app/core/models/content.model';
import { IFormSection } from 'src/app/core/models/form.model';
import { FormInput } from 'src/app/core/models/user-event.model';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ToastOptions, ToastType } from '../toasts/toast.model';
import { ToastService } from '../toasts/toast.service';
import { FormComponent } from './form.component';

@Component({
  template: '',
  standalone: false
})
export abstract class BaseFormComponent<T = any> implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(FormComponent) formComponent: FormComponent;
  form: IFormSection[] = [];
  isSubmitting = false;
  userEventSource: string;

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    @Optional() protected toastService?: ToastService,
    @Optional() protected reCaptchaService?: ReCaptchaService
  ) {}
  reCaptchaIsReady;

  destroy$ = new Subject();

  get formDisabled(): boolean {
    return this.reCaptchaIsReady === false || !!this.formComponent?.disabled;
  }

  protected async waitForReCaptcha(): Promise<void> {
    if (this.reCaptchaIsReady) {
      return;
    }

    return new Promise<void>((resolve) => {
      this.reCaptchaService?.ready$.pipe(takeUntil(this.destroy$)).subscribe((isReady) => {
        if (isReady) {
          resolve();
        }
      });
    });
  }

  ngOnInit(): void {
    if (this.platformHelper.isiOSNative) {
      void Keyboard.setAccessoryBarVisible({ isVisible: true });
    }

    void this.reCaptchaService?.showBadge();
    this.reCaptchaService?.ready$.subscribe((value) => (this.reCaptchaIsReady = value));
  }

  ngAfterViewInit(): void {
    this.formComponent?.formError.pipe(takeUntil(this.destroy$)).subscribe(({ label, value }) => {
      this.pushUserEvent(UserEventAction.error, label, value);
    });

    this.formComponent?.typingStarted.pipe(takeUntil(this.destroy$)).subscribe((label) => {
      this.pushUserEvent(UserEventAction.typing, label);
    });
  }

  ngOnDestroy(): void {
    this.reCaptchaService?.hideBadge();
    this.destroy$.next(void 0);
  }

  submit(event: Event, pushUserEvent = true): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.submit, event.text(), undefined, this.getCheckboxAnRadioValues());
    }

    this.formComponent.submit();
  }

  abstract submitValues(values: T): Promise<void>;

  showToast(type: ToastType, content?: IText, title?: string, message?: string): void {
    const toastOptions = new ToastOptions({
      title,
      type,
      message,
      content,
      keepAfterRouteChange: true,
      autoClose: true
    });
    this.toastService?.show(toastOptions);
  }

  protected pushUserSuccessEvent(): void {
    this.pushUserEvent(UserEventAction.success, undefined, undefined, this.getCheckboxAnRadioValues());
  }

  protected pushUserEvent(action: UserEventAction, label?: string, value?: string, object?: unknown): void {
    this.userEventService.pushEvent(this.userEventSource, action, label, value, object);
  }

  private getCheckboxAnRadioValues(): FormInput[] {
    return this.formComponent?.controls
      .flatMap((c) => c.controls)
      .filter((c) => c.type === FormType.checkbox || c.type === FormType.radio)
      .map((c) => new FormInput(c, this.formComponent.form.get(c.name)?.value));
  }
}
