import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { FormType } from 'src/app/core/constants/form.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { IPasswordControl } from 'src/app/core/models/form.model';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-password-control',
  templateUrl: './password-control.component.html',
  standalone: false
})
export class PasswordControlComponent extends BaseFormControlComponent<IPasswordControl> implements OnInit, OnDestroy {
  @Output() changeTrigger = new EventEmitter<string>();

  ngOnInit(): void {
    super.ngOnInit();
    this.config.passwordControl = ObjectHelper.deepCopy(this.control) as IPasswordControl;
  }

  onChange(event: Event): void {
    let value = (event.target as HTMLInputElement).value;
    // This is an iOS check for — (emdash), as iOS safari automatically converts double dash to emdash.
    // As it's currently not possible to prevent this in HTML/JS, we check for emdash and convert it back to double dash.
    if (value.includes('—')) {
      value = value.replace('—', '--');
      this.formControl?.setValue(value);
    }
    this.changeTrigger.emit((event.target as HTMLInputElement).value);
  }

  toggleShowPassword(): void {
    if (!this.config.enableShowPassword) {
      return;
    }

    this.config.passwordControl.type = this.config.passwordControl.type === FormType.password ? FormType.text : FormType.password;
  }
}
