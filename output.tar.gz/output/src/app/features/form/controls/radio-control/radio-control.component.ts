import { Component, OnDestroy, OnInit } from '@angular/core';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { IRadioControl, RadioDisplayType } from 'src/app/core/models/form.model';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-radio-control',
  templateUrl: './radio-control.component.html',
  standalone: false
})
export class RadioControlComponent extends BaseFormControlComponent<IRadioControl> implements OnInit, OnDestroy {
  radioDisplayType = RadioDisplayType;

  ngOnInit(): void {
    super.ngOnInit();
    this.config.displayType = this.config.displayType ?? RadioDisplayType.default;

    if (this.config.displayType === RadioDisplayType.tabs) {
      this.formControl?.valueChanges.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe(() => {
        this.formState.submitted = false;
      });
    }
  }

  onChange(): void {
    this.pushUserEvent(UserEventAction.set, this.config.options.find((o) => o.value === this.formControl?.value)?.text);
  }
}
