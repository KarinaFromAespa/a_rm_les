import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { BlockBlobClient } from '@azure/storage-blob';
import { TranslateService } from '@ngx-translate/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { FileUploadRequest, IFileUpload, IUploadedFile, IUploadedFileForm } from 'src/app/core/models/file.model';
import { IFileControl } from 'src/app/core/models/form.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ContentService } from 'src/app/core/services/content.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-file-control',
  templateUrl: './file-control.component.html',
  standalone: false
})
export class FileControlComponent extends BaseFormControlComponent<IFileControl> implements OnInit {
  @Output() files = new EventEmitter<IUploadedFile[]>();
  @Output() busy = new EventEmitter<boolean>();
  @ViewChild('fileInput') fileInput: ElementRef<HTMLElement>;

  uploadedFiles: IUploadedFileForm[] = [];
  allowedFileExtensions?: string;
  maxUploadSizeMB: number;
  isMobile: boolean;

  get fileControl(): IFileControl {
    return this.control as IFileControl;
  }

  get maxUploadSizeMBMessage(): string {
    return (this.translateService.instant('file.message.maximum_size') as string).format([this.maxUploadSizeMB.toString()]);
  }
  get allowedFileExtensionsMessage(): string {
    return (this.translateService.instant('file.message.allowed_types') as string).format([this.allowedFileExtensions?.toString() ?? '']);
  }

  constructor(
    private contentService: ContentService,
    private reCaptchaService: ReCaptchaService,
    private toastService: ToastService,
    private translateService: TranslateService,
    private platformHelper: PlatformHelper,
    protected userEventService: UserEventService
  ) {
    super(userEventService);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.allowedFileExtensions = this.fileControl.allowedTypes
      ?.filter((t) => t.extension?.length)
      ?.map((t) => t.extension)
      .join(', ');
    this.maxUploadSizeMB = this.fileControl.maxUploadSizeMB || 25;

    this.isMobile = this.platformHelper.isMobile;
  }

  open(event: Event): void {
    this.pushUserEvent(UserEventAction.open, event.text());
    this.fileInput.nativeElement.click();
  }

  async change(event: Event): Promise<void> {
    const target = event?.target as HTMLInputElement;
    const files = target?.files;

    if (files) {
      await this.upload(files);
    }

    // Clear caching to prevent issues when uploading the same file twice in a row
    target.value = '';
  }

  async upload(files: FileList): Promise<void> {
    this.pushUserEvent(UserEventAction.add, 'files', files?.length.toString());

    if (!files?.length) {
      return;
    }

    let totalBytes = this.uploadedFiles.reduce((sum, file) => sum + file.size, 0);
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let i = 0; i < files.length; i++) {
      totalBytes = totalBytes + (files[i]?.size || 0);
    }
    if (totalBytes / 1000000 > this.maxUploadSizeMB) {
      void this.toastService.show(
        new ToastOptions({
          title: this.translateService.instant('general.label.error') as string,
          type: ToastType.error,
          message: this.maxUploadSizeMBMessage
        })
      );
      return;
    }

    this.busy.emit(true);

    const uploads$: Promise<void>[] = [];
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let i = 0; i < files.length; i++) {
      const upload$ = this.uploadFile(files[i]);
      uploads$.push(upload$);
    }

    await Promise.all(uploads$);
    this.files.emit(this.uploadedFiles.map((f) => ({ fileId: f.fileId, sasToken: f.sasToken }) as IUploadedFile));
    this.busy.emit(false);
  }

  remove(file: IUploadedFileForm): void {
    this.pushUserEvent(file.progress < 100 ? UserEventAction.cancel : UserEventAction.remove, 'file');
    this.uploadedFiles.splice(this.uploadedFiles.indexOf(file), 1);
    this.files.emit(this.uploadedFiles.map((f) => ({ fileId: f.fileId, sasToken: f.sasToken }) as IUploadedFile));
  }

  private async uploadFile(file: File): Promise<void> {
    const contentType = this.fileControl.allowedTypes?.find(
      (t) => t.extension === `.${file.name.split('.').pop()?.toLowerCase()}`
    )?.contentType;
    if (!contentType) {
      void this.toastService.show(
        new ToastOptions({
          title: this.translateService.instant('general.label.error') as string,
          type: ToastType.error,
          message: this.allowedFileExtensionsMessage
        })
      );
      return;
    }

    const uploadFile = { name: file.name, size: file.size, progress: 0, fileId: '', sasToken: '' };
    this.uploadedFiles.push(uploadFile);

    const response = await this.reCaptchaService.verify<IFileUpload, FileUploadRequest>(
      ReCaptchaAction.prepareFileUpload,
      new FileUploadRequest(),
      this.contentService.prepareFileUpload.bind(this.contentService)
    );
    uploadFile.fileId = response.fileId;
    uploadFile.sasToken = response.sasToken;

    const totalBytes = file.size;
    const client = new BlockBlobClient(response.url);

    await client.uploadData(file, {
      blobHTTPHeaders: { blobContentType: contentType, blobContentDisposition: `attachment; filename="${file.name}"` },
      onProgress: (progress) => {
        uploadFile.progress = (progress.loadedBytes / totalBytes) * 100;
      }
    });

    uploadFile.progress = 100;
  }
}
