import { Component, OnDestroy, OnInit } from '@angular/core';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-numeric-control',
  templateUrl: './numeric-control.component.html',
  standalone: false
})
export class NumericControlComponent extends BaseFormControlComponent implements OnInit, OnDestroy {}
