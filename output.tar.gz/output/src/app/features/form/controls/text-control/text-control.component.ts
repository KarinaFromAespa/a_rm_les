import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { FormType, repeatControlSuffix, verifyControlSuffix } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { AuthorizationLevel } from 'src/app/core/constants/user.constants';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { VerificationHelper } from 'src/app/core/helpers/verification.helper';
import { ITextControl } from 'src/app/core/models/form.model';
import { EmailAddressUpdateRequest, PhoneNumberUpdateRequest } from 'src/app/core/models/user.model';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { VerificationCodeMessageType } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-text-control',
  templateUrl: './text-control.component.html',
  standalone: false
})
export class TextControlComponent extends BaseFormControlComponent<ITextControl> implements OnInit, OnDestroy {
  formType = FormType;

  get showVerification(): boolean {
    return !!this.verifyControl?.errors && !this.formControl?.errors && !this.repeatOrMainControl?.errors;
  }
  get isVerified(): boolean {
    return this.showVerification && (!this.verifyControl?.errors?.verification || this.isPreviouslyVerified);
  }
  get isUnverified(): boolean {
    return this.showVerification && this.verifyControl?.errors?.verification && !this.isPreviouslyVerified;
  }

  private get verifyControl(): AbstractControl | null {
    return this.config.verify ? this.group.controls[this.control.name + verifyControlSuffix] : null;
  }
  private get repeatOrMainControl(): AbstractControl | null {
    if (this.control.name.endsWith(repeatControlSuffix)) {
      return this.group.controls[this.control.name.replace(repeatControlSuffix, '')];
    }

    return this.group.controls[this.control.name + repeatControlSuffix];
  }
  private get isPreviouslyVerified(): boolean {
    const isEmailPreviouslyVerified =
      this.control.type === FormType.email &&
      !!this.verificationHelper.verifiedEmailAddress &&
      this.formControl?.value === this.verificationHelper.verifiedEmailAddress;

    const isPhoneNumberPreviouslyVerified =
      this.control.type === FormType.phoneNumber &&
      !!this.verificationHelper.verifiedPhoneNumber &&
      this.formControl?.value === this.verificationHelper.verifiedPhoneNumber;

    return isEmailPreviouslyVerified || isPhoneNumberPreviouslyVerified;
  }

  constructor(
    private verificationHelper: VerificationHelper,
    private modalLoginHelper: ModalLoginHelper,
    private userHelper: UserHelper,
    private userService: UserService,
    private refreshTokenService: RefreshTokenService,
    protected userEventService: UserEventService
  ) {
    super(userEventService);
  }

  dateInputMask(event: Event): void {
    let newVal = (event.target as HTMLInputElement).value.replace(/\D/g, '');
    if (newVal.length === 0) {
      newVal = '';
    } else if (newVal.length <= 2) {
      newVal = newVal.replace(/^(\d{0,2})/, '$1');
    } else if (newVal.length <= 4) {
      newVal = newVal.replace(/^(\d{0,2})(\d{0,2})/, '$1-$2');
    } else {
      if (newVal.length > 8) {
        newVal = newVal.substring(0, 8);
      }
      newVal = newVal.replace(/^(\d{0,2})(\d{0,2})(\d{0,4})/, '$1-$2-$3');
    }

    if (this.formControl?.value !== newVal) {
      this.formControl?.setValue(newVal);
    }
  }

  postcodeInputMask(event: Event): void {
    const newVal = (event.target as HTMLInputElement).value.replace(/^([0-9]{4})([a-zA-Z]{2})$/g, '$1 $2').toUpperCase();
    if (this.formControl?.value !== newVal) {
      this.formControl?.setValue(newVal);
    }
  }

  phoneNumberInputMask(event: Event): void {
    const newVal = (event.target as HTMLInputElement).value.replace(/\D/g, '').replace(/^31/, '0');
    if (this.formControl?.value !== newVal) {
      this.formControl?.setValue(newVal);
    }
  }

  numberOnlyInputMask(event: Event): void {
    const newVal = (event.target as HTMLInputElement).value.replace(/\D/g, '');
    if (this.formControl?.value !== newVal) {
      this.formControl?.setValue(newVal);
    }
  }

  trimTrailSpace(event: Event): void {
    const newVal = (event.target as HTMLInputElement).value.replace(/[ \t]+$/g, '');
    if (this.formControl?.value !== newVal) {
      this.formControl?.setValue(newVal);
    }
  }

  onChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    // This is an iOS check for — (emdash), as iOS safari automatically converts double dash to emdash.
    // As it's currently not possible to prevent this in HTML/JS, we check for emdash and convert it back to double dash.
    if (value.includes('—')) {
      const newVal = value.replace('—', '--');
      if (this.formControl?.value !== newVal) {
        this.formControl?.setValue(newVal);
      }
    }
  }

  async verify(event: Event): Promise<void> {
    if (this.control.type !== FormType.email && this.control.type !== FormType.phoneNumber) {
      return;
    }

    this.pushUserEvent(UserEventAction.open, event.text());

    if (!this.userHelper.requiresPasswordLogin && this.userHelper.currentAuthorizationLevel !== AuthorizationLevel.twoFactor) {
      return await this.modalLoginHelper.triggerTwoFactorModal(this.userEventSource, undefined, () => this.continueVerify());
    }

    await this.continueVerify();
  }

  private async continueVerify(): Promise<void> {
    await this.verificationHelper.triggerVerificationModal({
      verifyType: this.control.type === FormType.email ? VerificationCodeMessageType.email : VerificationCodeMessageType.sms,
      emailAddress: this.control.type === FormType.email ? this.formControl?.value : undefined,
      phoneNumber: this.control.type === FormType.phoneNumber ? this.formControl?.value : undefined,
      verifyCallback: this.verifyCallback.bind(this) as (verificationCode: string) => Promise<void>
    });
  }

  private verifyCallback(verificationCode: string): Promise<void> {
    if (this.control.type === FormType.email) {
      const request = {
        emailAddress: this.formControl?.value,
        emailAddressVerificationCode: verificationCode
      } as EmailAddressUpdateRequest;
      return this.userService.updateEmailAddress(request).then(async () => await this.handleVerifyCallback());
    }

    if (this.control.type === FormType.phoneNumber) {
      const request = {
        phoneNumber: this.formControl?.value,
        phoneNumberVerificationCode: verificationCode
      } as PhoneNumberUpdateRequest;
      return this.userService.updatePhoneNumber(request).then(async () => await this.handleVerifyCallback());
    }

    return Promise.resolve();
  }

  private async handleVerifyCallback(): Promise<void> {
    this.verifyControl?.setValue(true);
    this.verifyControl?.updateValueAndValidity();

    this.formControl?.markAsPristine();
    this.repeatOrMainControl?.markAsPristine();

    if (this.control.type === FormType.email) {
      await this.refreshTokenService.refresh(this.userEventSource);
    }
  }
}
