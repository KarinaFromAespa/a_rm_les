import { Component, OnDestroy, OnInit } from '@angular/core';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-textarea-control',
  templateUrl: './textarea-control.component.html',
  standalone: false
})
export class TextareaControlComponent extends BaseFormControlComponent implements OnInit, OnDestroy {}
