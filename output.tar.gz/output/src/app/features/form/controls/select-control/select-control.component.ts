import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { ISelectControl } from 'src/app/core/models/form.model';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-select-control',
  templateUrl: './select-control.component.html',
  standalone: false
})
export class SelectControlComponent extends BaseFormControlComponent<ISelectControl> implements OnInit, OnDestroy {
  placeholderOnEmpty: boolean;

  ngOnInit(): void {
    super.ngOnInit();
    this.placeholderOnEmpty = this.hasValidator(FormValidatorTypeKeys.required) && this.control.value === 'undefined' ? true : false;
  }
}
