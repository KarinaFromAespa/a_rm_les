import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidatorFn } from '@angular/forms';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { FormType, FormValidatorTypeKeys, repeatControlSuffix } from 'src/app/core/constants/form.constants';
import { FormValidityStatus, IRepeatControl, ITextControl } from 'src/app/core/models/form.model';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-repeat-control',
  templateUrl: './repeat-control.component.html',
  standalone: false
})
export class RepeatControlComponent extends BaseFormControlComponent<IRepeatControl> implements OnInit, OnDestroy {
  @Input() showMandatory: boolean;

  repeatControlName: string;

  formValidatorTypeKeys = FormValidatorTypeKeys;

  isPasswordControl: boolean;

  currentValueControl?: AbstractControl;
  formRepeatControl?: AbstractControl;

  // For checklist
  repeatCheckHasError: boolean;

  ngOnInit(): void {
    super.ngOnInit();
    this.isPasswordControl = this.config.controlType === FormType.password;
    this.repeatControlName = this.config.name + repeatControlSuffix;

    // Create separate control objects
    this.config.mainControl = {
      type: this.config.controlType,
      name: this.config.name,
      value: this.control.value,
      enableShowPassword: this.config.enableShowPassword,
      emitChange: this.config.showValidationChecklist,
      autocomplete: this.config.autocomplete ? this.config.autocomplete : null,
      verify: this.config.verify,
      verifyLabel: this.config.verifyLabel
    } as ITextControl;
    this.config.repeatControl = {
      type: this.config.controlType,
      name: this.repeatControlName,
      value: this.control.value,
      enableShowPassword: this.config.enableShowPassword,
      emitChange: this.config.showValidationChecklist,
      autocomplete: this.config.autocomplete ? this.config.autocomplete : null,
      verifyLabel: this.config.verifyLabel
    } as ITextControl;

    // Manage validation separately
    this.formControl?.statusChanges.pipe(takeUntil(this.destroy$)).subscribe((status) => {
      this.control.errorMessages = [];

      if (this.config.mainControl) {
        switch (status) {
          case FormValidityStatus.invalid:
            this.config.mainControl.hasError = this.formControl?.dirty || this.formState.submitted;
            this.config.mainControl.isValid = false;
            this.getErrorMessages(this.formControl, this.config.showValidationChecklist);
            break;
          case FormValidityStatus.valid:
            this.config.mainControl.hasError = false;
            this.config.mainControl.isValid = this.formControl?.dirty || this.formState.submitted;
            break;
          default:
            this.config.mainControl.hasError = false;
            this.config.mainControl.isValid = false;
            break;
        }
      }
    });

    this.formRepeatControl = this.group.get(this.repeatControlName) ?? undefined;
    this.formRepeatControl?.statusChanges.pipe(takeUntil(this.destroy$)).subscribe((status) => {
      if (!this.config.repeatControl) {
        return;
      }
      this.config.repeatControl.hasError =
        (this.formRepeatControl?.dirty || this.formState.submitted) && status === FormValidityStatus.invalid;
      this.config.repeatControl.isValid =
        !this.config.repeatControl.hasError && (this.formRepeatControl?.dirty || this.formState.submitted);
    });

    if (this.config.showValidationChecklist) {
      // For updating checklist
      this.currentValueControl = new UntypedFormControl();

      this.formControl?.valueChanges.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((value) => {
        for (const item of this.controlValidators) {
          const key = item.validator.getKey();
          if (key === FormValidatorTypeKeys.minLength) {
            item.hasError = !value || this.formControl?.hasError(key);
          } else {
            item.hasError = this.formControl?.hasError(key);
          }
        }
      });
    }
  }

  onMainChange(value: string): void {
    if (!this.currentValueControl) {
      return;
    }
    // Manually handle validation for checklist on key up
    this.currentValueControl.setValue(value, { onlySelf: true });
    this.control.validators?.forEach((x) => {
      const validator: ValidatorFn = x.validator.getValidator();
      if (x.validator.getKey() === FormValidatorTypeKeys.passwordRequirements) {
        return;
      }
      if (x.validator.getKey() === FormValidatorTypeKeys.minLength) {
        x.hasError = !value || !!(this.currentValueControl && !(validator(this.currentValueControl) === null));
      } else {
        x.hasError = !!(this.currentValueControl && !(validator(this.currentValueControl) === null));
      }
    });
    this.repeatCheckHasError = value !== this.formRepeatControl?.value;
  }

  onRepeatChange(value: string): void {
    if (!this.currentValueControl) {
      return;
    }

    this.repeatCheckHasError = this.formControl?.value !== value;
  }
}
