import { Component, OnDestroy, OnInit } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { BaseFormControlComponent } from '../../form-control/base-form-control.component';

@Component({
  selector: 'air-checkbox-control',
  templateUrl: './checkbox-control.component.html',
  standalone: false
})
export class CheckboxControlComponent extends BaseFormControlComponent implements OnInit, OnDestroy {
  onChange(): void {
    this.pushUserEvent(UserEventAction.set, this.control.label, this.formControl?.value);
  }
}
