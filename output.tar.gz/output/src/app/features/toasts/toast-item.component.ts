import { Component, Input, OnInit } from '@angular/core';
import { Toast, ToastButton } from './toast.model';
import { ToastService } from './toast.service';

@Component({
  selector: 'air-toast-item',
  templateUrl: 'toast-item.component.html',
  standalone: false
})
export class ToastItemComponent implements OnInit {
  @Input() toast: Toast;
  title: string;

  constructor(private toastService: ToastService) {}

  ngOnInit(): void {
    this.title = this.toast.getTitle();
    if (this.toast.buttons) {
      for (const button of this.toast.buttons) {
        if (!button.action) {
          console.warn('No action is specified for the toast button. Did you mean to add "isCancel" property?');
        }
      }
    }
  }

  onButtonClick(button: ToastButton): void {
    // If the button has an action attached, call it
    if (button.action) {
      button.action();
      if (button.closeAfterAction) {
        this.toastService.clear(this.toast.id);
      }
    }

    // If the button has 'isCancel' true, close the toast
    if (button.isCancel) {
      this.toastService.clear(this.toast.id);
    }
  }
}
