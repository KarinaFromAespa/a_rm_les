import { animate, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from '../../core/animations/animation.constants';

export class AnimationStates {
  public static closed = 'closed';
  public static open = 'open';
}

export const animationSlideIn = trigger('slideIn', [
  state(
    '*',
    style({
      transform: 'translateY(0) scale(1)',
      opacity: 1
    })
  ),
  state(
    'void',
    style({
      transform: 'translateY(10px) scale(.98)',
      opacity: 0
    })
  ),
  transition('void => *', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);

export const animationSlideOut = trigger('slideOut', [
  state(
    '*',
    style({
      transform: 'translateY(0) scale(1)',
      opacity: 1
    })
  ),
  state(
    'void',
    style({
      transform: 'translateY(10px) scale(.98)',
      opacity: 0
    })
  ),
  transition('* => void', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);
