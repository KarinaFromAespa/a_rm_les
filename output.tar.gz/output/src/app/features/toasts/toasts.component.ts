import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivationStart, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { triggerChildAnimation } from '../../core/animations/trigger-child.animation';
import { verticalCollapseAnimation } from '../../core/animations/vertical-collapse.animation';
import { animationSlideIn, animationSlideOut } from './toast.animations';
import { Toast, ToastType } from './toast.model';
import { ToastService } from './toast.service';

@Component({
  selector: 'air-toasts',
  templateUrl: 'toasts.component.html',
  animations: [animationSlideIn, animationSlideOut, verticalCollapseAnimation, triggerChildAnimation],
  standalone: false
})
export class ToastsComponent implements OnInit, OnDestroy {
  toasts: Toast[] = [];
  destroy$ = new Subject();

  constructor(
    public toastService: ToastService,
    private router: Router,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    // Subscribe to new toasts
    this.toastService.onToast$.pipe(takeUntil(this.destroy$)).subscribe((toast) => {
      if (toast.type === ToastType.error) {
        this.userEventService.pushEvent(UserEventSource.toast, UserEventAction.error, toast.title, toast.message);
      }

      // Filter out existing toasts with the same id
      this.toasts = this.toasts.filter((x) => x.id !== toast.id);

      // add toasts to array, if it has a value to display
      if (toast.title || toast.message || toast.content) {
        this.toasts.push(toast);
      }

      // auto close toast if required
      if (toast.autoClose && !toast.buttons?.length) {
        setTimeout(() => {
          this.toasts = this.toasts.filter((x) => x.id !== toast.id);
          this.updateBodyClass();
        }, 5000);
      }

      // Update body class
      this.updateBodyClass();
    });

    // clear toasts on location change
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof ActivationStart) {
        // filter out toasts without 'keepAfterRouteChange' flag
        this.toasts = this.toasts.filter((x) => x.keepAfterRouteChange);
        this.updateBodyClass();
      }
    });
  }

  updateBodyClass(): void {
    if (this.toasts.length > 0) {
      document.body.classList.add('toast--open');
    } else {
      document.body.classList.remove('toast--open');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
