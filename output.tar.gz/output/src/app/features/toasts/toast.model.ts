import { IText } from 'src/app/core/models/content.model';

export enum ToastType {
  success = 'success',
  error = 'error',
  info = 'info'
}

export interface IToastOptions {
  id?: string;
  title?: string;
  message?: string;
  content?: IText;
  type?: ToastType;
  autoClose?: boolean;
  keepAfterRouteChange?: boolean;
  readonly buttons?: ToastButton[];
  addAction?: any;
}

export class ToastOptions implements IToastOptions {
  id?: string;
  title?: string;
  message?: string;
  content?: IText;
  type?: ToastType;
  autoClose?: boolean;
  keepAfterRouteChange?: boolean;
  readonly buttons: ToastButton[] = [];

  constructor(init?: Partial<IToastOptions>) {
    Object.assign(this, init);
  }

  public addAction(button: Partial<ToastButton>): void {
    this.buttons.push(new ToastButton(button));
  }
}

export class ToastButton {
  text?: string;
  buttonClass?: string;
  isCancel?: boolean;
  action?: () => void;
  closeAfterAction?: boolean;
  isLoading?: boolean;

  constructor(init?: Partial<ToastButton>) {
    Object.assign(this, init);
    if (this.isCancel && !init?.buttonClass) {
      this.buttonClass = 'button--secondary';
    }
  }
}

export class Toast {
  id: string;
  type: ToastType;
  title: string;
  message: string;
  content: IText;
  autoClose: boolean;
  keepAfterRouteChange: boolean;
  readonly buttons?: ToastButton[];

  getTitle(): string {
    return this.content?.title || this.title;
  }

  constructor(init?: Partial<Toast>) {
    this.autoClose = true;
    this.type = ToastType.info;
    Object.assign(this, init);
  }
}
