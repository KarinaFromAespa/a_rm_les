import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Toast, ToastOptions } from './toast.model';

@Injectable({ providedIn: 'root' })
export class ToastService {
  private readonly subject = new Subject<Toast>();
  readonly onToast$ = this.subject.asObservable();

  constructor() {}

  show(options: ToastOptions): void {
    const toast = new Toast({ ...options });
    toast.id = toast.id || this.generateId();
    this.subject.next(toast);
  }

  // Clear toasts (optionally for specific id)
  clear(id: string): void {
    this.subject.next(new Toast({ id }));
  }

  private generateId(): string {
    return (
      'modal_' +
      Math.random()
        .toString(36)
        .replace(/[^a-z]+/g, '')
        .substr(0, 5)
    );
  }
}
