import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ToastItemComponent } from './toast-item.component';
import { ToastsComponent } from './toasts.component';

@NgModule({
  declarations: [ToastsComponent, ToastItemComponent],
  imports: [CommonModule, SharedModule],
  exports: [ToastsComponent]
})
export class ToastModule {}
