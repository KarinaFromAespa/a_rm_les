import { IContentBlock, IText } from 'src/app/core/models/content.model';
import { IReCaptchaRequest } from 'src/app/core/models/reCaptcha.request';
import { IPage } from 'src/app/core/models/site.response';

export class PasswordSetCodeValidationRequest {
  constructor(code: string) {
    this.code = code;
  }

  code: string;
}

export class PasswordSetRequest implements IReCaptchaRequest {
  constructor(code: string, password: string) {
    this.code = code;
    this.password = password;
  }

  reCaptchaToken: string;
  code: string;
  password: string;
}

export interface IPasswordSetForm extends IContentBlock {
  title?: string;
  verificationText: IText;
  successPage: IPage;
}
