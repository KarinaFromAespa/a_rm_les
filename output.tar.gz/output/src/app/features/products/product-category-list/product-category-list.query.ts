import gql from 'graphql-tag';

export const getProductCategoriesQuery = gql`
  query getProductCategories {
    allProductCategory {
      items {
        id
        title
        name
        icon
      }
    }
  }
`;

export const getProductSubcategoriesQuery = gql`
  query getProductSubcategories {
    allProductSubcategory(where: { isHidden: false }) {
      items {
        id
        title
        name
        isHidden
      }
    }
  }
`;

export const getProductPartnersQuery = gql`
  query getPartnersAndSuppliers {
    allContent(where: { OR: [{ contentTypeAlias: "partner" }, { contentTypeAlias: "supplier" }] }) {
      items {
        ... on Partner {
          title
          url
          name
          supplierCode
          priority
        }
        ... on Supplier {
          title
          url
          name
          supplierCode
          priority
        }
      }
    }
  }
`;
