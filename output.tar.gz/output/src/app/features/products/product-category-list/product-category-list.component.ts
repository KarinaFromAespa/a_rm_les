import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { IProductCategory } from 'src/app/core/models/product.model';
import { IProductCategoryResponse } from 'src/app/core/models/product.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { getProductCategoriesQuery } from './product-category-list.query';

@Component({
  selector: 'air-product-category-list',
  templateUrl: './product-category-list.component.html',
  standalone: false
})
export class ProductCategoryListComponent implements OnInit, OnDestroy {
  @Output() categoryClick: EventEmitter<IProductCategory | null> = new EventEmitter<IProductCategory | null>();

  querySubscription: Subscription;
  productCategories: IProductCategory[];

  loading: boolean;
  destroy$ = new Subject();

  constructor(private graphQLService: GraphQLService) {}

  ngOnInit(): void {
    this.loading = true;
    this.graphQLService
      .watchQuery<IProductCategoryResponse>(getProductCategoriesQuery)
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        this.productCategories = result.data.allProductCategory.items;
        this.loading = result.loading;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onCategoryClick(category: IProductCategory | null): void {
    this.categoryClick.emit(category);
  }
}
