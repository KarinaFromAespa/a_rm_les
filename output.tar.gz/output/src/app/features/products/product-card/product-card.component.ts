import { Component, Input } from '@angular/core';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { IBaseProduct, IExternalProduct, IPhysicalProduct } from 'src/app/core/models/product.model';
import { IPageLink } from 'src/app/core/models/site.response';
import { CommerceHighlight } from 'src/app/core/models/user-event.model';

@Component({
  selector: 'air-product-card',
  templateUrl: './product-card.component.html',
  standalone: false
})
export class ProductCardComponent {
  @Input() product: IBaseProduct;
  @Input() isLarge = false;
  @Input() isDescriptionHidden = false;
  @Input() userEventSource: string;
  @Input() userEventObject?: CommerceHighlight;

  get productUrl(): string | IPageLink {
    return (
      (this.product as IExternalProduct).link?.[0] ||
      (this.product as IPhysicalProduct).externalUrl ||
      this.product._url ||
      this.product.url
    );
  }

  get isExternalLink(): boolean {
    return ProductHelper.isExternalProduct(this.product) || ProductHelper.isPhysicalProduct(this.product);
  }
}
