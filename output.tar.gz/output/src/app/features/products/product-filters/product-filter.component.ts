import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Subject, forkJoin } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SorterHelper } from 'src/app/core/helpers/sorter.helper';
import { IPartner } from 'src/app/core/models/partner.response';
import { IProductCategory, IProductPartner, IProductSubcategory } from 'src/app/core/models/product.model';
import { IProductCategoryResponse, IProductPartnerResponse, IProductSubcategoryResponse } from 'src/app/core/models/product.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { ISliderValues } from 'src/app/shared/components/common/slider/slider.model';
import { ModalRef } from '../../modal/modal-ref';
import {
  getProductCategoriesQuery,
  getProductPartnersQuery,
  getProductSubcategoriesQuery
} from '../product-category-list/product-category-list.query';
import { IProductFilter, ProductFilterName } from './product-filter.model';

@Component({
  selector: 'air-product-filter',
  templateUrl: './product-filter.component.html',
  standalone: false
})
export class ProductFilterComponent implements OnInit, OnChanges {
  @Input() initialFilters: IProductFilter;
  @Input() rangeCeiling;
  @Input() isModalComponent = false;
  @Input() subcategories: IProductSubcategory[] = [];
  @Input() filteredSubcategories: string[] = [];
  @Input() filteredPartners: string[] = [];
  @Input() initialFilteredPartners: string[] = [];
  @Output() filterChange: EventEmitter<IProductFilter> = new EventEmitter<IProductFilter>();

  filterForm: UntypedFormGroup;
  filters: IProductFilter;
  categories: IProductCategory[];
  hasSelectedCategories = false;
  subcategoriesHasVisibleItems = false;
  partnersList: IProductPartner[] = [];
  partnerListHasVisibleItems: boolean;
  productFilterName = ProductFilterName;
  partnerListExpanded = false;
  isPartnerListExpandable = false;

  loading: boolean;

  destroy$ = new Subject();

  private partnerListLimit = 3;
  private partners: IPartner[];

  constructor(
    private graphQLService: GraphQLService,
    private fb: UntypedFormBuilder,
    private modalRef: ModalRef
  ) {}

  ngOnInit(): void {
    this.loading = true;
    forkJoin([
      this.graphQLService.query<IProductCategoryResponse>(getProductCategoriesQuery),
      this.graphQLService.query<IProductSubcategoryResponse>(getProductSubcategoriesQuery),
      this.graphQLService.query<IProductPartnerResponse>(getProductPartnersQuery)
    ])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([categoriesQuery, subcategoriesQuery, partnersQuery]) => {
        this.categories = categoriesQuery.data.allProductCategory.items;
        this.subcategories = subcategoriesQuery.data.allProductSubcategory.items;
        this.partners = partnersQuery.data.allContent.items.filter((x) => x.supplierCode?.length);
        this.partners = SorterHelper.sortPartnersByNameAscending(
          this.partners.filter((partner) =>
            this.initialFilteredPartners.some((x) => x.toUpperCase() === partner.supplierCode?.toUpperCase())
          )
        );
        this.partnersList = this.partners.map(
          (x) =>
            ({
              title: x.title,
              supplierCode: x.supplierCode,
              isHidden: false,
              expandedListItem: false
            }) as IProductPartner
        );

        this.createFilterForm();
        this.handleSubcategoryFilter(this.filteredSubcategories);
        this.handlePartnerFilter(this.filteredPartners);
        this.loading = false;
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      !this.partners ||
      !changes.filteredPartners ||
      changes.filteredPartners.firstChange ||
      !changes.filteredSubcategories ||
      changes.filteredSubcategories.firstChange
    ) {
      return;
    }
    this.handleSubcategoryFilter(changes.filteredSubcategories.currentValue);
    this.handlePartnerFilter(changes.filteredPartners.currentValue);
  }

  createFilterForm(): void {
    const initialCategories: string[] = this.initialFilters?.categories?.length ? this.initialFilters.categories : [];
    this.hasSelectedCategories = initialCategories.length > 0;

    const initialSubcategories: string[] =
      this.hasSelectedCategories && this.initialFilters?.subcategories?.length ? this.initialFilters.subcategories : [];
    const initialPartners: string[] = this.initialFilters?.partners?.length ? this.initialFilters.partners : [];

    this.filterForm = this.fb.group({
      categories: this.fb.array(
        this.categories.map((category) => {
          const initialValue =
            initialCategories.length > 0 && category.name ? initialCategories.includes(category.name.toLowerCase()) : false;
          return this.fb.control(initialValue);
        })
      ),
      subcategories: this.fb.array(
        this.subcategories.map((subcategory) => {
          const initialValue =
            initialSubcategories.length > 0 && subcategory.title ? initialSubcategories.includes(subcategory.title.toLowerCase()) : false;
          return this.fb.control(initialValue);
        })
      ),
      partners: this.fb.array(
        this.partnersList.map((partner) => {
          const initialValue =
            initialPartners && partner.supplierCode ? initialPartners.includes(partner.supplierCode.toUpperCase()) : false;
          return this.fb.control(initialValue);
        })
      ),
      milesOnly: this.fb.control(!!this.initialFilters?.milesOnly),
      spotlighted: this.fb.control(!!this.initialFilters?.spotlighted),
      rangeMin: this.fb.control(this.initialFilters ? this.initialFilters.range.min : 0),
      rangeMax: this.fb.control(this.initialFilters ? this.initialFilters.range.max : null)
    });

    // Add subscription to direct changes if not loaded in a modal
    Object.keys(this.filterForm.controls).forEach((controlName: string) => {
      this.filterForm
        .get(controlName)
        ?.valueChanges.pipe(takeUntil(this.destroy$))
        .subscribe(() => {
          this.processFilters(!this.isModalComponent);
        });
    });
  }

  processFilters(saveFilters: boolean): void {
    const selectedCategories: string[] = (this.filterForm.get(ProductFilterName.categories)?.value as AbstractControl[])
      .map((checked: any, index: number) => (checked ? this.categories[index].name?.toLowerCase() : null))
      .filterEmpty();
    this.hasSelectedCategories = selectedCategories.length > 0;

    const selectedSubcategories: string[] = this.hasSelectedCategories
      ? (this.filterForm.get(ProductFilterName.subcategories)?.value as AbstractControl[])
          .map((checked: any, index: number) => (checked ? this.subcategories[index].title.toLowerCase() : null))
          .filterEmpty()
      : [];
    const selectedPartners: string[] = (this.filterForm.get(ProductFilterName.partners)?.value as AbstractControl[])
      .map((checked: any, index: number) => (checked ? this.partnersList[index].supplierCode?.toUpperCase() : null))
      .filterEmpty();

    // Update filters
    this.filters = {
      categories: selectedCategories,
      subcategories: selectedSubcategories,
      partners: selectedPartners,
      milesOnly: !!this.filterForm.get(ProductFilterName.milesOnly)?.value,
      spotlighted: !!this.filterForm.get(ProductFilterName.spotlighted)?.value,
      range: {
        min: parseInt(this.filterForm.get(ProductFilterName.rangeMin)?.value, 10),
        max: parseInt(this.filterForm.get(ProductFilterName.rangeMax)?.value, 10)
      },
      noSave: !saveFilters
    };

    this.filterChange.emit(this.filters);
  }

  onSliderUpdate(range: ISliderValues): void {
    if (range.min !== this.filterForm.get(ProductFilterName.rangeMin)?.value) {
      this.filterForm.get(ProductFilterName.rangeMin)?.setValue(range.min);
    }
    if (range.max !== this.filterForm.get(ProductFilterName.rangeMax)?.value) {
      this.filterForm.get(ProductFilterName.rangeMax)?.setValue(range.max);
    }
  }

  isPartnerHidden(partner: IProductPartner): boolean {
    return partner.isHidden || (this.isPartnerListExpandable && !this.partnerListExpanded && partner.expandedListItem);
  }

  isSubcategoryHidden(subcategory: string): boolean {
    return !this.filteredSubcategories.includes(subcategory);
  }

  toggleExpandPartnerList(): void {
    this.partnerListExpanded = !this.partnerListExpanded;
  }

  onApplyButtonClick(): void {
    this.processFilters(true);
    this.close();
  }

  close(): void {
    this.modalRef.close();
  }

  private handleSubcategoryFilter(filteredSubcategories: string[]): void {
    let subcategoriesHasVisibleItems = false;

    this.subcategories.map((s, i) => {
      const isVisible = this.hasSelectedCategories && filteredSubcategories.includes(s.title);
      if (isVisible) {
        if (!subcategoriesHasVisibleItems) {
          subcategoriesHasVisibleItems = true;
        }
      } else {
        if (this.filterForm) {
          // Deselect if not shown
          (this.filterForm.get(ProductFilterName.subcategories) as UntypedFormArray).controls[i].setValue(false, {
            onlySelf: false,
            emitEvent: false
          });
        }
      }
    });

    this.filteredSubcategories = filteredSubcategories;
    this.subcategoriesHasVisibleItems = subcategoriesHasVisibleItems;
  }

  private handlePartnerFilter(filteredPartners: string[]): void {
    let expandedListCount = 1;
    this.partnersList.map((x, i) => {
      x.isHidden = !filteredPartners?.length || !filteredPartners.some((y) => y.toUpperCase() === x.supplierCode?.toUpperCase());
      if (!x.isHidden) {
        x.expandedListItem = expandedListCount > this.partnerListLimit;
        expandedListCount++;
      } else {
        x.expandedListItem = false;
        // Deselect
        if (this.filterForm) {
          (this.filterForm.get(ProductFilterName.partners) as UntypedFormArray).controls[i].setValue(false, {
            onlySelf: false,
            emitEvent: false
          });
        }
      }
    });
    this.partnerListHasVisibleItems = expandedListCount > 1;
    this.isPartnerListExpandable = this.partnersList.some((x) => x.expandedListItem);
  }
}
