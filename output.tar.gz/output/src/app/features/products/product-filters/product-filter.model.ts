import { ISliderValues } from 'src/app/shared/components/common/slider/slider.model';

export enum ProductSortType {
  recommended = 'recommended',
  milesAscending = 'milesAscending',
  milesDescending = 'milesDescending'
}

export interface IProductFilter {
  categories: string[];
  subcategories: string[];
  partners: string[];
  range: ISliderValues;
  milesOnly: boolean;
  spotlighted: boolean;
  noSave: boolean;
}

export enum ProductFilterName {
  categories = 'categories',
  subcategories = 'subcategories',
  partners = 'partners',
  milesOnly = 'milesOnly',
  rangeMin = 'rangeMin',
  rangeMax = 'rangeMax',
  spotlighted = 'spotlighted'
}
