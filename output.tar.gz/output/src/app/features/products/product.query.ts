import gql from 'graphql-tag';
import { ProductType } from 'src/app/core/constants/product.constants';

export const imageFragment = gql`
  fragment ImageFragment on Image {
    name
    alt
    url
    umbracoFile {
      focalPoint {
        top
        left
      }
      focalPointUrlTemplate
    }
  }
`;

export const importedProductFragment = gql`
  fragment ImportedProductFields on ImportedProduct {
    productId
    price
    points
    isInStock
    supplierCode
  }
`;

export const productListFragment = gql`
  ${importedProductFragment}
  ${imageFragment}
  fragment ProductListFields on Product {
    id
    contentTypeAlias
    title
    shortDescription
    priority
    primaryImage {
      ...ImageFragment
    }
    importedProduct {
      ...ImportedProductFields
    }
    category {
      ... on ProductCategory {
        name
        title
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    url
    updateDate
    orderSuccessPage {
      _url: url
    }
    isHidden
    isSpotlighted
  }
`;

export const combinedProductListFragment = gql`
  ${importedProductFragment}
  ${imageFragment}
  fragment CombinedProductListFields on CombinedProduct {
    id
    contentTypeAlias
    title
    shortDescription
    primaryImage {
      ...ImageFragment
    }
    category {
      ... on ProductCategory {
        name
        title
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    priority
    variants {
      ... on ProductVariant {
        title
        importedProduct {
          ...ImportedProductFields
        }
        validityNotice
      }
    }
    url
    orderSuccessPage {
      _url: url
    }
    isHidden
    isSpotlighted
  }
`;

const externalLinkFragment = gql`
  fragment ProductExternalLinkFields on ExternalLink {
    ... on ExternalLink {
      contentTypeAlias
      icon
      label
      url
      bypassInAppBrowser
    }
  }
`;

const pageLinkFragment = gql`
  fragment ProductPageLinkFields on PageLink {
    contentTypeAlias
    label
    page {
      _url: url
    }
    icon
  }
`;

const triggerLinkFragment = gql`
  fragment ProductTriggerLinkFields on Trigger {
    contentTypeAlias
    icon
    label
    type
  }
`;

export const externalProductListFragment = gql`
  ${imageFragment}
  ${externalLinkFragment}
  ${pageLinkFragment}
  ${triggerLinkFragment}
  fragment ExternalProductListFields on ExternalProduct {
    id
    contentTypeAlias
    title
    shortDescription
    primaryImage {
      ...ImageFragment
    }
    priority
    category {
      ... on ProductCategory {
        name
        title
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    url
    points
    price
    discount
    supplierCode
    link {
      ...ProductExternalLinkFields
      ...ProductPageLinkFields
      ...ProductTriggerLinkFields
    }
    isHidden
    isSpotlighted
  }
`;

export const physicalProductListFragment = gql`
  fragment PhysicalProductListFields on PhysicalProduct {
    id
    contentTypeAlias
    title
    externalUrl
    primaryImageUrl
    shortDescription
    priority
    category {
      ... on ProductCategory {
        name
        title
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    variants {
      ... on PhysicalProductVariant {
        contentTypeAlias
        variantId
        title
        points
        price
      }
    }
    url
    isHidden
    isSpotlighted
  }
`;

export const charityListFieldsFragment = gql`
  fragment CharityListFields on Charity {
    id
    contentTypeAlias
    title
    shortDescription
    primaryImage {
      ...ImageFragment
    }
    logo {
      cropUrl(alias: "Partner Logo")
    }
    priority
    category {
      ... on ProductCategory {
        name
        title
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    url
    isHidden
    isSpotlighted
  }
`;

export const singleProductFragment = gql`
  ${productListFragment}
  ${imageFragment}
  fragment SingleProductFields on Product {
    ...ProductListFields
    additionalImages {
      ...ImageFragment
    }
    validityNotice
    hideDonationCampaign
  }
`;

export const singleCombinedProductFragment = gql`
  ${combinedProductListFragment}
  ${imageFragment}
  fragment SingleCombinedProductFields on CombinedProduct {
    ...CombinedProductListFields
    additionalImages {
      ...ImageFragment
    }
    variantMode
    hideDonationCampaign
  }
`;

export const singleCharityFragment = gql`
  ${imageFragment}
  fragment SingleCharityFields on Charity {
    contentTypeAlias
    id
    title
    shortDescription
    longDescription
    priority
    category {
      ... on ProductCategory {
        id
        name
        title
        url
      }
    }
    subcategory {
      ... on ProductSubcategory {
        title
      }
    }
    primaryImage {
      ...ImageFragment
    }
    url
    donationSuggestions {
      ... on DonationSuggestion {
        points
      }
    }
    orderSuccessPage {
      _url: url
    }
    cardNumber
    isHidden
  }
`;

export const getCharityProductsQuery = gql`
  ${productListFragment}
  ${charityListFieldsFragment}
  query GetCharityProducts {
    allContent(
      where: {
        OR: [
          { contentTypeAlias: "${ProductType.charity}" }
        ]
      }
    ) {
      items {
        ...ProductListFields
        ...CharityListFields
      }
    }
  }
`;

export const getProductsQuery = gql`
  ${productListFragment}
  ${combinedProductListFragment}
  ${externalProductListFragment}
  ${physicalProductListFragment}
  ${charityListFieldsFragment}
  query GetProducts {
    allContent(
      where: {
        OR: [
          { contentTypeAlias: "${ProductType.product}" },
          { contentTypeAlias: "${ProductType.combinedProduct}" },
          { contentTypeAlias: "${ProductType.externalProduct}" }
          { contentTypeAlias: "${ProductType.physicalProduct}" }
          { contentTypeAlias: "${ProductType.charity}" }
        ]
      }
    ) {
      items {
        ...ProductListFields
        ...CombinedProductListFields
        ...ExternalProductListFields
        ...PhysicalProductListFields
        ...CharityListFields
      }
    }
  }
`;

export const getSingleProductQuery = gql`
  ${singleProductFragment}
  ${singleCombinedProductFragment}
  ${singleCharityFragment}
  query GetProduct($id: ID) {
    content(id: $id) {
      ...SingleProductFields
      ...SingleCombinedProductFields
      ...SingleCharityFields
    }
  }
`;
