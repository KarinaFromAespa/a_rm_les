import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalRef } from '../modal/modal-ref';
import { ProductCardComponent } from './product-card/product-card.component';
import { ProductCategoryListComponent } from './product-category-list/product-category-list.component';
import { ProductFilterComponent } from './product-filters/product-filter.component';
import { ProductReceiptComponent } from './product-receipt/product-receipt.component';

@NgModule({
  declarations: [ProductCategoryListComponent, ProductCardComponent, ProductFilterComponent, ProductReceiptComponent],
  imports: [CommonModule, RouterModule, SharedModule, FormsModule, ReactiveFormsModule],
  providers: [ModalRef],
  exports: [ProductCategoryListComponent, ProductCardComponent, ProductFilterComponent, ProductReceiptComponent]
})
export class ProductModule {}
