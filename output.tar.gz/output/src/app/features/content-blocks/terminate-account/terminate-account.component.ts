import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { FormFieldName } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { LogoutHelper } from 'src/app/core/helpers/logout.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, ITerminateAccount } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IUserBasicLoginData } from 'src/app/core/models/login.response';
import { ICharity } from 'src/app/core/models/product.model';
import { ICharityResponse } from 'src/app/core/models/product.response';
import { ITerminateAccountFormValues } from 'src/app/core/models/terminate-account.model';
import { ITransferPointsToCharityRequest, TransferPointsFormRequest } from 'src/app/core/models/transfer-points.model';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalHelper } from '../../modal/modal.helper';
import { getCharityProductsQuery } from '../../products/product.query';
import { IContentBlockComponent } from '../content-block-component.model';

enum DonationMethod {
  charity = 'charity',
  user = 'user',
  nobody = 'nobody'
}

enum TransferMethod {
  emailAddress = FormFieldName.emailAddress,
  cardNumber = FormFieldName.cardNumber,
  charity = DonationMethod.charity,
  nobody = DonationMethod.nobody
}

@Component({
  selector: 'air-terminate-account',
  templateUrl: './terminate-account.component.html',
  standalone: false
})
export class TerminateAccountComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'terminate-account';
  contentBlockRegion = ContentBlockRegion;
  loading: boolean;
  region?: ContentBlockRegion;
  isFirst?: boolean;
  content: ITerminateAccount;
  userEventSource: string;

  donationMethod = DonationMethod;
  transferMethod = TransferMethod;

  charityProducts: ICharity[];
  donationMethodType: DonationMethod;
  transferMethodType: TransferMethod;
  currentUser?: IUserBasicLoginData;
  isSubmitting = false;
  destroy$ = new Subject();

  form = new FormGroup(
    {
      emailAddress: new FormControl<string | null>(null),
      cardNumber: new FormControl<string | null>(null)
    },
    { updateOn: 'blur' }
  );

  pickerForm = new FormGroup({
    charityId: new FormControl<string | null>(null)
  });

  get emailAddress(): FormControl<string | null> {
    return this.form.controls.emailAddress;
  }

  get cardNumber(): FormControl<string | null> {
    return this.form.controls.cardNumber;
  }

  get charityId(): FormControl<string | null> {
    return this.pickerForm.controls.charityId;
  }

  get formDisabled(): boolean {
    return !!(this.currentUser?.balance && (this.form.invalid || this.pickerForm.invalid));
  }

  get canTransferPoints() {
    return this.userHelper.canTransferPoints;
  }

  constructor(
    private transactionService: TransactionService,
    private userHelper: UserHelper,
    private route: Router,
    private modalHelper: ModalHelper,
    private graphQLService: GraphQLService,
    private userEventService: UserEventService,
    private logoutHelper: LogoutHelper
  ) {}

  ngOnInit(): void {
    this.graphQLService
      .watchQuery<ICharityResponse>(getCharityProductsQuery)
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (result.data.allContent === null) {
          return;
        }

        // Sort alphabetically
        this.charityProducts = result.data.allContent.items
          .filter((x: ICharity) => !x.isHidden)
          .slice()
          .sort((a, b) => a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
        this.loading = result.loading;
      });

    this.userHelper.currentUser$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((user) => {
      this.currentUser = user;
    });

    if (this.canTransferPoints) {
      this.setDonationMethodType(DonationMethod.charity);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  setDonationMethodType(type: DonationMethod, event?: Event): void {
    if (event) {
      this.pushUserEvent(UserEventAction.set, 'transfer target', event.text());
    }

    this.donationMethodType = type;
    this.form.reset();
    this.pickerForm.reset();

    switch (type) {
      case DonationMethod.charity: {
        this.setTransferMethodType(TransferMethod.charity);
        break;
      }
      case DonationMethod.user: {
        this.setTransferMethodType(TransferMethod.emailAddress);
        break;
      }
      case DonationMethod.nobody: {
        this.setTransferMethodType(TransferMethod.nobody);
        break;
      }
      default:
        break;
    }
  }

  setTransferMethodType(type: TransferMethod, event?: Event): void {
    if (event) {
      this.pushUserEvent(UserEventAction.set, 'transfer method', event.text());
    }

    this.transferMethodType = type;

    switch (type) {
      case TransferMethod.emailAddress: {
        this.cardNumber.clearValidators();
        this.charityId.clearValidators();
        this.emailAddress.setValidators([Validators.required.bind(this), Validators.email.bind(this)]);
        break;
      }
      case TransferMethod.cardNumber: {
        this.emailAddress.clearValidators();
        this.charityId.clearValidators();
        this.cardNumber.setValidators([
          Validators.required.bind(this),
          FormValidatorType.pattern(FormRegex.cardNumber.getRegExp()).getValidator()
        ]);
        break;
      }
      case TransferMethod.charity: {
        this.cardNumber.clearValidators();
        this.emailAddress.clearValidators();
        this.charityId.setValidators([Validators.required.bind(this)]);
        break;
      }
      case TransferMethod.nobody: {
        this.cardNumber.clearValidators();
        this.emailAddress.clearValidators();
        this.charityId.clearValidators();
        break;
      }
      default:
        break;
    }

    this.emailAddress.updateValueAndValidity();
    this.cardNumber.updateValueAndValidity();
    this.charityId.updateValueAndValidity();
  }

  onCharityChange(charityTitle: string): void {
    this.pushUserEvent(UserEventAction.set, 'charity', charityTitle);
  }

  async submit(event: Event): Promise<void> {
    const { emailAddress, cardNumber } = this.form.value as ITerminateAccountFormValues;
    const { charityId } = this.pickerForm.value as ITerminateAccountFormValues;

    this.pushUserEvent(
      UserEventAction.submit,
      event.text(),
      emailAddress || cardNumber ? 'transfer to user' : charityId ? `transfer to charity (${charityId})` : 'none'
    );

    await this.modalHelper.triggerConfirmationModal({
      text: this.content.confirmationText,
      action: async () => {
        await this.submitValues({
          emailAddress,
          cardNumber,
          charityId
        });
      },
      userEventSource: this.userEventSource
    });
  }

  async submitValues(values: ITerminateAccountFormValues): Promise<void> {
    this.isSubmitting = true;

    const points = this.currentUser?.balance;

    if (values.charityId && points) {
      await this.transferToCharityAndTerminate(points, values.charityId)
        .then(() => this.finishTermination())
        .finally(() => {
          this.isSubmitting = false;
        });
    } else if (points && (values.cardNumber || values.emailAddress)) {
      await this.transferToUserAndTerminate(points, values.cardNumber, values.emailAddress)
        .then(() => this.finishTermination())
        .finally(() => {
          this.isSubmitting = false;
        });
    } else {
      await this.transactionService
        .terminateAccount()
        .then(() => this.finishTermination())
        .finally(() => {
          this.isSubmitting = false;
        });
    }
  }

  private async transferToCharityAndTerminate(points: number, charityId: string): Promise<void> {
    const request: ITransferPointsToCharityRequest = {
      points
    };

    return await this.transactionService.transferAirmilesToCharity(charityId, request).then(async () => {
      await this.transactionService.terminateAccount();
    });
  }

  private async transferToUserAndTerminate(points: number, cardNumber: string, emailAddress: string) {
    const request = new TransferPointsFormRequest({
      cardNumber,
      emailAddress,
      points
    });

    return await this.transactionService.transferAirmiles(request).then(async () => {
      await this.transactionService.terminateAccount();
    });
  }

  private async finishTermination(): Promise<void> {
    await this.logoutHelper.logout();

    void this.route.navigate([this.content.successPage._url], { replaceUrl: true });
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value);
  }
}
