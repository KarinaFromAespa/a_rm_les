import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CardType } from 'src/app/core/constants/card.constants';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { ContentBlockRegion, ContentBlockType, IFeaturedProducts, IHighlightedProducts } from 'src/app/core/models/content.model';
import { ICustomCard } from 'src/app/core/models/custom-card.model';
import { IBaseProduct, IProductCategory } from 'src/app/core/models/product.model';
import { IProductResponse } from 'src/app/core/models/product.response';
import { CommerceHighlight } from 'src/app/core/models/user-event.model';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { ProductCategoryListComponent } from 'src/app/features/products/product-category-list/product-category-list.component';
import { getProductsQuery } from '../../products/product.query';

type IFeaturedProduct = IBaseProduct | ICustomCard;

@Component({
  selector: 'air-highlighted-products',
  templateUrl: './highlighted-products.component.html',
  standalone: false
})
export class HighlightedProductsComponent implements IContentBlockComponent, OnInit, OnDestroy {
  @ViewChild(ProductCategoryListComponent, { static: true }) categoryList: ProductCategoryListComponent;
  @Input() content: IHighlightedProducts | IFeaturedProducts;
  @Input() noLargeItems = false;
  @Input() region: ContentBlockRegion;

  className = 'highlighted-products';
  contentBlockRegion = ContentBlockRegion;
  isFirst?: boolean;

  userEventSource = UserEventSource.highlightedProducts;
  gtmActionTag: string;
  loading: boolean;

  products: { product: IBaseProduct | ICustomCard; userEventObject: CommerceHighlight }[] = [];
  isCategoryListHidden: boolean;
  isDescriptionHidden: boolean;
  destroy$ = new Subject();

  gtmDataForProductList: unknown;

  get hasCategory(): boolean {
    return !!(this.content as IHighlightedProducts).productOverviewPage && !this.isCategoryListHidden;
  }

  constructor(
    private graphQLService: GraphQLService,
    private router: Router,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    switch (this.content.contentTypeAlias) {
      case ContentBlockType.featuredProducts:
        this.loadFeaturedProducts();
        break;
      default:
        this.loadHighlightedProducts();
        break;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onCategoryClick(category: IProductCategory | null): void {
    const categoryName = category?.name;
    const [productOverviewPage] = ObjectHelper.wrapFieldToArray((this.content as IHighlightedProducts).productOverviewPage);

    let route = productOverviewPage?._url?.replace(/\/$/, '');
    route = category ? `${route}?category=${categoryName?.toLowerCase()}` : route;
    this.pushUserEvent(UserEventAction.link, category?.title, route);

    void this.router.navigate([productOverviewPage?._url], {
      queryParams: { category: categoryName?.toLowerCase() ?? null }
    });
  }

  isCustomCard(item: IFeaturedProduct): boolean {
    return item && item.contentTypeAlias === CardType.customCard;
  }

  private loadHighlightedProducts(): void {
    this.loading = true;
    this.graphQLService
      .watchQuery<IProductResponse>(getProductsQuery)
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        const supplierCode = (this.content as IHighlightedProducts).supplierCode;
        let products: IBaseProduct[] = result.data.allContent.items
          .filter((x) => !x?.isHidden && (!supplierCode || ProductHelper.getSupplierCode(x) === supplierCode))
          .slice()
          .sort((a, b) => Number(b.priority) - Number(a.priority) || new Date(b.updateDate).getTime() - new Date(a.updateDate).getTime());
        products = products.slice(0, (this.content as IHighlightedProducts).numberOfProducts);
        products = ProductHelper.preprocessProducts(products);
        this.loading = result.loading && this.categoryList?.loading;
        this.setProducts(products);
      });
  }

  private loadFeaturedProducts(): void {
    this.loading = true;
    this.noLargeItems = true;
    this.isCategoryListHidden = true;
    this.isDescriptionHidden = true;
    let products = (this.content as IFeaturedProducts).products.filter((x) => !(x as IBaseProduct)?.isHidden) as IBaseProduct[];
    products = ProductHelper.preprocessProducts(products);
    this.loading = false;
    this.setProducts(products);
  }

  private setProducts(products: (IBaseProduct | ICustomCard)[]) {
    this.products = products.map((product, index) => ({ product, userEventObject: new CommerceHighlight(index + 1, product) }));
    this.pushUserEvent(
      UserEventAction.view,
      undefined,
      undefined,
      this.products.map((p) => p.userEventObject)
    );
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value, object);
  }
}
