import { Component } from '@angular/core';
import { ContentBlockRegion, IBanner } from 'src/app/core/models/content.model';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-banner',
  templateUrl: './banner.component.html',
  standalone: false
})
export class BannerComponent implements IContentBlockComponent {
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IBanner;
  userEventSource: string;
  contentTypeAlias: string;
  componentName?: string;
  className = 'content-banner';
}
