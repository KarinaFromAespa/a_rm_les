import { Component } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ContentBlockRegion, ITextList } from 'src/app/core/models/content.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';

@Component({
  selector: 'air-text-list',
  templateUrl: './text-list.component.html',
  standalone: false
})
export class TextListComponent implements IContentBlockComponent {
  className = 'text-list';
  contentBlockRegion = ContentBlockRegion;
  region: ContentBlockRegion;
  isFirst: boolean;
  content: ITextList;
  userEventSource: string;

  constructor(
    private userEventService: UserEventService,
    private toastService: ToastService
  ) {}

  handleVote(title: string, vote: string, event: MouseEvent): void {
    (event.target as HTMLElement)?.closest('.text-list-feedback')?.classList.add('text-list-feedback--submitted');

    this.userEventService.pushEvent(this.userEventSource, UserEventAction.submit, title, vote);

    const feedbackSuccessText = ObjectHelper.wrapArrayToField(this.content.feedbackSuccessText);
    if (feedbackSuccessText) {
      this.toastService.show(
        new ToastOptions({
          type: ToastType.success,
          content: feedbackSuccessText,
          keepAfterRouteChange: false,
          autoClose: true
        })
      );
    }
  }
}
