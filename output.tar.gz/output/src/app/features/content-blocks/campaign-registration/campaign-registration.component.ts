import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { FormFieldName, FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { VerificationHelper } from 'src/app/core/helpers/verification.helper';
import {
  ICampaignRegistration,
  ICampaignRegistrationSettings,
  NewsletterApprovalMode
} from 'src/app/core/models/campaign-registration.model';
import { ContentBlockRegion } from 'src/app/core/models/content.model';
import { FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormControl, IFormSection, IOption, IRadioControl, IRepeatControl, RadioDisplayType } from 'src/app/core/models/form.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import {
  IUserCampaignRegistrationFormValues,
  LightUserCampaignCreateRequest,
  UserCampaignRegistrationRequest
} from 'src/app/core/models/user.model';
import { CampaignRegistrationService } from 'src/app/core/services/campaign-registration.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IConfirmationModal } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.model';
import { VerificationCodeMessageType } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { BaseFormComponent } from '../../form/base-form.component';
import { ModalHelper } from '../../modal/modal.helper';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-campaign-registration',
  templateUrl: './campaign-registration.component.html',
  standalone: false
})
export class CampaignRegistrationComponent
  extends BaseFormComponent<IUserCampaignRegistrationFormValues>
  implements IContentBlockComponent, OnInit
{
  className = 'campaign-registration';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: ICampaignRegistration;
  campaignRegistrationSettings: ICampaignRegistrationSettings;
  campaignRegistrationValues: IUserCampaignRegistrationFormValues;
  showRegistrationForm = false;
  newsletterSuggestionModal: IConfirmationModal;
  registerLightAccountVerificationCode?: string;
  reCaptchaAction = ReCaptchaAction;

  private formValues: IUserCampaignRegistrationFormValues;

  get enableLightCampaignAlternateReCaptcha(): boolean {
    return this.reCaptchaService?.enableAlternateReCaptcha?.[ReCaptchaAction.createLightCampaignUser] ?? false;
  }

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    protected reCaptchaService: ReCaptchaService,
    private campaignRegistrationService: CampaignRegistrationService,
    private translateService: TranslateService,
    private modalHelper: ModalHelper,
    private verificationHelper: VerificationHelper,
    private router: Router
  ) {
    super(userEventService, platformHelper, toastService, reCaptchaService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.verificationHelper.initialize({ content: this.content, userEventSource: this.userEventSource });

    this.newsletterSuggestionModal = {
      text: this.content.newsletterApprovalSuggestion,
      confirmText: this.translateService.instant('campaign_registration.label.sign_up') as string,
      cancelText: this.translateService.instant('campaign_registration.label.not_interested') as string,
      closeOnSelection: true,
      userEventSource: this.userEventSource,
      userEventSourceTopic: 'newsletter'
    } as IConfirmationModal;

    const [campaignRegistrationSettings] = ObjectHelper.wrapFieldToArray(this.content.campaignRegistrationSettings);
    this.campaignRegistrationSettings = campaignRegistrationSettings;

    const defaultSelection =
      this.content.defaultOption &&
      this.campaignRegistrationSettings.campaignRegistrationOptions.find(
        (x) => x.importedCampaign?.campaignId === this.content.defaultOption?.campaignId
      )
        ? this.content.defaultOption.campaignId
        : this.campaignRegistrationSettings.campaignRegistrationOptions[0].importedCampaign.campaignId;

    const termsAndNewsletterSection = {
      additionalClass: 'form-section--offset',
      controls: []
    } as IFormSection;

    this.form = [
      {
        additionalClass: this.campaignRegistrationSettings.campaignRegistrationOptions.length === 1 ? 'd--none' : undefined,
        title: this.translateService.instant('campaign_registration.label.choose_an_extra') as string,
        controls: [
          {
            name: 'campaignId',
            type: FormType.radio,
            displayType: RadioDisplayType.list,
            value: defaultSelection,
            options: this.campaignRegistrationSettings.campaignRegistrationOptions.map(
              (x) =>
                ({
                  value: x.importedCampaign.campaignId,
                  text: x.title
                }) as IOption
            )
          } as IRadioControl
        ]
      },
      {
        title: this.translateService.instant('campaign_registration.label.fill_in_your_email_address') as string,
        controls: [
          {
            type: FormType.email,
            label: this.translateService.instant('account.label.email') as string,
            name: FormFieldName.emailAddress,
            autocomplete: 'email',
            description: this.content?.emailVerificationNotice?.length ? this.content.emailVerificationNotice : null,
            runValidatorsSequentially: true,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.email.required') as string
              },
              { validator: FormValidatorType.email, errorMessage: this.translateService.instant('account.error.email.invalid') as string }
            ]
          } as IRepeatControl
        ]
      }
    ];

    if (this.campaignRegistrationSettings.newsletterApprovalMode !== NewsletterApprovalMode.optionalStep2) {
      termsAndNewsletterSection.controls.push({
        type: FormType.checkbox,
        label: this.content.newsletterApproval,
        name: FormFieldName.receivePromotionalEmails,
        validators:
          this.campaignRegistrationSettings.newsletterApprovalMode === NewsletterApprovalMode.required
            ? [
                {
                  validator: FormValidatorType.requiredTrue
                }
              ]
            : null
      } as IFormControl);
    }

    if (this.content.terms?.length) {
      termsAndNewsletterSection.controls.push({
        type: FormType.checkbox,
        label: this.content.terms,
        name: FormFieldName.acceptTerms,
        validators: [
          {
            validator: FormValidatorType.requiredTrue
          }
        ],
        description: this.content.dataNotice
      } as IFormControl);
    } else {
      termsAndNewsletterSection.controls.push({
        description: this.content.dataNotice
      } as IFormControl);
    }

    if (termsAndNewsletterSection.controls.length > 0) {
      this.form.push(termsAndNewsletterSection);
    }
  }

  async submitValues(values: IUserCampaignRegistrationFormValues): Promise<void> {
    values.receivePromotionalEmails = !!values.receivePromotionalEmails;

    // If optional newsletter opt-in
    if (
      !values.receivePromotionalEmails &&
      this.campaignRegistrationSettings.newsletterApprovalMode === NewsletterApprovalMode.optionalStep1
    ) {
      this.newsletterSuggestionModal.action = () => {
        values.receivePromotionalEmails = true;
        this.formComponent.form.get(FormFieldName.receivePromotionalEmails)?.setValue(true);
        void this.registerCampaign(values);
      };

      this.newsletterSuggestionModal.cancelAction = () => this.registerCampaign(values);
      return this.modalHelper.triggerConfirmationModal(this.newsletterSuggestionModal);
    }

    return this.registerCampaign(values);
  }

  async registerLightAccount(event: Event): Promise<void> {
    this.isSubmitting = true;
    this.pushUserEvent(UserEventAction.link, event.text(), 'skip');

    if (this.registerLightAccountVerificationCode) {
      await this.registerLightAccountAction(this.registerLightAccountVerificationCode);
    } else {
      return await this.verificationHelper.triggerVerificationModal({
        verifyType: VerificationCodeMessageType.email,
        emailAddress: this.campaignRegistrationValues.emailAddress,
        verifyCallback: this.registerLightAccountAction.bind(this) as (verificationCode: string) => Promise<void>,
        closeCallback: () => (this.isSubmitting = false)
      });
    }
  }

  private async registerCampaign(values: IUserCampaignRegistrationFormValues): Promise<void> {
    this.isSubmitting = true;
    this.formValues = values;

    values.selectedCampaignRegistrationOption = this.campaignRegistrationSettings.campaignRegistrationOptions.find(
      (x) => x.importedCampaign.campaignId === values.campaignId
    );
    values.campaignRegistrationSettingsId = this.campaignRegistrationSettings._id;

    await this.registerCampaignAction();
    this.isSubmitting = false;
  }

  private async registerCampaignAction(): Promise<void> {
    const request = new UserCampaignRegistrationRequest(this.formValues);

    await this.reCaptchaService
      .verify<void, UserCampaignRegistrationRequest>(
        ReCaptchaAction.activateRegistrationCampaign,
        request,
        this.campaignRegistrationService.activateRegistrationCampaign.bind(this.campaignRegistrationService)
      )
      .then(() => {
        this.pushUserSuccessEvent();

        // Redirect to success page
        void this.router.navigate([this.formValues.selectedCampaignRegistrationOption?.activationSuccessPage._url]);
      })
      .catch((error: IHttpError) => {
        this.isSubmitting = false;

        if (error?.error?.code === HttpErrorCodes.accountNotFound) {
          // Account not found, show registration form
          this.campaignRegistrationValues = this.formValues;
          this.showRegistrationForm = true;
          void document.querySelector('ion-content')?.scrollToTop(250);
          return;
        }

        throw error;
      });
  }

  private async registerLightAccountAction(verificationCode?: string): Promise<void> {
    this.registerLightAccountVerificationCode = verificationCode;

    const request = new LightUserCampaignCreateRequest(this.campaignRegistrationValues, this.content.origin);
    request.emailAddressVerificationCode = verificationCode;

    await this.reCaptchaService
      .verify(
        ReCaptchaAction.createLightCampaignUser,
        request,
        this.campaignRegistrationService.createLightCampaignUser.bind(this.campaignRegistrationService)
      )
      .then(() => {
        // Redirect to success page
        this.pushUserSuccessEvent();
        void this.router.navigate([this.campaignRegistrationValues.selectedCampaignRegistrationOption?.registrationSuccessPage._url]);
      })
      .catch((error: IHttpError) => {
        throw error;
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }
}
