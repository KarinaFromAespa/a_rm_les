import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { createWidget } from '@typeform/embed';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { scrollIntoViewIfNeeded } from 'src/app/core/helpers/layout.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion, ITypeform } from 'src/app/core/models/content.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-typeform',
  templateUrl: './typeform.component.html',
  standalone: false
})
export class TypeformComponent implements IContentBlockComponent, AfterViewInit {
  @ViewChild('formContainer') formContainer: ElementRef<HTMLDivElement>;

  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: ITypeform;
  userEventSource: string;
  contentTypeAlias: string;
  componentName?: string;
  className = 'typeform';

  constructor(
    private platformHelper: PlatformHelper,
    private userEventService: UserEventService
  ) {}

  ngAfterViewInit(): void {
    this.initTypeform();
  }

  private initTypeform(): void {
    createWidget(this.content.formId, {
      container: this.formContainer.nativeElement,
      autoResize: true,
      inlineOnMobile: true,
      hideHeaders: true,
      opacity: 0,
      onQuestionChanged: () => {
        scrollIntoViewIfNeeded(this.formContainer.nativeElement);
        if (this.platformHelper.isMobile) {
          setTimeout(() => {
            //On mobile, the form is not always scrolled into view after the height changed so check again after a delay
            scrollIntoViewIfNeeded(this.formContainer.nativeElement);
          }, 500);
        }

        this.pushUserEvent(UserEventAction.submit, 'question');
      },
      onSubmit: () => {
        this.pushUserEvent(UserEventAction.submit, 'form');
      }
    });
  }

  private pushUserEvent(action: UserEventAction, label: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, label);
  }
}
