import { Component, ElementRef, OnDestroy, OnInit, SimpleChange, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PaginatePipe } from 'ngx-pagination';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { scrollIntoViewIfNeeded } from 'src/app/core/helpers/layout.helper';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { SortOrder, SorterHelper } from 'src/app/core/helpers/sorter.helper';
import { ContentBlockRegion, IProductOverview } from 'src/app/core/models/content.model';
import { IOption } from 'src/app/core/models/form.model';
import { IBaseProduct } from 'src/app/core/models/product.model';
import { IProductResponse } from 'src/app/core/models/product.response';
import { CommerceHighlight } from 'src/app/core/models/user-event.model';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { ModalService } from '../../modal/modal.service';
import { ProductFilterComponent } from '../../products/product-filters/product-filter.component';
import { IProductFilter, ProductSortType } from '../../products/product-filters/product-filter.model';
import { getProductsQuery } from '../../products/product.query';

@Component({
  selector: 'air-product-overview',
  templateUrl: './product-overview.component.html',
  standalone: false
})
export class ProductOverviewComponent implements IContentBlockComponent, OnInit, OnDestroy {
  @ViewChild('header') header: ElementRef;
  className = 'product-overview';
  content: IProductOverview;
  region: ContentBlockRegion;
  isFirst: boolean;
  userEventSource: string;

  products: { product: IBaseProduct; userEventObject: CommerceHighlight }[];
  filteredProducts: { product: IBaseProduct; userEventObject?: CommerceHighlight }[] = [];
  filters: IProductFilter;
  filteredSubcategories: string[];
  initialFilteredPartners: string[];
  filteredPartners: string[];
  rangeCeiling: number;

  modalFilterComponent?: ProductFilterComponent;
  sorterOptions: IOption[];

  currentScreenSize: ScreenSize;
  screenSize = ScreenSize;
  page = 1;
  itemsPerPage = 12;

  loading = true;
  filtersActive = false;
  destroy$ = new Subject();

  sorterForm = new FormGroup({
    sortBy: new FormControl(ProductSortType.recommended)
  });

  constructor(
    private graphQLService: GraphQLService,
    private modalService: ModalService,
    private route: ActivatedRoute,
    private translateService: TranslateService,
    private userEventService: UserEventService,
    private paginatePipe: PaginatePipe
  ) {}

  ngOnInit(): void {
    this.sorterOptions = [
      { text: this.translateService.instant('product.sorter.recommended') as string, value: ProductSortType.recommended },
      { text: this.translateService.instant('product.sorter.miles_ascending') as string, value: ProductSortType.milesAscending },
      { text: this.translateService.instant('product.sorter.miles_descending') as string, value: ProductSortType.milesDescending }
    ];

    this.graphQLService
      .query<IProductResponse>(getProductsQuery)
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (!this.products) {
          let items = ProductHelper.preprocessProducts(result.data.allContent.items.filter((x) => !x.isHidden));
          items = ProductHelper.splitMilesOnlyProducts(items);
          items = SorterHelper.sortProductsByMostRecommended(items);
          this.products = [...items].map((product, index) => ({ product, userEventObject: new CommerceHighlight(index + 1, product) }));

          this.rangeCeiling = Math.max(
            ...this.products.map((x) => ProductHelper.getLowestCostForProduct(x.product).points).filter((x) => x)
          );
          const initCategory: string | undefined = this.route.snapshot.queryParamMap.get('category')?.toLowerCase();
          const initSubcategory: string | undefined = this.route.snapshot.queryParamMap.get('subcategory')?.toLowerCase();
          const initSpotlighted = this.route.snapshot.queryParamMap.get('spotlight')?.toLowerCase() === 'true';

          // Initialize filter
          this.filters = {
            categories: initCategory
              ? [initCategory]
              : this.content.category
                ? ProductHelper.getCategoriesNames(this.content.category)
                : [],
            subcategories: initSubcategory
              ? [initSubcategory]
              : this.content.subcategory
                ? ProductHelper.getSubcategoriesNames(this.content.subcategory)
                : [],
            partners: [],
            milesOnly: false,
            spotlighted: initSpotlighted || this.content.isSpotlighted || false,
            range: { min: 0, max: this.rangeCeiling },
            noSave: false
          };
          this.applyFilters(this.filters, true);

          this.loading = result.loading;
        }
      });
  }

  applyFilters(filters: IProductFilter, init = false): void {
    if (!filters || !this.products) {
      return;
    }

    // Apply filters except filters that need pre filtered products
    let filteredProducts = this.products.filter((p) => {
      const productCost = ProductHelper.getLowestCostForProduct(p.product);
      const isProductCharity = ProductHelper.isCharity(p.product);
      if (filters.categories.length > 0 && !filters.categories.some((category) => category === p.product.category?.name?.toLowerCase())) {
        return false;
      }
      if (filters.milesOnly && !isProductCharity && (productCost.price || !ProductHelper.isAvailable(p.product))) {
        return false;
      }
      if (filters.spotlighted && !p.product.isSpotlighted) {
        return false;
      }
      const productPoints = productCost.points ?? 0;
      if (!isProductCharity && filters.range.max && (productPoints < filters.range.min || productPoints > filters.range.max)) {
        return false;
      }
      return true;
    });

    // Update partner list shown in filter
    const filteredSubcategories = [...new Set(filteredProducts.map((p) => p.product.subcategory?.title).filterEmpty())];
    const filteredPartners = [...new Set(filteredProducts.map((p) => ProductHelper.getSupplierCode(p.product)).filterEmpty())];

    if (init) {
      // Initial filter should contain all possible values
      this.initialFilteredPartners = [...new Set(this.products.map((p) => ProductHelper.getSupplierCode(p.product)).filterEmpty())];
    }

    if (filters.noSave) {
      // Manually apply changes to show partner filter change in modal without applying filter to products
      if (!this.modalFilterComponent) {
        return;
      }

      const changes = {
        filteredSubcategories: new SimpleChange(this.modalFilterComponent.filteredSubcategories, filteredSubcategories, false),
        filteredPartners: new SimpleChange(this.modalFilterComponent.filteredPartners, filteredPartners, false)
      };

      this.modalFilterComponent.ngOnChanges(changes);
      return;
    }

    if (!init) {
      const categoryString = filters.categories.sort().join(', ');
      if (categoryString !== this.filters.categories.sort().join(', ')) {
        this.pushUserEvent(UserEventAction.filter, this.translateService.instant('product.filter.label.categories'), categoryString);
      }

      const subcategoryString = filters.subcategories.sort().join(', ');
      if (subcategoryString !== this.filters.subcategories.sort().join(', ')) {
        this.pushUserEvent(UserEventAction.filter, this.translateService.instant('product.filter.label.subcategories'), subcategoryString);
      }

      const partnerString = filters.partners.sort().join(', ');
      if (partnerString !== this.filters.partners.sort().join(', ')) {
        this.pushUserEvent(
          UserEventAction.filter,
          this.translateService.instant('product.filter.label.redemption_partners'),
          partnerString
        );
      }

      const rangeString = `${filters.range.min} - ${filters.range.max}`;
      if (rangeString !== `${this.filters.range.min} - ${this.filters.range.max}`) {
        this.pushUserEvent(UserEventAction.filter, this.translateService.instant('general.label.air_miles'), rangeString);
      }

      if (filters.milesOnly !== this.filters.milesOnly) {
        this.pushUserEvent(UserEventAction.filter, this.translateService.instant('general.label.miles_only'), filters.milesOnly.toString());
      }

      if (filters.spotlighted !== this.filters.spotlighted) {
        this.pushUserEvent(
          UserEventAction.filter,
          this.translateService.instant('product.filter.label.spotlighted'),
          filters.milesOnly.toString()
        );
      }
    }

    this.filters = filters;
    this.filteredSubcategories = filteredSubcategories;
    this.filteredPartners = filteredPartners;

    // Apply all filters that not have been applied yet
    filteredProducts = filteredProducts.filter((p) => {
      if (
        filters.subcategories.length > 0 &&
        !filters.subcategories.some((subcategory) => subcategory === p.product.subcategory?.title?.toLowerCase())
      ) {
        return false;
      }

      if (
        filters.partners.length > 0 &&
        !filters.partners.some((partner) => partner.toUpperCase() === ProductHelper.getSupplierCode(p.product)?.toUpperCase())
      ) {
        return false;
      }

      return true;
    });

    this.filteredProducts = filteredProducts;
    this.page = 1;
    this.sortProducts(false);

    setTimeout(() => {
      this.filtersActive =
        !!this.filters?.categories?.length ||
        !!this.filters?.partners?.length ||
        this.filters.milesOnly ||
        (this.filters && this.filters.range.min > 0) ||
        (this.filters && !!this.filters.range.max && this.filters.range.max < this.rangeCeiling) ||
        this.filters.spotlighted;
    }, 0);
  }

  onPageChange(page: number): void {
    this.pushUserEvent(UserEventAction.paging, page.toString());
    this.page = page;
    this.pushUserEventObjects();
    scrollIntoViewIfNeeded(this.header.nativeElement);
  }

  onFilterButtonClick(): void {
    const modal = this.modalService.open(undefined, ProductFilterComponent);
    this.modalFilterComponent = modal?.componentInstance as ProductFilterComponent;

    if (!this.modalFilterComponent || !modal) {
      return;
    }

    this.modalFilterComponent.initialFilters = ObjectHelper.deepCopy(this.filters) as IProductFilter;
    this.modalFilterComponent.rangeCeiling = this.rangeCeiling;
    this.modalFilterComponent.filteredSubcategories = this.filteredSubcategories;
    this.modalFilterComponent.initialFilteredPartners = this.initialFilteredPartners;
    this.modalFilterComponent.filteredPartners = this.filteredPartners;
    this.modalFilterComponent.isModalComponent = true;

    this.modalFilterComponent.filterChange.pipe(takeUntil(modal.onClose$)).subscribe({
      next: (filters) => {
        this.applyFilters(filters);
      },
      complete: () => {
        this.modalFilterComponent = undefined;
      }
    });
  }

  sortProducts(pushUserEvent = true): void {
    const sortType = this.sorterForm.value.sortBy;
    let filteredProducts = this.filteredProducts.map((p) => p.product);

    switch (sortType) {
      case ProductSortType.recommended:
        filteredProducts = SorterHelper.sortProductsByMostRecommended(filteredProducts);
        break;
      case ProductSortType.milesAscending:
      case ProductSortType.milesDescending:
        filteredProducts = SorterHelper.sortProductsByMiles(
          filteredProducts,
          sortType === ProductSortType.milesAscending ? SortOrder.asc : SortOrder.desc
        );
        break;
    }

    this.filteredProducts = filteredProducts.map((product, index) => {
      const productCost = ProductHelper.getLowestCostForProduct(product);
      const userEventObject = this.filteredProducts.find(
        (p) =>
          //Also filter on points and price, because miles only products cause duplicate id's
          p.product.id === product.id && p.userEventObject?.points === productCost.points && p.userEventObject.price === productCost.price
      )?.userEventObject;
      if (userEventObject) {
        userEventObject.position = index + 1;
      }
      return { product, userEventObject };
    });

    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.sort, this.sorterOptions.find((x) => x.value === sortType?.toString())?.text);
    }

    this.pushUserEventObjects();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private pushUserEventObjects() {
    this.pushUserEvent(
      UserEventAction.view,
      undefined,
      undefined,
      this.paginatePipe
        .transform(this.filteredProducts, { currentPage: this.page, itemsPerPage: this.itemsPerPage })
        .map((p) => p.userEventObject)
    );
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value, object);
  }
}
