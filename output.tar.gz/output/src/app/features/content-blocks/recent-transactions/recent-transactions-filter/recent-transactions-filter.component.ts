import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ITransaction } from 'src/app/core/models/transaction.model';
import { ModalRef } from 'src/app/features/modal/modal-ref';
import { ITransactionFilters } from '../recent-transactions.model';

@Component({
  selector: 'air-recent-transactions-filter',
  templateUrl: './recent-transactions-filter.component.html',
  providers: [DatePipe],
  standalone: false
})
export class RecentTransactionsFilterComponent implements OnInit {
  @Input() transactions: ITransaction[] = [];

  private _filters: ITransactionFilters = { dates: [], names: [] };
  get filters(): ITransactionFilters {
    return this._filters;
  }
  @Input() set filters(value: ITransactionFilters) {
    this._filters = { names: [...value.names], dates: [...value.dates] };
  }

  @Output() filterApply = new EventEmitter<ITransactionFilters>();

  dates: string[];
  names: string[];

  constructor(
    private modalRef: ModalRef,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.dates = this.transactions.map((transaction) => this.datePipe.transform(transaction.date, 'dd-MM-yyyy')).filterEmpty();
    this.names = this.transactions.map((transaction) => transaction.name ?? '').sort();
  }

  apply(): void {
    this.filterApply.emit(this.filters);
    this.close();
  }

  close(): void {
    this.modalRef.close();
  }
}
