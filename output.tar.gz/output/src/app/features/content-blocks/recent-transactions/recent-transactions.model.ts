export enum TransactionType {
  all = 'All',
  deposit = 'Deposit',
  withdrawal = 'Withdrawal'
}

export enum TransactionFilterType {
  date = 'date',
  name = 'name'
}

export interface ITransactionFilterItem {
  value: string;
  checked: boolean;
}

export interface ITransactionFilters {
  dates: string[];
  names: string[];
  transactionType?: TransactionType;
}
