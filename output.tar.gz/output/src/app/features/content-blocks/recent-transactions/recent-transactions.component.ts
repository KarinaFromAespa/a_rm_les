import { DatePipe } from '@angular/common';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { first } from 'rxjs';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { scrollIntoViewIfNeeded } from 'src/app/core/helpers/layout.helper';
import { ContentBlockRegion, ITransactions } from 'src/app/core/models/content.model';
import { IOption } from 'src/app/core/models/form.model';
import { IPage } from 'src/app/core/models/site.response';
import { ITransaction } from 'src/app/core/models/transaction.model';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { SortByPipe } from 'src/app/shared/pipes/sort-by.pipe';
import { ModalService } from '../../modal/modal.service';
import { IContentBlockComponent } from '../content-block-component.model';
import { RecentTransactionsFilterComponent } from './recent-transactions-filter/recent-transactions-filter.component';
import { ITransactionFilters, TransactionType } from './recent-transactions.model';

@Component({
  selector: 'air-recent-transactions',
  templateUrl: './recent-transactions.component.html',
  providers: [SortByPipe, DatePipe],
  standalone: false
})
export class RecentTransactionsComponent implements IContentBlockComponent, OnInit {
  @ViewChild('header') header: ElementRef;
  private _transactions: ITransaction[] = [];
  get transactions(): ITransaction[] {
    return this._transactions;
  }
  @Input() set transactions(value: ITransaction[] | undefined) {
    this._transactions = value ?? [];
    this.filteredTransactions = value ?? [];
  }
  @Input() showAll = true; // If not specified show full transaction table
  @Input() transactionsPage?: IPage;
  @Input() loading: boolean;

  className = 'recent-transactions';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: ITransactions;
  userEventSource = UserEventSource.recentTransactions;
  transactionType = TransactionType;
  transactionTypeOptions: IOption[];
  readonly contentBlockRegion = ContentBlockRegion;

  sortKey: string;
  sortAsc: boolean;

  page = 1;

  filteredTransactions: ITransaction[] = [];
  filtersActive = false;
  filterForm = new FormGroup({
    transactionType: new FormControl(TransactionType.all)
  });
  filters: ITransactionFilters = { dates: [], names: [], transactionType: TransactionType.all };

  constructor(
    private transactionService: TransactionService,
    private userEventService: UserEventService,
    private modalService: ModalService,
    private sortBy: SortByPipe,
    private datePipe: DatePipe,
    private translateService: TranslateService
  ) {}

  get title(): string {
    return this.content?.title && this.showAll
      ? this.content.title
      : this.translateService.instant('transactions.label.my_last_transactions');
  }

  get noTransactionsText(): string {
    return this.showAll
      ? this.translateService.instant('transactions.label.no_transactions_yet')
      : this.translateService.instant('transactions.label.no_recent_transactions');
  }

  async ngOnInit(): Promise<void> {
    this.transactionTypeOptions = [
      { text: this.translateService.instant('transactions.label.transactionType.all') as string, value: TransactionType.all },
      { text: this.translateService.instant('transactions.label.transactionType.deposit') as string, value: TransactionType.deposit },
      { text: this.translateService.instant('transactions.label.transactionType.withdrawal') as string, value: TransactionType.withdrawal }
    ];

    if (this.showAll) {
      this.loading = true;
      const data = await this.transactionService.getTransactions().finally(() => {
        this.loading = false;
      });

      this.transactions = data.map((transaction) => {
        transaction.name = transaction.name?.length
          ? transaction.name
          : (this.translateService.instant('transactions.label.unknown') as string);
        return transaction;
      });
    }
  }

  sort(key: string): void {
    this.sortKey = key;
    this.sortAsc = !this.sortAsc;
    this.pushUserEvent(this.sortAsc ? UserEventAction.sortAscending : UserEventAction.sortDescending, this.sortKey);
    this.filteredTransactions = this.sortBy.transform(this.filteredTransactions, this.sortKey, this.sortAsc) as ITransaction[];
  }

  onPageChange(page: number): void {
    this.pushUserEvent(UserEventAction.paging, page.toString());
    this.page = page;
    scrollIntoViewIfNeeded(this.header.nativeElement);
  }

  transactionTypeSelect(): void {
    this.filterTransactions({ ...this.filters, transactionType: this.filterForm.value.transactionType ?? undefined });
  }

  openFilterModal(): void {
    const modal = this.modalService.open(undefined, RecentTransactionsFilterComponent, {
      transactions: this.transactions,
      filters: this.filters
    });

    const modalComponent = modal?.componentInstance as RecentTransactionsFilterComponent;
    modalComponent.filterApply.pipe(first()).subscribe((filters: ITransactionFilters): void => {
      this.filterTransactions({ ...filters, transactionType: this.filterForm.value.transactionType ?? undefined });
    });
  }

  filterTransactions(filters: ITransactionFilters): void {
    this.filteredTransactions = [...this.transactions];

    if (filters.dates?.length) {
      this.filteredTransactions = this.filteredTransactions.filter((transaction) => {
        const date = this.datePipe.transform(transaction.date, 'dd-MM-yyyy');
        return date ? filters.dates.includes(date) : false;
      });
    }

    if (filters.names?.length) {
      this.filteredTransactions = this.filteredTransactions.filter((transaction) => filters.names.includes(transaction.name!));
    }

    switch (this.filterForm.value.transactionType) {
      case TransactionType.deposit:
        this.filteredTransactions = this.filteredTransactions.filter((transaction) => transaction.points > 0);
        break;
      case TransactionType.withdrawal:
        this.filteredTransactions = this.filteredTransactions.filter((transaction) => transaction.points < 0);
        break;
    }

    const datesString = filters.dates.sort().join(', ');
    if (datesString !== this.filters.dates.sort().join(', ')) {
      this.pushUserEvent(UserEventAction.filter, this.translateService.instant('transactions.label.date'), datesString);
    }

    const namesString = filters.names.sort().join(', ');
    if (namesString !== this.filters.names.sort().join(', ')) {
      this.pushUserEvent(UserEventAction.filter, this.translateService.instant('general.label.name'), namesString);
    }

    if (filters.transactionType !== this.filters.transactionType) {
      this.pushUserEvent(
        UserEventAction.filter,
        this.transactionTypeOptions.find((x) => x.value === this.filterForm.value.transactionType?.toString())?.text
      );
    }

    this.page = 1;
    this.filters = filters;
    this.filtersActive = !!(this.filters.names?.length || this.filters.dates?.length);
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value);
  }
}
