import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { DateHelper } from 'src/app/core/helpers/date.helper';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion, IHighlightedCampaign, IHighlightedPromotion, IHighlightedPromotions } from 'src/app/core/models/content.model';
import { ICampaign } from 'src/app/core/models/promotion.model';
import { ICampaignListResponse, ICampaignResponse } from 'src/app/core/models/promotion.response';
import { CommerceHighlight } from 'src/app/core/models/user-event.model';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { PromotionService } from 'src/app/core/services/promotion.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { campaignsQuery } from './highlighted-promotions.queries';

@Component({
  selector: 'air-highlighted-promotions',
  templateUrl: './highlighted-promotions.component.html',
  standalone: false
})
export class HighlightedPromotionsComponent implements IContentBlockComponent, OnInit {
  className = 'highlighted-promotions';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IHighlightedPromotions;
  loading: boolean;

  promotions: { promotion: IHighlightedPromotion; userEventObject: CommerceHighlight }[] = [];
  userEventSource: string;

  constructor(
    private promotionService: PromotionService,
    private graphQLService: GraphQLService,
    private translateService: TranslateService,
    private userEventService: UserEventService
  ) {}

  async ngOnInit(): Promise<void> {
    await this.getPromotions();
  }

  hasAlternativeTarget(promotion: IHighlightedPromotion): boolean {
    return !!promotion.alternativeTarget?.length;
  }

  activationLabel(promotion: IHighlightedPromotion): string {
    return promotion.requiresActivation && !promotion.isActivated
      ? this.translateService.instant('general.label.validity_activation')
      : this.translateService.instant('general.label.validity');
  }

  buttonLabel(promotion: IHighlightedPromotion): string | undefined {
    if (!promotion.requiresActivation) {
      return this.translateService.instant('general.label.view');
    }

    if (this.hasAlternativeTarget(promotion)) {
      return promotion.alternativeTarget?.[0].label;
    }

    return promotion.isActivated
      ? this.translateService.instant('general.label.view')
      : this.translateService.instant('campaign.label.activate');
  }

  private async getPromotions(): Promise<void> {
    this.loading = true;
    try {
      this.promotions = ((await this.getCampaigns()) ?? [])
        .map((campaign) => {
          const [importedCampaign] = ObjectHelper.wrapFieldToArray(campaign.importedCampaign);

          return {
            id: importedCampaign?.campaignId,
            title: campaign.title,
            image: campaign.primaryImage,
            points: campaign.points > 0 ? campaign.points : null,
            validTo: DateHelper.toNullableDate(campaign.individualEndDate ?? importedCampaign?.campaignEndDate),
            alternativeTarget: campaign.alternativeTarget,
            isActivated: campaign.isActivated,
            requiresActivation: importedCampaign?.requiresActivation,
            priority: campaign.priority ?? 0,
            url: campaign.url
          } as IHighlightedPromotion;
        })
        .sort((x, y) => y.priority - x.priority)
        .splice(0, this.content.numberOfPromotions)
        .map((promotion, index) => ({
          promotion,
          userEventObject: new CommerceHighlight(index + 1, undefined, promotion)
        }));
    } catch {
      this.promotions = [];
    } finally {
      this.loading = false;

      this.userEventService.pushEvent(
        this.userEventSource,
        UserEventAction.view,
        undefined,
        undefined,
        this.promotions.map((p) => p.userEventObject)
      );
    }
  }

  private async getCampaigns(): Promise<IHighlightedCampaign[] | null> {
    /* Get Campaigns from SAP */
    const promiseSap = this.promotionService.getCampaigns();

    /* Get Campaigns from Umbraco */
    const promiseUmbraco = this.graphQLService.query<ICampaignListResponse>(campaignsQuery).toPromise();

    const [resultSap, resultUmbraco] = await Promise.all([promiseSap, promiseUmbraco]);
    if (!resultUmbraco?.data?.allCampaign?.items || resultUmbraco.data.allCampaign.items.length === 0) {
      return [];
    }

    /* Combine SAP and Umbraco Campaigns */
    return this.combineCampaigns(resultUmbraco.data.allCampaign.items, resultSap);
  }

  private combineCampaigns(umbracoCampaigns: ICampaign[], sapCampaigns: ICampaignResponse[]): IHighlightedCampaign[] {
    return umbracoCampaigns
      .map((umbracoCampaign) => {
        const [importedCampaign] = ObjectHelper.wrapFieldToArray(umbracoCampaign.importedCampaign);
        const sapCampaign = sapCampaigns?.find((x) => importedCampaign?.campaignId === x.campaignId);

        if ((importedCampaign && !sapCampaign) || (umbracoCampaign.isAppOnly && !PlatformHelper.isNativeMobile)) {
          return null;
        }

        return {
          title: umbracoCampaign?.title,
          primaryImage: umbracoCampaign?.primaryImage,
          importedCampaign: umbracoCampaign?.importedCampaign,
          points: umbracoCampaign?.charity ? null : umbracoCampaign?.points,
          alternativeTarget: umbracoCampaign?.alternativeTarget,
          priority: umbracoCampaign?.priority,
          isActivated: sapCampaign?.isActivated,
          url: umbracoCampaign?.url,
          individualEndDate: sapCampaign?.individualEndDate
        } as IHighlightedCampaign;
      })
      .filterEmpty();
  }
}
