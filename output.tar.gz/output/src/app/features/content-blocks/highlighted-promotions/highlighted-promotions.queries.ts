import gql from 'graphql-tag';

const importedCampaignFragment = gql`
  fragment ImportedCampaignFields on ImportedCampaign {
    campaignId
    requiresActivation
    campaignEndDate
  }
`;

const imageFragment = gql`
  fragment ImageFields on Image {
    name
    alt
    url
    umbracoFile {
      focalPoint {
        top
        left
      }
      focalPointUrlTemplate
    }
  }
`;

const pageLinkFragment = gql`
  fragment PageLinkFields on PageLink {
    contentTypeAlias
    label
    page {
      _url: url
    }
    icon
  }
`;

const externalLinkFragment = gql`
  fragment HighlightedExternalLinkFields on ExternalLink {
    contentTypeAlias
    label
    url
    icon
    bypassInAppBrowser
  }
`;

const campaignFragment = gql`
  ${importedCampaignFragment}
  ${imageFragment}
  ${pageLinkFragment}
  ${externalLinkFragment}
  fragment CampaignFields on Campaign {
    title
    primaryImage {
      ...ImageFields
    }
    importedCampaign {
      ...ImportedCampaignFields
    }
    points
    charity {
      id
    }
    alternativeTarget {
      ...PageLinkFields
      ...HighlightedExternalLinkFields
    }
    priority
    isAppOnly
    url
  }
`;

export const campaignsQuery = gql`
  ${campaignFragment}
  query GetCampaigns {
    allCampaign {
      items {
        ...CampaignFields
      }
    }
  }
`;
