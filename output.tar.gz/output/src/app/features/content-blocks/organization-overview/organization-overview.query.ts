import gql from 'graphql-tag';

export const organizationOverviewQuery = gql`
  query getOrganizations {
    allContent(where: { OR: [{ contentTypeAlias: "partner" }, { contentTypeAlias: "charity" }, { contentTypeAlias: "supplier" }] }) {
      items {
        ... on Partner {
          contentTypeAlias
          title
          logo {
            cropUrl(alias: "Partner Logo")
          }
          url
          isHidden
        }
        ... on Charity {
          contentTypeAlias
          title
          logo {
            cropUrl(alias: "Partner Logo")
          }
          url
          isHidden
        }
        ... on Supplier {
          contentTypeAlias
          title
          logo {
            cropUrl(alias: "Partner Logo")
          }
          url
          isHidden
        }
      }
    }
  }
`;
