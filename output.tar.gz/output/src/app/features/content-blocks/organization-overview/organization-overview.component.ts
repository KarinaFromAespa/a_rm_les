import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ContentBlockRegion, IOrganizationOverview } from 'src/app/core/models/content.model';
import { IOrganization, IOrganizationOverviewResponse } from 'src/app/core/models/organization.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { IContentBlockComponent } from '../content-block-component.model';
import { organizationOverviewQuery } from './organization-overview.query';

@Component({
  selector: 'air-organization-overview',
  templateUrl: './organization-overview.component.html',
  standalone: false
})
export class OrganizationOverviewComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'organization-overview';
  content: IOrganizationOverview;
  region: ContentBlockRegion;
  isFirst: boolean;
  userEventSource: string;

  organizations: IOrganization[];
  loading: boolean;
  destroy$ = new Subject();
  contentBlockRegion = ContentBlockRegion;

  constructor(private graphQLService: GraphQLService) {}

  ngOnInit(): void {
    this.graphQLService
      .watchQuery<IOrganizationOverviewResponse>(organizationOverviewQuery)
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (result.data.allContent === null) {
          return;
        }

        this.organizations = [...result.data.allContent.items]
          .filter(
            (x) =>
              !x.isHidden &&
              (!this.content.organizationTypes?.length ||
                Object.values(this.content.organizationTypes).some((y) => y.toLowerCase() === x.contentTypeAlias.toLowerCase()))
          )
          .sort((x, y) => x.title.toLowerCase().localeCompare(y.title.toLowerCase()));
        this.loading = result.loading;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
