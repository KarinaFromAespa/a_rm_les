import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AuthorizationLevel } from 'src/app/core/constants/user.constants';
import { ErrorHelper } from 'src/app/core/helpers/error.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, IPartnerLogin } from 'src/app/core/models/content.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { PartnerLoginRequest } from 'src/app/core/models/login.request';
import { IPartnerLoginProfile } from 'src/app/core/models/login.response';
import { NavigationService } from 'src/app/core/services/navigation.service';
import { TokenService } from 'src/app/core/services/token.service';
import { ModalLoginHelper } from '../../modal/modal-login.helper';
import { ModalHelper } from '../../modal/modal.helper';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-partner-login',
  template: '',
  standalone: false
})
export class PartnerLoginComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className: string;
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IPartnerLogin;
  userEventSource: string;

  private partnerProfile: IPartnerLoginProfile;
  private partnerUsername: string;
  private partnerRedirectUrl: string;
  private partnerRedirectParams: URLSearchParams;
  private destroy$ = new Subject();

  constructor(
    private userHelper: UserHelper,
    private tokenService: TokenService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private navigationService: NavigationService,
    private modalHelper: ModalHelper,
    private modalLoginHelper: ModalLoginHelper,
    private errorHelper: ErrorHelper
  ) {}

  ngOnInit(): void {
    this.navigationService.removeLastHistory();
    this.activatedRoute.queryParams.pipe(takeUntil(this.destroy$)).subscribe((params) => {
      this.partnerUsername = params.userId as string;
      this.partnerRedirectUrl = params.redirectUrl as string;

      void this.getPartnerProfile();
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private async getPartnerProfile(): Promise<void> {
    if (!this.partnerUsername || !this.partnerRedirectUrl) {
      // Required partner params are missing
      void this.route.navigate(['/'], { replaceUrl: true });
      return;
    }
    const splitUrl = this.partnerRedirectUrl.split('?');
    this.partnerRedirectUrl = splitUrl[0];
    this.partnerRedirectUrl = UrlHelper.trimTrailingSlash(this.partnerRedirectUrl);
    let paramsString = '';
    if (splitUrl.length === 2) {
      paramsString = splitUrl[1];
    }

    this.partnerRedirectParams = new URLSearchParams(paramsString);

    this.partnerProfile = await this.tokenService.getPartnerProfile(this.content.profileName);
    this.triggerAuthentication(this.partnerProfile.preserveExistingLogin);
  }

  private triggerAuthentication(verifyCurrent?: boolean): void {
    if (!verifyCurrent || this.userHelper.currentAuthorizationLevel !== AuthorizationLevel.twoFactor) {
      if (verifyCurrent && this.userHelper.currentAuthorizationLevel === AuthorizationLevel.password) {
        void this.modalLoginHelper
          .triggerTwoFactorModal(
            this.userEventSource,
            this.onModalClose.bind(this),
            this.navigatePartnerLoggedIn.bind(this),
            true,
            this.content.twoFactorVerification?.[0],
            false
          )
          .catch((e) => this.triggerRetryModal(e));
        return;
      }
      void this.modalLoginHelper
        .triggerTwoFactorPasswordLoginModal(
          this.userEventSource,
          undefined,
          this.onModalClose.bind(this),
          this.navigatePartnerLoggedIn.bind(this),
          undefined,
          undefined,
          true,
          true,
          this.content.loginUsernameNotice,
          this.content.partnerNotice,
          this.content.color,
          this.content.twoFactorVerification?.[0],
          false
        )
        .catch((e) => this.triggerRetryModal(e));
      return;
    }

    void this.navigatePartnerLoggedIn();
  }

  private retryAuthentication(): void {
    this.triggerAuthentication(true);
  }

  triggerRetryModal(e: IHttpError): void {
    const message = this.errorHelper.getErrorMessage(e);
    this.modalHelper.triggerRetryModal(
      message ?? '',
      this.retryAuthentication.bind(this),
      this.onModalClose.bind(this),
      this.userEventSource,
      true,
      this.content.color
    );
  }

  private async navigatePartnerLoggedIn(): Promise<boolean> {
    if (this.userHelper.isLoggedIn && this.userHelper.currentUser?.authorizationLevel === AuthorizationLevel.twoFactor) {
      const request = new PartnerLoginRequest(this.content.profileName, this.partnerUsername);

      const isSuccess = await this.tokenService
        .createPartnerLoginToken(request)
        .then((partnerLoginData) => {
          this.setSuccessParam(true);
          if (partnerLoginData.encryptedUserId) {
            this.partnerRedirectParams.set('encryptedUserId', partnerLoginData.encryptedUserId);
          }

          this.redirectPartner();

          return true;
        })
        .catch((e: IHttpError) => {
          this.triggerRetryModal(e);
          return false;
        });

      return isSuccess;
    }

    return false;
  }

  private redirectPartner(): void {
    if (
      this.partnerProfile.validReturnUrls.some((url) =>
        new RegExp(url.replace(/[.+/?^${}()|[\]\\]/g, '\\$&').replace('*', '[^.]+')).test(this.partnerRedirectUrl)
      )
    ) {
      window.open(
        `${this.partnerRedirectUrl}?${this.partnerRedirectParams.toString()}`,
        PlatformHelper.isNativeMobile ? '_system' : '_self'
      );
    } else {
      void this.route.navigate(['/'], { replaceUrl: true });
    }
  }

  private onModalClose(): void {
    this.setSuccessParam(false);
    this.redirectPartner();
  }

  private setSuccessParam(value: boolean): void {
    this.partnerRedirectParams.set('success', value ? 'true' : 'false');
  }
}
