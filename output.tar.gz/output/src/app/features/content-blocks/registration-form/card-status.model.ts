import { IReCaptchaRequest } from 'src/app/core/models/reCaptcha.request';

export enum CardStatus {
  notFound = 'NotFound',
  hasAccount = 'HasAccount',
  hasNoAccount = 'HasNoAccount'
}

export class CardStatusCheckRequest implements IReCaptchaRequest {
  cardNumber: string;
  reCaptchaToken: string;
}

export interface ICardStatusCheckResponse {
  cardStatus: CardStatus;
}
