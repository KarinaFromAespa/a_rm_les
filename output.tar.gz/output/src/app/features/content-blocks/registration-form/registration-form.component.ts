import { Component, ElementRef, Inject, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs';
import { FormBoolean, FormFieldName, FormType, FormValidatorTypeKeys, Gender } from 'src/app/core/constants/form.constants';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { VerificationHelper } from 'src/app/core/helpers/verification.helper';
import { ICampaignRegistration, NewsletterApprovalMode } from 'src/app/core/models/campaign-registration.model';
import { ContentBlockRegion, IBaseRegistrationForm, IRegistrationForm, IRegistrationStep, IText } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import {
  IFormControl,
  IFormSection,
  IRadioControl,
  IRepeatControl,
  ISelectControl,
  IShowCondition,
  ITextControl
} from 'src/app/core/models/form.model';
import { PasswordLoginRequest } from 'src/app/core/models/login.request';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { RegistrationStepSection } from 'src/app/core/models/registration.model';
import {
  IUserCampaignRegistrationFormValues,
  IUserCreateFormValues,
  UserCampaignCreateRequest,
  UserCreateRequest
} from 'src/app/core/models/user.model';
import { CampaignRegistrationService } from 'src/app/core/services/campaign-registration.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { TokenService } from 'src/app/core/services/token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { IConfirmationModal } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.model';
import { VerificationCodeMessageType } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { BaseFormComponent } from '../../form/base-form.component';
import { ModalHelper } from '../../modal/modal.helper';
import { IContentBlockComponent } from '../content-block-component.model';
import { DOCUMENT } from '@angular/common';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';

@Component({
  selector: 'air-registration-form',
  templateUrl: './registration-form.component.html',
  standalone: false
})
export class RegistrationFormComponent
  extends BaseFormComponent<IUserCreateFormValues>
  implements IContentBlockComponent, OnInit, OnDestroy
{
  @ViewChild('stepHeader') private stepHeader: ElementRef<HTMLElement>;
  @Input() campaignRegistrationValues: IUserCampaignRegistrationFormValues;
  @Input() content: IBaseRegistrationForm;
  @Input() newsletterSuggestionModal: IConfirmationModal;
  @Input() userEventSource: string;

  className = 'registration-form';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  campaignRegistration: ICampaignRegistration;
  referralCode: string;
  isLoading = true;
  currentStepIndex = 0;
  reCaptchaAction = ReCaptchaAction;
  verificationCode?: string;

  private formValues: IUserCreateFormValues;

  get enableAlternateReCaptcha(): boolean {
    return [ReCaptchaAction.createUser, ReCaptchaAction.createCampaignUser].some(
      (a) => this.reCaptchaService?.enableAlternateReCaptcha?.[a]
    );
  }

  get currentStep(): IRegistrationStep | undefined {
    return this.content.steps?.[this.currentStepIndex];
  }

  get hasPreviousStep(): boolean {
    return !!this.content.steps?.[this.currentStepIndex - 1];
  }

  get currentStepText(): IText | undefined {
    return ObjectHelper.wrapArrayToField(this.currentStep?.stepText);
  }

  get buttonText(): string {
    let text =
      this.currentStepIndex + 1 !== this.content.steps?.length
        ? this.translateService.instant('general.label.next')
        : this.translateService.instant('account.label.register');
    if (this.content.steps && this.content.steps?.length > 1) {
      text +=
        ' ' +
        this.translateService.instant('account.label.step', {
          current: this.currentStepIndex + 1,
          total: this.content.steps?.length
        });
    }
    return text;
  }

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private elementRef: ElementRef<HTMLElement>,
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    protected reCaptchaService: ReCaptchaService,
    private userService: UserService,
    private campaignRegistrationService: CampaignRegistrationService,
    private tokenService: TokenService,
    private translateService: TranslateService,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private modalHelper: ModalHelper,
    private verificationHelper: VerificationHelper,
    private inboxHelper: InboxHelper
  ) {
    super(userEventService, platformHelper, toastService, reCaptchaService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.getReferralParams();
    this.verificationHelper.initialize({ content: this.content, userEventSource: this.userEventSource });

    this.createForm();
    this.isLoading = false;
  }

  nextStep(event: Event): void {
    this.pushUserEvent(UserEventAction.paging, event.text());

    if (!this.formComponent.checkActiveFormValidity()) {
      return;
    }

    this.currentStepIndex++;
    this.updateSections();
  }

  previousStep(event: Event): void {
    this.pushUserEvent(UserEventAction.paging, event.text());

    this.currentStepIndex--;
    this.updateSections();
  }

  async submitValues(values: IUserCreateFormValues): Promise<void> {
    this.isSubmitting = true;

    // Prepare form values for backend
    values.origin = this.content.origin;
    if (values.hasCard === FormBoolean.no) {
      values.cardNumber = undefined;
    }

    if (this.campaignRegistrationValues) {
      values.emailAddress = this.campaignRegistrationValues.emailAddress;
      const [campaignRegistrationSettings] = ObjectHelper.wrapFieldToArray(this.campaignRegistration.campaignRegistrationSettings);

      if (campaignRegistrationSettings.newsletterApprovalMode === NewsletterApprovalMode.optionalStep2) {
        if (!values.receivePromotionalEmails) {
          this.newsletterSuggestionModal.action = async () => {
            values.receivePromotionalEmails = true;
            this.formComponent.form.get(FormFieldName.receivePromotionalEmails)?.setValue(true);
            await this.registerCampaign(values);
          };

          this.newsletterSuggestionModal.cancelAction = () => this.registerCampaign(values);

          if (!this.verificationCode) {
            return this.modalHelper.triggerConfirmationModal(this.newsletterSuggestionModal);
          }
        }
      } else {
        values.receivePromotionalEmails = this.campaignRegistrationValues.receivePromotionalEmails;
      }

      void this.registerCampaign(values);
    } else {
      void this.registerAccount(values);
    }
  }

  private updateSections(): void {
    this.form.forEach((formSection) => {
      formSection.hidden = !this.currentStep?.sections.some((stepSection) => stepSection === formSection.sectionType);
    });

    if (this.document.activeElement instanceof HTMLElement) {
      this.document.activeElement?.blur();
    }
    this.stepHeader?.nativeElement.scrollIntoView({ behavior: 'smooth' });

    setTimeout(() => {
      this.elementRef.nativeElement
        .querySelector('.form-section:not([hidden])')
        ?.querySelector<HTMLElement>('input, select, textarea, button')
        ?.focus();
    }, 300);
  }

  private async registerCampaign(values: IUserCreateFormValues): Promise<void> {
    this.isSubmitting = true;
    this.formValues = values;

    if (this.verificationCode) {
      this.registerCampaignAction(this.verificationCode);
    } else {
      return await this.verificationHelper.triggerVerificationModal({
        verifyType: VerificationCodeMessageType.email,
        emailAddress: values.emailAddress,
        verifyCallback: this.registerCampaignAction.bind(this) as (verificationCode: string) => Promise<void>,
        closeCallback: () => (this.isSubmitting = false)
      });
    }
  }

  private async registerCampaignAction(verificationCode?: string): Promise<void> {
    this.verificationCode = verificationCode;
    const request = new UserCampaignCreateRequest(
      this.formValues,
      this.campaignRegistrationValues.campaignId,
      this.campaignRegistrationValues.campaignRegistrationSettingsId,
      this.referralCode
    );
    request.emailAddressVerificationCode = verificationCode;

    await this.reCaptchaService
      .verify(
        ReCaptchaAction.createCampaignUser,
        request,
        this.campaignRegistrationService.createCampaignUser.bind(this.campaignRegistrationService)
      )
      .then(async () => {
        // Do login
        const loginRequest = new PasswordLoginRequest(this.formValues.emailAddress, this.formValues.password);
        await this.reCaptchaService
          .verify(
            ReCaptchaAction.createPasswordLoginToken,
            loginRequest,
            this.tokenService.createPasswordLoginToken.bind(this.tokenService)
          )
          .finally(() => {
            this.pushUserSuccessEvent();

            void this.route.navigate([this.campaignRegistrationValues.selectedCampaignRegistrationOption?.registrationSuccessPage._url]);
          });
      })
      .catch(() => {});

    this.isSubmitting = false;
  }

  private async registerAccount(values: IUserCreateFormValues) {
    this.isSubmitting = true;
    this.formValues = values;

    if (this.verificationCode) {
      this.registerAccountAction(this.verificationCode);
    } else {
      return await this.verificationHelper.triggerVerificationModal({
        verifyType: VerificationCodeMessageType.email,
        emailAddress: values.emailAddress,
        verifyCallback: async (verificationCode: string) => {
          await this.registerAccountAction(verificationCode);
        },
        closeCallback: () => (this.isSubmitting = false)
      });
    }
  }

  private async registerAccountAction(verificationCode?: string) {
    this.verificationCode = verificationCode;
    const request = new UserCreateRequest(this.formValues, this.referralCode);

    request.emailAddressVerificationCode = verificationCode;

    await this.reCaptchaService
      .verify(ReCaptchaAction.createUser, request, this.userService.createUser.bind(this.userService))
      .then(async () => {
        // Do login
        const loginRequest = new PasswordLoginRequest(this.formValues.emailAddress, this.formValues.password);
        await this.reCaptchaService
          .verify(
            ReCaptchaAction.createPasswordLoginToken,
            loginRequest,
            this.tokenService.createPasswordLoginToken.bind(this.tokenService)
          )
          .finally(() => {
            this.pushUserSuccessEvent();

            void (async () => {
              await this.inboxHelper.refreshUnreadInboxCount();

              //Delayed refresh of unread inbox count, making account in message provider can be delayed
              if (this.inboxHelper.unreadInboxCount$.value === 0) {
                setTimeout(() => {
                  void this.inboxHelper.refreshUnreadInboxCount();
                }, 10000);
              }
            })();

            void this.route.navigate([(this.content as IRegistrationForm).successPage._url]);
          });
      })
      .catch(() => {});

    this.isSubmitting = false;
  }

  private getReferralParams(): void {
    this.activatedRoute.queryParams.pipe(takeUntil(this.destroy$)).subscribe((params) => {
      if (params.referralCode) {
        this.referralCode = params.referralCode as string;
      }
    });
  }

  private createForm(): void {
    if (!this.content.steps?.length) {
      //If not customizable in backed use default configuration (for campaign registration)
      this.content.steps = [
        {
          sections: [
            RegistrationStepSection.EmailAddress,
            RegistrationStepSection.PersonalData,
            RegistrationStepSection.Address,
            RegistrationStepSection.CurrentCard,
            RegistrationStepSection.Password,
            RegistrationStepSection.Newsletter
          ]
        }
      ];
    }

    this.content.steps?.forEach((step) => {
      step.sections.forEach((section) => {
        switch (section) {
          case RegistrationStepSection.Address:
            this.form.push(this.addressSection());
            break;
          case RegistrationStepSection.CurrentCard:
            this.form.push(this.currentCardSection());
            break;
          case RegistrationStepSection.EmailAddress:
            if (!this.campaignRegistrationValues) {
              this.form.push(this.emailAddressSection());
            } else {
              this.campaignRegistration = this.content as ICampaignRegistration;
            }
            break;
          case RegistrationStepSection.Password:
            this.form.push(this.passwordSection());
            break;
          case RegistrationStepSection.PersonalData:
            this.form.push(this.personalDataSection());
            break;
          case RegistrationStepSection.Newsletter:
            this.form.push(this.newsletterSection());
            break;
        }
      });
    });
  }

  private addressSection(): IFormSection {
    return {
      title: this.translateService.instant('account.label.your_address'),
      isGrid: true,
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.Address),
      sectionType: RegistrationStepSection.Address,
      controls: [
        {
          type: FormType.postalCode,
          label: this.translateService.instant('account.label.postal_code'),
          name: FormFieldName.postalCode,
          autocomplete: 'postal-code',
          asyncValidators: [
            {
              validator: FormValidatorType.wrapValidators([
                FormValidatorType.required,
                FormValidatorType.pattern(FormRegex.postalCode.getRegExp()),
                FormValidatorType.addressSuggestion(
                  this.reCaptchaService.verify.bind(this.reCaptchaService),
                  this.userService.getAddressSuggestion.bind(this.userService),
                  false
                )
              ]),
              errorMessages: {
                [FormValidatorTypeKeys.required]: this.translateService.instant('account.error.postal_code.required'),
                [FormValidatorTypeKeys.pattern]: this.translateService.instant('account.error.postal_code.invalid'),
                [FormValidatorTypeKeys.getAddressSuggestion]: this.content.addressInvalidNotice
              }
            }
          ],
          containerClass: 'col-4 col-2--md col-4--sm'
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.house_number'),
          name: FormFieldName.houseNumber,
          autocomplete: 'empty',
          asyncValidators: [
            {
              validator: FormValidatorType.wrapValidators([
                FormValidatorType.required,
                FormValidatorType.pattern(FormRegex.houseNumber.getRegExp()),
                FormValidatorType.addressSuggestion(
                  this.reCaptchaService.verify.bind(this.reCaptchaService),
                  this.userService.getAddressSuggestion.bind(this.userService),
                  false
                )
              ]),
              errorMessages: {
                [FormValidatorTypeKeys.required]: this.translateService.instant('account.error.house_number.required'),
                [FormValidatorTypeKeys.pattern]: this.translateService.instant('account.error.house_number.invalid')
              }
            }
          ],
          containerClass: 'col-4 col-2--md col-2--sm'
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.house_number_supplement'),
          name: FormFieldName.houseNumberSupplement,
          autocomplete: 'empty',
          disabled: true,
          validators: [
            {
              validator: FormValidatorType.pattern(FormRegex.houseNumberSupplement.getRegExp()),
              errorMessage: this.translateService.instant('account.error.house_number_supplement.invalid')
            }
          ],
          containerClass: 'col-4 col-2--md col-2--sm'
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.street_name'),
          name: FormFieldName.streetName,
          autocomplete: 'address-line1',
          disabled: true,
          runValidatorsSequentially: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.street_name.required')
            },
            {
              validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
              errorMessage: this.translateService.instant('account.error.street_name.invalid')
            }
          ],
          asyncValidators: [
            {
              validator: FormValidatorType.addressLineAutoComplete()
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.city'),
          name: FormFieldName.city,
          autocomplete: 'address-level2',
          disabled: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.city.required')
            },
            {
              validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
              errorMessage: this.translateService.instant('account.error.city.invalid')
            }
          ]
        } as ITextControl
      ]
    } as IFormSection;
  }

  private currentCardSection(): IFormSection {
    return {
      title: this.translateService.instant('account.label.do_you_already_have_a_card'),
      additionalClass: 'form-section--has-card',
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.CurrentCard),
      sectionType: RegistrationStepSection.CurrentCard,
      controls: [
        {
          name: FormFieldName.hasCard,
          type: FormType.radio,
          value: FormBoolean.no,
          options: [
            {
              value: FormBoolean.no,
              text: this.translateService.instant('account.label.no_card_yet')
            },
            {
              value: FormBoolean.yes,
              text: this.translateService.instant('account.label.already_have_a_card')
            }
          ],
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.has_card.required')
            }
          ]
        } as IRadioControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.your_current_card_number'),
          name: FormFieldName.cardNumber,
          showWhen: { controlName: FormFieldName.hasCard, value: FormBoolean.yes } as IShowCondition,
          containerClass: 'form-group--card-number',
          description: this.translateService.instant('account.description.card_number_barcode'),
          textOnlyDescription: true,
          runValidatorsSequentially: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.card_number.required')
            },
            {
              validator: FormValidatorType.multiPattern(FormRegex.cardNumber),
              errorMessage: this.translateService.instant('account.error.card_number.invalid')
            }
          ],
          asyncValidators: [
            {
              validator: FormValidatorType.checkCardStatus(
                this.reCaptchaService.verify.bind(this.reCaptchaService),
                this.userService.checkCardStatus.bind(this.userService)
              )
            }
          ]
        } as ITextControl
      ]
    } as IFormSection;
  }

  private emailAddressSection(): IFormSection {
    return {
      title: this.translateService.instant('account.label.your_email'),
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.EmailAddress),
      sectionType: RegistrationStepSection.EmailAddress,
      controls: [
        {
          type: FormType.email,
          label: this.translateService.instant('account.label.email'),
          name: FormFieldName.emailAddress,
          autocomplete: 'email',
          description: this.content?.emailVerificationNotice?.length ? this.content.emailVerificationNotice : null,
          runValidatorsSequentially: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.email.required')
            },
            { validator: FormValidatorType.email, errorMessage: this.translateService.instant('account.error.email.invalid') }
          ],
          asyncValidators: [
            {
              validator: FormValidatorType.checkUserExistence(
                this.reCaptchaService.verify.bind(this.reCaptchaService),
                this.userService.checkUserExistence.bind(this.userService)
              )
            }
          ]
        } as IRepeatControl
      ]
    } as IFormSection;
  }

  private passwordSection(): IFormSection {
    return {
      title: this.translateService.instant('account.label.your_login_information'),
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.Password),
      sectionType: RegistrationStepSection.Password,
      controls: [
        {
          type: FormType.repeat,
          label: this.translateService.instant('account.label.password'),
          name: FormFieldName.password,
          autocomplete: 'new-password',
          fullWidth: false,
          controlType: FormType.password,
          enableShowPassword: true,
          showValidationChecklist: true,
          validationChecklistTitle: this.translateService.instant('account.label.password_requirements'),
          repeatControlLabel: this.translateService.instant('account.label.repeat_password'),
          repeatErrorMessage: this.translateService.instant('account.error.password.repeat'),
          repeatChecklistMessage: this.translateService.instant('account.error.password.identical'),
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.password.required'),
              hideFromChecklist: true
            },
            {
              validator: FormValidatorType.pattern(FormRegex.symbols.getRegExp()),
              errorMessage: this.translateService.instant('account.error.password.invalid_special_chars'),
              hideFromChecklist: true
            },
            {
              validator: FormValidatorType.minLength(10),
              errorMessage: this.translateService.instant('account.error.password.min_length')
            },
            {
              validator: FormValidatorType.maxLength(60),
              errorMessage: this.translateService.instant('account.error.password.max_length')
            },
            {
              validator: FormValidatorType.multiPattern(FormRegex.atLeastOneUppercase),
              errorMessage: this.translateService.instant('account.error.password.uppercase')
            },
            {
              validator: FormValidatorType.multiPattern(FormRegex.atLeastOneLowercase),
              errorMessage: this.translateService.instant('account.error.password.lowercase')
            },
            {
              validator: FormValidatorType.multiPattern(FormRegex.atLeastOneDigit),
              errorMessage: this.translateService.instant('account.error.password.number')
            },
            {
              validator: FormValidatorType.multiPattern(FormRegex.atLeastOneSymbol),
              errorMessage: this.translateService.instant('account.error.password.symbols')
            },
            {
              validator: FormValidatorType.passwordRequirements(),
              errorMessage: this.translateService.instant('account.error.password.requirements'),
              hideFromChecklist: true
            }
          ]
        } as IRepeatControl
      ]
    } as IFormSection;
  }

  private personalDataSection(): IFormSection {
    return {
      title: this.translateService.instant('account.label.your_information'),
      isGrid: true,
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.PersonalData),
      sectionType: RegistrationStepSection.PersonalData,
      controls: [
        {
          type: FormType.select,
          label: this.translateService.instant('account.label.title'),
          name: FormFieldName.gender,
          placeholder: this.translateService.instant('account.label.choose_title'),
          containerClass: 'col-6 col-3--sm col-4--sm',
          options: [
            { text: this.translateService.instant('account.label.title_male'), value: Gender.male },
            { text: this.translateService.instant('account.label.title_female'), value: Gender.female },
            { text: this.translateService.instant('account.label.title_neutral'), value: Gender.neutral }
          ]
        } as ISelectControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.first_name'),
          name: FormFieldName.firstName,
          autocomplete: 'given-name',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.first_name.required')
            },
            {
              validator: FormValidatorType.pattern(FormRegex.humanName.getRegExp()),
              errorMessage: this.translateService.instant('account.error.first_name.invalid')
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.last_name'),
          name: FormFieldName.lastName,
          autocomplete: 'family-name',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.last_name.required')
            },
            {
              validator: FormValidatorType.pattern(FormRegex.humanName.getRegExp()),
              errorMessage: this.translateService.instant('account.error.last_name.invalid')
            }
          ]
        } as ITextControl,
        {
          type: FormType.date,
          label: this.translateService.instant('account.label.birth_date'),
          name: FormFieldName.birthDate,
          autocomplete: 'bday',
          placeholder: this.translateService.instant('account.label.birth_date_placeholder'),
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.birth_date.required')
            },
            {
              validator: FormValidatorType.pattern(FormRegex.date.getRegExp()),
              errorMessage: this.translateService.instant('account.error.birth_date.invalid')
            },
            {
              validator: FormValidatorType.birthDateWithMinimumAge, // Checks birth year
              errorMessage: this.translateService.instant('account.error.birth_date.invalid_year')
            }
          ]
        } as ITextControl
      ]
    } as IFormSection;
  }

  private newsletterSection(): IFormSection {
    const newsletterSection = {
      controls: [],
      hidden: !this.currentStep?.sections.some((s) => s === RegistrationStepSection.Newsletter),
      sectionType: RegistrationStepSection.Newsletter
    } as IFormSection;
    const [campaignRegistrationSettings] = ObjectHelper.wrapFieldToArray(this.campaignRegistration?.campaignRegistrationSettings);

    if (!this.campaignRegistrationValues || campaignRegistrationSettings?.newsletterApprovalMode === NewsletterApprovalMode.optionalStep2) {
      // Show opt-in checkbox
      newsletterSection.title = this.translateService.instant('account.label.newsletter');
      const newsletterBenefitsText = ObjectHelper.wrapArrayToField(this.content.newsletterBenefitsText);
      if (newsletterBenefitsText) {
        newsletterSection.body = `
        <div class="toast__item form--register__newsletter">
          <div class="toast__content">
            <h4 class="toast__title">${newsletterBenefitsText.title}</h4>
            <div class="toast__message">${newsletterBenefitsText.body}</div>
          </div>
        </div>`;
      }

      newsletterSection.controls.push({
        type: FormType.checkbox,
        label: this.content.newsletterApproval,
        name: FormFieldName.receivePromotionalEmails,
        description: `<hr />`,
        containerClass: 'form--register__newsletter-checkbox'
      } as IFormControl);

      if (!this.campaignRegistrationValues) {
        if (this.content.terms?.length) {
          newsletterSection.controls.push({
            type: FormType.checkbox,
            label: this.content.terms,
            name: FormFieldName.acceptTerms,
            containerClass: 'form--register__terms',
            validators: [
              {
                validator: FormValidatorType.requiredTrue
              }
            ],
            description: this.content.dataNotice
          } as IFormControl);
        } else {
          newsletterSection.controls.push({
            description: this.content.dataNotice
          } as IFormControl);
        }
      }
    }
    return newsletterSection;
  }
}
