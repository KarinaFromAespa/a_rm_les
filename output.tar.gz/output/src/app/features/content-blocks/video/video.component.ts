import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ContentBlockRegion, IVideo } from 'src/app/core/models/content.model';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-video',
  templateUrl: './video.component.html',
  standalone: false
})
export class VideoComponent implements IContentBlockComponent, OnInit {
  className = 'video';
  contentBlockRegion = ContentBlockRegion;
  region: ContentBlockRegion;
  isFirst: boolean;
  content: IVideo;
  userEventSource: string;

  url: SafeResourceUrl;

  constructor(private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.content.videoUrl);
  }
}
