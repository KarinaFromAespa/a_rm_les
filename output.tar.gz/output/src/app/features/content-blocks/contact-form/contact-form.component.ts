import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { FormBoolean, FormFieldName, FormType, Gender } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContactFormQuestion, IContactFormValues, PublicContactFormRequest } from 'src/app/core/models/contact-form.model';
import { ContentBlockRegion, IContactForm } from 'src/app/core/models/content.model';
import { FileType, IUploadedFile } from 'src/app/core/models/file.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFileControl, IFormControl, IFormSection, IRadioControl, ISelectControl, ITextControl } from 'src/app/core/models/form.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { FormsService } from 'src/app/core/services/forms.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { BaseFormComponent } from '../../form/base-form.component';
import { ModalLoginHelper } from '../../modal/modal-login.helper';
import { ModalHelper } from '../../modal/modal.helper';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-contact-form',
  templateUrl: './contact-form.component.html',
  standalone: false
})
export class ContactFormComponent
  extends BaseFormComponent<IContactFormValues>
  implements IContentBlockComponent, OnInit, AfterViewInit, OnDestroy
{
  className = 'contact-form';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IContactForm;
  userEventSource: string;

  accountOptionsSection: IFormSection;
  loginRequired: boolean;
  isLoggedIn: boolean;
  destroy$ = new Subject();

  private files: IUploadedFile[];

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    protected recaptchaService: ReCaptchaService,
    private translateService: TranslateService,
    private modalHelper: ModalHelper,
    private modalLoginHelper: ModalLoginHelper,
    private userHelper: UserHelper,
    private userService: UserService,
    private formsService: FormsService,
    private route: Router
  ) {
    super(userEventService, platformHelper, toastService, recaptchaService);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.accountOptionsSection = {
      hidden: false,
      additionalClass: 'form-section--no-padding',
      controls: [
        {
          name: FormFieldName.hasAccount,
          type: FormType.radio,
          value: FormBoolean.yes,
          options: [
            {
              value: FormBoolean.yes,
              text: this.translateService.instant('account.label.already_have_an_account_can_log_in') as string
            },
            {
              value: FormBoolean.no,
              text: this.translateService.instant('account.label.no_account_yet_cannot_log_in') as string
            }
          ],
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.has_account.required') as string
            }
          ]
        } as IRadioControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          label: this.translateService.instant('account.label.email') as string,
          name: FormFieldName.emailAddress,
          autocomplete: 'email',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.email.required') as string
            },
            {
              validator: FormValidatorType.email,
              errorMessage: this.translateService.instant('account.error.email.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.select,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          label: this.translateService.instant('account.label.title') as string,
          name: FormFieldName.gender,
          placeholder: this.translateService.instant('account.label.choose_title') as string,
          options: [
            { text: this.translateService.instant('account.label.title_male') as string, value: Gender.male },
            { text: this.translateService.instant('account.label.title_female') as string, value: Gender.female },
            { text: this.translateService.instant('account.label.title_neutral') as string, value: Gender.neutral }
          ]
        } as ISelectControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          label: this.translateService.instant('account.label.last_name') as string,
          name: FormFieldName.lastName,
          autocomplete: 'family-name',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.last_name.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.humanName.getRegExp()),
              errorMessage: this.translateService.instant('account.error.last_name.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.date,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeBirthDate,
          label: this.translateService.instant('account.label.birth_date') as string,
          name: FormFieldName.birthDate,
          autocomplete: 'bday',
          placeholder: this.translateService.instant('account.label.birth_date_placeholder') as string,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.birth_date.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.date.getRegExp()),
              errorMessage: this.translateService.instant('account.error.birth_date.invalid') as string
            },
            {
              validator: FormValidatorType.birthDate,
              errorMessage: this.translateService.instant('account.error.birth_date.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.postalCode,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeAddress,
          label: this.translateService.instant('account.label.postal_code') as string,
          name: FormFieldName.postalCode,
          autocomplete: 'postal-code',
          runValidatorsSequentially: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.postal_code.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.postalCode.getRegExp()),
              errorMessage: this.translateService.instant('account.error.postal_code.invalid') as string
            }
          ],
          asyncValidators: [
            {
              validator: FormValidatorType.addressSuggestion(
                this.recaptchaService.verify.bind(this.reCaptchaService),
                this.userService.getAddressSuggestion.bind(this.userService)
              )
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeAddress,
          label: this.translateService.instant('account.label.house_number') as string,
          name: FormFieldName.houseNumber,
          autocomplete: 'empty',
          runValidatorsSequentially: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.house_number.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.houseNumber.getRegExp()),
              errorMessage: this.translateService.instant('account.error.house_number.invalid') as string
            }
          ],
          asyncValidators: [
            {
              validator: FormValidatorType.addressSuggestion(
                this.recaptchaService.verify.bind(this.reCaptchaService),
                this.userService.getAddressSuggestion.bind(this.userService)
              )
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeAddress,
          label: this.translateService.instant('account.label.house_number_supplement') as string,
          name: FormFieldName.houseNumberSupplement,
          autocomplete: 'empty',
          validators: [
            {
              validator: FormValidatorType.pattern(FormRegex.houseNumberSupplement.getRegExp()),
              errorMessage: this.translateService.instant('account.error.house_number_supplement.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeAddress,
          label: this.translateService.instant('account.label.street_name') as string,
          name: FormFieldName.streetName,
          autocomplete: 'address-line1',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.street_name.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
              errorMessage: this.translateService.instant('account.error.street_name.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          hidden: !this.content.includeAddress,
          label: this.translateService.instant('account.label.city') as string,
          name: FormFieldName.city,
          autocomplete: 'address-level2',
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.city.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.address.getRegExp()),
              errorMessage: this.translateService.instant('account.error.city.invalid') as string
            }
          ]
        } as ITextControl,
        {
          type: FormType.text,
          label: this.translateService.instant('account.label.card_number') as string,
          hidden: !this.content.includeCardNumber,
          name: FormFieldName.cardNumber,
          showWhen: { controlName: FormFieldName.hasAccount, value: FormBoolean.no },
          containerClass: 'form-group--card-number',
          description: this.translateService.instant('account.description.card_number') as string,
          textOnlyDescription: true,
          validators: [
            {
              validator: FormValidatorType.required,
              errorMessage: this.translateService.instant('account.error.card_number.required') as string
            },
            {
              validator: FormValidatorType.pattern(FormRegex.cardNumber.getRegExp()),
              errorMessage: this.translateService.instant('account.error.card_number.invalid') as string
            }
          ]
        } as ITextControl
      ]
    };

    this.updateLoggedIn();

    // Build form
    this.form = [
      {
        title: this.content.title,
        controls: [
          {
            name: FormFieldName.question,
            type: FormType.textarea,
            label: this.translateService.instant('contact_form.label.your_question') as string,
            validators: [
              {
                validator: FormValidatorType.required
              },
              {
                validator: FormValidatorType.maxLength(1000),
                errorMessage: this.translateService.instant('contact_form.error.question.invalid_too_long') as string
              },
              {
                validator: FormValidatorType.pattern(FormRegex.question.getRegExp()),
                errorMessage: this.translateService.instant('contact_form.error.question.invalid_special_chars') as string
              }
            ]
          } as IFormControl,
          {
            name: FormFieldName.file,
            type: FormType.file,
            allowedTypes: [FileType.pdf, FileType.doc, FileType.docx, FileType.jpg, FileType.jpeg, FileType.png]
          } as IFileControl
        ]
      } as IFormSection,
      this.accountOptionsSection
    ];

    this.userHelper.isLoggedInChanged$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.updateLoggedIn();
    });
  }

  ngAfterViewInit(): void {
    this.formComponent?.form
      ?.get(FormFieldName.hasAccount)
      ?.valueChanges.pipe(takeUntil(this.destroy$), distinctUntilChanged())
      .subscribe(() => {
        this.updateLoggedIn();
      });
  }

  ngOnDestroy(): void {
    super.ngOnDestroy();
    this.destroy$.next(void 0);
  }

  setFiles(files: IUploadedFile[]): void {
    this.files = files;
  }

  submit(event: Event): void {
    this.pushUserEvent(UserEventAction.submit, event.text(), this.content.category);
    super.submit(event, false);
  }

  async submitValues(values: IContactFormValues): Promise<void> {
    values.uploadedFiles = this.files;

    // If not logged in, show and await password login modal
    if (!this.isLoggedIn && values.hasAccount === FormBoolean.yes) {
      await this.modalLoginHelper.triggerPasswordLoginModal(this.userEventSource, undefined, undefined, () => {
        this.updateLoggedIn();
        void (async () => {
          await this.triggerContactInformationModal(values);
        })();
      });
      return;
    }

    // If already logged in show contact information modal
    if (await this.triggerContactInformationModal(values)) {
      return;
    }

    // Send question when logged in
    this.isSubmitting = true;

    await this.reCaptchaService
      ?.verify(
        ReCaptchaAction.sendPublicContactForm,
        new PublicContactFormRequest(values, this.content.category),
        this.formsService.publicContact.bind(this.formsService)
      )
      .then(() => {
        void this.route.navigate([this.content.successPage._url]);
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  async triggerContactInformationModal(values: IContactFormValues): Promise<boolean> {
    if (this.isLoggedIn) {
      const currentUserDetails = await this.userService.getUserContactDetails();

      await this.modalHelper.triggerContactInformationModal(
        new ContactFormQuestion(values, this.content.category),
        currentUserDetails,

        this.content.successPage._url,
        this.userEventSource
      );
      return true;
    }
    return false;
  }

  private updateLoggedIn(): void {
    this.isLoggedIn = this.userHelper.isLoggedIn;
    this.accountOptionsSection.hidden = this.isLoggedIn;

    this.loginRequired =
      !this.isLoggedIn && (!this.formComponent || this.formComponent.form?.get(FormFieldName.hasAccount)?.value === FormBoolean.yes);
  }
}
