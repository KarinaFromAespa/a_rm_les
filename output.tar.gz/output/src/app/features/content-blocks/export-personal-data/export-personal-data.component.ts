import { Component, OnInit } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion, IPersonalData } from 'src/app/core/models/content.model';
import { IFileUrl } from 'src/app/core/models/file.response';
import { PersonalDataState, PersonalDataStatus } from 'src/app/core/models/user.model';
import { PersonalDataService } from 'src/app/core/services/personal-data.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-export-personal-data',
  templateUrl: './export-personal-data.component.html',
  standalone: false
})
export class ExportPersonalDataComponent implements IContentBlockComponent, OnInit {
  className = 'export-personal-data';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IPersonalData;
  userEventSource: string;

  personalDataStatus = PersonalDataStatus;
  personalDataState = PersonalDataState;

  personalDataView: PersonalDataState;
  personalDataLink: string;
  status: PersonalDataStatus;

  isSubmitting = false;
  loading: boolean;

  constructor(
    private personalDataService: PersonalDataService,
    private toastService: ToastService,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.loading = true;

    this.getPersonalDataStatus().finally(() => {
      this.loading = false;
    });
  }

  getPersonalDataStatus(): Promise<void> {
    return this.personalDataService.checkPersonalDataStatus().then((status) => {
      this.status = status.personalDataExportStatus;
      switch (this.status) {
        case PersonalDataStatus.notFound:
        default:
          this.personalDataView = PersonalDataState.request;
          break;
        case PersonalDataStatus.pending:
          this.personalDataView = PersonalDataState.processing;
          break;
        case PersonalDataStatus.available:
        case PersonalDataStatus.downloaded:
          this.personalDataView = PersonalDataState.download;
          break;
        case PersonalDataStatus.expired:
          this.personalDataView = PersonalDataState.downloadExpired;
          break;
      }
    });
  }

  requestPersonalData(event: Event): void {
    this.pushUserEvent(UserEventAction.submit, event);
    this.isSubmitting = true;
    void this.personalDataService
      .exportUserPersonalData()
      .then(() => {
        this.personalDataView = PersonalDataState.processing;
        this.toastService.show(
          new ToastOptions({
            type: ToastType.success,
            content: this.content.requestSuccessText
          })
        );
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  getPersonalData(event: Event): void {
    this.isSubmitting = true;
    this.pushUserEvent(UserEventAction.download, event);
    this.personalDataService
      .getUserPersonalData()
      .then((file: IFileUrl) => {
        if (PlatformHelper.isNativeMobile) {
          // If in app open in browser
          window.open(file.url, '_system');
        } else {
          window.location.href = file.url;
        }
      })
      .finally(() => {
        void this.getPersonalDataStatus();
        this.isSubmitting = false;
      });
  }

  private pushUserEvent(action: UserEventAction, event: Event) {
    this.userEventService.pushEvent(this.userEventSource, action, event.text());
  }
}
