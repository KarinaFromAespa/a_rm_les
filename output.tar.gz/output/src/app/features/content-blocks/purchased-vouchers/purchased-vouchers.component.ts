import { Component, OnInit } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ContentBlockRegion, IPurchasedVouchers } from 'src/app/core/models/content.model';
import { IOrderVouchers, VoucherDeliveryRequest } from 'src/app/core/models/voucher.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { VoucherService } from 'src/app/core/services/voucher.service';
import { ModalHelper } from '../../modal/modal.helper';
import { ModalButton } from '../../modal/modal.model';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-purchased-vouchers',
  templateUrl: './purchased-vouchers.component.html',
  standalone: false
})
export class PurchasedVouchersComponent implements IContentBlockComponent, OnInit {
  className: string;
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IPurchasedVouchers;
  userEventSource: string;

  vouchers: IOrderVouchers[] = [];
  displayedVouchers: IOrderVouchers[] = [];

  numberDisplayed = 0;

  loading = true;
  redeliverVouchersButton: ModalButton;

  constructor(
    private voucherService: VoucherService,
    private toastService: ToastService,
    private modalHelper: ModalHelper,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    void this.voucherService
      .getVouchers()
      .then((data) => {
        this.vouchers = data.map((x) => {
          // Calculate if vouchers are still valid
          const maxValidityDate = Math.max(
            ...x.vouchers
              .filter((y) => !!y.validity)
              .map((y) => {
                const expiryDate = new Date(y.validity!);
                expiryDate.setHours(0);
                const expiryTimeValue = expiryDate.getTime();
                expiryDate.setDate(expiryDate.getDate() + 1);
                y.expired = expiryDate <= new Date();
                return expiryTimeValue;
              })
          );

          const validityCutOff = new Date(maxValidityDate);
          validityCutOff.setDate(validityCutOff.getDate() + 7);
          x.showGenerateLink =
            x.vouchers.some((y) => !y.downloadUrl) && (x.vouchers.some((y) => !y.validity) || validityCutOff >= new Date());
          return x;
        });

        this.displayMoreVouchers();
      })
      .finally(() => {
        this.loading = false;
      });
  }

  async triggerRedeliverVouchers(orders: IOrderVouchers, event: Event): Promise<void> {
    this.pushUserEvent(UserEventAction.submit, event);
    await this.modalHelper.triggerConfirmationModal({
      text: this.content.generationConfirmationText,
      action: async () => {
        await this.redeliverVouchers(orders);
      },
      userEventSource: this.userEventSource,
      userEventSourceTopic: 'redelivery'
    });
  }

  async redeliverVouchers(order: IOrderVouchers): Promise<void> {
    await this.voucherService.redeliverVouchers(new VoucherDeliveryRequest(order.vouchers.map((x) => x.voucherCode))).then(() => {
      this.toastService.show(
        new ToastOptions({
          content: this.content.generationSuccessText,
          type: ToastType.success
        })
      );
    });
  }

  displayMoreVouchers(): void {
    this.numberDisplayed = Math.min(this.vouchers.length, this.numberDisplayed + this.content.numberOfOrders);
    this.displayedVouchers = this.vouchers.slice(0, this.numberDisplayed);
  }

  downloadClick(event: Event): void {
    this.pushUserEvent(UserEventAction.download, event);
  }

  private pushUserEvent(action: UserEventAction, event: Event) {
    this.userEventService.pushEvent(this.userEventSource, action, event.text());
  }
}
