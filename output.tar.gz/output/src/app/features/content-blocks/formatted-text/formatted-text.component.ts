import { Component } from '@angular/core';
import { Alignment } from 'src/app/core/models/content.model';
import { AbstractFormattedTextComponent } from 'src/app/features/content-blocks/formatted-text/formatted-text-component.abstract';

@Component({
  selector: 'air-formatted-text',
  templateUrl: './formatted-text.component.html',
  standalone: false
})
export class FormattedTextComponent extends AbstractFormattedTextComponent {
  className = 'formatted-text';

  get alignment(): string {
    return this.alignedImage.alignment === Alignment.before ? 'left' : 'right';
  }
}
