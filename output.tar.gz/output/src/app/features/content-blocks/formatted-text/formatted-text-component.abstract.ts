import { Component, OnInit } from '@angular/core';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ContentBlockRegion, IAlignedImage, IFormattedText } from '../../../core/models/content.model';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  template: '',
  standalone: false
})
export abstract class AbstractFormattedTextComponent implements IContentBlockComponent, OnInit {
  className: string;
  content: IFormattedText;
  isFirst: boolean;
  region: ContentBlockRegion;
  alignedImage: IAlignedImage;
  userEventSource: string;

  get hasLinks(): boolean {
    return !!this.content.links?.length;
  }

  ngOnInit(): void {
    const [alignedImage] = ObjectHelper.wrapFieldToArray(this.content.alignedImage);
    this.alignedImage = alignedImage;
  }

  getButtonClass(): string {
    const classNames: string[] = [];

    if (this.content.emphasizeLinks) {
      classNames.push('button--cta');
    } else {
      if (this.region === ContentBlockRegion.secondary) {
        classNames.push('button--tertiary');
      } else {
        classNames.push('button--border');
        classNames.push('button--transparent');
      }
    }

    return classNames.join(' ');
  }
}
