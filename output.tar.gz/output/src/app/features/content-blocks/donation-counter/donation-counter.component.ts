import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subject, delay, first, lastValueFrom, of, takeUntil } from 'rxjs';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ContentBlockRegion, IDonationCounter } from 'src/app/core/models/content.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { ICharity } from 'src/app/core/models/product.model';
import { IPageLink } from 'src/app/core/models/site.response';
import { IDonationOverview } from 'src/app/core/models/transaction.model';
import { SiteService } from 'src/app/core/services/site.service';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { CounterComponent } from 'src/app/shared/components/counter/counter.component';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-donation-counter',
  templateUrl: './donation-counter.component.html',
  standalone: false
})
export class DonationCounterComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'donation-counter';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IDonationCounter;
  userEventSource: string;

  canLoad = true;
  charity?: ICharity;
  donationOverview?: IDonationOverview;
  destroy$ = new Subject();

  get link(): IPageLink | undefined {
    return ObjectHelper.wrapArrayToField(this.content.link);
  }

  @ViewChild(CounterComponent)
  private counterComponent?: CounterComponent;

  constructor(
    private siteService: SiteService,
    private transactionService: TransactionService
  ) {}

  async ngOnInit(): Promise<void> {
    await this.getCharity();
    if (!this.canLoad) {
      return;
    }

    this.getDonationOverview();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private getDonationOverview(): void {
    void (async () => {
      let continuePolling = true;
      this.donationOverview = await this.transactionService.getDonationOverview().catch<undefined>((error: IHttpError) => {
        continuePolling = error.status !== 404;
        return undefined;
      });

      if (!this.donationOverview || !this.counterComponent) {
        this.canLoad = false;

        if (continuePolling) {
          await lastValueFrom(of(void 0).pipe(delay(300000)));
          void this.getDonationOverview();
        }

        return;
      }

      this.canLoad = true;

      const lowValue = this.donationOverview.pointsDonated;
      const highValue =
        this.donationOverview.pointsDonated + this.donationOverview.refreshIntervalInSeconds * this.donationOverview.pointsPerSecond;
      const duration = this.donationOverview.refreshIntervalInSeconds * 1000;

      this.counterComponent.counterUpdated.pipe(takeUntil(this.destroy$)).subscribe((value) => {
        const isBadgeVisible =
          this.siteService.pageContext.value?.donationCampaignProductPoints &&
          this.siteService.pageContext.value?.donationCampaignProductLabel;

        if (!isBadgeVisible) {
          return;
        }

        if (this.counterComponent) {
          this.counterComponent.badgeNumber = this.siteService.pageContext.value?.donationCampaignProductPoints
            ? Math.floor(value / this.siteService.pageContext.value.donationCampaignProductPoints)
            : undefined;
          this.counterComponent.badgeLabel = this.siteService.pageContext.value?.donationCampaignProductLabel;
        }
      });

      await this.counterComponent.setValues(lowValue, highValue, duration);
      void this.getDonationOverview();
    })();
  }

  private async getCharity(): Promise<void> {
    const pageContext = await this.siteService.pageContext
      .pipe(
        takeUntil(this.destroy$),
        first((x) => !!x)
      )
      .toPromise();

    this.charity = pageContext?.donationCampaignCharity;
    this.canLoad = !!this.charity;
  }
}
