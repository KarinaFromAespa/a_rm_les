import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContentBlockRegion, IRedirectForm } from 'src/app/core/models/content.model';
import { NavigationService } from 'src/app/core/services/navigation.service';
import { SiteService } from 'src/app/core/services/site.service';
import { ModalLoginHelper } from '../../modal/modal-login.helper';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-password-token',
  template: '',
  standalone: false
})
export class PasswordTokenComponent implements OnInit, IContentBlockComponent {
  className = 'password-token';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IRedirectForm;
  userEventSource: string;

  constructor(
    private route: Router,
    private modalLoginHelper: ModalLoginHelper,
    private siteService: SiteService,
    private navigationService: NavigationService
  ) {}

  ngOnInit(): void {
    this.navigationService.removeLastHistory();
    void this.modalLoginHelper.triggerPasswordResetModal(
      undefined,
      // Close callback
      () => {
        void this.route.navigate([this.siteService.siteSettings?.homePageUrl], { replaceUrl: true });
      },
      () => {
        // Success close callback

        void this.route.navigate([this.content.successPage._url], { replaceUrl: true });
      },
      true
    );
  }
}
