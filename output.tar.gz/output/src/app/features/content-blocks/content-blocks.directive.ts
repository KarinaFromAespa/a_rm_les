import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[airContentBlocks]',
  standalone: false
})
export class ContentBlocksDirective {
  constructor(public viewContainerRef: ViewContainerRef) {}
}
