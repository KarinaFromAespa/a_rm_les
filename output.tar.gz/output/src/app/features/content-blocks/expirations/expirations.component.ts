import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { scrollIntoViewIfNeeded } from 'src/app/core/helpers/layout.helper';
import { ContentBlockRegion, IExpirations } from 'src/app/core/models/content.model';
import { ITransaction } from 'src/app/core/models/transaction.model';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-expirations',
  templateUrl: './expirations.component.html',
  standalone: false
})
export class ExpirationsComponent implements IContentBlockComponent, OnInit, AfterViewInit {
  @ViewChild('header') header: ElementRef;
  className = 'expirations';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IExpirations;
  userEventSource: string;

  expirations: ITransaction[] = [];

  page = 1;
  loading: boolean;

  constructor(
    private transactionService: TransactionService,
    private userEventService: UserEventService,
    private route: ActivatedRoute
  ) {
    if (this.content) {
      this.loading = true;
    }
  }

  ngOnInit(): void {
    void this.transactionService
      .expirations()
      .then((data) => {
        this.expirations = data ?? [];
      })
      .finally(() => {
        this.loading = false;
      });
  }

  ngAfterViewInit(): void {
    this.route.fragment.subscribe((f) => {
      setTimeout(() => {
        const element = document.querySelector(`#${f}`) as HTMLElement;
        if (element) {
          void document.querySelector('ion-content')?.scrollToPoint(0, element.offsetTop, 250);
        }
      }, 250);
    });
  }

  onPageChange(page: number): void {
    this.userEventService.pushEvent(this.userEventSource, UserEventAction.paging, page.toString());
    this.page = page;
    scrollIntoViewIfNeeded(this.header.nativeElement);
  }
}
