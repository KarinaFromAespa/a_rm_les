import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ContentBlockRegion, IReferralRewards } from 'src/app/core/models/content.model';
import { IReferralRegistrationReward, IReferralRewardsResponse } from 'src/app/core/models/referral-registration.model';
import { ReferralRegistrationsService } from 'src/app/core/services/referral-registrations.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-share-referral-awards',
  templateUrl: './referral-rewards.component.html',
  providers: [DatePipe],
  standalone: false
})
export class ReferralRewardsComponent implements IContentBlockComponent, OnInit {
  className = 'referral-rewards';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IReferralRewards;
  userEventSource: string;
  referralRewards: IReferralRegistrationReward[];
  isLoading: boolean;

  readonly contentBlockRegion = ContentBlockRegion;

  constructor(
    private referralRegistrationsService: ReferralRegistrationsService,
    private translateService: TranslateService,
    private datePipe: DatePipe
  ) {}

  get subtitle(): string {
    return (
      this.translateService.instant('general.label.validity') +
      ': ' +
      this.datePipe.transform(this.content.referralRegistrationSettings.endDate, 'dd-MM-yyyy')
    );
  }

  async ngOnInit(): Promise<void> {
    await this.getReferralRewards();
  }

  private async getReferralRewards(): Promise<void> {
    this.isLoading = true;

    const rewards = await this.referralRegistrationsService.getReferralRewards(this.content.referralRegistrationSettings._id);
    this.setActivatedRewards(rewards);
    this.isLoading = false;
  }

  private setActivatedRewards(rewards: IReferralRewardsResponse[]): void {
    this.referralRewards = this.content.referralRegistrationSettings.referralRegistrationRewards.map((reward) => {
      const activatedReward: IReferralRewardsResponse | undefined = rewards.find(
        (r) => r.campaignId === reward.importedCampaign?.campaignId
      );
      return {
        ...reward,
        isActivated: !!activatedReward?.isActivated
      };
    });
  }
}
