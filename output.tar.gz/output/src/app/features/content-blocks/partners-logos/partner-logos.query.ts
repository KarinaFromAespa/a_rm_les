import gql from 'graphql-tag';

export const partnerLogosQuery = gql`
  query GetPartnerLogos {
    allPartner {
      items {
        ... on Partner {
          title
          logo {
            cropUrl(alias: "Partner Logo")
          }
          url
          isHidden
        }
      }
    }
  }
`;
