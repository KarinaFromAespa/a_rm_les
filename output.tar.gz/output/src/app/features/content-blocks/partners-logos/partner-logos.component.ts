import { Component, OnDestroy, OnInit } from '@angular/core';
import { ApolloQueryResult } from '@apollo/client/core';
import { Subject, of } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ContentBlockRegion, IPartnerLogos } from 'src/app/core/models/content.model';
import { IPartner, IPartnerListResponse } from 'src/app/core/models/partner.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { partnerLogosQuery } from './partner-logos.query';

@Component({
  selector: 'air-partner-logos',
  templateUrl: './partner-logos.component.html',
  standalone: false
})
export class PartnerLogosComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'partner-logos';
  region?: ContentBlockRegion;
  content: IPartnerLogos;
  isFirst?: boolean;
  userEventSource = UserEventSource.partnerLogos;

  partners: IPartner[] = [];
  loading: boolean;
  loadingError: boolean;
  destroy$ = new Subject();
  contentBlockRegion = ContentBlockRegion;

  constructor(private graphQLService: GraphQLService) {}

  ngOnInit(): void {
    this.loading = true;
    this.graphQLService
      .watchQuery<IPartnerListResponse>(partnerLogosQuery, undefined, true)
      .pipe(
        catchError(() => {
          this.loading = false;
          this.loadingError = true;
          return of({ data: null, loading: false } as ApolloQueryResult<null>);
        })
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (result?.data?.allPartner === null) {
          return;
        }

        this.partners = result.data?.allPartner.items.filter((x) => !x.isHidden) ?? [];
        this.loading = result.loading;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
