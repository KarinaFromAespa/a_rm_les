import { Component } from '@angular/core';
import { IImageBlock } from 'src/app/core/models/content.model';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';

@Component({
  selector: 'air-image',
  templateUrl: './image.component.html',
  standalone: false
})
export class ImageComponent implements IContentBlockComponent {
  className = 'image';
  content: IImageBlock;
  userEventSource: string;

  constructor() {}
}
