import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, IPlayableWidget } from 'src/app/core/models/content.model';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { ResizeService } from 'src/app/core/services/resize.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-playable-widget',
  templateUrl: './playable-widget.component.html',
  standalone: false
})
export class PlayableWidgetComponent implements IContentBlockComponent, AfterViewInit {
  @ViewChild('playableWidget') widgetElement: ElementRef<HTMLIFrameElement>;

  className = 'playable-widget';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IPlayableWidget;
  userEventSource: string;
  isLoading = true;

  private readonly baseUrl = 'https://air-miles.leadfamly.com/campaign/view/iframe/0/hash:{0}';

  constructor(
    private userHelper: UserHelper,
    private resizeService: ResizeService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngAfterViewInit(): void {
    this.setWidgetAttributes();
  }

  private setWidgetAttributes(): void {
    if (!this.widgetElement?.nativeElement) {
      return;
    }

    let src = this.baseUrl;
    src = src.format([this.content.widgetHash]);

    const encryptedUserDataForPlayable = (this.userHelper.currentUser as IUserLoginData)?.encryptedUserDataForPlayable;
    if (encryptedUserDataForPlayable) {
      src += `?data=${encodeURIComponent(encryptedUserDataForPlayable)}`;
    }

    const size = this.resizeService.getCurrentSize();
    if (size <= ScreenSize.sm && this.content.mobileHeight) {
      this.setHeight(this.content.mobileHeight);
    }

    if (size > ScreenSize.sm && this.content.desktopHeight) {
      this.setHeight(this.content.desktopHeight);
    }

    this.widgetElement.nativeElement.src = src;
    this.isLoading = false;
    this.cdRef.detectChanges();
  }

  private setHeight(height: number): void {
    if (!this.widgetElement?.nativeElement) {
      return;
    }

    this.widgetElement.nativeElement.style.height = `${height}px`;
  }
}
