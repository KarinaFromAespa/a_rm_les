import { Component, ElementRef, OnDestroy, OnInit, QueryList, Renderer2, ViewChildren } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { FormFieldName } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, ITransferPoints } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IUserBasicLoginData } from 'src/app/core/models/login.response';
import { ITransferPointsFormValues, TransferPointsFormRequest } from 'src/app/core/models/transfer-points.model';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalHelper } from '../../modal/modal.helper';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

enum TransferMethod {
  emailAddress = FormFieldName.emailAddress,
  cardNumber = FormFieldName.cardNumber
}

@Component({
  selector: 'air-transfer-points',
  templateUrl: './transfer-points.component.html',
  standalone: false
})
export class TransferPointsComponent implements IContentBlockComponent, OnInit, OnDestroy {
  @ViewChildren('sticker') stickers: QueryList<ElementRef>;

  className = 'transfer-points';
  contentBlockRegion = ContentBlockRegion;
  region?: ContentBlockRegion;
  isFirst?: boolean;
  content: ITransferPoints;
  userEventSource: string;

  transferMethod = TransferMethod;

  transferMethodType: TransferMethod;
  currentUser?: IUserBasicLoginData;
  pointsValueSnapshot = 0;
  isSubmitting = false;
  isCustomValueVisible = false;
  destroy$ = new Subject();

  form = new FormGroup(
    {
      emailAddress: new FormControl<string | null>(null),
      cardNumber: new FormControl<string | null>(null),
      points: new FormControl<number | null>(null, [Validators.required.bind(this), Validators.min(1), Validators.max(100000)])
    },
    { updateOn: 'blur' }
  );

  get emailAddress(): FormControl<string | null> {
    return this.form.controls.emailAddress;
  }

  get cardNumber(): FormControl<string | null> {
    return this.form.controls.cardNumber;
  }

  get points(): FormControl<number | null> {
    return this.form.controls.points;
  }

  get formDisabled(): boolean {
    return this.form.invalid;
  }

  constructor(
    private transactionService: TransactionService,
    private userHelper: UserHelper,
    private refreshTokenService: RefreshTokenService,
    private renderer: Renderer2,
    private toastService: ToastService,
    private modalHelper: ModalHelper,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.setTransferMethodType(TransferMethod.emailAddress);

    this.userHelper.currentUser$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((user) => {
      this.currentUser = user;

      this.points.setValidators([
        Validators.required.bind(this),
        Validators.min(1),
        Validators.max(Math.min(this.currentUser?.balance ?? 100000, 100000))
      ]);
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  setTransferMethodType(type: TransferMethod, event?: Event): void {
    if (event) {
      this.pushUserEvent(UserEventAction.set, 'transfer method', event.text());
    }

    this.transferMethodType = type;
    if (type === TransferMethod.emailAddress) {
      this.emailAddress.setValidators([Validators.required.bind(this), Validators.email.bind(this)]);
      this.cardNumber.clearValidators();
    } else {
      this.cardNumber.setValidators([
        Validators.required.bind(this),
        FormValidatorType.pattern(FormRegex.cardNumber.getRegExp()).getValidator()
      ]);
      this.emailAddress.clearValidators();
    }

    this.emailAddress.updateValueAndValidity();
    this.cardNumber.updateValueAndValidity();
  }

  setTransferPoints(points: string, isCustom: boolean, isFullAmount: boolean): void {
    if (!points) {
      return;
    }

    let userEventLabel = 'amount';
    if (isCustom) {
      userEventLabel = 'custom ' + userEventLabel;
    } else if (isFullAmount) {
      userEventLabel = 'full ' + userEventLabel;
    }

    this.pushUserEvent(UserEventAction.set, userEventLabel, points);
  }

  onCustomValueChange(event: Event): void {
    this.setTransferPoints((event.target as HTMLInputElement)?.value, true, false);
  }

  onStickerClick(elementRef: HTMLElement, points: number, isCustomValueOption = false, isFullAmount = false): void {
    this.points.patchValue(points);
    this.setTransferPoints(points?.toString(), isCustomValueOption, isFullAmount);
    // show input field to set a custom transfer points value
    this.isCustomValueVisible = isCustomValueOption;
    if (!this.isCustomValueVisible) {
      if (!this.points.dirty) {
        this.points.markAsDirty();
      }
    } else {
      this.points.markAsPristine();
    }
    // highlight clicked sticker
    this.stickers.forEach((ref) => this.renderer.addClass(ref.nativeElement, 'sticker--inactive'));
    this.renderer.removeClass(elementRef, 'sticker--inactive');
  }

  async submit(event: Event): Promise<void> {
    this.pushUserEvent(UserEventAction.submit, event.text(), this.points.value?.toString());

    const values = this.form.value as ITransferPointsFormValues;
    // Clear unselected field
    if (this.transferMethodType === TransferMethod.cardNumber) {
      values.emailAddress = '';
    } else {
      values.cardNumber = '';
    }

    await this.modalHelper.triggerConfirmationModal({
      text: this.content.confirmationText,
      action: async () => {
        await this.submitValues(values);
      },
      userEventSource: this.userEventSource
    });
  }

  async submitValues(values: ITransferPointsFormValues): Promise<void> {
    this.isSubmitting = true;

    const request = new TransferPointsFormRequest(values);

    await this.transactionService
      .transferAirmiles(request)
      .then(() => {
        const toastOptions = new ToastOptions({
          content: this.content.successText,
          type: ToastType.success,
          autoClose: true,
          id: 'transfer_points_succeed'
        });
        this.toastService.show(toastOptions);
        // refresh token and user data to update the card number
        this.setTransferMethodType(TransferMethod.emailAddress);
        this.stickers.forEach((ref) => this.renderer.removeClass(ref.nativeElement, 'sticker--inactive'));
        this.form.reset();

        // Refresh token and user data to update the balance (after giving SAP some time to process the transfer).
        setTimeout(() => {
          void this.refreshTokenService.refresh(this.userEventSource);
        }, 1000);
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value);
  }

  get canTransferPoints() {
    return this.userHelper.canTransferPoints;
  }
}
