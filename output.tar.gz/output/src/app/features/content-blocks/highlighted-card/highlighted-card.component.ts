import { Component } from '@angular/core';
import { Alignment } from 'src/app/core/models/content.model';
import { AbstractFormattedTextComponent } from 'src/app/features/content-blocks/formatted-text/formatted-text-component.abstract';

@Component({
  selector: 'air-highlighted-card',
  templateUrl: './highlighted-card.component.html',
  standalone: false
})
export class HighlightedCardComponent extends AbstractFormattedTextComponent {
  className = 'highlighted-card';

  get alignment(): string {
    return this.alignedImage.alignment === Alignment.before ? 'left' : 'right';
  }
}
