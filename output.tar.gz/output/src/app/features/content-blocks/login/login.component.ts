import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, ILogin } from 'src/app/core/models/content.model';
import { NavigationService } from 'src/app/core/services/navigation.service';
import { ModalLoginHelper } from '../../modal/modal-login.helper';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-login',
  template: '',
  standalone: false
})
export class LoginComponent implements OnInit, IContentBlockComponent {
  className = 'login';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: ILogin;
  userEventSource: string;

  constructor(
    private userHelper: UserHelper,
    private route: Router,
    private modalLoginHelper: ModalLoginHelper,
    private navigationService: NavigationService
  ) {}

  ngOnInit(): void {
    this.navigationService.removeLastHistory();
    if (this.navigateLoggedIn()) {
      return;
    }

    void this.modalLoginHelper.triggerPasswordLoginModal(
      this.userEventSource,
      undefined,
      () => {
        if (this.navigateLoggedIn()) {
          return;
        }

        void this.route.navigate(['/'], { replaceUrl: true });
      },
      undefined,
      this.content.completeProfilePage,
      this.content.successPage
    );
  }

  navigateLoggedIn(): boolean {
    if (!this.userHelper.requiresPasswordLogin) {
      void this.route.navigate([this.content.successPage._url], { replaceUrl: true });
      return true;
    }

    return false;
  }
}
