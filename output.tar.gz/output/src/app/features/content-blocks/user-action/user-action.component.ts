import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormBoolean, FormFieldName, FormType } from 'src/app/core/constants/form.constants';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { ContentBlockRegion, ContentBlockType, IUserActionContentBlock } from 'src/app/core/models/content.model';
import { FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IRadioControl, IUserActionFormValue, RadioDisplayType } from 'src/app/core/models/form.model';
import {
  UserInboxPreferences,
  UserPersonalizationPreferences,
  UserPromotionPreferences,
  UserPushPromotionPreferences,
  UserPushServicePreferences,
  UserToggleValue
} from 'src/app/core/models/user.model';
import { BiometricsService } from 'src/app/core/services/biometrics.service';
import { PushMessageService } from 'src/app/core/services/push-message.service';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { IFormContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { ToastType } from '../../toasts/toast.model';

@Component({
  selector: 'air-user-action',
  templateUrl: './user-action.component.html',
  standalone: false
})
export class UserActionComponent
  extends BaseFormComponent<IUserActionFormValue>
  implements IFormContentBlockComponent, OnInit, AfterViewInit
{
  currentValue = false;

  trueLabel: string;
  falseLabel: string;

  content: IUserActionContentBlock;
  className = 'user-action';
  isFirst?: boolean;
  region?: ContentBlockRegion;

  valueInputName = FormFieldName.value as string;
  successPageUrl: string;

  get isDisabled(): boolean {
    return super.formDisabled || !this.formComponent?.form || this.formComponent.form.pristine ? true : false;
  }

  get shouldAutoUpdate(): boolean {
    const queryType = this.activatedRoute.snapshot.queryParams?.type as string;
    if (queryType === undefined || this.activatedRoute.snapshot.queryParams?.activate === undefined) {
      return false;
    }
    return this.content?.contentTypeAlias.toLowerCase() === queryType.toLowerCase();
  }

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    private userService: UserService,
    private translateService: TranslateService,
    private biometricsService: BiometricsService,
    private refreshTokenService: RefreshTokenService,
    private inboxHelper: InboxHelper,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private pushMessageService: PushMessageService
  ) {
    super(userEventService, platformHelper, toastService);
  }

  async ngOnInit(): Promise<void> {
    super.ngOnInit();

    if (this.content?.contentTypeAlias) {
      // Differentiate input control names by type
      this.valueInputName = `${this.content?.contentTypeAlias}_${this.valueInputName}`;
    }

    if (!this.shouldAutoUpdate) {
      switch (this.content?.contentTypeAlias) {
        case ContentBlockType.updatePersonalizationPreferences:
          this.currentValue = (await this.userService.getUserPersonalizationPreferences()).allowPersonalization;
          break;

        case ContentBlockType.updatePromotionPreferences:
          this.currentValue = (await this.userService.getUserPromotionPreferences()).receivePromotionalEmails;
          break;

        case ContentBlockType.updateInboxPreferences:
          this.currentValue = (await this.userService.getUserInboxPreferences()).enableInbox;
          break;

        case ContentBlockType.updatePushPromotionPreferences:
          this.currentValue = (await this.userService.getPushPromotionPreferences()).receivePromotionalPushMessages;
          break;

        case ContentBlockType.updatePushServicePreferences:
          this.currentValue = (await this.userService.getPushServicePreferences()).receiveServicePushMessages;
          break;

        case ContentBlockType.updateBiometricsPreferences:
          this.currentValue = await this.biometricsService.getUserPreferences();
          break;
      }
    }

    this.form = [
      {
        controls: [
          {
            name: this.valueInputName,
            type: FormType.radio,
            displayType: RadioDisplayType.horizontal,
            value: this.getFormattedValue(this.currentValue),
            options: [
              {
                value: FormBoolean.yes,
                text: this.translateService.instant('general.label.yes_please') as string
              },
              {
                value: FormBoolean.no,
                text: this.translateService.instant('general.label.no_thank_you') as string
              }
            ],
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.required') as string
              }
            ]
          } as IRadioControl
        ]
      }
    ];
  }

  ngAfterViewInit(): void {
    super.ngAfterViewInit();

    // opt-in value is provided in url params
    if (this.shouldAutoUpdate) {
      const { activate, successPage } = this.activatedRoute.snapshot.queryParams;
      this.successPageUrl = successPage as string;
      // make a force save of the form
      const value = this.getFormattedValue((activate as string).toLowerCase() === 'true');
      const formValue: IUserActionFormValue = { value };
      this.formComponent?.form.get(this.valueInputName)?.setValue(formValue.value);
      this.formComponent?.submit();
    }
  }

  async submitValues(values: IUserActionFormValue): Promise<void> {
    const toggleValue = values[this.valueInputName] === FormBoolean.yes;
    this.isSubmitting = true;

    let updateCall: null | ((request?: any) => Promise<void>) = null;
    let request: UserToggleValue | boolean | null = null;

    switch (this.content?.contentTypeAlias) {
      case ContentBlockType.updatePersonalizationPreferences:
        {
          request = new UserPersonalizationPreferences(toggleValue);
          updateCall = this.userService.updateUserPersonalizationPreferences.bind(this.userService) as () => Promise<void>;
        }
        break;
      case ContentBlockType.updatePromotionPreferences:
        {
          request = new UserPromotionPreferences(toggleValue);
          updateCall = this.userService.updateUserPromotionPreferences.bind(this.userService) as () => Promise<void>;
        }
        break;
      case ContentBlockType.updateInboxPreferences:
        {
          request = new UserInboxPreferences(toggleValue);
          updateCall = async (request: UserInboxPreferences) => {
            await this.userService.updateUserInboxPreferences(request);
            await this.refreshTokenService.refresh(this.userEventSource);
            void this.inboxHelper.refreshUnreadInboxCount();
          };
        }
        break;
      case ContentBlockType.updatePushPromotionPreferences:
        {
          request = new UserPushPromotionPreferences(toggleValue);
          updateCall = (async (request: UserPushPromotionPreferences) => {
            await this.userService.updatePushPromotionPreferences(request);
            if (request.receivePromotionalPushMessages) {
              await this.pushMessageService.tryRegisterDevice(true);
            }
          }).bind(this.userService) as () => Promise<void>;
        }
        break;
      case ContentBlockType.updatePushServicePreferences:
        {
          request = new UserPushServicePreferences(toggleValue);
          updateCall = (async (request: UserPushServicePreferences) => {
            await this.userService.updatePushServicePreferences(request);
            if (request.receiveServicePushMessages) {
              await this.pushMessageService.tryRegisterDevice(true);
            }
          }).bind(this.userService) as () => Promise<void>;
        }
        break;
      case ContentBlockType.updateBiometricsPreferences:
        {
          request = toggleValue;
          updateCall = this.biometricsService.setUserPreferences.bind(this.biometricsService) as () => Promise<void>;
        }
        break;
    }
    if (updateCall) {
      await updateCall(request)
        .then(() => {
          this.pushUserSuccessEvent();
          if (this.successPageUrl) {
            // gets a full url address
            if (UrlHelper.isExternalLink(this.successPageUrl)) {
              if (PlatformHelper.isNativeMobile) {
                // If in app open in browser
                window.open(this.successPageUrl, '_system');
              } else {
                window.location.href = encodeURI(this.successPageUrl);
              }
            } else {
              // Get relative path for angular routing
              void this.route.navigateByUrl(
                this.successPageUrl.startsWith('http') ? new URL(this.successPageUrl).pathname : this.successPageUrl
              );
            }
            return;
          }
          this.formComponent.form.markAsPristine();
          this.showToast(ToastType.success, this.content.successText);
        })
        .catch(() => {
          this.isSubmitting = false;
        })
        .finally(() => {
          this.isSubmitting = false;
        });
    }
  }

  private getFormattedValue(value: boolean): FormBoolean {
    return value ? FormBoolean.yes : FormBoolean.no;
  }
}
