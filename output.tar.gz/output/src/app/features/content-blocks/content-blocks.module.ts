import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from 'src/app/shared/shared.module';
import { CardDetailsComponent } from '../dashboard/card-details/card-details.component';
import { UpdatePasswordComponent } from '../personal/personal-details/update-password/update-password.component';
import { UpdateProfileComponent } from '../personal/personal-details/update-profile/update-profile.component';
import { ProductModule } from '../products/products.module';
import { BlockCardComponent } from './block-card/block-card.component';
import { BookingWidgetComponent } from './booking-widget/booking-widget.component';
import { CampaignRegistrationComponent } from './campaign-registration/campaign-registration.component';
import { CardListItemComponent } from './card-list/card-list-item.component';
import { CardListComponent } from './card-list/card-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { ContentBlocksComponent } from './content-blocks.component';
import { ContentBlocksDirective } from './content-blocks.directive';
import { DashboardOverviewComponent } from './dashboard-overview/dashboard-overview.component';
import { DonationCounterComponent } from './donation-counter/donation-counter.component';
import { ExpirationsComponent } from './expirations/expirations.component';
import { ExportPersonalDataComponent } from './export-personal-data/export-personal-data.component';
import { FormattedTextComponent } from './formatted-text/formatted-text.component';
import { HighlightedCardComponent } from './highlighted-card/highlighted-card.component';
import { HighlightedProductsComponent } from './highlighted-products/highlighted-products.component';
import { HighlightedPromotionsComponent } from './highlighted-promotions/highlighted-promotions.component';
import { ImageComponent } from './image/image.component';
import { InboxMessageListComponent } from './inbox/inbox-message-list/inbox-message-list.component';
import { InboxMessageViewComponent } from './inbox/inbox-message-view/inbox-message-view.component';
import { InboxComponent } from './inbox/inbox.component';
import { LoginComponent } from './login/login.component';
import { OrganizationOverviewComponent } from './organization-overview/organization-overview.component';
import { PartnerLoginComponent } from './partner-login/partner-login.component';
import { PartnerLogosComponent } from './partners-logos/partner-logos.component';
import { PasswordTokenComponent } from './password-token/password-token.component';
import { PlayableWidgetComponent } from './playable-widget/playable-widget.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { PurchasedVouchersComponent } from './purchased-vouchers/purchased-vouchers.component';
import { RecentTransactionsFilterComponent } from './recent-transactions/recent-transactions-filter/recent-transactions-filter.component';
import { RecentTransactionsComponent } from './recent-transactions/recent-transactions.component';
import { ReferralRewardsComponent } from './referral-rewards/referral-rewards.component';
import { ShareAccountComponent } from './share-account/share-account.component';
import { ShareReferralLinkComponent } from './share-referral-link/share-referral-link.component';
import { TerminateAccountComponent } from './terminate-account/terminate-account.component';
import { TextListComponent } from './text-list/text-list.component';
import { TransferPointsComponent } from './transfer-points/transfer-points.component';
import { UserActionComponent } from './user-action/user-action.component';
import { VideoComponent } from './video/video.component';

@NgModule({
  declarations: [
    ContentBlocksDirective,
    ContentBlocksComponent,
    FormattedTextComponent,
    HighlightedCardComponent,
    HighlightedProductsComponent,
    ProductOverviewComponent,
    CardListComponent,
    CardListItemComponent,
    ImageComponent,
    TextListComponent,
    CardDetailsComponent,
    DashboardOverviewComponent,
    UserActionComponent,
    UpdateProfileComponent,
    UpdatePasswordComponent,
    PurchasedVouchersComponent,
    HighlightedPromotionsComponent,
    RecentTransactionsComponent,
    ContactFormComponent,
    TransferPointsComponent,
    TerminateAccountComponent,
    LoginComponent,
    PartnerLoginComponent,
    PasswordTokenComponent,
    OrganizationOverviewComponent,
    BlockCardComponent,
    ExpirationsComponent,
    ExportPersonalDataComponent,
    CampaignRegistrationComponent,
    ShareAccountComponent,
    VideoComponent,
    BookingWidgetComponent,
    PlayableWidgetComponent,
    DonationCounterComponent,
    RecentTransactionsFilterComponent,
    PartnerLogosComponent,
    ShareReferralLinkComponent,
    ReferralRewardsComponent,
    InboxComponent,
    InboxMessageListComponent,
    InboxMessageViewComponent
  ],
  imports: [CommonModule, SharedModule, ProductModule, NgxPaginationModule],
  exports: [
    ContentBlocksComponent,
    ContentBlocksDirective,
    DashboardOverviewComponent,
    HighlightedProductsComponent,
    PurchasedVouchersComponent,
    ExportPersonalDataComponent,
    DonationCounterComponent
  ]
})
export class ContentBlocksModule {}
