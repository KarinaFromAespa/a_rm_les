import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Share } from '@capacitor/share';
import { TranslateService } from '@ngx-translate/core';
import { delay, lastValueFrom, of } from 'rxjs';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion, IShareReferralLink } from 'src/app/core/models/content.model';
import { ReferralRegistrationsService } from 'src/app/core/services/referral-registrations.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-share-referral-link',
  templateUrl: './share-referral-link.component.html',
  standalone: false
})
export class ShareReferralLinkComponent implements IContentBlockComponent, OnInit {
  @ViewChild('copyElement') copyElement: ElementRef<HTMLInputElement>;

  className: string;
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IShareReferralLink;
  userEventSource: string;

  canShare: boolean;
  inviteLink: string;
  isLoading = true;

  private isCopying: boolean;

  constructor(
    private userEventService: UserEventService,
    private toastService: ToastService,
    private referralRegistrationsService: ReferralRegistrationsService,
    private platformHelper: PlatformHelper,
    private translateService: TranslateService
  ) {}

  async ngOnInit(): Promise<void> {
    this.inviteLink = await this.referralRegistrationsService.getRegistrationInvitationLink(
      this.content.referralRegistrationSettings?._id,
      `${this.platformHelper.getCurrentAbsoluteBaseUrl()}${this.content.referralRegistrationSettings?.registrationPage._url}`
    );

    const result = await Share.canShare().catch(() => ({ value: false }));
    this.canShare = result.value;

    this.isLoading = false;
  }

  async shareLink(event: Event): Promise<void> {
    this.pushUserEvent(UserEventAction.open, event.text());
    await Share.share({ url: this.inviteLink, title: this.content.messageTitle, text: this.content.messageDescription });
  }

  async copyLink(event?: Event): Promise<void> {
    if (this.isCopying) {
      return;
    }

    this.isCopying = true;
    this.pushUserEvent(UserEventAction.submit, event?.text() ?? 'copy');
    const succeeded = await navigator.clipboard
      .writeText(this.inviteLink)
      .then(() => true)
      .catch(() => {
        this.toastService.show(
          new ToastOptions({
            title: this.translateService.instant(`general.label.error`) as string,
            message: !document.hasFocus()
              ? (this.translateService.instant(`referral.form.error.no_focus`) as string)
              : (this.translateService.instant(`referral.form.error.other`) as string),
            type: ToastType.error
          })
        );

        return false;
      });

    if (!succeeded) {
      this.isCopying = false;
      return;
    }

    if (this.hasFocus()) {
      this.copyElement?.nativeElement?.select();
    }

    if (!this.platformHelper.isAndroidMobile || !this.platformHelper.isMinimumAndroidSDKVersion(33)) {
      this.toastService.show(
        new ToastOptions({
          content: this.content.successText,
          type: ToastType.success
        })
      );
    }

    void lastValueFrom(of(null).pipe(delay(1000))).finally(() => (this.isCopying = false));
  }

  hasFocus(): boolean {
    return document.activeElement === this.copyElement?.nativeElement;
  }

  private pushUserEvent(action: UserEventAction, label?: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, label);
  }
}
