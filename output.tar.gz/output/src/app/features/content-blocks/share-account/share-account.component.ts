import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FormFieldName } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, IShareAccount, IText } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IUserLoginData } from 'src/app/core/models/login.response';
import {
  IInvitationBlock,
  InvitationBlockType,
  MergeInvitationRequest,
  MergeInvitationStatus,
  MergeInvitationStatusRequest,
  ReceivedMergeInvitation,
  SentMergeInvitation
} from 'src/app/core/models/merge-invitation.model';
import { CardLinksService } from 'src/app/core/services/card-links.service';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalHelper } from '../../modal/modal.helper';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';
import { IShareAccountFormValues } from './share-account.model';

enum InvitationMethod {
  emailAddress = FormFieldName.emailAddress,
  cardNumber = FormFieldName.cardNumber
}

@Component({
  selector: 'air-share-account',
  templateUrl: './share-account.component.html',
  standalone: false
})
export class ShareAccountComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'share-account';
  contentBlockRegion = ContentBlockRegion;
  region?: ContentBlockRegion;
  isFirst?: boolean;
  content: IShareAccount;
  userEventSource: string;

  invitationMethod = InvitationMethod;
  invitationBlockType = InvitationBlockType;
  invitationMethodType: InvitationMethod;
  receivedInvitations: ReceivedMergeInvitation[] = [];
  sentInvitations: SentMergeInvitation[] = [];

  isMerged: boolean;
  noEmailExists = false;
  isLoading = true;
  isSubmitting = false;
  destroy$ = new Subject();

  form = new FormGroup(
    {
      emailAddress: new FormControl<string | null>(null),
      cardNumber: new FormControl<string | null>(null)
    },
    { updateOn: 'blur' }
  );

  get emailAddress(): FormControl<string | null> {
    return this.form.controls.emailAddress;
  }

  get cardNumber(): FormControl<string | null> {
    return this.form.controls.cardNumber;
  }

  get formDisabled(): boolean {
    return this.form.invalid;
  }

  constructor(
    private cardLinksService: CardLinksService,
    private userHelper: UserHelper,
    private toastService: ToastService,
    private refreshTokenService: RefreshTokenService,
    private modalHelper: ModalHelper,
    private userEventService: UserEventService
  ) {}

  async ngOnInit(): Promise<void> {
    this.setInvitationMethodType(InvitationMethod.emailAddress);

    await this.refreshTokenService.refresh(this.userEventSource, false, false);

    this.userHelper.currentUser$.pipe(takeUntil(this.destroy$)).subscribe((user) => {
      this.isMerged = !!(user as IUserLoginData)?.isMerged;
      this.noEmailExists = !(user as IUserLoginData)?.emailAddress;
    });

    await this.getInvitations();

    this.isLoading = false;
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  setInvitationMethodType(type: InvitationMethod, event?: Event): void {
    if (event) {
      this.pushUserEvent(UserEventAction.set, 'invitation method', event.text());
    }

    this.invitationMethodType = type;
    if (type === InvitationMethod.emailAddress) {
      this.emailAddress.setValidators([Validators.required.bind(this), Validators.email.bind(this)]);
      this.cardNumber.clearValidators();
    } else {
      this.cardNumber.setValidators([
        Validators.required.bind(this),
        FormValidatorType.pattern(FormRegex.cardNumber.getRegExp()).getValidator()
      ]);
      this.emailAddress.clearValidators();
    }

    this.emailAddress.updateValueAndValidity();
    this.cardNumber.updateValueAndValidity();
  }

  async submit(event: Event): Promise<void> {
    const values = this.form.value as IShareAccountFormValues;

    // Clear unselected field
    if (this.invitationMethodType === InvitationMethod.cardNumber) {
      values.emailAddress = '';
    } else {
      values.cardNumber = '';
    }

    // Check email address and show modal if not valid.
    // Otherwise, submitValues
    await this.submitValues(values, event);
  }

  async submitValues(values: IShareAccountFormValues, event: Event): Promise<void> {
    this.isSubmitting = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    const request = new MergeInvitationRequest(values);

    await this.cardLinksService
      .sendMergeInvitation(request)
      .then(async () => {
        await this.getInvitations();
        this.showSuccessToast(this.content.invitationSuccessText);
        // refresh token and user data to update the card number
        this.setInvitationMethodType(InvitationMethod.emailAddress);
        this.form.reset();
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  async getInvitations(): Promise<void> {
    await this.cardLinksService.getReceivedMergeInvitations().then((invitations: ReceivedMergeInvitation[]) => {
      this.receivedInvitations = invitations;
    });

    await this.cardLinksService.getSentMergeInvitations().then((invitations: SentMergeInvitation[]) => {
      this.sentInvitations = invitations;
    });
  }

  setInvitationStatus(invitationId: string, status: MergeInvitationStatus): Promise<void> {
    return this.cardLinksService.setMergeInvitationStatus(invitationId, new MergeInvitationStatusRequest(status)).then(async () => {
      await this.getInvitations();
    });
  }

  acceptInvitation(invitationBlock: IInvitationBlock, event: Event): void {
    invitationBlock.isLoading = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    this.triggerConfirmationModal(
      this.content.acceptConfirmationText,
      () =>
        this.setInvitationStatus(invitationBlock.invitationId, MergeInvitationStatus.accepted)
          .then(async () => {
            await this.refreshTokenService.refresh(this.userEventSource);
            this.showSuccessToast(this.content.acceptSuccessText);
          })
          .finally(() => (invitationBlock.isLoading = false)),
      invitationBlock,
      'connection'
    );
  }

  rejectInvitation(invitationBlock: IInvitationBlock, event: Event): void {
    invitationBlock.isLoading = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    void this.setInvitationStatus(invitationBlock.invitationId, MergeInvitationStatus.rejected)
      .then(() => {
        this.showSuccessToast(this.content.rejectSuccessText);
      })
      .finally(() => {
        invitationBlock.isLoading = false;
      });
  }

  cancelInvitation(invitationBlock: IInvitationBlock, event: Event): void {
    invitationBlock.isLoading = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    void this.setInvitationStatus(invitationBlock.invitationId, MergeInvitationStatus.cancelled)
      .then(() => {
        this.showSuccessToast(this.content.rejectSuccessText);
      })
      .finally(() => (invitationBlock.isLoading = false));
  }

  deleteInvitation(invitationBlock: IInvitationBlock, event: Event): void {
    invitationBlock.isLoading = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    void this.cardLinksService
      .deleteMergeInvitation(invitationBlock.invitationId)
      .then(() => {
        void this.getInvitations();
      })
      .finally(() => {
        invitationBlock.isLoading = false;
      });
  }

  stopSharedAccount(invitationBlock: IInvitationBlock, event: Event): void {
    invitationBlock.isLoading = true;
    this.pushUserEvent(UserEventAction.submit, event.text());
    this.triggerConfirmationModal(
      this.content.stopConfirmationText,
      () =>
        this.cardLinksService
          .stopSharedAccount()
          .then(async () => {
            await this.refreshTokenService.refresh(this.userEventSource);
            this.showSuccessToast(this.content.stopSuccessText);
          })
          .finally(() => (invitationBlock.isLoading = false)),
      invitationBlock,
      'disconnection'
    );
  }

  private showSuccessToast(text: IText) {
    this.toastService.show(
      new ToastOptions({
        content: text,
        type: ToastType.success
      })
    );
  }

  private triggerConfirmationModal(
    content: IText,
    action: () => void | Promise<void>,
    invitationBlock: IInvitationBlock,
    userEventSourceTopic: string
  ) {
    void this.modalHelper.triggerConfirmationModal(
      {
        text: content,
        action,
        userEventSource: this.userEventSource,
        userEventSourceTopic
      },
      () => {
        invitationBlock.isLoading = false;
      }
    );
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value);
  }
}
