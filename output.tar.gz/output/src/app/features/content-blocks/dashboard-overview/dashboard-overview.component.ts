import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { PromotionHelper } from 'src/app/core/helpers/promotion.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion, IDashboardOverview } from 'src/app/core/models/content.model';
import { ITransactionOverview } from 'src/app/core/models/transaction.model';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';

@Component({
  selector: 'air-dashboard-overview',
  templateUrl: './dashboard-overview.component.html',
  standalone: false
})
export class DashboardOverviewComponent implements OnInit, IContentBlockComponent {
  className = 'dashboard-overview';
  transactionOverview?: ITransactionOverview;
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IDashboardOverview;
  userEventSource: string;
  loading: boolean;

  constructor(
    private transactionService: TransactionService,
    private promotionHelper: PromotionHelper,
    private inboxHelper: InboxHelper,
    private userHelper: UserHelper,
    private translateService: TranslateService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    void this.promotionHelper.refreshUnactivatedPromotionsCounter();
    void this.inboxHelper.refreshUnreadInboxCount();
    void this.transactionService
      .getTransactionOverview(this.content.numberOfTransactions)
      .then((data) => {
        this.transactionOverview = data;
        if (this.transactionOverview.balance) {
          void this.userHelper.updateBalance(this.transactionOverview.balance);
        }

        this.transactionOverview.recentTransactions = data.recentTransactions.map((transaction) => {
          transaction.name = transaction.name?.length
            ? transaction.name
            : (this.translateService.instant('transactions.label.unknown') as string);
          return transaction;
        });
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
