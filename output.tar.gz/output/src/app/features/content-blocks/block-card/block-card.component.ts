import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ContentBlockRegion, IBlockCard } from 'src/app/core/models/content.model';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { ModalHelper } from '../../modal/modal.helper';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-block-card',
  templateUrl: './block-card.component.html',
  standalone: false
})
export class BlockCardComponent implements IContentBlockComponent, OnDestroy {
  className = 'block-card';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IBlockCard;
  userEventSource: string;

  isLoading: boolean;
  destroy$ = new Subject();

  constructor(
    private route: Router,
    private userService: UserService,
    private refreshTokenService: RefreshTokenService,
    private modalHelper: ModalHelper,
    private userEventService: UserEventService
  ) {}

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async onConfirm(): Promise<void> {
    await this.userService
      .blockUserCard()
      .then(() => {
        // refresh token and user data to update the card number
        void this.refreshTokenService.refresh(this.userEventSource);

        void this.route.navigate([this.content.successPage?._url]);
      })
      .finally(() => {
        this.isLoading = false;
      });
  }

  async onSubmit(event: Event): Promise<void> {
    this.userEventService.pushEvent(this.userEventSource, UserEventAction.submit, event.text());

    await this.modalHelper.triggerConfirmationModal({
      text: this.content.confirmationText,
      action: async () => {
        await this.onConfirm();
      },
      userEventSource: this.userEventSource
    });
  }
}
