import { Component, Input, OnInit, Renderer2, Type, ViewChild } from '@angular/core';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { StringHelper } from 'src/app/core/helpers/string.helper';
import { Channel, ContentBlockRegion, ContentBlockType, IContentBlock, IFormattedText } from 'src/app/core/models/content.model';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { PasswordResetComponent } from '../password-reset/password-reset.component';
import { PasswordSetComponent } from '../password-set/password-set.component';
import { UpdatePasswordComponent } from '../personal/personal-details/update-password/update-password.component';
import { UpdateProfileComponent } from '../personal/personal-details/update-profile/update-profile.component';
import { BannerComponent } from './banner/banner.component';
import { BlockCardComponent } from './block-card/block-card.component';
import { BookingWidgetComponent } from './booking-widget/booking-widget.component';
import { CampaignRegistrationComponent } from './campaign-registration/campaign-registration.component';
import { CardListComponent } from './card-list/card-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { ContentBlocksDirective } from './content-blocks.directive';
import { DashboardOverviewComponent } from './dashboard-overview/dashboard-overview.component';
import { DonationCounterComponent } from './donation-counter/donation-counter.component';
import { ExpirationsComponent } from './expirations/expirations.component';
import { ExportPersonalDataComponent } from './export-personal-data/export-personal-data.component';
import { FormattedTextComponent } from './formatted-text/formatted-text.component';
import { HighlightedCardComponent } from './highlighted-card/highlighted-card.component';
import { HighlightedProductsComponent } from './highlighted-products/highlighted-products.component';
import { HighlightedPromotionsComponent } from './highlighted-promotions/highlighted-promotions.component';
import { ImageComponent } from './image/image.component';
import { InboxComponent } from './inbox/inbox.component';
import { LoginComponent } from './login/login.component';
import { OrganizationOverviewComponent } from './organization-overview/organization-overview.component';
import { PartnerLoginComponent } from './partner-login/partner-login.component';
import { PartnerLogosComponent } from './partners-logos/partner-logos.component';
import { PasswordTokenComponent } from './password-token/password-token.component';
import { PlayableWidgetComponent } from './playable-widget/playable-widget.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { PurchasedVouchersComponent } from './purchased-vouchers/purchased-vouchers.component';
import { RecentTransactionsComponent } from './recent-transactions/recent-transactions.component';
import { ReferralRewardsComponent } from './referral-rewards/referral-rewards.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ShareAccountComponent } from './share-account/share-account.component';
import { ShareReferralLinkComponent } from './share-referral-link/share-referral-link.component';
import { TerminateAccountComponent } from './terminate-account/terminate-account.component';
import { TextListComponent } from './text-list/text-list.component';
import { TransferPointsComponent } from './transfer-points/transfer-points.component';
import { TypeformComponent } from './typeform/typeform.component';
import { UserActionComponent } from './user-action/user-action.component';
import { VideoComponent } from './video/video.component';

@Component({
  selector: 'air-content-blocks',
  templateUrl: './content-blocks.component.html',
  standalone: false
})
export class ContentBlocksComponent implements OnInit {
  @Input() content: IContentBlock[];
  @Input() region: ContentBlockRegion;
  @Input() hasDedicatedContent: boolean;
  @ViewChild(ContentBlocksDirective, { static: true }) airContentBlocks: ContentBlocksDirective;

  constructor(private renderer2: Renderer2) {}

  ngOnInit(): void {
    this.loadContent();
  }

  loadContent(): void {
    const viewContainerRef = this.airContentBlocks.viewContainerRef;

    if (!this.content) {
      return;
    }

    this.content.forEach((block, index) => {
      const channel = PlatformHelper.isNativeMobile ? Channel.app : Channel.web;

      if (block.channels?.length && !block.channels.includes(channel)) {
        return;
      }

      const component = this.mapBlockToComponent(block);

      // If component is null, return
      if (!component) {
        return;
      }

      const componentRef = viewContainerRef.createComponent(component);
      const regionString = this.region.replace('partnerPrimary', 'primary');
      componentRef.instance.isFirst = index === 0;
      componentRef.instance.content = block;
      componentRef.instance.region = this.region;
      componentRef.instance.userEventSource = `${StringHelper.convertCamelCaseToSpaces(block.contentTypeAlias)} - ${regionString}`;

      const wrapper = this.renderer2.createElement('div') as Node;
      this.renderer2.addClass(wrapper, 'content-block');
      this.renderer2.addClass(wrapper, `content-block--${componentRef.instance.className}`);

      const componentElement = componentRef.location.nativeElement as Node;
      const componentParent = componentElement.parentNode;
      this.renderer2.insertBefore(componentParent, wrapper, componentElement);
      this.renderer2.appendChild(wrapper, componentElement);
    });
  }

  mapBlockToComponent(block: IContentBlock): Type<IContentBlockComponent> | null {
    let component: Type<IContentBlockComponent> | null = null;
    const alignedImage = ObjectHelper.wrapFieldToArray((block as IFormattedText).alignedImage);

    switch (block.contentTypeAlias) {
      case ContentBlockType.formattedText:
        component =
          this.region === ContentBlockRegion.highlighted && alignedImage.length > 0 ? HighlightedCardComponent : FormattedTextComponent;
        break;

      case ContentBlockType.text:
        component = FormattedTextComponent;
        break;

      case ContentBlockType.captionedImage:
        component = ImageComponent;
        break;

      case ContentBlockType.actionList:
      case ContentBlockType.cardList:
        component = CardListComponent;
        break;

      case ContentBlockType.textList:
        component = TextListComponent;
        break;

      case ContentBlockType.highlightedProducts:
      case ContentBlockType.featuredProducts:
        component = HighlightedProductsComponent;
        break;

      case ContentBlockType.productOverview:
        component = ProductOverviewComponent;
        break;

      case ContentBlockType.registrationForm:
        component = RegistrationFormComponent;
        break;

      case ContentBlockType.passwordReset:
        component = PasswordResetComponent;
        break;

      case ContentBlockType.updateProfile:
        component = UpdateProfileComponent;
        break;

      case ContentBlockType.updatePassword:
        component = UpdatePasswordComponent;
        break;

      case ContentBlockType.dashboardOverview:
        component = DashboardOverviewComponent;
        break;

      case ContentBlockType.highlightedPromotions:
        component = HighlightedPromotionsComponent;
        break;

      case ContentBlockType.updatePersonalizationPreferences:
      case ContentBlockType.updatePromotionPreferences:
      case ContentBlockType.updateInboxPreferences:
      case ContentBlockType.updatePushPromotionPreferences:
      case ContentBlockType.updatePushServicePreferences:
      case ContentBlockType.updateBiometricsPreferences:
        component = UserActionComponent;
        break;

      case ContentBlockType.vouchers:
        component = PurchasedVouchersComponent;
        break;

      case ContentBlockType.partnerLogos:
        component = PartnerLogosComponent;
        break;

      case ContentBlockType.login:
        component = LoginComponent;
        break;

      case ContentBlockType.partnerLogin:
        component = PartnerLoginComponent;
        break;

      case ContentBlockType.passwordToken:
        component = PasswordTokenComponent;
        break;

      case ContentBlockType.contactForm:
        component = ContactFormComponent;
        break;

      case ContentBlockType.transferPoints:
        component = TransferPointsComponent;
        break;

      case ContentBlockType.terminateAccount:
        component = TerminateAccountComponent;
        break;

      case ContentBlockType.organizationLogos:
        component = OrganizationOverviewComponent;
        break;

      case ContentBlockType.blockCard:
        component = BlockCardComponent;
        break;

      case ContentBlockType.transactions:
        component = RecentTransactionsComponent;
        break;

      case ContentBlockType.expirations:
        component = ExpirationsComponent;
        break;

      case ContentBlockType.campaignRegistration:
        component = CampaignRegistrationComponent;
        break;

      case ContentBlockType.shareAccount:
        component = ShareAccountComponent;
        break;

      case ContentBlockType.personalData:
        component = ExportPersonalDataComponent;
        break;

      case ContentBlockType.video:
        component = VideoComponent;
        break;

      case ContentBlockType.bookingWidget:
        component = BookingWidgetComponent;
        break;

      case ContentBlockType.playableWidget:
        component = PlayableWidgetComponent;
        break;

      case ContentBlockType.donationCounter:
        component = DonationCounterComponent;
        break;

      case ContentBlockType.banner:
        component = BannerComponent;
        break;

      case ContentBlockType.setPassword:
        component = PasswordSetComponent;
        break;

      case ContentBlockType.shareReferralLink:
        component = ShareReferralLinkComponent;
        break;

      case ContentBlockType.referralRewards:
        component = ReferralRewardsComponent;
        break;

      case ContentBlockType.inbox:
        component = InboxComponent;
        break;

      case ContentBlockType.typeform:
        component = TypeformComponent;
        break;
    }

    return component;
  }
}
