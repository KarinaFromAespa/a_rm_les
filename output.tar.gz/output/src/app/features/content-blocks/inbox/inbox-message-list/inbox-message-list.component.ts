import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IInboxMessage } from 'src/app/core/models/inbox-message.model';

@Component({
  selector: 'air-inbox-message-list',
  templateUrl: './inbox-message-list.component.html',
  standalone: false
})
export class InboxMessageListComponent {
  @Input() messages: IInboxMessage[] = [];
  @Input() activeMessage?: IInboxMessage;
  @Output() activeMessageId = new EventEmitter<number>();
  @Output() deleteMessageId = new EventEmitter<{ messageId: number; label?: string }>();
  @Output() manage = new EventEmitter<{ isManage: boolean; label?: string }>();

  activeId?: number;
  isManage = false;

  showMessage(id: number): void {
    if (!this.isManage) {
      this.activeMessageId.emit(id);
    }
  }

  toggleIsManage(event: Event): void {
    this.isManage = !this.isManage;
    this.manage.emit({ isManage: this.isManage, label: event.text() });
  }

  deleteMessage(id: number): void {
    if (this.activeId === id) {
      this.activeId = undefined;
    }
    this.deleteMessageId.emit({ messageId: id });
  }
}
