import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { IInbox } from 'src/app/core/models/content.model';
import { IInboxMessage } from 'src/app/core/models/inbox-message.model';
import { InboxMessage } from 'src/app/core/models/user-event.model';
import { InboxService } from 'src/app/core/services/inbox.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { IConfirmationModal } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.model';
import { ModalHelper } from '../../modal/modal.helper';
import { ToastOptions, ToastType } from '../../toasts/toast.model';
import { ToastService } from '../../toasts/toast.service';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-inbox',
  templateUrl: './inbox.component.html',
  standalone: false
})
export class InboxComponent implements IContentBlockComponent, OnInit {
  className = 'inbox';
  content: IInbox;
  userEventSource: string;

  isLoading = true;
  isInboxEnabled = false;
  isManage = false;
  messages: IInboxMessage[] = [];
  activeMessage?: IInboxMessage;
  deleteMessageConfirmModal: IConfirmationModal;

  constructor(
    private translateService: TranslateService,
    private inboxService: InboxService,
    private toastService: ToastService,
    private userService: UserService,
    private modalHelper: ModalHelper,
    private inboxHelper: InboxHelper,
    private userEventService: UserEventService
  ) {}

  async ngOnInit(): Promise<void> {
    void this.inboxHelper.refreshUnreadInboxCount();

    this.deleteMessageConfirmModal = {
      text: this.content.deleteConfirmationText,
      confirmText: this.translateService.instant('general.label.remove') as string,
      cancelText: this.translateService.instant('general.label.cancel') as string,
      userEventSource: this.userEventSource,
      userEventSourceTopic: 'remove'
    } as IConfirmationModal;

    this.isInboxEnabled = (await this.userService.getUserInboxPreferences()).enableInbox;
    if (this.isInboxEnabled) {
      this.messages = await this.inboxService.getMessages();
      this.pushUserEvent(UserEventAction.view, undefined, this.messages);
    }
    this.isLoading = false;
  }

  setActiveMessage(id: number): void {
    const message = this.messages.find((m) => m.id === id);
    this.pushUserEvent(UserEventAction.open, undefined, message);
    if (message) {
      message.isRead = true;
    }
    this.activeMessage = message;
  }

  async deleteMessage(event: { messageId: number; label?: string }): Promise<void> {
    const message = this.messages.find((m) => m.id === event.messageId);
    this.pushUserEvent(UserEventAction.remove, event.label, message);

    this.deleteMessageConfirmModal.userEventObject = message ? new InboxMessage(message) : undefined;
    this.deleteMessageConfirmModal.action = async () => {
      if (this.activeMessage?.id === event.messageId) {
        this.activeMessage = undefined;
      }

      this.messages = this.messages.filter((m) => m.id !== event.messageId); //Delete immediately to make the action feel quick
      await this.inboxService.deleteMessage(event.messageId);

      this.toastService.show(
        new ToastOptions({
          type: ToastType.success,
          content: this.content.deleteSuccessText
        })
      );

      //Refresh messages there could be older messaged that weren't loaded, delayed so the inbox provided can process delete request
      setTimeout(() => {
        void this.inboxHelper.refreshUnreadInboxCount();
        void this.inboxService.getMessages().then((messages) => {
          this.messages = messages;
          this.pushUserEvent(UserEventAction.view, undefined, this.messages);
        });
      }, 1500);
    };
    return this.modalHelper.triggerConfirmationModal(this.deleteMessageConfirmModal);
  }

  setIsManage(event: { isManage: boolean; label?: string }): void {
    this.pushUserEvent(event.isManage ? UserEventAction.open : UserEventAction.close, event.label);
    this.isManage = event.isManage;
  }

  private pushUserEvent(action: UserEventAction, label?: string, messages?: IInboxMessage | IInboxMessage[]): void {
    this.userEventService.pushEvent(
      this.userEventSource,
      action,
      label,
      undefined,
      Array.isArray(messages)
        ? messages.map((message, index) => new InboxMessage(message, index + 1))
        : messages
          ? new InboxMessage(messages)
          : null
    );
  }
}
