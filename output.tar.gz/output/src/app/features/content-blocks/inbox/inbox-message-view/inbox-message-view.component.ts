import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { IInboxMessage } from 'src/app/core/models/inbox-message.model';
import { InboxService } from 'src/app/core/services/inbox.service';

@Component({
  selector: 'air-inbox-message-view',
  templateUrl: './inbox-message-view.component.html',
  standalone: false
})
export class InboxMessageViewComponent implements OnChanges {
  @Input() message: IInboxMessage;
  @Output() deleteMessageId = new EventEmitter<{ messageId: number; label?: string }>();

  constructor(
    private inboxService: InboxService,
    private inboxHelper: InboxHelper
  ) {}

  async ngOnChanges(changes: SimpleChanges): Promise<void> {
    if (
      changes.message.firstChange ||
      (changes.message && (changes.message.currentValue as IInboxMessage).id !== (changes.message.previousValue as IInboxMessage).id)
    ) {
      await this.inboxService.messageRead(this.message.id);
      setTimeout(() => {
        void this.inboxHelper.refreshUnreadInboxCount();
      }, 1500);
    }
  }

  async trackMessageAction(): Promise<void> {
    await this.inboxService.messageAction(this.message.id);
  }

  getActionTarget(url: string): string {
    return UrlHelper.isExternalLink(url) ? '_blank' : '_self';
  }

  deleteMessage(event: Event): void {
    this.deleteMessageId.emit({ messageId: this.message.id, label: event.text() });
  }
}
