import { Component, OnInit } from '@angular/core';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ContentBlockRegion, IActionList, ICard, ICardList } from 'src/app/core/models/content.model';
import { IPageLink } from 'src/app/core/models/site.response';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';

@Component({
  selector: 'air-card-list',
  templateUrl: './card-list.component.html',
  standalone: false
})
export class CardListComponent implements IContentBlockComponent, OnInit {
  className = 'card-list';
  contentBlockRegion = ContentBlockRegion;
  region?: ContentBlockRegion;
  isFirst?: boolean;
  content: IActionList | ICardList;
  userEventSource: string;

  unifiedLink?: IPageLink;

  ngOnInit(): void {
    this.unifiedLink = ObjectHelper.wrapFieldToArray(this.content.link)[0];
  }

  get cards(): ICard[] {
    return 'actions' in this.content ? this.content.actions : this.content.cards;
  }
}
