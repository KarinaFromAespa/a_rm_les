import { Component, Input, OnInit } from '@angular/core';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { ICard } from 'src/app/core/models/content.model';
import { IImage, IPageLink } from 'src/app/core/models/site.response';

@Component({
  selector: 'air-card-list-item',
  templateUrl: './card-list-item.component.html',
  standalone: false
})
export class CardListItemComponent implements ICard, OnInit {
  @Input() description?: string;
  @Input() image: IImage;
  @Input() link?: IPageLink | IPageLink[];
  @Input() title: string;
  @Input() userEventSource: string;
  @Input() step?: number;

  contentTypeAlias: string;
  unifiedLink?: IPageLink;

  get linkLabel(): string {
    return [this.step, this.title].filter((x) => !!x).join(' ');
  }

  ngOnInit(): void {
    // Preview and normal modes contain different structures - we have to convert it into IPageLink[]
    this.unifiedLink = this.link ? ObjectHelper.wrapFieldToArray(this.link)[0] : undefined;
  }
}
