import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { BookingWidgetType } from 'src/app/core/constants/booking-widget.constants';
import { ContentBlockRegion, IBookingWidget } from 'src/app/core/models/content.model';
import { IContentBlockComponent } from '../content-block-component.model';

@Component({
  selector: 'air-booking-widget',
  templateUrl: './booking-widget.component.html',
  standalone: false
})
export class BookingWidgetComponent implements IContentBlockComponent, AfterViewInit {
  @ViewChild('bookingWidget') widgetElement: ElementRef<HTMLIFrameElement>;

  className = 'booking-widget';
  isFirst?: boolean;
  region?: ContentBlockRegion;
  content: IBookingWidget;
  userEventSource: string;
  isLoading = true;

  private readonly baseUrl =
    'https://www.booking.com/flexiproduct.html?product={0}&w={1}&h={2}&lang={3}&aid={4}&target_aid={5}&selected_currency={6}';

  constructor(
    private translateService: TranslateService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngAfterViewInit(): void {
    this.setWidgetAttributes();
  }

  private setWidgetAttributes(): void {
    if (!this.widgetElement?.nativeElement) {
      return;
    }

    let product: string | null = null;
    let width = '';
    let height = '';

    const languageCode = this.translateService.currentLang || this.translateService.defaultLang;
    const parent = this.widgetElement.nativeElement.parentElement?.parentElement;
    const parentWidth = parent?.clientWidth;

    switch (this.content.type) {
      case BookingWidgetType.searchBox:
        product = 'nsb';
        width = '100%';
        height = '330';
        break;

      case BookingWidgetType.inspiringSearchBox:
        if (parentWidth && parentWidth < 500) {
          // 'Inspiring search box' is not responsive for smaller screens
          parent.style.display = 'none';
          break;
        }

        product = 'sbp';
        width = `${parentWidth || 500}`;
        height = '300';
        break;

      case BookingWidgetType.map:
        product = 'map';
        width = '100%';
        height = '590';
        break;
    }

    if (!product?.length) {
      this.isLoading = false;
      this.cdRef.detectChanges();

      return;
    }

    let src = this.appendWidgetAttributesFromSettings(this.baseUrl);
    src = src.format([product, width, height, languageCode, this.content.widgetId, this.content.affiliateId, 'EUR']);

    this.widgetElement.nativeElement.src = src;
    this.widgetElement.nativeElement.width = width;
    this.widgetElement.nativeElement.height = height;
    this.widgetElement.nativeElement.style.width = width;
    this.widgetElement.nativeElement.style.height = height;

    this.isLoading = false;
    this.cdRef.detectChanges();
  }

  private appendWidgetAttributesFromSettings(src: string): string {
    if (!this.content.settings?.length) {
      return this.appendDefaultWidgetAttributes(src);
    }

    this.content.settings.forEach((setting) => {
      const name = setting.split('=')[0].replace(/data-/g, '');
      const value = setting.split('=')[1].replace(/"/g, '');
      src += `&${name}=${value}`;
    });

    return this.appendDefaultWidgetAttributes(src);
  }

  private appendDefaultWidgetAttributes(src: string): string {
    if (this.content.type === BookingWidgetType.map) {
      if (!src.includes('&latitude=')) {
        src += `&latitude=52.132633`;
      }
      if (!src.includes('&longitude=')) {
        src += `&longitude=5.291266`;
      }
      if (!src.includes('&zoom=')) {
        src += `&zoom=7`;
      }
    }

    return src;
  }
}
