import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContentBlocksModule } from '../content-blocks/content-blocks.module';
import { PageRoutingModule } from './page-routing.module';
import { PageComponent } from './page.component';

@NgModule({
  declarations: [PageComponent],
  imports: [CommonModule, PageRoutingModule, ContentBlocksModule, SharedModule]
})
export class PageModule {}
