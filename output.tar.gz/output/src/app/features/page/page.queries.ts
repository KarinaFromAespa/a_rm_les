import gql from 'graphql-tag';

export const redirectsQuery = gql`
  query RedirectsQuery {
    content(url: "/resources/redirects") {
      children {
        items {
          ... on Redirect {
            sourcePath
            targetPage {
              url
            }
          }
        }
      }
    }
  }
`;

export const checkPageQuery = gql`
  query CheckPage($url: String!) {
    content(url: $url) {
      id
    }
  }
`;
