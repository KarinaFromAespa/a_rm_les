import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContentBlocksModule } from '../../content-blocks/content-blocks.module';
import { AbstractLoadablePageModule } from '../loadable-page.abstract';
import { PersonalModule } from '../../personal/personal.module';
import { ContentPageComponent } from './content-page.component';

@NgModule({
  declarations: [ContentPageComponent],
  imports: [CommonModule, ContentBlocksModule, SharedModule, PersonalModule],
  exports: [ContentPageComponent]
})
export class ContentPageModule extends AbstractLoadablePageModule {
  rootComponent = ContentPageComponent;

  constructor() {
    super();
  }
}
