import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { IContentPageResponse } from 'src/app/core/models/page.response';
import { AbstractLoadablePageComponent } from '../loadable-page.abstract';

@Component({
  selector: 'air-content-page',
  templateUrl: './content-page.component.html',
  standalone: false
})
export class ContentPageComponent extends AbstractLoadablePageComponent implements OnInit, OnDestroy {
  pageData: IContentPageResponse;

  get hasPrimaryContent(): boolean {
    return this.pageData.primaryContent.length > 0;
  }

  get hasWidePrimaryContent(): boolean {
    return this.pageData.primaryContent.filter((x) => SiteConstants.wideContentTypes.includes(x.contentTypeAlias)).length > 0;
  }

  get hasSecondaryContent(): boolean {
    return !!this.pageData.secondaryContent?.length;
  }

  get isPersonalPage(): boolean {
    return PageHelper.isAuthorizedPage(this.pageData);
  }

  constructor(cdRef: ChangeDetectorRef) {
    super(cdRef);
  }
}
