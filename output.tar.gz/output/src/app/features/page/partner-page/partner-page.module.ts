import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContentBlocksModule } from '../../content-blocks/content-blocks.module';
import { AbstractLoadablePageModule } from '../loadable-page.abstract';
import { PartnerPageComponent } from './partner-page.component';

@NgModule({
  declarations: [PartnerPageComponent],
  imports: [CommonModule, SharedModule, ContentBlocksModule],
  exports: [PartnerPageComponent]
})
export class PartnerPageModule extends AbstractLoadablePageModule {
  rootComponent = PartnerPageComponent;

  constructor() {
    super();
  }
}
