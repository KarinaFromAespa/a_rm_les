import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ContentBlockType, IHighlightedProducts } from 'src/app/core/models/content.model';
import { IPartnerPageResponse } from 'src/app/core/models/page.response';
import { AbstractLoadablePageComponent } from '../loadable-page.abstract';

@Component({
  selector: 'air-partner-page',
  templateUrl: './partner-page.component.html',
  standalone: false
})
export class PartnerPageComponent extends AbstractLoadablePageComponent implements OnInit, OnDestroy {
  pageData: IPartnerPageResponse;
  highlightedProducts: IHighlightedProducts;
  userEventSource = UserEventSource.details;

  constructor(
    cdRef: ChangeDetectorRef,
    private translateService: TranslateService
  ) {
    super(cdRef);
  }

  ngOnInit(): void {
    super.ngOnInit();

    if (this.pageData?.supplierCode?.length) {
      this.highlightedProducts = {
        contentTypeAlias: ContentBlockType.highlightedProducts,
        title: (this.translateService.instant('partner.label.redemption_offers') as string).format([this.pageData.title]),
        numberOfProducts: 4,
        supplierCode: this.pageData.supplierCode
      };
    }
  }
}
