import { Location } from '@angular/common';
import { ChangeDetectorRef, Compiler, Component, Injector, NgModuleRef, OnDestroy, OnInit, ViewContainerRef } from '@angular/core';
import { NavigationEnd, Router, UrlTree } from '@angular/router';
import { EMPTY, Observable, Subject, from, of, throwError } from 'rxjs';
import { catchError, map, takeUntil } from 'rxjs/operators';
import { PageType } from 'src/app/core/constants/page.constants';
import { AuthHelper } from 'src/app/core/helpers/auth.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContentBlockRegion } from 'src/app/core/models/content.model';
import { IPageResponse } from 'src/app/core/models/page.response';
import { SiteService } from 'src/app/core/services/site.service';
import { PageService } from 'src/app/features/page/page.service';
import { AbstractLoadablePageModule } from './loadable-page.abstract';

@Component({
  templateUrl: './page.component.html',
  standalone: false
})
export class PageComponent implements OnInit, OnDestroy {
  pageData$: Observable<IPageResponse>;
  contentBlockRegion = ContentBlockRegion;
  loading = false;
  isInMaintenance: boolean;
  moduleRef: NgModuleRef<any>;

  destroy$ = new Subject();

  constructor(
    private pageService: PageService,
    private siteService: SiteService,
    private router: Router,
    private location: Location,
    private cdRef: ChangeDetectorRef,
    private authHelper: AuthHelper,
    private viewContainerRef: ViewContainerRef,
    private compiler: Compiler,
    private injector: Injector,
    private platformHelper: PlatformHelper
  ) {}

  ngOnInit(): void {
    this.fetchData();

    // Subscribe to routing events to capture same routing strategy,
    // which triggers re-fetching data for new url.
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cdRef.detectChanges();
        this.fetchData();
      }
    });
  }

  fetchData(): void {
    // Clear the viewContainer of the current page
    this.viewContainerRef.clear();
    this.loading = true;
    this.isInMaintenance = this.siteService.isInMaintenance;

    const snapshot = this.router.routerState.snapshot;
    const closeRequest$ = new Subject<any>();

    from(this.pageService.getPageData())
      .pipe(
        takeUntil(this.destroy$),
        takeUntil(closeRequest$),
        catchError(() =>
          // Check if the page url has redirects
          this.pageService.hasRedirects(snapshot).pipe(
            catchError((error) => throwError(error)),
            map((redirect) => {
              // If redirect is found, navigate there
              if (redirect) {
                void this.router.navigateByUrl(redirect as UrlTree);
                closeRequest$.next(void 0);
                closeRequest$.complete();
              } else {
                // Throw exception to catch in subsequent catchError
                throw EMPTY;
              }
            })
          )
        ),
        catchError(() => {
          // If it ends up here, it means no redirects have been found and the REST call also failed.
          // So redirect to not-found.
          void this.router.navigateByUrl(this.siteService.siteSettings.errorPageUrl, { skipLocationChange: true }).then(() => {
            this.location.replaceState(snapshot.url);
          });
          return of(null);
        })
      )
      .subscribe((page) => {
        this.platformHelper.onlineState = true;
        if (page) {
          void this.loadModule(page);
        }
      });
  }

  ngOnDestroy(): void {
    if (this.moduleRef) {
      this.moduleRef.destroy();
    }
    this.destroy$.next(void 0);
  }

  private async loadModule(page: IPageResponse): Promise<void> {
    let loadedModule: any;
    switch (page.contentTypeAlias) {
      case PageType.page:
      case PageType.plainPage:
      case PageType.maintenancePage:
        loadedModule = await import('./content-page/content-page.module').then((x) => x.ContentPageModule);
        break;
      case PageType.personalPageBasic:
      case PageType.personalPagePassword:
      case PageType.personalPageTwoFactor:
        if (!this.authHelper.canActivate()) {
          break;
        }
        loadedModule = await import('./content-page/content-page.module').then((x) => x.ContentPageModule);
        break;
      case PageType.partnerPage:
      case PageType.supplierPage:
        loadedModule = await import('./partner-page/partner-page.module').then((x) => x.PartnerPageModule);
        break;
      case PageType.productPage:
      case PageType.productPageCombined:
      case PageType.charity:
        loadedModule = await import('./product-page/product-page.module').then((x) => x.ProductPageModule);
        break;
      case PageType.ticketTemplatePage:
        loadedModule = await import('./ticket-template-page/ticket-template-page.module').then((x) => x.TicketTemplatePageModule);
        break;
      case PageType.campaignPage:
        if (!this.authHelper.canActivate()) {
          break;
        }
        loadedModule = await import('./campaign-page/campaign-page.module').then((x) => x.CampaignPageModule);
        break;
      case PageType.embeddedPage:
        loadedModule = await import('./embedded-page/embedded-page.module').then((x) => x.EmbeddedPageModule);
        break;
      default:
        console.warn('Page type undefined', page.contentTypeAlias);
        void this.router.navigateByUrl('/');
        break;
    }

    if (!loadedModule) {
      throw new Error('LoadedModule is undefined.');
    }

    // Compile the module
    void this.compiler
      .compileModuleAsync(loadedModule)
      .then((moduleFactory) => {
        // Create a moduleRef, resolve the module set rootComponent and create it
        this.moduleRef = moduleFactory.create(this.injector);
        const componentFactory = this.moduleRef.componentFactoryResolver.resolveComponentFactory(
          (this.moduleRef.instance as AbstractLoadablePageModule).rootComponent
        );

        const component = componentFactory.create(this.injector);
        this.viewContainerRef.insert(component.hostView);
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
