import { Injectable } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PageType } from 'src/app/core/constants/page.constants';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { removeCanonicalLink, setCanonicalLink } from 'src/app/core/helpers/canonical.helper';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { IPageResponse } from 'src/app/core/models/page.response';
import { IRedirectListResponse } from 'src/app/core/models/redirect.response';
import { ExternalTranslateService } from 'src/app/core/services/external-translate.service';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { SiteService } from 'src/app/core/services/site.service';
import { UmbracoApiService } from 'src/app/core/services/umbraco-api.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { MyCardSheetService } from 'src/app/shared/components/my-card-sheet/my-card-sheet.service';
import { redirectsQuery } from './page.queries';

@Injectable({ providedIn: 'root' })
export class PageService {
  pageDataSubject = new BehaviorSubject<IPageResponse | null>(null);
  pageData$ = this.pageDataSubject.asObservable();

  constructor(
    private api: UmbracoApiService,
    private siteService: SiteService,
    protected router: Router,
    private titleService: Title,
    private metaService: Meta,
    private translateService: TranslateService,
    private graphQLService: GraphQLService,
    private platformHelper: PlatformHelper,
    private myCardSheetService: MyCardSheetService,
    private userEventService: UserEventService,
    private externalTranslateService: ExternalTranslateService
  ) {}

  async getPageData(url: string = this.router.url): Promise<IPageResponse> {
    this.pageDataSubject.next(null);

    // Make sure we fetch the page context first and await its response
    const pageContext = await this.siteService.loadPageContext();

    if (this.siteService.isInMaintenance) {
      url = pageContext?.maintenancePage._url ?? url;
      if (this.platformHelper.isMobile) {
        this.myCardSheetService.open();
      }
    }

    const previewMode = this.siteService.isInPreviewMode;
    const strippedUrl = PageHelper.stripUrl(url);
    const pageResponse = await this.api.get<IPageResponse>(`url?url=${strippedUrl}&depth=2&hyperlinks=false`, [0], true, previewMode);
    this.pageDataSubject.next(pageResponse);
    this.handleResponse(pageResponse);

    if (pageResponse.contentTypeAlias !== PageType.ticketTemplatePage) {
      this.userEventService.pushEvent(UserEventSource.page, UserEventAction.view, undefined, strippedUrl);
    } else {
      this.siteService.clearContext();
    }

    return pageResponse;
  }

  private handleResponse(data: IPageResponse): void {
    // If hero title is empty, set hero title to page title.
    if (data.hero && !data.hero?.title) {
      data.hero.title = data.title;
    }

    this.setMetaData(data);
    this.externalTranslateService.load(data.languages);
    this.userEventService.setUserEventCategory(data.contentTypeAlias);
    this.userEventService.pageTitle = data.title;
  }

  hasRedirects(state: RouterStateSnapshot): Observable<UrlTree | undefined> {
    const strippedUrl = PageHelper.stripUrl(state.url);
    return this.graphQLService.watchQuery<IRedirectListResponse>(redirectsQuery).pipe(
      map((redirectsResult) => {
        const data = redirectsResult.data;
        const redirect = data.content.children.items.filter(
          (x) => x.sourcePath.toLowerCase().trim().replace(/^\/+/g, '') === strippedUrl.replace(/^\/+/g, '')
        );

        if (redirect && redirect.length > 0) {
          let splitUrl = state.url.split('?');
          let params = '';
          if (splitUrl.length > 1) {
            params = `?${splitUrl[1]}`;
          } else {
            splitUrl = state.url.split('#');
            if (splitUrl.length > 1) {
              params = `#${splitUrl[1]}`;
            }
          }
          const targetUrl = `${redirect[0].targetPage.url}${params}`;

          return this.router.parseUrl(targetUrl);
        }
      })
    );
  }

  setMetaData(data: IPageResponse): void {
    this.addMetaName('theme-color', getComputedStyle(document.documentElement).getPropertyValue('--color-primary'));

    this.titleService.setTitle(this.formatTitle(data.title));
    this.addMetaProperty('og:title', data.ogTitle ? data.ogTitle : data.hero?.title ? data.hero.title : data.title);

    if (data.ogDescription) {
      this.addMetaProperty('og:description', data.ogDescription);
    }

    const origin = window.location.origin;
    this.addMetaProperty('og:url', `${origin}${this.router.url}`);

    const ogImage = data.ogImage ?? data.hero?.image;
    this.addMetaProperty('og:image', ogImage?.umbracoFile?.cropUrls['Social Media Card'] ?? `${origin}/assets/images/og-image.jpg`);

    if (data.seoDescription) {
      this.addMetaName('description', data.seoDescription);
    }

    if (data.keywords) {
      this.addMetaName('keywords', data.keywords.join(', '));
    }

    if (!SiteConstants.indexedContentTypes.includes(data.contentTypeAlias) || data.noIndex) {
      this.addMetaName('robots', 'noindex');
    }

    this.handleCanonical(data);
  }

  private addMetaName(name: string, content: string) {
    this.metaService.updateTag({ name, content }, `name='${name}'`);
  }

  private addMetaProperty(name: string, content: string) {
    this.metaService.updateTag({ property: name, content }, `property='${name}'`);
  }

  private formatTitle(title: string) {
    return `${title} - ${this.translateService.instant('general.label.air_miles') as string}`;
  }

  private handleCanonical(data: IPageResponse): void {
    let canonicalUrl: string | null = null;
    if (data._url === this.siteService.siteSettings.homePageUrl) {
      //For homepage canonical should be the root domain
      canonicalUrl = `https://${document.location.host.replace(/\/$/, '')}`;
    } else if (data._url) {
      canonicalUrl = `https://${document.location.host}${data._url.replace(/\/$/, '')}`;
    }
    if (canonicalUrl) {
      setCanonicalLink(canonicalUrl);
    } else {
      removeCanonicalLink();
    }
  }
}
