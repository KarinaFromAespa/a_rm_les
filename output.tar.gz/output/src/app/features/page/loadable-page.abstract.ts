import { ChangeDetectorRef, Component, HostBinding, NgModule, OnDestroy, OnInit, Type } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AppModule } from 'src/app/app.module';
import { PageType } from 'src/app/core/constants/page.constants';
import { StringHelper } from 'src/app/core/helpers/string.helper';
import { ContentBlockRegion } from 'src/app/core/models/content.model';
import { PageService } from './page.service';

@NgModule()
export abstract class AbstractLoadablePageModule {
  abstract rootComponent: Type<any>;
}

@Component({
  template: '',
  standalone: false
})
export abstract class AbstractLoadablePageComponent implements OnInit, OnDestroy {
  @HostBinding('class') get class(): string {
    this.cdRef.detectChanges();
    return `page ${this.pageType ? 'page--' + StringHelper.toKebabCase(this.pageType) : ''}`;
  }
  protected pageService: PageService;

  abstract pageData: any;
  contentBlockRegion = ContentBlockRegion;
  loading = false;

  pageType: PageType;

  protected destroy$ = new Subject();

  constructor(protected cdRef: ChangeDetectorRef) {
    this.pageService = AppModule.appInjector.get(PageService);
  }

  ngOnInit(): void {
    this.pageService.pageData$.pipe(takeUntil(this.destroy$)).subscribe((pageData) => {
      if (pageData) {
        this.pageData = pageData;
        this.pageType = (pageData.contentTypeAlias as PageType) || PageType.page;
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
