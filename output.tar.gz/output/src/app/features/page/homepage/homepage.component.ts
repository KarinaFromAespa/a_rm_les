import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ContentBlockRegion } from 'src/app/core/models/content.model';
import { IContentPageResponse } from 'src/app/core/models/page.response';
import { SiteService } from 'src/app/core/services/site.service';
import { PageService } from '../page.service';

@Component({
  selector: 'air-homepage',
  templateUrl: './homepage.component.html',
  standalone: false
})
export class HomepageComponent implements OnInit, OnDestroy {
  @HostBinding('class') readonly class: string = `page page--homepage`;

  pageData?: IContentPageResponse;
  contentBlockRegion = ContentBlockRegion;
  destroy$ = new Subject();
  private homeUrl?: string;

  constructor(
    private pageService: PageService,
    private siteService: SiteService,
    private router: Router,
    private userHelper: UserHelper
  ) {}

  async ngOnInit(): Promise<void> {
    if (this.useAppUrl()) {
      await this.router.navigate([this.homeUrl]);
      window.history.replaceState({}, '', '\\');
      return;
    }

    await this.loadPageData();
  }

  private useAppUrl(): boolean {
    const useAppUrl =
      !!this.siteService.siteSettings?.appHomePageUrl &&
      PlatformHelper.isNativeMobile &&
      this.userHelper.isLoggedIn &&
      !this.siteService.pageContext.value &&
      this.router.url !== SiteConstants.rootRoute;

    const homeUrlFragment = useAppUrl ? this.siteService.siteSettings?.appHomePageUrl : this.siteService.siteSettings?.homePageUrl;
    const [, queryParams] = this.router.url.split('?');
    const queryParamsFragment = queryParams ? `?${queryParams}` : '';
    this.homeUrl = homeUrlFragment ? `${homeUrlFragment}${queryParamsFragment}` : undefined;

    return useAppUrl;
  }

  private async loadPageData() {
    this.pageData = this.homeUrl ? ((await this.pageService.getPageData(this.homeUrl)) as IContentPageResponse) : undefined;

    // Subscribe to routing events to capture same routing strategy,
    // which triggers re-fetching data for new url.
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe(() => async (event) => {
      if (event instanceof NavigationEnd) {
        this.pageData = this.homeUrl ? ((await this.pageService.getPageData(this.homeUrl)) as IContentPageResponse) : undefined;
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
