import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContentBlocksModule } from '../../content-blocks/content-blocks.module';
import { ProductModule } from '../../products/products.module';
import { HomepageRoutingModule } from './homepage-routing.module';
import { HomepageComponent } from './homepage.component';

@NgModule({
  declarations: [HomepageComponent],
  imports: [CommonModule, SharedModule, ContentBlocksModule, HomepageRoutingModule, ProductModule]
})
export class HomepageModule {}
