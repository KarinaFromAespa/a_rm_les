import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AnimationStates, animationSheetDown } from 'src/app/core/animations/sheet.animations';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { BannerTheme } from 'src/app/core/constants/banner.constants';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { PromotionHelper } from 'src/app/core/helpers/promotion.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { IExpiration } from 'src/app/core/models/transaction.model';
import { ResizeService } from 'src/app/core/services/resize.service';
import { SiteService } from 'src/app/core/services/site.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { MyCardSheetService } from 'src/app/shared/components/my-card-sheet/my-card-sheet.service';
import { IntersectionStatus } from 'src/app/shared/directives/intersection-observer.directive';

@Component({
  selector: 'air-card-details',
  templateUrl: './card-details.component.html',
  animations: [animationSheetDown],
  standalone: false
})
export class CardDetailsComponent implements OnInit, OnDestroy {
  @Input() pointsEarned?: number;
  @Input() pointsSpent?: number;
  @Input() upcomingExpiration?: IExpiration;
  @Input() expirationsPageUrl?: string;
  @Input() inboxPageUrl?: string;
  @Input() loading: boolean;

  bannerTheme = BannerTheme;
  userEventSource = UserEventSource.cardDetails;
  currentScreenSize: ScreenSize;
  screenSize = ScreenSize;

  destroy$ = new Subject();
  currentUser?: IUserLoginData;

  isMobile: boolean;
  isiOSMobile: boolean;
  unactivatedPromotionsCount: number;
  promotionsPageUrl?: string;
  unreadInboxCount: number;

  animationState: string = AnimationStates.closed;
  animationStates = AnimationStates;
  intersectionStatus = IntersectionStatus;

  get hasUpcomingExpiration(): boolean {
    return !!this.upcomingExpiration;
  }

  get showPromotionsNotification(): boolean {
    return this.unactivatedPromotionsCount > 0 && !!this.promotionsBannerPageUrl?.length;
  }

  get balance(): number | undefined {
    return this.currentUser?.balance;
  }

  get promotionsBannerIcon(): string {
    return this.hasUpcomingExpiration ? 'icon-ui-alert' : 'icon-ui-gift';
  }

  get promotionsBannerPageUrl(): string | undefined {
    return this.hasUpcomingExpiration
      ? this.expirationsPageUrl
        ? `${this.expirationsPageUrl}#expirations`
        : undefined
      : this.promotionsPageUrl;
  }

  get promotionsBannerTheme(): BannerTheme {
    return this.hasUpcomingExpiration ? BannerTheme.redLight : BannerTheme.pink;
  }

  get showUnreadInboxNotification(): boolean {
    return this.unreadInboxCount > 0 && !!this.inboxPageUrl?.length;
  }

  constructor(
    private userHelper: UserHelper,
    private resizeService: ResizeService,
    private myCardSheetService: MyCardSheetService,
    private platformHelper: PlatformHelper,
    private userEventService: UserEventService,
    private siteService: SiteService,
    private promotionHelper: PromotionHelper,
    private inboxHelper: InboxHelper
  ) {}

  ngOnInit(): void {
    this.resizeService.onResize$.pipe(takeUntil(this.destroy$)).subscribe((size) => {
      this.currentScreenSize = size;
    });

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((pageContext) => {
      this.promotionsPageUrl = pageContext?.promotionsPage?._url;

      this.inboxPageUrl = pageContext?.inboxPage?._url;
    });

    this.userHelper.currentUser$.pipe(takeUntil(this.destroy$)).subscribe((user) => {
      this.currentUser = user as IUserLoginData | undefined;
    });

    this.promotionHelper.unactivatedPromotionsCount$.pipe(takeUntil(this.destroy$)).subscribe((numberOfUnactivatedPromotions) => {
      this.unactivatedPromotionsCount = numberOfUnactivatedPromotions;
    });

    this.inboxHelper.unreadInboxCount$.pipe(takeUntil(this.destroy$)).subscribe((unreadInboxCount) => {
      this.unreadInboxCount = unreadInboxCount;
    });

    this.isMobile = this.platformHelper.isMobile;
    this.isiOSMobile = this.platformHelper.isiOSMobile;
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onVisibilityChanged(status: IntersectionStatus): void {
    this.animationState = status === IntersectionStatus.notVisible ? AnimationStates.open : AnimationStates.closed;
  }

  openCardSheet(): void {
    this.pushUserEvent(UserEventAction.open, 'card sheet');
    this.myCardSheetService.open();
  }

  private pushUserEvent(action: UserEventAction, label: string) {
    this.userEventService.pushEvent(this.userEventSource, action, label);
  }
}
