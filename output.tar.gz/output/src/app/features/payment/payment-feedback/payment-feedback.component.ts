import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PaymentFeedbackType } from 'src/app/core/constants/payment.constants';
import { ProductType } from 'src/app/core/constants/product.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { StringHelper } from 'src/app/core/helpers/string.helper';
import { IText } from 'src/app/core/models/content.model';
import { PageContext } from 'src/app/core/models/site.response';
import { CommerceOrder } from 'src/app/core/models/user-event.model';
import { SiteService } from 'src/app/core/services/site.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalRef } from '../../modal/modal-ref';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'air-payment-feedback',
  templateUrl: './payment-feedback.component.html',
  standalone: false
})
export class PaymentFeedbackComponent implements OnInit {
  public paymentFeedbackType = PaymentFeedbackType;
  @Input() feedbackType: PaymentFeedbackType;
  @Input() productType?: ProductType;
  @Input() successText?: IText;
  @Input() failedText?: IText;
  @Input() failedPaymentText?: IText;
  @Input() userEventSource: string;
  @Input() commerceOrder?: CommerceOrder;

  pageContext?: PageContext | null;
  transactionId?: string;
  destroy$ = new Subject();

  get feedbackFailed(): IText | undefined {
    return this.productType === ProductType.charity ? this.pageContext?.donationFailed : this.pageContext?.orderFailed;
  }

  get feedbackFailedPayment(): IText | undefined {
    return this.pageContext?.orderFailedPayment;
  }

  get feedbackFailedPaymentDeepLink(): IText | undefined {
    return this.pageContext?.orderFailedPaymentDeepLink;
  }

  get feedbackFailedFunds(): IText | undefined {
    return this.productType === ProductType.charity ? this.pageContext?.donationFailedFunds : this.pageContext?.orderFailedFunds;
  }

  get feedbackFailedAccount(): IText | undefined {
    return this.pageContext?.donationFailedAccount;
  }

  get feedbackSuccess(): IText | undefined {
    return this.productType === ProductType.charity ? this.pageContext?.donationSuccess : this.pageContext?.orderSuccess;
  }

  get isCharity(): boolean {
    return this.productType === ProductType.charity;
  }

  constructor(
    private siteService: SiteService,
    private modalRef: ModalRef,
    private paymentService: PaymentService,
    private route: ActivatedRoute,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.transactionId = this.route.snapshot.queryParamMap.get('trxid') ?? undefined;

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageContext = data;
    });

    this.userEventSource = `${this.userEventSource} - order result`;
    this.pushUserEvent(UserEventAction.view, StringHelper.convertCamelCaseToSpaces(this.feedbackType), undefined, this.commerceOrder);
  }

  onButtonClick(event: Event): void {
    switch (this.feedbackType) {
      case PaymentFeedbackType.failed:
      case PaymentFeedbackType.failedFunds:
      case PaymentFeedbackType.failedAccount:
      case PaymentFeedbackType.success:
        this.pushUserEvent(UserEventAction.close, event.text());
        this.closeModal();
        break;
      case PaymentFeedbackType.failedPayment:
      case PaymentFeedbackType.failedPaymentDeepLink:
        this.pushUserEvent(UserEventAction.link, event.text(), 'retry');
        this.retryPayment();
        break;
      default:
        return;
    }
  }

  retryPayment(): void {
    if (!this.transactionId) {
      return;
    }
    this.paymentService.retryPaymentWithTransactionId(this.transactionId, this.userEventSource);
  }

  closeModal(pushUserEvent = false): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }

    void this.paymentService.resetPayment();
    this.modalRef.close();
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value, object);
  }
}
