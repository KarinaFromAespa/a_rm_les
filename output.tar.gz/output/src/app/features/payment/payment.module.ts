import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalRef } from '../modal/modal-ref';
import { PaymentFeedbackComponent } from './payment-feedback/payment-feedback.component';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { PaymentReceiptComponent } from './payment-receipt/payment-receipt.component';
import { PaymentTotalComponent } from './payment-total-cost/payment-total.component';
import { PAYMENT_FEEDBACK, PAYMENT_OPTIONS, PAYMENT_RECEIPT } from './payment.token';

@NgModule({
  declarations: [PaymentReceiptComponent, PaymentOptionsComponent, PaymentFeedbackComponent, PaymentTotalComponent],
  imports: [CommonModule, SharedModule, TranslateModule],
  providers: [
    ModalRef,
    { provide: PAYMENT_RECEIPT, useValue: PaymentReceiptComponent },
    { provide: PAYMENT_OPTIONS, useValue: PaymentOptionsComponent },
    { provide: PAYMENT_FEEDBACK, useValue: PaymentFeedbackComponent }
  ],
  exports: [PaymentReceiptComponent, PaymentOptionsComponent]
})
export class PaymentModule {}
