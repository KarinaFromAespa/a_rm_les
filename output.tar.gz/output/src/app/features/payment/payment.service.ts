import { Location } from '@angular/common';
import { Inject, Injectable, ɵComponentType } from '@angular/core';
import { Router } from '@angular/router';
import { InAppBrowser } from '@capgo/inappbrowser';
import { BehaviorSubject } from 'rxjs';
import { first } from 'rxjs/operators';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { PaymentFeedbackType } from 'src/app/core/constants/payment.constants';
import { ProductType } from 'src/app/core/constants/product.constants';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { IHttpError } from 'src/app/core/models/http.model';
import {
  IOrderCombinedProductRequest,
  IOrderCombinedProductVariant,
  IOrderProductRequest,
  IOrderWithDonationRequest,
  IOrderWithPriceRequest
} from 'src/app/core/models/order.model';
import {
  IPayment,
  IPaymentIssuer,
  IPaymentMethod,
  IPaymentMethodAPI,
  IPaymentOrderResponse,
  IPaymentReceipt
} from 'src/app/core/models/payment.model';
import { IBaseProduct } from 'src/app/core/models/product.model';
import { ITransferPointsToCharityRequest } from 'src/app/core/models/transfer-points.model';
import { CommerceOrder } from 'src/app/core/models/user-event.model';
import { ApiService } from 'src/app/core/services/api.service';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { TransactionService } from 'src/app/core/services/transaction.service';
import { CapacitorStorageService } from 'src/app/core/storage/capacitor-storage.service';
import { ModalRef } from '../modal/modal-ref';
import { ModalOptions } from '../modal/modal.model';
import { ModalService } from '../modal/modal.service';
import { PAYMENT_FEEDBACK, PAYMENT_OPTIONS, PAYMENT_RECEIPT } from './payment.token';

@Injectable({ providedIn: 'root' })
export class PaymentService extends ApiService {
  private commerceOrder?: CommerceOrder;
  protected currentPayment = new BehaviorSubject<IPayment | undefined>(undefined);
  payment$ = this.currentPayment.asObservable();
  transactionId?: string;

  constructor(
    private modalService: ModalService,
    private router: Router,
    private location: Location,
    private refreshTokenService: RefreshTokenService,
    private transactionService: TransactionService,
    private storageService: CapacitorStorageService,
    @Inject(PAYMENT_RECEIPT) private paymentReceiptComponent: ɵComponentType<any>,
    @Inject(PAYMENT_OPTIONS) private paymentOptionsComponent: ɵComponentType<any>,
    @Inject(PAYMENT_FEEDBACK) private paymentFeedbackComponent: ɵComponentType<any>
  ) {
    super();
  }

  get payment(): IPayment | undefined {
    return this.currentPayment.value;
  }

  get receipt(): IPaymentReceipt | undefined {
    return this.payment?.receipt;
  }

  get isOnlyMiles(): boolean {
    return !this.receipt?.total.price;
  }

  startPaymentWithReceipt(receipt: IPaymentReceipt): void {
    this.currentPayment.next({ ...this.payment, receipt });
    this.showPaymentReceipt();
  }

  retryPaymentWithTransactionId(transactionId: string, userEventSource: string): void {
    this.currentPayment.next({ ...this.payment });
    this.transactionId = transactionId;
    this.showPaymentOptions(userEventSource, true);
  }

  setPaymentMethod(method: IPaymentMethod): void {
    this.currentPayment.next({ ...this.payment, paymentMethod: method });
  }

  setPaymentIssuer(issuer: IPaymentIssuer): void {
    this.currentPayment.next({ ...this.payment, paymentIssuer: issuer });
  }

  resetPayment(): void {
    this.currentPayment.next(undefined);
  }

  setReceipt(receipt: IPaymentReceipt): void {
    this.currentPayment.next({ ...this.payment, receipt });
  }

  async getPaymentMethods(): Promise<IPaymentMethodAPI[]> {
    return await this.httpGet<IPaymentMethodAPI[]>({
      path: `payments/methods`
    });
  }

  async executePayment(userEventSource: string): Promise<void> {
    if (this.transactionId) {
      return this.retryPayment(userEventSource);
    }

    if (!this.receipt) {
      console.warn('No receipt found for payment');
      return;
    }

    // For charities, a different request is made
    if (ProductHelper.isCharity(this.receipt.product as IBaseProduct)) {
      return this.executeTransfer(userEventSource);
    }

    const productId = (this.receipt.product as IBaseProduct).id;

    let path = 'orders/';
    switch ((this.receipt.product as IBaseProduct).contentTypeAlias) {
      case ProductType.combinedProduct:
        path += `combined-products/${productId}`;
        if (this.receipt.donationCampaign?.points) {
          path += `/charities/${this.receipt.donationCampaign.charity._id}`;
        }
        break;
      case ProductType.importedCard:
      case ProductType.card:
        path += `cards/${productId}`;
        break;
      case ProductType.product:
        path += `products/${productId}`;
        if (this.receipt.donationCampaign?.points) {
          path += `/charities/${this.receipt.donationCampaign.charity._id}`;
        }
        break;
      default:
        console.warn('Unknown product type in payment', (this.receipt.product as IBaseProduct).contentTypeAlias);
        return;
    }
    path += `/payment/${this.isOnlyMiles ? 'false' : 'true'}`;

    let body: Partial<IOrderProductRequest> | Partial<IOrderCombinedProductRequest>;
    if (ProductHelper.isCombinedProduct(this.receipt.product as IBaseProduct)) {
      body = {
        productVariantAmounts: this.receipt.selectedProducts.map(
          (product) => ({ amount: product.amount, sapProductId: product.productId }) as IOrderCombinedProductVariant
        )
      } as IOrderCombinedProductRequest;
    } else {
      body = {
        amount: this.receipt.selectedProducts[0].amount
      } as IOrderProductRequest;
    }

    let returnUrl: string | undefined = undefined;
    if (!this.isOnlyMiles) {
      returnUrl = PageHelper.stripUrl(this.platformHelper.getCurrentAbsoluteUrl());
      body = {
        ...body,
        paymentMethodId: this.payment?.paymentMethod?.paymentMethodId,
        paymentIssuerId: this.payment?.paymentIssuer?.paymentIssuerId,
        returnUrl
      } as IOrderWithPriceRequest;
    }

    if (this.receipt.donationCampaign?.points) {
      body = {
        ...body,
        donatedPoints: this.receipt.donationCampaign.points
      } as IOrderWithDonationRequest;
    }

    return this.httpPost<IPaymentOrderResponse>({
      path,
      body
    })
      .then((response) => {
        this.handlePaymentResponse(userEventSource, response, returnUrl);
      })
      .catch((error: IHttpError) => {
        switch (error?.error?.code) {
          case HttpErrorCodes.insufficientFunds:
            this.onError(userEventSource, PaymentFeedbackType.failedFunds);
            break;
          default:
            this.onError(userEventSource);
            break;
        }
      });
  }

  async retryPayment(userEventSource: string): Promise<void> {
    let path = 'orders/payments/';
    switch ((this.receipt?.product as IBaseProduct)?.contentTypeAlias) {
      case ProductType.importedCard:
      case ProductType.card:
        path += 'cards/';
        break;
      default:
        break;
    }
    path += `${this.transactionId}/new`;

    const body = {
      paymentMethodId: this.payment?.paymentMethod?.paymentMethodId,
      paymentIssuerId: this.payment?.paymentIssuer?.paymentIssuerId,
      returnUrl: PageHelper.stripUrl(this.platformHelper.getCurrentAbsoluteUrl())
    } as Partial<IOrderWithPriceRequest>;

    return this.httpPost<IPaymentOrderResponse>({
      path,
      body,
      suppressAllErrorCodes: true
    })
      .then((response) => {
        this.handlePaymentResponse(userEventSource, response, body.returnUrl);
      })
      .catch(() => {
        this.onError(userEventSource);
      })
      .finally(() => {
        this.transactionId = undefined;
      });
  }

  async executeTransfer(userEventSource: string): Promise<void> {
    if (!this.receipt) {
      console.warn('No receipt found for payment');
      return;
    }

    const request: ITransferPointsToCharityRequest = {
      points: this.receipt.total.points
    };

    await this.transactionService
      .transferAirmilesToCharity(this.receipt.product.id, request)
      .then(() => {
        this.handlePaymentResponse(userEventSource);
      })
      .catch((error: IHttpError) => {
        switch (error?.error?.code) {
          case HttpErrorCodes.insufficientFunds:
            this.onError(userEventSource, PaymentFeedbackType.failedFunds);
            break;
          case HttpErrorCodes.invalidAccount:
            this.onError(userEventSource, PaymentFeedbackType.failedAccount);
            break;
          default:
            this.onError(userEventSource);
            break;
        }
      });
  }

  handlePaymentResponse(userEventSource: string, response?: IPaymentOrderResponse, returnUrl?: string): void {
    // If response has a url, it's a redirect to payment.
    // Otherwise, payment was air-miles only and successful
    if (response && response.url) {
      if (this.receipt?.commerceOrder) {
        void this.storageService.set(`${SiteConstants.purchaseStorageName}-${response.purchaseId}`, this.receipt.commerceOrder);
      }

      if (this.platformHelper.isiOSNative) {
        window.open(response.url, '_system');
      } else if (this.platformHelper.isAndroidNative) {
        InAppBrowser.removeAllListeners();
        InAppBrowser.addListener('urlChangeEvent', (event) => {
          if (event.url.includes('://') && !event.url.match(/^https?:\/\//)) {
            //Browser loads a custom scheme, happens when a bank app is not installed
            InAppBrowser.close();
            InAppBrowser.removeAllListeners();
            this.onError(userEventSource, PaymentFeedbackType.failedPaymentDeepLink);
          }

          if (PageHelper.stripUrl(event.url) === returnUrl) {
            InAppBrowser.close();
            InAppBrowser.removeAllListeners();
            const eventUrl = new URL(event.url);
            void this.router.navigateByUrl(`${eventUrl.pathname}${eventUrl.search}`);
          }
        });
        InAppBrowser.openWebView({ url: response.url, title: '' });
      } else {
        window.location.href = response.url;
      }
    } else {
      const redirectUrl = (this.payment?.receipt?.product as IBaseProduct)?.orderSuccessPage?._url;
      void this.onSuccess(userEventSource, redirectUrl);
    }
  }

  async onSuccess(userEventSource: string, redirectUrl?: string, purchaseId?: string): Promise<ModalRef | null> {
    await this.setCommerceOrder(purchaseId);

    // Refresh token and user data to update the balance (after giving SAP some time to process the redemption).
    setTimeout(() => {
      void this.refreshTokenService.refresh(userEventSource);
    }, 10000);

    const modal = this.showFeedbackModalForType(PaymentFeedbackType.success, userEventSource);

    modal?.onClose$.pipe(first()).subscribe(() => {
      if (redirectUrl) {
        void this.router.navigateByUrl(redirectUrl);
      }
    });

    // 'Eat' the queryParams, replace current state with strippedUrl
    const strippedUrl = PageHelper.stripUrl(this.router.url);
    this.location.replaceState(strippedUrl);

    const keys = (await this.storageService.keys()).filter((k) => k.startsWith(SiteConstants.purchaseStorageName));
    for (const key of keys) {
      await this.storageService.delete(key);
    }

    return modal;
  }

  onError(
    userEventSource: string,
    paymentFeedbackType: PaymentFeedbackType = PaymentFeedbackType.failed,
    productType: ProductType | null = null
  ): ModalRef | null {
    return this.showFeedbackModalForType(paymentFeedbackType, userEventSource, productType);
  }

  async onPaymentError(userEventSource: string, purchaseId?: string): Promise<ModalRef | null> {
    await this.setCommerceOrder(purchaseId);
    return this.showFeedbackModalForType(PaymentFeedbackType.failedPayment, userEventSource);
  }

  showPaymentReceipt(): ModalRef | null {
    return this.modalService.open(new ModalOptions({ classModifier: 'payment' }), this.paymentReceiptComponent);
  }

  showPaymentOptions(userEventSource: string, isRetry = false): ModalRef | null {
    const modal = this.modalService.open(new ModalOptions({ classModifier: 'payment' }), this.paymentOptionsComponent, {
      isRetry,
      userEventSource: this.receipt?.userEventSource ?? userEventSource,
      commerceOrder: this.commerceOrder
    });
    return modal;
  }

  showFeedbackModalForType(type: PaymentFeedbackType, userEventSource: string, productType: ProductType | null = null): ModalRef | null {
    return this.modalService.open(new ModalOptions({ classModifier: 'payment' }), this.paymentFeedbackComponent, {
      feedbackType: type,
      productType: productType ?? this.receipt?.product?.contentTypeAlias,
      successText: this.receipt?.successText,
      failedText: this.receipt?.failedText,
      failedPaymentText: this.receipt?.failedPaymentText,
      userEventSource: this.receipt?.userEventSource ?? userEventSource,
      commerceOrder: this.commerceOrder
    });
  }

  private async setCommerceOrder(purchaseId?: string): Promise<void> {
    this.commerceOrder =
      this.receipt?.commerceOrder ?? (await this.storageService.get<CommerceOrder>(`${SiteConstants.purchaseStorageName}-${purchaseId}`));
  }
}
