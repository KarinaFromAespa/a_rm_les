import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ProductType } from 'src/app/core/constants/product.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IFormState } from 'src/app/core/models/form.model';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { IPaymentReceipt } from 'src/app/core/models/payment.model';
import { IBaseProduct } from 'src/app/core/models/product.model';
import { PageContext } from 'src/app/core/models/site.response';
import { UserAddress } from 'src/app/core/models/user.model';
import { SiteService } from 'src/app/core/services/site.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { ModalRef } from '../../modal/modal-ref';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'air-payment-receipt',
  templateUrl: './payment-receipt.component.html',
  standalone: false
})
export class PaymentReceiptComponent implements OnInit, OnDestroy {
  pageContext?: PageContext | null;
  receipt?: IPaymentReceipt;
  isSubmitting: boolean;

  formState: IFormState = { submitted: false };
  showAddress: boolean;
  showEmail: boolean;
  terms?: string;

  userAddress?: UserAddress;
  loading: boolean;
  destroy$ = new Subject();

  form = new FormGroup({});

  get isCombinedProduct(): boolean {
    return ProductHelper.isCombinedProduct(this.receipt?.product as IBaseProduct);
  }

  get isCharity(): boolean {
    return ProductHelper.isCharity(this.receipt?.product as IBaseProduct);
  }

  get user(): IUserLoginData | undefined {
    return this.userHelper.currentUser as IUserLoginData | undefined;
  }

  get fullName(): string {
    return `${this.user?.firstName ? this.user?.firstName : ''} ${this.user?.lastName ? this.user?.lastName : ''}`.trim();
  }

  get notEnoughMiles(): boolean {
    return this.receipt ? (this.userHelper.currentUser?.balance || 0) < this.receipt.total.points : false;
  }

  get isOnlyMiles(): boolean {
    return this.paymentService.isOnlyMiles;
  }

  get orderButtonText(): string {
    if (this.notEnoughMiles) {
      return 'payment.receipt.label.not_enough_miles';
    } else if (this.isOnlyMiles) {
      return this.isCharity ? 'payment.receipt.label.place_donation' : 'payment.receipt.label.only_miles';
    }
    return 'payment.receipt.label.place_order';
  }

  get userEventSource(): string {
    return `${this.receipt?.userEventSource} - order confirmation`;
  }

  constructor(
    private modalRef: ModalRef,
    private userHelper: UserHelper,
    private paymentService: PaymentService,
    private siteService: SiteService,
    private userService: UserService,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.paymentService.payment$.pipe(takeUntil(this.destroy$)).subscribe((payment) => {
      this.receipt = payment?.receipt;
      this.userAddress = this.receipt?.userAddress;

      if (this.receipt && ProductHelper.isProductCard(this.receipt.product as any)) {
        this.showAddress = true;
        if (!this.userAddress) {
          void this.getUserAddress();
        }
      } else {
        this.showEmail = true;
      }
    });

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageContext = data;

      this.terms =
        this.receipt?.termsText || !this.pageContext || !this.receipt?.product
          ? this.receipt?.termsText
          : this.receipt.product.contentTypeAlias === ProductType.charity
            ? this.pageContext.donationTerms
            : this.pageContext.orderTerms;
    });
  }

  async getUserAddress(): Promise<void> {
    this.loading = true;
    try {
      this.userAddress = await this.userService.getUserAddress();
    } catch {
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  closeModal(): void {
    this.pushUserEvent(UserEventAction.close);
    void this.paymentService.resetPayment();
    this.modalRef.close();
  }

  async onOrderClick(event: Event): Promise<void> {
    this.formState.submitted = true;
    this.form.markAsDirty();

    if (!this.form.valid) {
      return;
    }

    this.pushUserEvent(UserEventAction.confirm, event, this.receipt?.commerceOrder);

    if (!this.paymentService.isOnlyMiles) {
      this.paymentService.showPaymentOptions(this.userEventSource);
    } else {
      this.isSubmitting = true;
      await this.paymentService.executePayment(this.userEventSource);
      this.isSubmitting = false;
    }
  }

  private pushUserEvent(action: UserEventAction, event?: Event, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, event?.text(), undefined, object);
  }
}
