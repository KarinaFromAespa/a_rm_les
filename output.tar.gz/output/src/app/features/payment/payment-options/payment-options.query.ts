import { gql } from 'apollo-angular';

export const logoFragment = gql`
  fragment LogoFields on ImageCropper {
    cropUrl(alias: "Payment Logo")
  }
`;

export const getPaymentMethodsQuery = gql`
  ${logoFragment}
  query getPaymentMethods {
    allPaymentMethod {
      items {
        title
        logo {
          ...LogoFields
        }
        paymentMethodId
        paymentIssuers {
          ... on PaymentIssuer {
            title
            logo {
              ...LogoFields
            }
            paymentIssuerId
          }
        }
      }
    }
  }
`;
