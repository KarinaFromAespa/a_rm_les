import { animate, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from 'src/app/core/animations/animation.constants';

export class AnimationStates {
  public static showMethods = 'showMethods';
  public static showIssuers = 'showIssuers';
}

export const animationStepSwitcher = trigger('animationStepSwitcher', [
  state(AnimationStates.showMethods, style({ transform: 'translateX(0%)' })),
  state(AnimationStates.showIssuers, style({ transform: 'translateX(calc(-100% - 1rem))' })),
  transition('* <=> *', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);

export const animationShowIssuers = trigger('animationShowIssuers', [
  transition('void => *', [
    style({ opacity: 0 }),
    animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`, style({ opacity: 1 }))
  ]),
  transition('* => void', [animate(`${AnimationConstants.baseDuration * 0.75}ms ${AnimationConstants.baseEasing}`, style({ opacity: 0 }))])
]);
