import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { IPayment, IPaymentIssuer, IPaymentMethod, IPaymentMethodAPI, IPaymentMethodResponse } from 'src/app/core/models/payment.model';
import { CommerceOrder } from 'src/app/core/models/user-event.model';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalRef } from '../../modal/modal-ref';
import { PaymentService } from '../payment.service';
import { AnimationStates, animationShowIssuers, animationStepSwitcher } from './payment-options.animations';
import { getPaymentMethodsQuery } from './payment-options.query';

@Component({
  selector: 'air-payment-options',
  templateUrl: './payment-options.component.html',
  animations: [animationStepSwitcher, animationShowIssuers],
  standalone: false
})
export class PaymentOptionsComponent implements OnInit, OnDestroy {
  @Input() isRetry: boolean;
  @Input() userEventSource: string;
  @Input() commerceOrder: CommerceOrder;

  payment?: IPayment;
  paymentMethods: IPaymentMethod[] = [];

  animationState: AnimationStates;
  userEventSourceInput: string;

  loading: boolean;
  isSubmitting = false;
  destroy$ = new Subject();

  get canContinue(): boolean {
    const paymentMethod = this.payment?.paymentMethod;
    const paymentIssuer = this.payment?.paymentIssuer;

    // Check if payment method is set, and if so, if payment method requires (and has) an issuer. If all pass, canContinue is true;
    return !!paymentMethod && ((!!paymentMethod.paymentIssuers && !(paymentMethod.paymentIssuers.length > 0)) || !!paymentIssuer);
  }

  constructor(
    private graphQLService: GraphQLService,
    private paymentService: PaymentService,
    private modalRef: ModalRef,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.paymentService.payment$.pipe(takeUntil(this.destroy$)).subscribe((payment) => {
      this.payment = payment;
    });
    void this.getPaymentMethods();
    this.userEventSourceInput = this.userEventSource;
    this.userEventSource = `${this.userEventSource} - payment options`;
  }

  async getPaymentMethods(): Promise<void> {
    // Get methods from API
    const promiseAPI = this.paymentService.getPaymentMethods();

    /* Get methods from Umbraco */
    const promiseUmbraco = this.graphQLService.query<IPaymentMethodResponse>(getPaymentMethodsQuery).toPromise();

    /* Await calls in parallel */
    const [resultAPI, resultUmbraco] = await Promise.all([promiseAPI, promiseUmbraco]);
    if (!resultAPI || !resultUmbraco?.data?.allPaymentMethod?.items) {
      return void this.paymentService.onError(this.userEventSourceInput);
    }
    this.modalRef.update();

    // Intersect the methods
    this.intersectPaymentMethods(resultUmbraco.data?.allPaymentMethod?.items, resultAPI);
  }

  intersectPaymentMethods(paymentMethods: IPaymentMethod[], apiMethods: IPaymentMethodAPI[]): void {
    // Iterate through paymentMethods and paymentIssuers
    const intersectedMethods = paymentMethods?.reduce((results: IPaymentMethod[], paymentMethod) => {
      const apiMethod = apiMethods.find((x) => x.paymentMethodId === paymentMethod.paymentMethodId);
      if (apiMethod) {
        results.push({
          ...paymentMethod,
          paymentIssuers: paymentMethod.paymentIssuers?.filter((paymentIssuer) =>
            apiMethod.paymentIssuerIds.includes(paymentIssuer?.paymentIssuerId)
          )
        });
      }
      return results;
    }, []);

    if (!intersectedMethods || intersectedMethods.length === 0) {
      this.paymentService.onError(this.userEventSourceInput);
    } else {
      this.paymentMethods = intersectedMethods;
    }
  }

  onSelectMethod(method: IPaymentMethod): void {
    this.pushUserEvent(UserEventAction.set, 'method', method.title);
    this.paymentService.setPaymentMethod(method);
    if (method.paymentIssuers?.length) {
      this.animationState = AnimationStates.showIssuers;
    }
  }

  onSelectIssuer(issuer: IPaymentIssuer): void {
    this.pushUserEvent(UserEventAction.set, 'issuer', issuer.title);
    this.paymentService.setPaymentIssuer(issuer);
    this.animationState = AnimationStates.showIssuers;
  }

  onBackClick(event: Event): void {
    this.pushUserEvent(UserEventAction.link, event.text(), 'back');

    if (this.payment?.paymentMethod && this.payment.paymentMethod.paymentIssuers?.length) {
      this.animationState = AnimationStates.showMethods;
      this.payment.paymentMethod = undefined;
      this.payment.paymentIssuer = undefined;
    } else {
      if (this.payment?.receipt) {
        this.paymentService.showPaymentReceipt();
      } else {
        // Without receipt we know it's a retry, so show the retryModal again
        void this.paymentService.onPaymentError(this.userEventSourceInput);
      }
    }
  }

  async onNextClick(event: Event): Promise<void> {
    const method = this.paymentService.payment?.paymentMethod?.title;
    const issuer = this.paymentService.payment?.paymentIssuer?.title;
    this.pushUserEvent(
      UserEventAction.submit,
      event.text(),
      issuer ? `${method} (${issuer})` : method,
      this.payment?.receipt?.commerceOrder ?? this.commerceOrder
    );

    this.isSubmitting = true;
    await this.paymentService.executePayment(this.userEventSourceInput);
    this.isSubmitting = false;
  }

  closeModal(): void {
    this.pushUserEvent(UserEventAction.close);
    void this.paymentService.resetPayment();
    this.modalRef.close();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, label, value, object);
  }
}
