import { InjectionToken } from '@angular/core';

export const PAYMENT_RECEIPT: InjectionToken<string> = new InjectionToken<string>('PAYMENT_RECEIPT');
export const PAYMENT_OPTIONS: InjectionToken<string> = new InjectionToken<string>('PAYMENT_OPTIONS');
export const PAYMENT_FEEDBACK: InjectionToken<string> = new InjectionToken<string>('PAYMENT_FEEDBACK');
