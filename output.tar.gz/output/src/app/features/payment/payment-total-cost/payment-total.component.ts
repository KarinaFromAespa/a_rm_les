import { Component, OnInit } from '@angular/core';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IPaymentReceipt } from 'src/app/core/models/payment.model';
import { IBaseProduct } from 'src/app/core/models/product.model';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'air-payment-total',
  templateUrl: './payment-total.component.html',
  standalone: false
})
export class PaymentTotalComponent implements OnInit {
  receipt?: IPaymentReceipt;

  get remainingBalance(): number {
    return (this.userHelper.currentUser?.balance ?? 0) - (this.paymentService.receipt?.total?.points ?? 0);
  }

  get isCharity(): boolean {
    return ProductHelper.isCharity(this.receipt?.product as IBaseProduct);
  }

  constructor(
    private paymentService: PaymentService,
    private userHelper: UserHelper
  ) {}

  ngOnInit(): void {
    this.receipt = this.paymentService.receipt;
  }
}
