export const SEARCH_MIN_QUERY_LENGTH = 3;
