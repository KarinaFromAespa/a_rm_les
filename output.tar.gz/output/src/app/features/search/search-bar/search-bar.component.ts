import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { SearchBarInputComponent } from 'src/app/shared/components/search-bar-input/search-bar-input.component';
import { SearchService } from '../search.service';

@Component({
  selector: 'air-search-bar',
  templateUrl: './search-bar.component.html',
  standalone: false
})
export class SearchBarComponent implements OnInit, OnDestroy {
  @ViewChild(SearchBarInputComponent) searchBarInputComponent: SearchBarInputComponent;

  destroy$ = new Subject();
  userEventAction = UserEventAction;

  constructor(
    private searchService: SearchService,
    private router: Router,
    private reCaptchaService: ReCaptchaService
  ) {}

  get disabled(): boolean {
    return !this.reCaptchaService.isReady;
  }

  ngOnInit(): void {
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.searchBarInputComponent.onClose();
    });

    void this.reCaptchaService.initialize();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onCancel(): void {
    this.searchService.query$.next('');
  }

  onClose(): void {
    this.searchService.clear();
  }

  onFocus(): void {
    if (!this.searchService.active$.getValue()) {
      this.searchService.active$.next(true);
    }

    if (this.searchBarInputComponent.hasInput) {
      this.onInput();
    }
  }

  onBlur(): void {
    if (this.searchBarInputComponent.hasInput) {
      return;
    }

    this.searchService.active$.next(false);
  }

  onInput(): void {
    if (this.searchBarInputComponent.searchForm.invalid) {
      return;
    }

    this.searchService.query$.next(this.searchBarInputComponent.searchForm.value.query ?? '');
  }

  onKeyDown($event: KeyboardEvent): void {
    if ($event.key !== 'Escape') {
      return;
    }

    (document.activeElement as HTMLInputElement).blur();

    this.searchBarInputComponent.onCancel();
  }
}
