import { DocumentNode } from 'graphql';
import gql from 'graphql-tag';
import {
  charityListFieldsFragment,
  combinedProductListFragment,
  externalProductListFragment,
  physicalProductListFragment,
  productListFragment
} from '../products/product.query';

export const buildSuggestedProductsQuery = (ids: string[]): DocumentNode => gql`
  ${productListFragment}
  ${combinedProductListFragment}
  ${externalProductListFragment}
  ${physicalProductListFragment}
  ${charityListFieldsFragment}
  query GetSuggestedProducts {
    allContent(
      where: {
        AND: [
          { id_any: [${ids.join(',')}] }
        ]
      }
    ) {
      items {
        id
        ...ProductListFields
        ...CombinedProductListFields
        ...ExternalProductListFields
        ...PhysicalProductListFields
        ...CharityListFields
      }
    }
  }
`;

export const buildSuggestedPersonalPagesQuery = (ids: string[]): DocumentNode => gql`
  fragment PersonalPageBasicFields on PersonalPageBasic {
    title
    seoDescription
  }
  fragment PersonalPagePasswordFields on PersonalPagePassword {
    title
    seoDescription
  }
  fragment PersonalPageTwoFactorFields on PersonalPageTwoFactor {
    title
    seoDescription
  }
  query GetSuggestedPersonalPages {
    allContent(
      where: {
        AND: [
          { id_any: [${ids.join(',')}] }
        ]
      }
    ) {
      items {
        ...PersonalPageBasicFields
        ...PersonalPagePasswordFields
        ...PersonalPageTwoFactorFields
        id
        url
        ancestors {
          items {
            ... on PersonalPageBasic {
              title
            }
            ... on PersonalPagePassword {
              title
            }
            ... on PersonalPageTwoFactor {
              title
            }
            contentTypeAlias
          }
        }
      }
    }
  }
`;

export const buildSuggestedPagesQuery = (ids: string[]): DocumentNode => gql`
  fragment PageFields on Page {
    title
    seoDescription
  }
  fragment PlainPageFields on PlainPage {
    title
    seoDescription
  }
  fragment PartnerFields on Partner {
    title
    seoDescription
  }
  fragment SupplierFields on Supplier {
    title
    seoDescription
  }

  query GetSuggestedPages {
    allContent(
      where: {
        AND: [
          { id_any: [${ids.join(',')}] }
        ]
      }
    ) {
      items {
        id
        url
        ancestors {
          items {
            ... on Page {
              title
            }
            ... on PlainPage {
              title
            }
            contentTypeAlias
          }
        }
        ...PageFields
        ...PlainPageFields
        ...PartnerFields
        ...SupplierFields
      }
    }
  }
`;
