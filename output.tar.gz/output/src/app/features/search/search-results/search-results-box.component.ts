import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subject, lastValueFrom } from 'rxjs';
import { debounceTime, switchMap, takeUntil } from 'rxjs/operators';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { CommerceHighlight, PageHighlight } from 'src/app/core/models/user-event.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { SEARCH_MIN_QUERY_LENGTH } from '../search.constants';
import { SearchPageType, SearchProductType, SearchResultsType } from '../search.model';
import { SearchService } from '../search.service';
import { ProductHelper } from 'src/app/core/helpers/product.helper';

@Component({
  selector: 'air-search-results-box',
  templateUrl: './search-results-box.component.html',
  standalone: false
})
export class SearchResultsBoxComponent implements OnInit, OnDestroy {
  results?: SearchResultsType;
  expandedType?: string;
  loading: boolean;
  queryLength: number;
  minQueryLength = SEARCH_MIN_QUERY_LENGTH;
  userEventSource = UserEventSource.search;

  destroy$ = new Subject();

  constructor(
    private searchService: SearchService,
    private translateService: TranslateService,
    private userEventService: UserEventService
  ) {}

  get isActive(): boolean {
    const query = this.searchService.query$.getValue();
    return this.searchService.active$.getValue() && !!query?.length;
  }

  async ngOnInit(): Promise<void> {
    const [translationProducts, translationPhysicalProducts, translationPages, translationPersonalPages]: string[] = await Promise.all([
      lastValueFrom<string>(this.translateService.get('general.search.category.products')),
      lastValueFrom<string>(this.translateService.get('general.search.category.physical_products')),
      lastValueFrom<string>(this.translateService.get('general.search.category.pages')),
      lastValueFrom<string>(this.translateService.get('general.search.category.personal_pages'))
    ]);

    this.searchService.query$
      .pipe(
        debounceTime(300),
        switchMap((query: string | null) => {
          this.expandedType = undefined;
          this.queryLength = query?.length ?? 0;
          this.loading = true;
          this.results = undefined;

          return this.searchService.getResults();
        }),
        takeUntil(this.destroy$)
      )
      .subscribe((response) => {
        this.loading = false;

        if (response == null) {
          this.results = undefined;
          return;
        }

        const products: SearchProductType = {
          title: translationProducts,
          mode: 'product',
          items: [
            ...response.products
              .filter((product) => product?.url)
              .map((product, index) => ({ product, userEventObject: new CommerceHighlight(index + 1, product) }))
          ]
        };
        const physicalProductsData = ProductHelper.preprocessProducts(response.physicalProducts);
        const physicalProducts: SearchProductType = {
          title: translationPhysicalProducts,
          mode: 'physical-product',
          items: [
            ...physicalProductsData.map((product, index) => ({ product, userEventObject: new CommerceHighlight(index + 1, product) }))
          ]
        };
        const pages: SearchPageType = {
          title: translationPages,
          mode: 'list',
          items: [
            ...response.pages
              .filter((page) => page?.url)
              .map((page, index) => ({ page, userEventObject: new PageHighlight(index + 1, page) }))
          ]
        };
        const personalPages: SearchPageType = {
          title: translationPersonalPages,
          mode: 'list',
          items: [
            ...response.personalPages
              .filter((page) => page?.url)
              .map((page, index) => ({ page, userEventObject: new PageHighlight(index + 1, page) }))
          ]
        };

        const results: SearchResultsType = [];

        if (products.items.length) {
          results.push(products);
        }
        if (physicalProducts.items.length) {
          results.push(physicalProducts);
        }
        if (pages.items.length) {
          results.push(pages);
        }
        if (personalPages.items.length) {
          results.push(personalPages);
        }

        if (this.expandedType) {
          const activeType = results.find((type) => type.title === this.expandedType);

          if (!activeType || activeType.items.length < 1) {
            this.expandedType = undefined;
          }
        }

        this.results = results;
        this.pushViewEvent();
      });
  }

  getCollapsedLimit(mode: string): number {
    return mode === 'product' ? 3 : 4;
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onExpand(event: { title: string; clickEvent: Event }): void {
    this.expandedType = event.title;
    this.pushUserEvent(UserEventAction.open, event.clickEvent, event.title);
    this.pushViewEvent();
  }

  onCollapse(event: { title: string; clickEvent: Event }): void {
    this.expandedType = undefined;
    this.pushUserEvent(UserEventAction.close, event.clickEvent, event.title);
    this.pushViewEvent();
  }

  close(): void {
    this.pushUserEvent(UserEventAction.cancel);
    this.expandedType = undefined;
    this.searchService.clear();
  }

  private pushViewEvent(): void {
    this.pushUserEvent(
      UserEventAction.view,
      undefined,
      undefined,
      this.results
        ?.filter((result) => !this.expandedType || result.title === this.expandedType)
        .map((result) => ({
          title: result.title,
          items: result.items
            .map((item) => (item as { userEventObject: unknown }).userEventObject)
            .slice(0, result.title !== this.expandedType ? this.getCollapsedLimit(result.mode) : undefined)
        }))
    );
  }

  private pushUserEvent(action: UserEventAction, event?: Event, value?: string, object?: unknown) {
    this.userEventService.pushEvent(this.userEventSource, action, event?.text(), value, object);
  }
}
