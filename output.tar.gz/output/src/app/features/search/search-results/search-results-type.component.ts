import { Component, EventEmitter, Input, Output } from '@angular/core';
import { animationExpandCollapse } from 'src/app/core/animations/expand-collapse.animations';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { SearchPageType, SearchProductType } from '../search.model';

@Component({
  selector: 'air-search-results-type',
  templateUrl: './search-results-type.component.html',
  animations: [animationExpandCollapse],
  standalone: false
})
export class SearchResultsTypeComponent {
  @Input() type: SearchPageType | SearchProductType;
  @Input() expanded = false;
  @Input() collapsedLimit: number;
  @Output() expand: EventEmitter<any> = new EventEmitter<any>();
  @Output() collapse: EventEmitter<any> = new EventEmitter<any>();
  userEventSource = UserEventSource.search;

  get limit(): number {
    return this.expanded ? Infinity : this.collapsedLimit;
  }

  toggle(event: Event): void {
    this.expanded = !this.expanded;

    if (this.expanded) {
      this.expand.emit({ title: this.type?.title, clickEvent: event });
    } else {
      this.collapse.emit({ title: this.type?.title, clickEvent: event });
    }
  }
}
