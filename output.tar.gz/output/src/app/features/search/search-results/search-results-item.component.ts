import { Component, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IProduct } from 'src/app/core/models/product.model';
import { IPage } from 'src/app/core/models/site.response';

@Component({
  selector: 'air-search-results-item',
  templateUrl: './search-results-item.component.html',
  standalone: false
})
export class SearchResultsItemComponent {
  @Input() item: IPage | IProduct;
  @Input() userEventSource: string;

  constructor(private translateService: TranslateService) {}

  get title(): string {
    return (this.item as IPage).title || (this.translateService.instant('personal.label.overview') as string);
  }

  get parent(): string | undefined {
    const ancestors: IPage[] =
      (this.item as IPage).ancestors?.items.filter((x: IPage) => x.contentTypeAlias.toLowerCase() !== 'folder') ?? [];

    return ancestors && ancestors.length > 0 ? ancestors[ancestors.length - 1].title : undefined;
  }

  get description(): string | undefined {
    return (this.item as IPage).seoDescription;
  }
}
