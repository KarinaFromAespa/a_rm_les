import { IBaseProduct, IProduct } from 'src/app/core/models/product.model';
import { IReCaptchaRequest } from 'src/app/core/models/reCaptcha.request';
import { IPage } from 'src/app/core/models/site.response';
import { CommerceHighlight, PageHighlight } from 'src/app/core/models/user-event.model';
export class SearchRequest implements IReCaptchaRequest {
  constructor(searchQuery: string) {
    this.searchQuery = searchQuery;
  }
  searchQuery: string;
  reCaptchaToken: string;
}
export interface SearchPageType {
  title: string;
  mode: 'list';
  items: { page: IPage; userEventObject: PageHighlight }[];
}
export interface SearchProductType {
  title: string;
  mode: 'product' | 'physical-product';
  items: { product: IBaseProduct; userEventObject: CommerceHighlight }[];
}

export type SearchResultsType = (SearchPageType | SearchProductType)[];

export interface SuggestionResponse {
  pages: IPage[];
  personalPages: IPage[];
  products: IProduct[];
  physicalProducts: IProduct[];
}

export interface ContentSuggestion {
  umbracoId: string;
  contentCategory: ContentCategory;
}

export enum ContentCategory {
  page = 'Page',
  personalPage = 'PersonalPage',
  product = 'Product',
  physicalProduct = 'PhysicalProduct'
}
