import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from 'src/app/shared/shared.module';

import { SearchBarComponent } from './search-bar/search-bar.component';
import { SearchResultsBoxComponent } from './search-results/search-results-box.component';
import { SearchResultsItemComponent } from './search-results/search-results-item.component';
import { SearchResultsTypeComponent } from './search-results/search-results-type.component';
import { TranslateModule } from '@ngx-translate/core';
import { ProductModule } from '../products/products.module';

@NgModule({
  declarations: [SearchBarComponent, SearchResultsBoxComponent, SearchResultsItemComponent, SearchResultsTypeComponent],
  imports: [CommonModule, ReactiveFormsModule, TranslateModule, SharedModule, ProductModule],
  providers: [],
  exports: [SearchBarComponent, SearchResultsBoxComponent, SearchResultsItemComponent, SearchResultsTypeComponent]
})
export class SearchModule {}
