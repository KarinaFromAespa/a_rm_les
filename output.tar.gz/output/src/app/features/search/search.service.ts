import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { IPagesResponse } from 'src/app/core/models/page.response';
import { IProductResponse } from 'src/app/core/models/product.response';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ApiService } from 'src/app/core/services/api.service';
import { ContentService } from 'src/app/core/services/content.service';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { SEARCH_MIN_QUERY_LENGTH } from './search.constants';
import { ContentCategory, ContentSuggestion, SearchRequest, SuggestionResponse } from './search.model';
import { buildSuggestedPagesQuery, buildSuggestedPersonalPagesQuery, buildSuggestedProductsQuery } from './search.queries';

@Injectable({ providedIn: 'root' })
export class SearchService extends ApiService {
  query$ = new BehaviorSubject<string>('');
  active$ = new BehaviorSubject<boolean>(false);

  constructor(
    private contentService: ContentService,
    private graphQLService: GraphQLService,
    private reCaptchaService: ReCaptchaService,
    private userEventService: UserEventService,
    private router: Router
  ) {
    super();

    this.router.events.subscribe(() => {
      this.clear();
    });
  }

  async getResults(): Promise<SuggestionResponse | null> {
    const searchQuery = this.query$?.getValue().trim();

    if (!searchQuery || searchQuery.length < SEARCH_MIN_QUERY_LENGTH) {
      return null;
    }

    return await this.reCaptchaService.verify(
      ReCaptchaAction.getContentSuggestions,
      new SearchRequest(searchQuery),
      this.getSuggestions.bind(this)
    );
  }

  clear(): void {
    this.query$.next('');
    this.active$.next(false);
  }

  private async getSuggestions(request: SearchRequest): Promise<SuggestionResponse | null> {
    this.userEventService.pushEvent(UserEventSource.search, UserEventAction.submit, undefined, undefined, undefined, {
      query: request.searchQuery
    });

    try {
      const suggestions = await this.reCaptchaService.verify<ContentSuggestion[], SearchRequest>(
        ReCaptchaAction.getContentSuggestions,
        request,
        this.contentService.getSuggestions.bind(this.contentService)
      );

      const pagesSuggestions = suggestions.filter((suggestion) => suggestion.contentCategory === ContentCategory.page);
      const personalPagesSuggestions = suggestions.filter((suggestion) => suggestion.contentCategory === ContentCategory.personalPage);
      const productsSuggestions = suggestions.filter(
        (suggestion) =>
          suggestion.contentCategory === ContentCategory.product || suggestion.contentCategory === ContentCategory.physicalProduct
      );

      const pagesIds = pagesSuggestions.map((item) => `"${item.umbracoId}"`);
      const pagesQuery = buildSuggestedPagesQuery(pagesIds);
      const pagesPromise = this.graphQLService.query<IPagesResponse>(pagesQuery).toPromise();

      const personalPagesIds = personalPagesSuggestions.map((item) => `"${item.umbracoId}"`);
      const personalPagesQuery = buildSuggestedPersonalPagesQuery(personalPagesIds);
      const personalPagesPromise = this.graphQLService.query<IPagesResponse>(personalPagesQuery).toPromise();

      const productsIds = productsSuggestions.map((item) => `"${item.umbracoId}"`);
      const productQuery = buildSuggestedProductsQuery(productsIds);
      const productsPromise = this.graphQLService.query<IProductResponse>(productQuery).toPromise();

      const [resolvedPages, resolvedPersonalPages, resolvedProducts] = await Promise.all([
        pagesPromise,
        personalPagesPromise,
        productsPromise
      ]);

      return {
        pages: pagesSuggestions
          .map((item) => resolvedPages?.data.allContent.items.find((page) => page.id === item.umbracoId))
          .filterEmpty(),
        personalPages: personalPagesSuggestions
          .map((item) => resolvedPersonalPages?.data.allContent.items.find((page) => page.id === item.umbracoId))
          .filterEmpty(),
        products: productsSuggestions
          .map((item) =>
            resolvedProducts?.data.allContent.items.find(
              (product) => product.id === item.umbracoId && item.contentCategory === ContentCategory.product
            )
          )
          .filterEmpty(),
        physicalProducts: productsSuggestions
          .map((item) =>
            resolvedProducts?.data.allContent.items.find(
              (product) => product.id === item.umbracoId && item.contentCategory === ContentCategory.physicalProduct
            )
          )
          .filterEmpty()
      };
    } catch {
      return null;
    }
  }
}
