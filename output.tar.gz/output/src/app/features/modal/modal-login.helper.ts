import { Injectable } from '@angular/core';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IColor, IText } from 'src/app/core/models/content.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { IPage } from 'src/app/core/models/site.response';
import { BiometricsService } from 'src/app/core/services/biometrics.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { SiteService } from 'src/app/core/services/site.service';
import { TokenService } from 'src/app/core/services/token.service';
import { LoginModalComponent } from 'src/app/shared/modals/login-modal/login-modal.component';
import { LoginModalService } from 'src/app/shared/modals/login-modal/login-modal.service';
import { PasswordResetModalComponent } from 'src/app/shared/modals/password-reset-modal/password-reset-modal.component';
import { IPasswordResetModalInputs } from 'src/app/shared/modals/password-reset-modal/password-reset-modal.model';
import { TwoFactorLoginModalComponent } from 'src/app/shared/modals/two-factor-login-modal/two-factor-login-modal.component';
import { ModalOptions } from './modal.model';
import { ModalService } from './modal.service';

@Injectable({ providedIn: 'root' })
export class ModalLoginHelper {
  constructor(
    private modalService: ModalService,
    private siteService: SiteService,
    private biometricsService: BiometricsService,
    private reCaptchaService: ReCaptchaService,
    private tokenService: TokenService,
    private loginModalService: LoginModalService,
    private userHelper: UserHelper
  ) {}

  async triggerPasswordLoginModal(
    userEventSource: string,
    emailAddress?: string,
    onCloseCallback?: () => void,
    onLoginCallback?: () => void,
    completeProfilePage?: IPage,
    loginSuccessPage?: IPage,
    alternateMode?: boolean,
    disableBackdropClick?: boolean,
    loginUsernameNotice?: string,
    partnerNotice?: string,
    color?: IColor,
    triggerBiometrics = true
  ): Promise<void> {
    if (!this.siteService.pageContext.getValue()) {
      await this.siteService.loadPageContext();
    }

    if (
      triggerBiometrics &&
      (await this.triggerBiometricsPasswordModal(userEventSource, onCloseCallback, onLoginCallback, completeProfilePage, loginSuccessPage))
    ) {
      return;
    }

    return await this.modalService.openWithOnClose(
      new ModalOptions({ onCloseCallback, disableBackdropClick, color }),
      LoginModalComponent,
      {
        emailAddress,
        onLoginCallback,
        checkLoginCloseCallback: true,
        completeProfilePage,
        loginSuccessPage,
        userEventSource,
        alternateMode,
        loginUsernameNotice,
        partnerNotice,
        color,
        triggerBiometrics
      }
    );
  }

  async triggerTwoFactorModal(
    userEventSource: string,
    onCloseCallback?: () => void,
    onLoginCallback?: () => Promise<any>,
    disableBackdropClick?: boolean,
    twoFactorVerification?: IText,
    triggerBiometrics = true,
    color?: IColor
  ): Promise<void> {
    if (!this.siteService.pageContext.getValue()) {
      await this.siteService.loadPageContext();
    }

    if (triggerBiometrics && (await this.triggerBiometricsTwoFactorModal(userEventSource, onCloseCallback, onLoginCallback))) {
      return;
    }

    return await this.modalService.openWithOnClose(
      new ModalOptions({ onCloseCallback, disableBackdropClick, color }),
      TwoFactorLoginModalComponent,
      {
        onLoginCallback,
        userEventSource,
        twoFactorVerification,
        triggerBiometrics,
        color
      }
    );
  }

  async triggerTwoFactorPasswordLoginModal(
    userEventSource: string,
    emailAddress?: string,
    onCloseCallback?: () => void,
    onLoginCallback?: () => Promise<unknown>,
    completeProfilePage?: IPage,
    loginSuccessPage?: IPage,
    alternateMode?: boolean,
    disableBackdropClick?: boolean,
    loginUsernameNotice?: string,
    partnerNotice?: string,
    color?: IColor,
    twoFactorVerification?: IText,
    triggerBiometrics = true
  ): Promise<void> {
    if (!this.siteService.pageContext.getValue()) {
      await this.siteService.loadPageContext();
    }

    return await this.triggerPasswordLoginModal(
      userEventSource,
      emailAddress,
      onCloseCallback,
      () => {
        void (async () =>
          await this.triggerTwoFactorModal(
            userEventSource,
            onCloseCallback,
            onLoginCallback,
            disableBackdropClick,
            twoFactorVerification,
            triggerBiometrics,
            color
          ))();
      },
      completeProfilePage,
      loginSuccessPage,
      alternateMode,
      disableBackdropClick,
      loginUsernameNotice,
      partnerNotice,
      color,
      triggerBiometrics
    );
  }

  async triggerPasswordResetModal(
    inputs?: IPasswordResetModalInputs,
    onCloseCallback?: () => void,
    onSuccessCloseCallback?: () => void,
    standalone = false
  ): Promise<void> {
    const modalOptions = new ModalOptions({ onCloseCallback });
    return await this.modalService.openWithOnClose(modalOptions, PasswordResetModalComponent, {
      inputs,
      modalOptions,
      onCloseCallback,
      onSuccessCloseCallback,
      standalone
    });
  }

  private async triggerBiometricsPasswordModal(
    userEventSource: string,
    onCloseCallback?: () => void,
    onLoginCallback?: () => void,
    completeProfilePage?: IPage,
    loginSuccessPage?: IPage
  ): Promise<boolean> {
    const request = await this.biometricsService.verifyPasswordLogin(userEventSource);
    if (!request) {
      return false;
    }

    return await this.reCaptchaService
      .verify(ReCaptchaAction.createPasswordLoginToken, request, this.tokenService.createPasswordLoginToken.bind(this.tokenService))
      .then(() => {
        this.loginModalService.handleLoginCallback(
          userEventSource,
          completeProfilePage,
          loginSuccessPage,
          onLoginCallback,
          true,
          onCloseCallback
        );

        return true;
      })
      .catch(() => false);
  }

  private async triggerBiometricsTwoFactorModal(
    userEventSource: string,
    onCloseCallback?: () => void,
    onLoginCallback?: () => Promise<void>
  ): Promise<boolean> {
    const request = await this.biometricsService.verifyTwoFactorLogin(this.userHelper.currentUser?.refreshToken ?? '', userEventSource);
    if (!request) {
      return false;
    }

    return this.reCaptchaService
      .verify(ReCaptchaAction.createTwoFactorLoginToken, request, this.tokenService.createTwoFactorLoginToken.bind(this.tokenService))
      .then(() => {
        void this.loginModalService.handleTwoFactorCallback(onCloseCallback, onLoginCallback);
        return true;
      })
      .catch(() => false);
  }
}
