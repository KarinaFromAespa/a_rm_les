import { Component, Input } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalRef } from './modal-ref';
import { ModalButton, ModalOptions } from './modal.model';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'modal-default',
  templateUrl: './modal.component.html',
  standalone: false
})
export class ModalComponent {
  @Input() userEventSource: string;

  constructor(
    public options: ModalOptions,
    private modalRef: ModalRef,
    private userEventService: UserEventService
  ) {}

  close(pushUserEvent = false): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }

    this.modalRef.close();
  }

  onButtonClick(button: ModalButton, event: Event): void {
    // If the button has an action attached, call it
    if (button.action) {
      if (button.userEventAction) {
        this.pushUserEvent(button.userEventAction, event);
      }

      button.action();
      if (button.closeAfterAction) {
        this.close();
      }
    }

    // If the button has 'isCancel' true, close the modalRef
    if (button.isCancel) {
      this.pushUserEvent(UserEventAction.close, event);
      this.close();
    }
  }

  private pushUserEvent(action: UserEventAction, event?: Event) {
    if (this.userEventSource) {
      this.userEventService.pushEvent(this.userEventSource, action, event?.text());
    }
  }
}
