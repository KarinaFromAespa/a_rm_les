import { Observable, Subject } from 'rxjs';
import { ModalOptions } from './modal.model';

export class ModalRef {
  private readonly onClose = new Subject<any>();
  onClose$: Observable<any> = this.onClose.asObservable();

  private readonly onUpdate = new Subject<any>();
  onUpdate$: Observable<any> = this.onUpdate.asObservable();

  componentInstance: any;
  options: ModalOptions;

  constructor() {}

  close(): void {
    this.onClose.next(void 0);
  }

  update(): void {
    this.onUpdate.next(void 0);
  }
}
