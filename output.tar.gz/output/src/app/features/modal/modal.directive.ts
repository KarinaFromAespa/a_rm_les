import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[modalContentHost]',
  standalone: false
})
export class ModalContentHostDirective {
  constructor(public viewContainerRef: ViewContainerRef) {}
}

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[modalAnchor]',
  standalone: false
})
export class ModalAnchorDirective {
  constructor(public viewContainerRef: ViewContainerRef) {}
}
