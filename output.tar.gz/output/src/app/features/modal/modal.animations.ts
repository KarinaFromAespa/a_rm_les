import { animate, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from '../../core/animations/animation.constants';

export const animationModal = trigger('animationModal', [
  state(
    '*',
    style({
      transform: 'translateY(0)',
      opacity: 1
    })
  ),
  state(
    'void',
    style({
      transform: 'translateY(50%)',
      opacity: 0
    })
  ),
  transition('void => *', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)),
  transition('* => void', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);

export const animationModalGrow = trigger('animationModalGrow', [
  transition('void <=> *', []),
  transition('* <=> *', [
    style({ height: '{{ startHeight }}px' }),
    animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`, style({ height: '*' }))
  ])
]);
