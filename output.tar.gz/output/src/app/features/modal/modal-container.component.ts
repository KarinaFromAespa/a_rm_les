import {
  Component,
  ComponentFactory,
  ComponentFactoryResolver,
  ComponentRef,
  ElementRef,
  EventEmitter,
  HostBinding,
  Output,
  Type,
  ViewChild
} from '@angular/core';
import { Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { animationFadeInOut } from '../../core/animations/fade.animations';
import { triggerChildAnimation } from '../../core/animations/trigger-child.animation';
import { ModalRef } from './modal-ref';
import { animationModal, animationModalGrow } from './modal.animations';
import { ModalComponent } from './modal.component';
import { ModalContentHostDirective } from './modal.directive';
import { ModalInjector } from './modal.injector';
import { ModalOptions } from './modal.model';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'modal-container',
  templateUrl: './modal-container.component.html',
  animations: [animationModal, animationFadeInOut, triggerChildAnimation, animationModalGrow],
  standalone: false
})
export class ModalContainerComponent {
  @HostBinding('@triggerChildAnimation')
  @ViewChild(ModalContentHostDirective, { static: true })
  modalContentHost: ModalContentHostDirective;
  @ViewChild('modalContainer', { static: true }) modalContainer: ElementRef<HTMLElement>;
  @Output() modalClose = new EventEmitter<any>();

  id: string;
  modalRef?: ModalRef;
  component: ComponentRef<any>;
  options?: ModalOptions;
  startHeight = 0;
  currentHeight = 0;

  closed = false;
  animateModal: boolean;

  destroy$ = new Subject();

  constructor(
    private readonly factoryResolver: ComponentFactoryResolver,
    private platformHelper: PlatformHelper
  ) {}

  open(options: ModalOptions, component?: Type<any>, componentInputs?: unknown): ModalRef {
    this.modalRef = this.renderComponent(options, component, componentInputs);
    this.options = options;

    return this.modalRef;
  }

  close(): void {
    this.modalClose.emit();
    if (this.modalRef) {
      this.modalRef.close();
    }
    this.closed = true;
  }

  onAnimationModalDone(): void {
    if (this.component && this.closed) {
      this.component.destroy();
      this.modalRef = undefined;
    }
  }

  onUpdate(): void {
    this.startHeight = this.modalContainer.nativeElement.scrollHeight;
    this.animateModal = !this.animateModal;
  }

  onBackdropClick(): void {
    if (this.options?.disableBackdropClick || this.platformHelper.isMobile) {
      return;
    }

    this.close();
  }

  private renderComponent(options: ModalOptions, component?: Type<any>, componentInputs?: unknown): ModalRef {
    // Cleanup previous listeners
    this.destroy$.next(void 0);

    // add options to Map (unique values)
    const map = new WeakMap();
    map.set(ModalOptions, options);

    // add the ModalRef for dependency injection
    const modalRef = new ModalRef();
    map.set(ModalRef, modalRef);

    // Subscribe to close call from component
    modalRef.onClose$.pipe(takeUntil(this.destroy$), take(1)).subscribe(() => {
      this.close();
    });

    modalRef.onUpdate$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.onUpdate();
    });

    // Store current height for modal animation
    this.startHeight = this.modalContainer.nativeElement.clientHeight;

    const viewContainerRef = this.modalContentHost.viewContainerRef;
    viewContainerRef.clear();

    const factory: ComponentFactory<any> = this.factoryResolver.resolveComponentFactory(component || ModalComponent);
    this.component = factory.create(new ModalInjector(viewContainerRef.injector, map));
    if (componentInputs) {
      for (const key of Object.keys(componentInputs)) {
        ((this.component.instance as Type<any>)[key] as unknown) = componentInputs[key];
      }
    }
    viewContainerRef.insert(this.component.hostView);

    modalRef.componentInstance = this.component.instance;
    modalRef.options = options;

    // Perform update call
    this.onUpdate();

    return modalRef;
  }
}
