import { Type } from '@angular/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { IColor } from 'src/app/core/models/content.model';

export class ModalButton {
  text?: string;
  buttonClass?: string;
  isCancel?: boolean;
  action?: () => void;
  closeAfterAction?: boolean;
  isLoading?: boolean;
  userEventAction?: UserEventAction;
  get isPrimary(): boolean {
    return !this.buttonClass?.includes('button--secondary');
  }

  constructor(init?: Partial<ModalButton>) {
    Object.assign(this, init);
    if (this.isCancel && !init?.buttonClass) {
      this.buttonClass = 'button--secondary';
    }
  }
}

export interface IModalOptions {
  title?: string;
  message?: string;
  classModifier?: string;
  readonly buttons?: ModalButton[];
  isWideButtonGroup?: boolean;
  addAction?: any;
  onCloseCallback?: () => void;
  disableBackdropClick?: boolean;
  color?: IColor;
}

export class ModalOptions implements IModalOptions {
  title?: string;
  message?: string;
  classModifier?: string;
  isWideButtonGroup?: boolean;
  readonly buttons: ModalButton[] = [];
  onCloseCallback?: () => void;
  disableBackdropClick?: boolean;
  color?: IColor;

  constructor(init?: Partial<IModalOptions>) {
    Object.assign(this, init);
  }

  public addAction(button: Partial<ModalButton>): void {
    this.buttons.push(new ModalButton(button));
  }
}

export class Modal {
  id: string;
  component?: Type<any>;

  constructor(init?: Partial<Modal>) {
    Object.assign(this, init);
  }
}
