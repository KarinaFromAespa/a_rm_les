import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalContainerComponent } from './modal-container.component';
import { ModalComponent } from './modal.component';
import { ModalAnchorDirective, ModalContentHostDirective } from './modal.directive';

@NgModule({
  declarations: [ModalContainerComponent, ModalComponent, ModalContentHostDirective, ModalAnchorDirective],
  imports: [CommonModule, SharedModule],
  exports: [ModalContainerComponent, ModalContentHostDirective, ModalAnchorDirective],
  bootstrap: []
})
export class ModalModule {}
