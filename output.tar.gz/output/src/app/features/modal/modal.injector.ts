import { InjectionToken, Injector, Type } from '@angular/core';
import { ModalRef } from './modal-ref';
import { ModalOptions } from './modal.model';

export class ModalInjector implements Injector {
  constructor(
    private parentInjector: Injector,
    private additionalTokens: WeakMap<any, ModalRef | ModalOptions>
  ) {}

  get(
    token: Type<ModalRef | ModalOptions> | InjectionToken<ModalRef | ModalOptions>,
    notFoundValue?: ModalRef | ModalOptions | null
  ): ModalOptions | ModalRef | undefined {
    const value = this.additionalTokens.get(token);
    if (value) {
      return value;
    }
    return this.parentInjector.get<ModalRef | ModalOptions>(token, notFoundValue ?? undefined);
  }
}
