import {
  ApplicationRef,
  ComponentFactory,
  ComponentFactoryResolver,
  ComponentRef,
  Injectable,
  Type,
  ViewContainerRef
} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AppComponent } from 'src/app/app.component';
import { ModalContainerComponent } from './modal-container.component';
import { ModalRef } from './modal-ref';
import { ModalOptions } from './modal.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ModalService {
  rootViewContainer?: ViewContainerRef;
  modalContainer?: ComponentRef<ModalContainerComponent>;
  modalRef?: ModalRef;
  lastFocusedElement: HTMLElement | null = null;
  returnFocusTimeout?: number;
  isOpen: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  private options: ModalOptions;

  constructor(
    private readonly factoryResolver: ComponentFactoryResolver,
    private readonly applicationRef: ApplicationRef,
    private router: Router
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        window.clearTimeout(this.returnFocusTimeout);
        if (this.modalRef) {
          this.close();
        }
      }
    });
  }

  private rootViewContainerRef(): ViewContainerRef | undefined {
    try {
      const appComponentInstance = this.applicationRef.components[0].instance as AppComponent;
      return appComponentInstance.modalAnchor.viewContainerRef;
    } catch {
      console.warn('No rootViewContainerRef available.');
      return undefined;
    }
  }

  open(options: ModalOptions = new ModalOptions(), component?: Type<any>, componentInputs?: unknown): ModalRef | null {
    this.rootViewContainer = this.rootViewContainerRef();
    this.options = options;
    this.lastFocusedElement = document.activeElement as HTMLElement;

    // Add body class
    document.body.classList.add('modal--open');
    this.isOpen.next(true);

    if (!this.modalContainer) {
      return this.renderContainer(options, component, componentInputs);
    }

    this.modalRef = this.modalContainer.instance.open(options, component, componentInputs);
    return this.modalRef;
  }

  async openWithOnClose(options: ModalOptions = new ModalOptions(), component?: Type<any>, componentInputs?: unknown): Promise<void> {
    const modalInstance = this.open(options, component, componentInputs);
    return await modalInstance?.onClose$.pipe(first()).toPromise();
  }

  close(checkCloseCallback = true): void {
    if (this.modalContainer) {
      this.modalContainer.destroy();
    }

    // Remove body class
    document.body.classList.remove('modal--open');
    this.isOpen.next(false);

    if (this.returnFocusTimeout) {
      clearTimeout(this.returnFocusTimeout);
    }

    this.returnFocusTimeout = window.setTimeout(() => {
      this.lastFocusedElement?.focus();
      this.lastFocusedElement = null;
    });

    if (checkCloseCallback && this.options?.onCloseCallback) {
      this.options.onCloseCallback();
    }

    this.modalContainer = undefined;
    this.modalRef = undefined;
  }

  private renderContainer(options: ModalOptions, component?: Type<any>, componentInputs?: unknown): ModalRef | null {
    const factory: ComponentFactory<ModalContainerComponent> = this.factoryResolver.resolveComponentFactory(ModalContainerComponent);
    if (this.rootViewContainer) {
      this.modalContainer = factory.create(this.rootViewContainer.injector);
    }

    if (this.modalContainer) {
      this.rootViewContainer?.insert(this.modalContainer.hostView);
    }

    this.modalContainer?.instance.modalClose.pipe(first()).subscribe(() => {
      this.close();
    });

    this.modalRef = this.modalContainer?.instance.open(options, component, componentInputs);
    this.modalContainer?.changeDetectorRef.detectChanges();

    return this.modalRef ?? null;
  }
}
