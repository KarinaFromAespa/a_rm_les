import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ContactFormQuestion } from 'src/app/core/models/contact-form.model';
import { IColor } from 'src/app/core/models/content.model';
import { UserContactDetails } from 'src/app/core/models/user.model';
import { ConfirmationModalComponent } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.component';
import { IConfirmationModal } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.model';

import { PasswordVerificationModalComponent } from 'src/app/shared/modals/password-verification-modal/password-verification-modal.component';
import { IPasswordVerificationModal } from 'src/app/shared/modals/password-verification-modal/password-verification-modal.model';
import { VerificationModalComponent } from 'src/app/shared/modals/verification-modal/verification-modal.component';
import { IVerificationModal } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { ContactInformationModalComponent } from '../../shared/modals/contact-information-modal/contact-information-modal.component';
import { ModalRef } from './modal-ref';
import { ModalOptions } from './modal.model';
import { ModalService } from './modal.service';

@Injectable({ providedIn: 'root' })
export class ModalHelper {
  constructor(
    private modalService: ModalService,
    private translateService: TranslateService
  ) {}

  triggerContentModal(title: string, message: string, userEventSource: string): ModalRef | null {
    const options = new ModalOptions({ title, message });
    options.addAction({
      text: this.translateService.instant('general.label.close') as string,
      buttonClass: 'button--primary',
      isCancel: true
    });

    return this.modalService.open(options, undefined, { userEventSource });
  }

  triggerRetryModal(
    message: string,
    onRetry: () => void,
    onCancel: () => void,
    userEventSource: string,
    disableBackdropClick?: boolean,
    color?: IColor
  ): void {
    const options = new ModalOptions({
      title: this.translateService.instant('general.label.error') as string,
      message: `<p>${message}</p>`,
      onCloseCallback: onCancel,
      disableBackdropClick,
      isWideButtonGroup: true,
      color
    });

    options.addAction({
      text: this.translateService.instant('general.label.close') as string,
      buttonClass: 'button--secondary',
      userEventAction: UserEventAction.cancel,
      action: onCancel
    });
    options.addAction({
      text: this.translateService.instant('general.label.retry') as string,
      buttonClass: 'button--primary',
      userEventAction: UserEventAction.submit,
      action: onRetry
    });

    this.modalService.open(options, undefined, { userEventSource: `${userEventSource} - retry` });
  }

  async triggerContactInformationModal(
    contactFormQuestion: ContactFormQuestion,
    currentUserDetails: UserContactDetails,
    successPageUrl: string,
    userEventSource: string
  ): Promise<void> {
    return await this.modalService.openWithOnClose(undefined, ContactInformationModalComponent, {
      contactFormQuestion,
      currentUserDetails,
      successPageUrl,
      userEventSource
    });
  }

  async triggerConfirmationModal(content: IConfirmationModal, onCloseCallback?: () => void): Promise<void> {
    return await this.modalService.openWithOnClose(new ModalOptions({ onCloseCallback }), ConfirmationModalComponent, {
      content
    });
  }

  async triggerVerificationModal(content: IVerificationModal, onCloseCallback?: () => void): Promise<void> {
    return await this.modalService.openWithOnClose(new ModalOptions({ onCloseCallback }), VerificationModalComponent, {
      content
    });
  }

  async triggerPasswordVerificationModal(content: IPasswordVerificationModal, onCloseCallback?: () => void): Promise<void> {
    return await this.modalService.openWithOnClose(new ModalOptions({ onCloseCallback }), PasswordVerificationModalComponent, {
      content
    });
  }
}
