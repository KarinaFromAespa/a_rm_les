import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';

@Injectable({ providedIn: 'root' })
export class IonicStorageService {
  private store: Storage | null = null;

  constructor(private storage: Storage) {}

  async get<T>(key: string): Promise<T> {
    await this.ensureStorageExists();
    return (await this.store?.get(key)) as T;
  }

  async set(key: string, value: unknown): Promise<void> {
    await this.ensureStorageExists();
    await this.store?.set(key, value);
  }

  async delete(key: string): Promise<void> {
    await this.ensureStorageExists();
    await this.store?.remove(key);
  }

  async clear(): Promise<void> {
    await this.ensureStorageExists();
    await this.store?.clear();
  }

  private async ensureStorageExists(): Promise<void> {
    if (!this.store) {
      this.store = await this.storage.create();
    }
  }
}
