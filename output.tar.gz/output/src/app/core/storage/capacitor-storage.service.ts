import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import { IonicStorageService } from './ionic-storage.service';

@Injectable({ providedIn: 'root' })
export class CapacitorStorageService {
  constructor(private ionicStorageService: IonicStorageService) {}

  async get<T>(key: string): Promise<T> {
    const value = (await Preferences.get({ key })).value;
    if (value) {
      return JSON.parse(value) as T;
    }

    // Backwards compatibility after AIR-834
    const previousValue = await this.ionicStorageService.get<T>(key);
    if (previousValue) {
      void this.set(key, previousValue).then(() => this.ionicStorageService.delete(key));
    }

    return previousValue;
  }

  async set(key: string, value: unknown): Promise<void> {
    await Preferences.set({ key, value: JSON.stringify(value) });
  }

  async keys(): Promise<string[]> {
    return (await Preferences.keys()).keys;
  }

  async delete(key: string): Promise<void> {
    await Preferences.remove({ key });

    // Backwards compatibility after AIR-834
    void this.ionicStorageService.delete(key);
  }
}
