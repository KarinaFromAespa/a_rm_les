import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { LogoutHelper } from '../helpers/logout.helper';

export const logoutGuard: CanActivateFn = async () => {
  const logoutHelper = inject(LogoutHelper);
  const router = inject(Router);

  await logoutHelper.logout();

  return router.createUrlTree(['/']);
};
