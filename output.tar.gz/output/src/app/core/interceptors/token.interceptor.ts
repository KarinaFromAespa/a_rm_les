import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, from, lastValueFrom } from 'rxjs';
import { catchError, take } from 'rxjs/operators';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { HttpNativeHelper } from 'src/app/core/helpers/http-native.helper';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { environment } from 'src/environments/environment';
import { HttpErrorCodes } from '../constants/error.constants';
import { UserEventSource } from '../constants/user-event.constants';
import { PlatformHelper } from '../helpers/platform.helper';
import { IError } from '../models/http.model';
import { XsrfService } from '../services/xsrf.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  private refreshTokenInProgress = false;
  private refreshTokenSubject = new Subject<{ succeeded: boolean; suppressErrorCode?: boolean }>();

  constructor(
    private httpNativeHelper: HttpNativeHelper,
    private refreshTokenService: RefreshTokenService,
    private xsrfService: XsrfService
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (!request.url.startsWith(environment.apiUrl)) {
      return next.handle(request);
    }

    const observable = from(this.handleRequest(request, next));
    return observable.pipe(catchError((error: HttpErrorResponse) => this.refreshToken(request, next, error)));
  }

  private async handleRequest(request: HttpRequest<unknown>, next: HttpHandler): Promise<HttpEvent<unknown>> {
    let observable: Observable<HttpEvent<unknown>>;
    request = await this.addHeaders(request);

    if (PlatformHelper.isNativeMobile) {
      observable = from(this.httpNativeHelper.handleRequest(request));
    } else {
      observable = next.handle(request);
    }

    return lastValueFrom(observable);
  }

  private async addHeaders(request: HttpRequest<unknown>): Promise<HttpRequest<unknown>> {
    const xsrf = await this.xsrfService.getClientCookie();

    if (xsrf) {
      let headers = request.headers;
      headers = headers.set(SiteConstants.xsrfHeaderName, xsrf);
      request = request.clone({
        headers,
        withCredentials: true
      });
    } else {
      request = request.clone({
        withCredentials: true
      });
    }

    return request;
  }

  private async refreshToken(request: HttpRequest<unknown>, next: HttpHandler, error: HttpErrorResponse): Promise<HttpEvent<unknown>> {
    if (!error) {
      Promise.reject();
    }

    if (error.status !== 401 || error.url?.endsWith('v1/token') || error.url?.endsWith('v1/token/xsrf')) {
      return Promise.reject(error);
    }

    let response: { succeeded: boolean; suppressErrorCode?: boolean } | undefined = undefined;
    if (this.refreshTokenInProgress) {
      response = await this.refreshTokenSubject.pipe(take(1)).toPromise();
    } else {
      let errorObj: IError | null = null;
      if (PlatformHelper.isNativeMobile && error.error) {
        try {
          errorObj = JSON.parse(error.error);
        } catch {}
      } else {
        errorObj = error.error;
      }

      this.refreshTokenInProgress = true;
      response = await this.refreshTokenService
        .refresh(
          UserEventSource.page,
          errorObj ? [HttpErrorCodes.twoFactorLoginRequired, HttpErrorCodes.twoFactorUpgradeRequired].includes(errorObj.code) : false
        )
        .finally(() => {
          this.refreshTokenInProgress = false;
        });
      this.refreshTokenSubject.next(response);
    }
    if (response && !response.succeeded && request.method !== 'GET') {
      return Promise.reject(error);
    }
    return this.handleRequest(request, next).catch((e) => {
      if (response?.suppressErrorCode) {
        return;
      }

      throw e;
    }) as Promise<HttpEvent<unknown>>;
  }
}
