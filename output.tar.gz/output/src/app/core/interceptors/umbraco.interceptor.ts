import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NEVER, Observable, Subject, from } from 'rxjs';
import { catchError, first, switchMap, takeUntil } from 'rxjs/operators';
import { PageType } from 'src/app/core/constants/page.constants';
import { AuthorizationLevel } from 'src/app/core/constants/user.constants';
import { HttpNativeHelper } from 'src/app/core/helpers/http-native.helper';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { BasicLoginRequest } from 'src/app/core/models/login.request';
import { IPageResponse } from 'src/app/core/models/page.response';
import { RefreshTokenService } from 'src/app/core/services/refresh-token.service';
import { TokenService } from 'src/app/core/services/token.service';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { environment } from 'src/environments/environment';
import { UserEventSource } from '../constants/user-event.constants';
import { CancelledError } from '../models/error.response';
import { NavigationService } from '../services/navigation.service';

@Injectable()
export class UmbracoInterceptor implements HttpInterceptor {
  private cancel$ = new Subject<void>();

  constructor(
    private modalLoginHelper: ModalLoginHelper,
    private userHelper: UserHelper,
    private tokenService: TokenService,
    private refreshTokenService: RefreshTokenService,
    private navigationService: NavigationService,
    private httpNativeHelper: HttpNativeHelper,
    private route: ActivatedRoute
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (!request.url.startsWith(environment.umbraco.cdnUrl) && !request.url.startsWith(environment.umbraco.previewUrl)) {
      return next.handle(request);
    }

    const observable = this.handleRequest(request, next);
    return observable.pipe(
      switchMap(async (response: HttpEvent<unknown>) => {
        if (!(response instanceof HttpResponse)) {
          return response;
        }

        if (await this.handleAuthorization(response)) {
          return response;
        }

        throw new CancelledError();
      }),
      catchError((e) => {
        if (e instanceof CancelledError) {
          return NEVER;
        }

        throw e;
      })
    );
  }

  private handleRequest(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    let observable: Observable<HttpEvent<unknown>> | null = null;

    if (PlatformHelper.isNativeMobile) {
      observable = from(this.httpNativeHelper.handleRequest(this.addHeaders(request)));
    } else {
      observable = next.handle(this.addHeaders(request));
    }

    return observable;
  }

  private addHeaders(request: HttpRequest<unknown>): HttpRequest<unknown> {
    return request.clone({
      setHeaders: {
        ['accept']: 'charset=utf-8',
        ['umb-project-alias']: environment.umbraco.projectAlias,
        ['Accept-Language']: 'nl-NL'
      }
    });
  }

  private async handleAuthorization(response: HttpResponse<unknown>): Promise<boolean> {
    const body = response?.body as IPageResponse;
    let currentAuthorization = this.userHelper.currentAuthorizationLevel ?? null;

    if (body?.contentTypeAlias && body.contentTypeAlias !== PageType.pageContext) {
      if (!this.userHelper.isLoggedIn && this.userHelper.currentUser) {
        await this.tokenService.logout();
      }

      const queryParamMap = this.route.snapshot.queryParamMap;
      const memberId =
        queryParamMap.get('memberId') ??
        queryParamMap.get('encryptedMemberId') ??
        queryParamMap.get('ZMemberID_2') ??
        queryParamMap.get('zmemberid_2');

      if (
        memberId &&
        (!this.userHelper.isLoggedIn ||
          currentAuthorization === AuthorizationLevel.basic ||
          (!PlatformHelper.isNativeMobile && this.userHelper.currentUser?.memberId !== memberId))
      ) {
        // Silently try to login via parameter
        await this.tokenService
          .createBasicLoginToken(new BasicLoginRequest(memberId), false)
          .then(() => {
            void this.userHelper.isLoggedInChanged$.pipe(first((x) => !!x)).toPromise();
            currentAuthorization = AuthorizationLevel.basic;
          })
          .catch((error) => {
            console.log('Error silent token:', error);
          });
      }
    }

    if (!PageHelper.isAuthorizedPage(body)) {
      return true;
    }

    const pageAuthorization = this.getPageAuthorizationLevel(body.contentTypeAlias);
    const requiredAuthorization =
      (pageAuthorization === AuthorizationLevel.twoFactor && currentAuthorization !== AuthorizationLevel.twoFactor) ||
      (pageAuthorization === AuthorizationLevel.password && (!currentAuthorization || currentAuthorization === AuthorizationLevel.basic)) ||
      (pageAuthorization === AuthorizationLevel.basic && !currentAuthorization)
        ? pageAuthorization
        : null;

    switch (requiredAuthorization) {
      case AuthorizationLevel.basic:
      case AuthorizationLevel.password: {
        void this.modalLoginHelper.triggerPasswordLoginModal(UserEventSource.page, undefined, () => this.handleAuthorizationCallback());
        return !!(await this.userHelper.isLoggedInChanged$
          .pipe(
            first((x) => x === AuthorizationLevel.password),
            takeUntil(this.cancel$)
          )
          ?.toPromise());
      }
      case AuthorizationLevel.twoFactor: {
        if (this.userHelper.requiresPasswordLogin) {
          void this.modalLoginHelper.triggerTwoFactorPasswordLoginModal(
            UserEventSource.page,
            undefined,
            () => {
              this.navigationService.back();
              this.cancel$.next();
            },
            () => Promise.resolve(this.handleAuthorizationCallback())
          );
        } else {
          void this.modalLoginHelper.triggerTwoFactorModal(
            UserEventSource.page,
            () => {
              this.navigationService.back();
              this.cancel$.next();
            },
            () => Promise.resolve(this.handleAuthorizationCallback())
          );
        }

        return !!(await this.userHelper.isLoggedInChanged$
          .pipe(
            first((x) => x === AuthorizationLevel.twoFactor),
            takeUntil(this.cancel$)
          )
          ?.toPromise());
      }
      default: {
        if (currentAuthorization !== AuthorizationLevel.basic && this.userHelper.isAccessTokenAlmostExpired) {
          await this.refreshTokenService.refresh(UserEventSource.page, requiredAuthorization === AuthorizationLevel.twoFactor, false);
        }
      }
    }

    return !requiredAuthorization;
  }

  private handleAuthorizationCallback(): void {
    setTimeout(() => {
      if (!this.userHelper.isLoggedIn) {
        this.navigationService.back();
        this.cancel$.next();
      }
    }, 500);
  }

  private getPageAuthorizationLevel(contentTypeAlias: string): AuthorizationLevel | null {
    switch (contentTypeAlias) {
      case PageType.personalPageBasic:
      case PageType.campaignPage:
        return AuthorizationLevel.basic;
      case PageType.personalPagePassword:
        return AuthorizationLevel.password;
      case PageType.personalPageTwoFactor:
        return AuthorizationLevel.twoFactor;
      default:
        return null;
    }
  }
}
