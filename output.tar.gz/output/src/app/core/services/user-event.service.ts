import { Injectable } from '@angular/core';
import { UserEventAction, UserEventCategory } from '../constants/user-event.constants';
import { PageHelper } from '../helpers/page.helper';
import { GtmService } from './gtm.service';
import { InsightsService } from './insights.service';
import { SiteService } from './site.service';

@Injectable({ providedIn: 'root' })
export class UserEventService {
  private userEventCategory: UserEventCategory;
  private currentSource: string;
  private context?: object;
  pageTitle: string;

  constructor(
    private gtmService: GtmService,
    private insightsService: InsightsService,
    private siteService: SiteService
  ) {}

  pushEvent(source: string, action: UserEventAction, label?: string, value?: string, object?: unknown, context?: object): void {
    if (action === UserEventAction.link) {
      if (value && value.includes(location.host)) {
        const url = new URL(value);
        value = url.pathname;
      } else {
        value = value ? PageHelper.stripUrl(value) : value;
      }
    }

    const keepContext = this.currentSource?.split('-')[0].trim() === source?.split('-')[0].trim();
    this.context = keepContext && this.context ? { ...this.context, ...context } : context;
    this.currentSource = source;

    const category = this.userEventCategory;
    object = object === null || (Array.isArray(object) && object.length === 0) ? undefined : object;

    if (this.siteService.siteSettings?.enableConsoleEvents) {
      const objectString = JSON.stringify(object);
      const contextString = JSON.stringify(this.context);
      console.log(
        `category: ${category}\nsource: ${source}\naction: ${action}\nlabel: ${label}\n` +
          `value: ${value}\nobject: ${objectString}\ncontext: ${contextString}`
      );
    }

    void this.gtmService.trackUserEvent(this.pageTitle, category, source, action, label, value, object, this.context);
    this.insightsService.trackUserEvent(this.pageTitle, category, source, action, label, value, object, this.context);
  }

  setUserEventCategory(contentTypeAlias: string): void {
    switch (contentTypeAlias) {
      case 'campaign':
        this.userEventCategory = UserEventCategory.campaign;
        break;
      case 'charity':
        this.userEventCategory = UserEventCategory.charity;
        break;
      case 'product':
      case 'combinedProduct':
        this.userEventCategory = UserEventCategory.product;
        break;
      case 'partner':
        this.userEventCategory = UserEventCategory.partner;
        break;
      case 'supplier':
        this.userEventCategory = UserEventCategory.supplier;
        break;
      case 'personalPageBasic':
      case 'personalPagePassword':
      case 'personalPageTwoFactor':
        this.userEventCategory = UserEventCategory.personal;
        break;
      default:
        this.userEventCategory = UserEventCategory.public;
        break;
    }
  }
}
