import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ScreenSize } from '../components/resize-detector/resize-detector.model';

@Injectable({ providedIn: 'root' })
export class ResizeService {
  private resizeSubject: BehaviorSubject<ScreenSize>;

  get onResize$(): Observable<ScreenSize> {
    return this.resizeSubject.asObservable().pipe(debounceTime(50), distinctUntilChanged());
  }

  constructor() {
    this.resizeSubject = new BehaviorSubject<ScreenSize>(ScreenSize.lg);
  }

  onResize(size: ScreenSize): void {
    this.resizeSubject.next(size);
  }

  getCurrentSize(): ScreenSize {
    switch (true) {
      case window.innerWidth < 325:
        return ScreenSize.xsm;
      case window.innerWidth < 768:
        return ScreenSize.sm;
      case window.innerWidth < 1024:
        return ScreenSize.md;
    }
    return ScreenSize.lg;
  }
}
