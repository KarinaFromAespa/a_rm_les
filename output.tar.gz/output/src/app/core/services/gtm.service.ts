import { Inject, Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { SiteConstants, WINDOW_TOKEN } from 'src/app/core/constants/site.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserEventAction, UserEventCategory } from '../constants/user-event.constants';
import { CookieConsentHelper } from '../helpers/cookie-consent.helper';
import { StringHelper } from '../helpers/string.helper';
import { UserHelper } from '../helpers/user.helper';
import { CommerceOrderPair } from '../models/user-event.model';
import { SiteService } from './site.service';

declare global {
  interface Window {
    dataLayer: unknown[];
  }
}

@Injectable({ providedIn: 'root' })
export class GtmService {
  private gtmScriptBlockId = 'gtmScript';

  constructor(
    @Inject(WINDOW_TOKEN) private window: Window,
    private siteService: SiteService,
    private cookieConsentHelper: CookieConsentHelper,
    private cookieService: CookieService,
    private userHelper: UserHelper,
    private platformHelper: PlatformHelper
  ) {
    this.window.dataLayer = this.window.dataLayer || [];
  }

  async trackUserEvent(
    pageTitle: string,
    category: UserEventCategory,
    source: string,
    action: UserEventAction,
    label?: string,
    value?: string,
    object?: unknown,
    context?: object
  ): Promise<void> {
    const user = this.userHelper.currentUser;
    this.dataLayerPush({
      event: [pageTitle, source, action, label].filter((x) => x).join(' - '),
      category,
      source,
      action,
      label,
      value,
      object,
      context,
      user: {
        id: user?.memberId,
        balance: user?.balance,
        authorizationLevel: user ? StringHelper.convertCamelCaseToSpaces(user.authorizationLevel) : undefined,
        clientId: this.cookieService.get(SiteConstants.gaCookieName).replace(/^GA1\.[0-9]\.([.0-9]*)$/, '$1'),
        consent: await this.cookieConsentHelper.allCookiesAccepted()
      },
      system: {
        userAgent: this.window.navigator.userAgent,
        platform: this.platformHelper.platformString,
        appVersion: PlatformHelper.isNativeMobile ? this.platformHelper.version : undefined
      }
    });

    if (object instanceof CommerceOrderPair) {
      await this.processCommerceOrderPair(pageTitle, category, source, object);
    }
  }

  private dataLayerPush(data: unknown): void {
    if (this.siteService.isInMaintenance || this.siteService.isInPreviewMode) {
      return;
    }

    this.window.dataLayer.push({
      event: undefined,
      category: undefined,
      source: undefined,
      action: undefined,
      label: undefined,
      value: undefined,
      object: undefined,
      context: undefined,
      user: undefined,
      system: undefined
    });

    this.window.dataLayer.push(data);
  }

  private async processCommerceOrderPair(
    pageTitle: string,
    category: UserEventCategory,
    source: string,
    commerceOrderPair: CommerceOrderPair
  ): Promise<void> {
    const changedItems = commerceOrderPair.changedItems;
    const addedItems = changedItems
      .filter((i) => i.quantity && i.quantity > 0)
      .map((i) => {
        i.quantity = i.quantity ? Math.abs(i.quantity) : 1;
        return i;
      });
    const removedItems = changedItems
      .filter((i) => i.quantity && i.quantity < 0)
      .map((i) => {
        i.quantity = i.quantity ? Math.abs(i.quantity) : 1;
        return i;
      });

    if (removedItems.length > 0) {
      await this.trackUserEvent(pageTitle, category, source, UserEventAction.remove, undefined, undefined, removedItems);
    }

    if (addedItems.length > 0) {
      await this.trackUserEvent(pageTitle, category, source, UserEventAction.add, undefined, undefined, addedItems);
    }
  }

  addSnippet(): void {
    const gtmContainerId = this.siteService.siteSettings.gtmContainerId;
    if (!/^GTM-[A-Z0-9]{4,7}$/.test(gtmContainerId) || document.getElementById(this.gtmScriptBlockId) != null) {
      return;
    }

    const nonce = this.cookieService.get(SiteConstants.nonceCookieName);

    const script = document.createElement('script');
    script.async = true;
    script.id = this.gtmScriptBlockId;
    script.nonce = nonce;
    script.src = `https://www.googletagmanager.com/gtm.js?id=${gtmContainerId}`;
    document.head.prepend(script);

    const noscript = document.createElement('noscript');
    noscript.nonce = nonce;
    noscript.innerHTML = `<iframe src="https://www.googletagmanager.com/ns.html?id=${gtmContainerId}"
      height="0" width="0" style="display: none; visibility: hidden"></iframe>`;
    document.body.prepend(noscript);

    this.dataLayerPush({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
    this.dataLayerPush({ nonce });
  }
}
