import { Injectable } from '@angular/core';
import { ApolloError, ApolloQueryResult, gql } from '@apollo/client/core';
import { TranslateService } from '@ngx-translate/core';
import { Apollo } from 'apollo-angular';
import { DocumentNode } from 'graphql';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { SiteService } from './site.service';

@Injectable({ providedIn: 'root' })
export class GraphQLService {
  constructor(
    private siteService: SiteService,
    private apollo: Apollo,
    private toastService: ToastService,
    private translateService: TranslateService
  ) {}

  query<T>(query: DocumentNode, variables?: Record<string, string | string[]>, suppressErrors = false): Observable<ApolloQueryResult<T>> {
    query = this.checkPreviewMode(query);

    return this.apollo
      .query<T>({
        query,
        variables: variables ? variables : undefined
      })
      .pipe(catchError((err: ApolloError) => (!suppressErrors ? this.handleErrorMessage(err) : throwError(err))));
  }

  watchQuery<T>(query: DocumentNode, variables?: Record<string, string>, suppressErrors = false): Observable<ApolloQueryResult<T>> {
    query = this.checkPreviewMode(query);

    return this.apollo
      .watchQuery<T>({
        query,
        variables: variables ? variables : undefined
      })
      .valueChanges.pipe(catchError((err: ApolloError) => (!suppressErrors ? this.handleErrorMessage(err) : throwError(err))));
  }

  private handleErrorMessage(error: ApolloError | string): Observable<never> {
    this.toastService.show(
      new ToastOptions({
        title: this.translateService.instant('general.label.error') as string,
        message: this.translateService.instant(`http.error.graphql`) as string,
        type: ToastType.error,
        id: 'graphql_error'
      })
    );

    return throwError(error);
  }

  private checkPreviewMode(query: DocumentNode): DocumentNode {
    if (!this.siteService.isInPreviewMode) {
      return query;
    }

    let queryString = query.loc?.source.body || '';
    const queryLines = queryString.split('\n');
    const queryLineIndex = queryLines.findIndex((x) => x.trimLeft().startsWith('query'));
    if (queryLineIndex === -1) {
      console.warn('no query line found, check query if preview should be enabled');
      return query;
    }

    // Mark operation name to begin with Preview
    queryLines[queryLineIndex] = queryLines[queryLineIndex].replace('query ', 'query Preview');
    // Add preview to query
    queryString = queryLines.slice(queryLineIndex + 1).join('\n');
    const hasParametersRegex = /[\\)] {$/m;
    const addComma = hasParametersRegex.test(queryString); // Check if parameters already exist
    if (!addComma) {
      queryString = queryString.replace(/([A-Za-z]) {$/m, `$1() {`);
    }
    queryString = queryString.replace(')', `${addComma ? ', ' : ''}preview: true)`);

    return gql`
      ${queryLines.slice(0, queryLineIndex + 1)}
      ${queryString}
    `;
  }
}
