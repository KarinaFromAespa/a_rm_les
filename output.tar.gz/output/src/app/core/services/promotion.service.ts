import { Injectable } from '@angular/core';
import { HttpErrorCodes } from '../constants/error.constants';
import { ICampaignResponse, IPromotionCountResponse } from '../models/promotion.response';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class PromotionService extends ApiService {
  constructor() {
    super();
  }

  async getCampaigns(): Promise<ICampaignResponse[]> {
    return await this.httpGet<ICampaignResponse[]>({ path: `promotions/campaigns` });
  }

  async getCampaign(campaignId: string): Promise<ICampaignResponse> {
    return await this.httpGet<ICampaignResponse>({ path: `promotions/campaigns/${campaignId}` });
  }

  async activateCampaign(campaignId: string, suppressErrorCodes?: HttpErrorCodes[]): Promise<void> {
    return await this.httpPut<void>({ path: `promotions/campaigns/${campaignId}/activated`, body: {}, suppressErrorCodes });
  }

  async markCampaignAsRead(umbracoCampaignId: string): Promise<void> {
    return await this.httpPut<void>({ path: `promotions/campaigns/${umbracoCampaignId}/read`, body: {} });
  }

  async getUnactivatedPromotionsCount(): Promise<IPromotionCountResponse | null> {
    return await this.httpGet<IPromotionCountResponse>({ path: 'promotions/count' });
  }
}
