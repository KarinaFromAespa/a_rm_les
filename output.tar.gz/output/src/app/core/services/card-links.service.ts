import { Injectable } from '@angular/core';
import {
  MergeInvitationRequest,
  MergeInvitationStatusRequest,
  ReceivedMergeInvitation,
  SentMergeInvitation
} from '../models/merge-invitation.model';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class CardLinksService extends ApiService {
  constructor() {
    super();
  }

  async getReceivedMergeInvitations(): Promise<ReceivedMergeInvitation[]> {
    return await this.httpGet<ReceivedMergeInvitation[]>({
      path: `card-links/shared-account/invitations/received`
    });
  }

  async getSentMergeInvitations(): Promise<SentMergeInvitation[]> {
    return await this.httpGet<SentMergeInvitation[]>({
      path: `card-links/shared-account/invitations/sent`
    });
  }

  async setMergeInvitationStatus(invitationId: string, request: MergeInvitationStatusRequest): Promise<void> {
    return await this.httpPut<void>({
      path: `card-links/shared-account/invitations/${invitationId}/status`,
      body: request
    });
  }

  async sendMergeInvitation(request: MergeInvitationRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `card-links/shared-account/invitations/sent`,
      body: request
    });
  }

  async deleteMergeInvitation(invitationId: string): Promise<void> {
    return await this.httpDelete<void>({
      path: `card-links/shared-account/invitations/${invitationId}`
    });
  }

  async stopSharedAccount(): Promise<void> {
    return await this.httpDelete<void>({
      path: `card-links/shared-account`
    });
  }
}
