import { Injectable } from '@angular/core';
import { IOrderVouchers, VoucherDeliveryRequest } from '../models/voucher.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class VoucherService extends ApiService {
  constructor() {
    super();
  }

  async getVouchers(): Promise<IOrderVouchers[]> {
    return await this.httpGet<IOrderVouchers[]>({
      path: `vouchers`
    });
  }

  async redeliverVouchers(request: VoucherDeliveryRequest): Promise<void> {
    return await this.httpPost({
      path: `vouchers/deliveries`,
      body: request
    });
  }
}
