import { Injectable } from '@angular/core';
import { BiometricsClient, BiometricsRequestType } from '../helpers/biometrics-client';

@Injectable({ providedIn: 'root' })
export class BiometricsCredentialsService {
  private server = 'https://www.airmiles.nl/';

  constructor(private biometricsClient: BiometricsClient) {}

  async updateCredentials(memberId: string, emailAddress: string): Promise<void> {
    const credentials = await this.biometricsClient.getCredentials(BiometricsRequestType.password, this.server);
    if (!credentials) {
      return;
    }

    credentials.username = emailAddress;

    await this.biometricsClient.setCredentials(
      BiometricsRequestType.password,
      this.server,
      memberId,
      credentials.username,
      credentials.password
    );
  }
}
