import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { CookieConsentHelper } from '../helpers/cookie-consent.helper';
import { SiteService } from './site.service';

@Injectable({ providedIn: 'root' })
export class VwoService {
  private isEnabled = false;
  private vwoScriptBlockId = 'vwoCode';

  constructor(
    private siteService: SiteService,
    private cookieConsentHelper: CookieConsentHelper,
    private cookieService: CookieService
  ) {
    this.cookieConsentHelper.cookieConsentValue$.subscribe((cookieConsentValue) => {
      this.updateState(cookieConsentValue);
    });
  }

  async load(): Promise<void> {
    this.updateState(await this.cookieConsentHelper.getCookieConsentValue());
  }

  private updateState(cookieConsentValue: boolean): void {
    this.isEnabled = cookieConsentValue || window.navigator.userAgent.includes('HeadlessChrome');

    if (this.isEnabled) {
      void this.addSnippet();
    } else {
      this.removeSnippet();
    }
  }

  private addSnippet(): void {
    const vwoAccountId = this.siteService.siteSettings?.vwoAccountId;
    if (!vwoAccountId?.length || document.getElementById(this.vwoScriptBlockId) != null) {
      return;
    }

    const link = document.createElement('link');
    link.rel = 'preconnect';
    link.href = 'https://dev.visualwebsiteoptimizer.com';
    document.head.prepend(link);

    const nonce = this.cookieService.get(SiteConstants.nonceCookieName);
    const script = document.createElement('script');
    script.id = this.vwoScriptBlockId;
    script.nonce = nonce;
    script.src = '/assets/js/vwo.js';
    script.dataset.vwoAccountId = vwoAccountId;
    document.head.prepend(script);
  }

  private removeSnippet(): void {
    if (document.getElementById(this.vwoScriptBlockId) != null) {
      window.location.reload();
    }
  }
}
