import { inject, NgModule } from '@angular/core';
import { ApolloClientOptions, ApolloLink, GraphQLRequest, InMemoryCache } from '@apollo/client/core';
import { setContext } from '@apollo/client/link/context';
import { provideApollo } from 'apollo-angular';
import { HttpLink } from 'apollo-angular/http';
import { environment } from 'src/environments/environment';
import { UmbracoTokenService } from './umbraco-token.service';

const createApollo = (): ApolloClientOptions<any> => {
  const httpLink = inject(HttpLink);
  const umbracoTokenService = inject(UmbracoTokenService);

  const basic = setContext(async (operation: GraphQLRequest) => {
    let apiKey: string | null = null;
    if (operation.operationName?.startsWith('Preview')) {
      apiKey = (await umbracoTokenService.getPreviewToken()).key;
    }

    return {
      headers: {
        ['accept']: 'charset=utf-8',
        ['umb-project-alias']: environment.umbraco.projectAlias,
        ['Accept-Language']: 'nl-NL',
        ...(apiKey && {
          ['Api-Key']: apiKey
        })
      }
    };
  });

  const link = ApolloLink.from([basic, httpLink.create({ uri: environment.umbraco.graphQLServerUrl })]);

  return {
    link,
    cache: new InMemoryCache()
  };
};

@NgModule({
  imports: [],
  providers: [provideApollo(createApollo)]
})
export class GraphQLModule {}
