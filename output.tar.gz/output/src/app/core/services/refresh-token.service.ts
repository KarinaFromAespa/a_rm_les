import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Device } from '@capacitor/device';
import { first } from 'rxjs/operators';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { MyCardSheetService } from 'src/app/shared/components/my-card-sheet/my-card-sheet.service';
import { HttpErrorCodes } from '../constants/error.constants';
import { AuthorizationLevel } from '../constants/user.constants';
import { PlatformHelper } from '../helpers/platform.helper';
import { IHTTPError, IHttpError } from '../models/http.model';
import { ApiService } from './api.service';
import { XsrfService } from './xsrf.service';

@Injectable({ providedIn: 'root' })
export class RefreshTokenService extends ApiService {
  constructor(
    private myCardSheetService: MyCardSheetService,
    private modalLoginHelper: ModalLoginHelper,
    private router: Router,
    private xsrfService: XsrfService
  ) {
    super();
  }

  async refresh(
    userEventSource: string,
    twoFactorRequired = false,
    triggerLoginOnException = true
  ): Promise<{ succeeded: boolean; suppressErrorCode?: boolean }> {
    if (!this.userHelper.currentUser?.refreshToken) {
      await this.triggerLoginModal(twoFactorRequired, userEventSource);
      return { succeeded: false };
    }

    let succeeded = true;
    let suppressErrorCode = false;
    const suppressErrorCodes = this.platformHelper.isMobile
      ? [HttpErrorCodes.serverError, HttpErrorCodes.internalServerError, HttpErrorCodes.internalServerTimeout]
      : [];

    await this.httpPost<IUserLoginData>({
      path: `token/login`,
      body: {
        refreshToken: this.userHelper.currentUser.refreshToken,
        deviceId: PlatformHelper.isNativeMobile ? (await Device.getId()).identifier : undefined
      },
      suppressErrorCodes
    })
      .then(async (currentUser: IUserLoginData) => {
        await this.handleLogin(currentUser);
      })
      .catch(async (e: IHttpError | IHTTPError) => {
        if (e.status === 500 && this.platformHelper.isMobile) {
          suppressErrorCode = true;
          this.myCardSheetService.open(true);
        } else if (triggerLoginOnException && e.status !== 500) {
          await this.userHelper.setCurrentUser(undefined);
          await this.triggerLoginModal(twoFactorRequired, userEventSource);
        }

        succeeded = false;
      });

    if (twoFactorRequired && this.userHelper.currentAuthorizationLevel === AuthorizationLevel.password) {
      void this.modalLoginHelper.triggerTwoFactorModal(userEventSource, () => this.userHelper.setCurrentLoggedInStatus());
      await this.userHelper.isLoggedInChanged$.pipe(first((x) => !!x)).toPromise();
    }

    return { succeeded, suppressErrorCode };
  }

  private async handleLogin(user: IUserLoginData): Promise<void> {
    await this.userHelper.setCurrentUser(user);
    await this.xsrfService.setClientCookie();
  }

  private async triggerLoginModal(twoFactorRequired: boolean, userEventSource: string): Promise<void> {
    if (twoFactorRequired) {
      void this.modalLoginHelper.triggerTwoFactorPasswordLoginModal(userEventSource, undefined, () => void this.router.navigateByUrl('/'));
      await this.userHelper.isLoggedInChanged$.pipe(first((x) => !!x)).toPromise();
    } else {
      void this.modalLoginHelper.triggerPasswordLoginModal(userEventSource, undefined, () => void this.router.navigateByUrl('/'));
      await this.userHelper.isLoggedInChanged$.pipe(first((x) => !!x)).toPromise();
    }
  }
}

// Note: TokenService and RefreshTokenService have been separated to prevent circular dependencies
