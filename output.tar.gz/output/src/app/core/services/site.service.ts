import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject, from } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PageContext, SiteSettings } from 'src/app/core/models/site.response';
import { IEmbedded } from 'src/app/core/models/umbraco.response';
import { UmbracoApiService } from './umbraco-api.service';

@Injectable({ providedIn: 'root' })
export class SiteService {
  private _isSsr = false;

  siteSettings: SiteSettings;
  pageContext = new BehaviorSubject<PageContext | undefined | null>(undefined); // Initial value undefined to enable checking for first load.

  constructor(
    private api: UmbracoApiService,
    private activatedRoute: ActivatedRoute
  ) {}

  get isInMaintenance(): boolean {
    return !this.isSsr && !!this.pageContext.getValue()?.maintenancePage;
  }

  get isSsr(): boolean {
    const params = this.activatedRoute.snapshot.queryParams;
    if (params?.ssr) {
      this._isSsr = true;
    }

    return this._isSsr;
  }

  get isInPreviewMode(): boolean {
    return this.activatedRoute.snapshot.queryParamMap.get('preview') === 'true';
  }

  loadSiteSettings(): Promise<IEmbedded<SiteSettings> | undefined> {
    return from(this.api.get<IEmbedded<SiteSettings>>('type?contentType=siteSettings'))
      .pipe(
        tap((data) => {
          this.siteSettings = Object.assign(new SiteSettings(), data._embedded.content[0]);
        })
      )
      .toPromise();
  }

  loadPageContext(suppressAllErrorCodes = false): Promise<PageContext | undefined> {
    const pageContextUrl = this.siteSettings?.defaultPageContext._url;
    if (!pageContextUrl) {
      // Prevent an exception if the site settings isn't loaded so the barcode sheet can appear
      return Promise.resolve(undefined);
    }

    return from(this.api.get<PageContext>(`url?url=${pageContextUrl}&depth=2`, undefined, suppressAllErrorCodes))
      .pipe(tap((data) => this.pageContext.next(data ? Object.assign(new PageContext(), data) : null)))
      .toPromise();
  }

  clearContext(): void {
    this.pageContext.next(null);
  }
}
