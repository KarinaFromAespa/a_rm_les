import { Injectable } from '@angular/core';
import { HttpErrorCodes } from '../constants/error.constants';
import { LightUserCampaignCreateRequest, UserCampaignCreateRequest, UserCampaignRegistrationRequest } from '../models/user.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class CampaignRegistrationService extends ApiService {
  constructor() {
    super();
  }

  async activateRegistrationCampaign(request: UserCampaignRegistrationRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `campaign-registrations/${this.getCampaignRegistrationSettingsId(request)}/users/existing`,
      body: request,
      suppressErrorCodes: [HttpErrorCodes.accountNotFound]
    });
  }

  async createCampaignUser(request: UserCampaignCreateRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `campaign-registrations/${this.getCampaignRegistrationSettingsId(request)}/users/new`,
      body: request
    });
  }

  async createLightCampaignUser(request: LightUserCampaignCreateRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `campaign-registrations/${this.getCampaignRegistrationSettingsId(request)}/users/new/light`,
      body: request
    });
  }

  private getCampaignRegistrationSettingsId(request: UserCampaignRegistrationRequest | UserCampaignCreateRequest) {
    const campaignRegistrationSettingsId = request.campaignRegistrationSettingsId;
    delete request.campaignRegistrationSettingsId;
    return campaignRegistrationSettingsId;
  }
}
