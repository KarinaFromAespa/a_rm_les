import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class NavigationService {
  private history: string[] = [];

  constructor(
    private router: Router,
    private location: Location
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Store navigation within Air Miles
        this.history.push(event.urlAfterRedirects);
      }
    });
  }

  removeLastHistory(): void {
    // Use if any navigation uses `replaceUrl: true`
    this.history.pop();
  }

  back(): void {
    // Remove last entry from history.
    this.removeLastHistory();
    // Check for history within Air Miles
    if (this.history.length > 0) {
      const previousUrl = this.history[this.history.length - 1];
      void this.router.navigateByUrl(previousUrl);
    } else {
      // If no navigation history within Air Miles is known, redirect to home instead.
      void this.router.navigateByUrl('/');
    }
    // Remove this navigation from the history push, as the subscription trigger re-adds it
    this.removeLastHistory();
  }
}
