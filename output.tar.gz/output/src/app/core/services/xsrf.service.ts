import { Injectable } from '@angular/core';
import { PlatformHelper } from '../helpers/platform.helper';
import { ApiService } from './api.service';
import { environment } from 'src/environments/environment';
import { CookieService } from 'ngx-cookie-service';
import { delay, lastValueFrom, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class XsrfService extends ApiService {
  constructor(private cookieService: CookieService) {
    super();
  }

  // Maximum delay (in milliseconds) to wait for the XSRF client cookie, preventing AntiForgeryException errors.
  // Response 'set-cookie' headers may not have been processed before the next request.
  // If necessary, this delay is applied between the /token/xsrf request and the subsequent request.
  // Reference: AIR-1234
  private maxDelayMs: 1500;
  private lastUpdatedOn?: Date;

  async getClientCookie(): Promise<string | null> {
    if (PlatformHelper.isNativeMobile) {
      return null;
    }

    let xsrf = this.cookieService.get(environment.xsrfClientCookieName);
    if (xsrf || !this.lastUpdatedOn) {
      return xsrf;
    }

    let time = this.maxDelayMs + this.lastUpdatedOn.getTime() - new Date().getTime();
    if (time > 0) {
      time = Math.max(100, Math.min(this.maxDelayMs, time));

      await lastValueFrom(of(void 0).pipe(delay(time)));
      xsrf = this.cookieService.get(environment.xsrfClientCookieName);
    }

    return xsrf;
  }

  async setClientCookie(): Promise<void> {
    if (PlatformHelper.isNativeMobile) {
      return;
    }

    this.cookieService.delete(environment.xsrfClientCookieName);
    await this.httpPost<void>({ path: 'token/xsrf', body: {} });
    this.lastUpdatedOn = new Date();
  }
}
