import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ERROR_CODES_WITH_MESSAGES } from 'src/app/core/constants/error.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { environment } from 'src/environments/environment';
import { UmbracoTokenService } from './umbraco-token.service';

@Injectable({ providedIn: 'root' })
export abstract class UmbracoApiService {
  private apiUrl: string;
  private previewUrl: string;
  private http: HttpClient;
  private umbracoTokenService: UmbracoTokenService;
  protected toastService: ToastService;
  protected translateService: TranslateService;
  protected platformHelper: PlatformHelper;

  constructor() {
    this.http = inject(HttpClient);
    this.toastService = inject(ToastService);
    this.translateService = inject(TranslateService);
    this.platformHelper = inject(PlatformHelper);
    this.umbracoTokenService = inject(UmbracoTokenService);
    this.apiUrl = environment.umbraco.cdnUrl;
    this.previewUrl = environment.umbraco.previewUrl;
  }

  async get<T = null>(
    path: string,
    suppressErrorCodes: number[] | null = null,
    suppressAllErrorCodes = false,
    previewMode = false
  ): Promise<T> {
    const headers = {};
    let reqUrl = this.apiUrl;

    if (previewMode) {
      headers['Api-Key'] = (await this.umbracoTokenService.getPreviewToken()).key;
      reqUrl = this.previewUrl;
    }

    const result = (await this.http
      .get(`${reqUrl}/${path}`, { headers })
      .pipe(catchError((error: HttpErrorResponse) => this.handleErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes)))
      .toPromise()) as Promise<T>;

    this.handleNetwork();
    return result;
  }

  async post<T = null>(path: string, body: unknown, suppressErrorCodes: number[] | null = null, suppressAllErrorCodes = false): Promise<T> {
    return this.http
      .post(`${this.apiUrl}/${path}`, body)
      .pipe(catchError((error: HttpErrorResponse) => this.handleErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes)))
      .toPromise() as Promise<T>;
  }

  async put<T = null>(path: string, body: unknown, suppressErrorCodes: number[] | null = null, suppressAllErrorCodes = false): Promise<T> {
    return this.http
      .put(`${this.apiUrl}/${path}`, body)
      .pipe(catchError((error: HttpErrorResponse) => this.handleErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes)))
      .toPromise() as Promise<T>;
  }

  async patch<T = null>(
    path: string,
    body: unknown,
    suppressErrorCodes: number[] | null = null,
    suppressAllErrorCodes = false
  ): Promise<T> {
    return this.http
      .patch(`${this.apiUrl}/${path}`, body)
      .pipe(catchError((error: HttpErrorResponse) => this.handleErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes)))
      .toPromise() as Promise<T>;
  }

  async delete<T = null>(path: string, suppressErrorCodes: number[] = [], suppressAllErrorCodes = false): Promise<T> {
    return this.http
      .delete(`${this.apiUrl}/${path}`)
      .pipe(catchError((error: HttpErrorResponse) => this.handleErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes)))
      .toPromise() as Promise<T>;
  }

  private handleErrorMessage(error: HttpErrorResponse, suppressErrorCodes: number[] | null, suppressAllErrorCodes: boolean) {
    const isNetworkError = this.handleNetwork(error.status);

    if (!isNetworkError && !suppressErrorCodes?.includes(error.status) && !suppressAllErrorCodes) {
      const status = ERROR_CODES_WITH_MESSAGES.includes(error.status) ? error.status.toString() : 'default';
      const message = this.translateService.instant(`http.error.${status}`) as string;
      const toastOptions = new ToastOptions({
        title: this.translateService.instant('general.label.error') as string,
        message,
        type: ToastType.error
      });
      this.toastService.show(toastOptions);
    }

    return throwError(error);
  }

  private handleNetwork(status?: number): boolean {
    // Network http status
    // 0 | Unknown Error - CORS preflight failed
    // -3 | Host could not be resolved
    // -6 | Internet connection is offline
    // 504 | Gateway Timeout
    // 502 | Bad gateway
    const isNetworkError = status === 0 || status === -3 || status === -6 || status === 504 || status === 502;
    this.platformHelper.onlineState = !isNetworkError;

    return isNetworkError;
  }
}
