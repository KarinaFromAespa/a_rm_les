import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ScrollService {
  scrollSubject: BehaviorSubject<number>;

  get onScroll$(): Observable<number> {
    return this.scrollSubject.asObservable().pipe(debounceTime(25));
  }

  constructor() {
    this.scrollSubject = new BehaviorSubject(0);
  }

  updateScroll(scrollTop: number): void {
    this.scrollSubject.next(scrollTop);
  }
}
