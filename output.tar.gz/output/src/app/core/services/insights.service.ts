import { ErrorHandler, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AngularPlugin } from '@microsoft/applicationinsights-angularplugin-js';
import { ApplicationInsights, ICustomProperties, IEventTelemetry } from '@microsoft/applicationinsights-web';
import { environment } from 'src/environments/environment';
import { UserEventAction, UserEventCategory } from '../constants/user-event.constants';
import { CookieConsentHelper } from '../helpers/cookie-consent.helper';
import { SiteService } from './site.service';

@Injectable({ providedIn: 'root' })
export class InsightsService {
  private isEnabled = false;
  private isPending = false;
  private pendingData: { event: IEventTelemetry; customProperties?: ICustomProperties }[] = [];
  private angularPlugin = new AngularPlugin();
  private applicationInsights = new ApplicationInsights({
    config: {
      connectionString: environment.applicationInsightsConnectionString,
      extensions: [this.angularPlugin],
      extensionConfig: {
        [this.angularPlugin.identifier]: {
          router: this.router,
          errorServices: [new ErrorHandler()]
        }
      },
      enableCorsCorrelation: true,
      enableRequestHeaderTracking: true,
      enableResponseHeaderTracking: true,
      correlationHeaderDomains: ['*.airmiles.nl']
    }
  });

  constructor(
    private router: Router,
    private cookieConsentHelper: CookieConsentHelper,
    private siteService: SiteService
  ) {
    this.cookieConsentHelper.cookieConsentValue$.subscribe((cookieConsentValue) => {
      this.updateState(cookieConsentValue);
    });
  }

  async load(): Promise<void> {
    this.updateState(await this.cookieConsentHelper.getCookieConsentValue());
  }

  trackUserEvent(
    pageTitle: string,
    category: UserEventCategory,
    source: string,
    action: UserEventAction,
    label?: string,
    value?: string,
    object?: unknown,
    context?: object
  ): void {
    if ((!this.isEnabled && !this.isPending) || this.siteService.isInMaintenance || this.siteService.isInPreviewMode) {
      return;
    }

    const element = {
      event: { name: [pageTitle, source, action, label].filter((x) => x).join(' - ') },
      customProperties: { category, source, action, label, value, object, context }
    };

    if (this.isEnabled) {
      this.applicationInsights.trackEvent(element.event, element.customProperties);
    } else {
      this.pendingData.push(element);
    }
  }

  private updateState(cookieConsentValue: boolean): void {
    this.isEnabled = cookieConsentValue;
    this.isPending = cookieConsentValue == null;

    if (this.isEnabled) {
      this.applicationInsights.loadAppInsights();

      this.pendingData.forEach((element) => {
        this.applicationInsights.trackEvent(element.event, element.customProperties);
      });
      this.pendingData = [];
    } else {
      try {
        this.applicationInsights.unload();
      } catch {}
    }
  }
}
