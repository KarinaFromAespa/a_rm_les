import { Injectable } from '@angular/core';
import { ReCaptchaV3Service } from 'ng-recaptcha-2';
import { BehaviorSubject, delay, firstValueFrom, of } from 'rxjs';
import { IReCaptchaRequest, ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { HttpErrorCodes } from '../constants/error.constants';
import { IHttpError } from '../models/http.model';

@Injectable({ providedIn: 'root' })
export class ReCaptchaService {
  isReady = false;
  alternateReCaptchaToken?: string;
  enableAlternateReCaptcha: Partial<Record<ReCaptchaAction, boolean>> = {};

  private readonly readySubject = new BehaviorSubject<boolean>(false);
  readonly ready$ = this.readySubject.asObservable();

  constructor(private reCaptchaV3Service: ReCaptchaV3Service) {}

  async initialize(): Promise<void> {
    let initializeAttempt = 0;
    let element: Element | null = null;

    while (!element && initializeAttempt < 5) {
      await of()
        .pipe(delay(250 * initializeAttempt))
        .toPromise();

      element = document.getElementsByClassName('grecaptcha-badge')?.[0];
      element?.setAttribute('inert', 'true');
      initializeAttempt++;
    }

    if (element) {
      this.isReady = true;
    }
  }

  async verify<T = void, U = void>(action: string, request: IReCaptchaRequest, callback: (request: U) => Promise<T>): Promise<T> {
    if (!this.isReady) {
      await this.initialize();
    }

    request.reCaptchaToken = await firstValueFrom(this.reCaptchaV3Service.execute(action));
    request.alternateReCaptchaToken = this.alternateReCaptchaToken;

    return callback(request as U)
      .then((response) => {
        Object.keys(this.enableAlternateReCaptcha).map((x) => (this.enableAlternateReCaptcha[x] = false));
        return response;
      })
      .catch((error: IHttpError) => {
        if (error?.error?.code === HttpErrorCodes.insufficientReCaptchaScore) {
          this.enableAlternateReCaptcha[action] = true;
        }

        throw error;
      })
      .finally(() => (this.alternateReCaptchaToken = undefined));
  }

  async showBadge(): Promise<void> {
    if (!this.isReady) {
      await this.initialize();
    }

    const element = document.getElementsByClassName('grecaptcha-badge')?.[0] as HTMLElement;
    if (element) {
      element.style.visibility = 'visible';
      setTimeout(() => {
        element.style.visibility = 'hidden';
      }, 11000);
      this.readySubject.next(this.isReady);
    }
  }

  hideBadge(): void {
    const element = document.getElementsByClassName('grecaptcha-badge')?.[0] as HTMLElement;
    if (element) {
      element.style.visibility = 'hidden';
    }

    this.alternateReCaptchaToken = undefined;
  }
}
