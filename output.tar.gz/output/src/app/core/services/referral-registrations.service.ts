import { Injectable } from '@angular/core';
import { IReferralLinkResponse, IReferralRewardsResponse } from '../models/referral-registration.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class ReferralRegistrationsService extends ApiService {
  constructor() {
    super();
  }

  async getRegistrationInvitationLink(id: string, baseUrl: string): Promise<string> {
    return (await this.httpGet<IReferralLinkResponse>({ path: `referral-registrations/${id}/url?registrationBaseUrl=${baseUrl}` })).url;
  }

  async getReferralRewards(id: string): Promise<IReferralRewardsResponse[]> {
    return await this.httpGet<IReferralRewardsResponse[]>({ path: `referral-registrations/${id}/rewards` });
  }
}
