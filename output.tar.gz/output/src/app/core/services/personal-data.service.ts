import { Injectable } from '@angular/core';
import { IFileUrl } from '../models/file.response';
import { PersonalDataStatusCheck } from '../models/user.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class PersonalDataService extends ApiService {
  constructor() {
    super();
  }

  async getUserPersonalData(): Promise<IFileUrl> {
    return await this.httpGet<IFileUrl>({ path: `personal-data/export` });
  }

  async exportUserPersonalData(): Promise<void> {
    return await this.httpPost<void>({ path: `personal-data/export`, body: {} });
  }

  async checkPersonalDataStatus(): Promise<PersonalDataStatusCheck> {
    return await this.httpGet<PersonalDataStatusCheck>({ path: `personal-data/export/status` });
  }
}
