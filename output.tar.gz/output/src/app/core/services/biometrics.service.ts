import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Credentials } from 'capacitor-native-biometric';
import { first, lastValueFrom } from 'rxjs';
import { ModalHelper } from 'src/app/features/modal/modal.helper';
import { TwoFactorAuthenticationToken } from 'src/app/shared/modals/two-factor-login-modal/two-factor-login-modal.model';
import { SiteConstants } from '../constants/site.constants';
import { UserEventAction } from '../constants/user-event.constants';
import { BiometricsClient, BiometricsRequestType } from '../helpers/biometrics-client';
import { PlatformHelper } from '../helpers/platform.helper';
import { PasswordLoginRequest, TwoFactorLoginRequest } from '../models/login.request';
import { PageContext } from '../models/site.response';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';
import { SiteService } from './site.service';
import { UserEventService } from './user-event.service';

@Injectable({ providedIn: 'root' })
export class BiometricsService {
  private pageContext?: PageContext;
  private server = 'https://www.airmiles.nl/';

  constructor(
    private biometricsClient: BiometricsClient,
    private modalHelper: ModalHelper,
    private storageService: CapacitorStorageService,
    private userEventService: UserEventService,
    private translateService: TranslateService,
    private siteService: SiteService
  ) {}

  async setPasswordLogin(memberId: string, request: PasswordLoginRequest): Promise<void> {
    return this.setLogin(memberId, request);
  }

  async setTwoFactorLogin(
    memberId: string,
    request: TwoFactorLoginRequest,
    authenticationToken: () => Promise<TwoFactorAuthenticationToken>
  ): Promise<void> {
    const credentials = await this.biometricsClient.getCredentials(BiometricsRequestType.password, this.server);
    if (!credentials) {
      return;
    }

    return this.setLogin(memberId, request, authenticationToken);
  }

  async verifyPasswordLogin(userEventSource: string): Promise<PasswordLoginRequest | null> {
    const credentials = await this.verify(BiometricsRequestType.password, userEventSource);
    if (!credentials) {
      return null;
    }

    return new PasswordLoginRequest(credentials.username, credentials.password, false);
  }

  async verifyTwoFactorLogin(refreshToken: string, userEventSource: string): Promise<TwoFactorLoginRequest | null> {
    const credentials = await this.verify(BiometricsRequestType.twoFactor, userEventSource);
    if (!credentials) {
      return null;
    }

    return new TwoFactorLoginRequest(refreshToken, undefined, credentials.password, false);
  }

  async resetOnUserChange(memberId: string): Promise<void> {
    if (!memberId?.length) {
      return;
    }

    if (memberId === (await this.biometricsClient.getMemberId(this.server))) {
      return;
    }

    return this.reset();
  }

  async reset(): Promise<void> {
    await this.storageService.delete(SiteConstants.biometricsPreferencesStorageName);
    await this.storageService.delete(SiteConstants.biometricsCancelCountStorageName);

    await this.biometricsClient.deleteCredentials(this.server);
  }

  async getUserPreferences(): Promise<boolean> {
    return this.storageService.get<boolean>(SiteConstants.biometricsPreferencesStorageName);
  }

  async setUserPreferences(value: boolean): Promise<void> {
    if (value) {
      void this.storageService.set(SiteConstants.biometricsCancelCountStorageName, 0);
    }

    return this.storageService.set(SiteConstants.biometricsPreferencesStorageName, value);
  }

  async hasPasswordCredentials(): Promise<boolean> {
    const userPreferences = await this.getUserPreferences();
    if (!userPreferences) {
      return false;
    }

    const credentials = await this.biometricsClient.getCredentials(BiometricsRequestType.password, this.server);
    return !!credentials;
  }

  private async isAvailable(): Promise<boolean> {
    if (!PlatformHelper.isNativeMobile) {
      return false;
    }

    if (!(await this.loadPageContext())) {
      return false;
    }

    return (await this.biometricsClient.isAvailable()).isAvailable;
  }

  private async setLogin<T>(
    memberId: string,
    request: T,
    authenticationToken?: () => Promise<TwoFactorAuthenticationToken>
  ): Promise<void> {
    if (!(await this.isAvailable())) {
      return;
    }

    const userPreferences = await this.getUserPreferences();
    if (userPreferences === false) {
      return;
    }

    if (userPreferences === true) {
      void this.accept(memberId, request, authenticationToken);
      return;
    }

    return this.showUserPreferencesMessage(memberId, request, authenticationToken);
  }

  private async verify(type: BiometricsRequestType, userEventSource: string): Promise<Credentials | null> {
    if (!(await this.getUserPreferences()) || !(await this.isAvailable())) {
      return null;
    }

    const credentials = await this.biometricsClient.getCredentials(type, this.server);
    if (!credentials) {
      return null;
    }

    userEventSource = `${userEventSource ? `${userEventSource} - ` : ''}biometrics ${
      type === BiometricsRequestType.password ? 'password' : 'two-factor'
    } login`;

    const verified = await this.verifyIdentity(type, userEventSource);
    return verified ? credentials : null;
  }

  private async verifyIdentity(type: BiometricsRequestType, userEventSource: string): Promise<boolean> {
    const verified = await this.biometricsClient
      .verifyIdentity({
        title: this.translateService.instant('user.label.biometrics_verification') as string,
        description: this.pageContext?.biometricsLoginDescription,
        reason: this.pageContext?.biometricsLoginDescription,
        negativeButtonText: this.translateService.instant('general.label.cancel') as string
      })
      .then(() => {
        this.userEventService.pushEvent(userEventSource, UserEventAction.submit);
        return true;
      })
      .catch(async (e: Error) => {
        if (e.message === 'Authentication failed.') {
          return await this.verifyIdentity(type, userEventSource);
        }

        this.userEventService.pushEvent(userEventSource, UserEventAction.cancel);

        const count = ((await this.storageService.get<number>(SiteConstants.biometricsCancelCountStorageName)) ?? 0) + 1;
        void this.storageService.set(SiteConstants.biometricsCancelCountStorageName, count);

        if (count === 3) {
          await this.showUserPreferencesCancelledMessage(userEventSource);
        }

        return false;
      });

    return verified;
  }

  private async accept<T>(memberId: string, request: T, authenticationToken?: () => Promise<TwoFactorAuthenticationToken>): Promise<void> {
    await this.setUserPreferences(true);

    if (request instanceof PasswordLoginRequest) {
      await this.biometricsClient.setCredentials(
        BiometricsRequestType.password,
        this.server,
        memberId,
        request.emailAddress,
        request.password
      );
    } else if (request instanceof TwoFactorLoginRequest) {
      const response = await authenticationToken?.();
      if (!response?.token) {
        return;
      }

      await this.biometricsClient.setCredentials(BiometricsRequestType.twoFactor, this.server, memberId, null, response.token);
    }
  }

  private async decline(confirm: boolean): Promise<void> {
    await this.setUserPreferences(false);

    if (confirm) {
      await this.showUserPreferencesDeclinedMessage();
    }
  }

  private async showUserPreferencesMessage<T>(
    memberId: string,
    request: T,
    authenticationToken?: () => Promise<TwoFactorAuthenticationToken>
  ): Promise<void> {
    await this.modalHelper.triggerConfirmationModal({
      text: this.pageContext?.biometricsSetup,
      confirmText: this.translateService.instant('general.label.yes_please') as string,
      cancelText: this.translateService.instant('general.label.no_thank_you') as string,
      action: () => void this.accept(memberId, request, authenticationToken),
      cancelAction: () => this.decline(true),
      userEventSource: 'biometrics setup',
      closeOnSelection: true
    });
  }

  private async showUserPreferencesCancelledMessage(userEventSource: string): Promise<void> {
    await this.modalHelper.triggerConfirmationModal({
      text: this.pageContext?.biometricsCanceled,
      confirmText: this.translateService.instant('general.label.yes_please') as string,
      cancelText: this.translateService.instant('general.label.no_thank_you') as string,
      action: () => this.decline(false),
      userEventSource,
      userEventSourceTopic: 'disable',
      closeOnSelection: true
    });
  }

  private async showUserPreferencesDeclinedMessage(): Promise<void> {
    const modalRef = this.modalHelper.triggerContentModal(
      this.pageContext?.biometricsDeclined.title ?? '',
      this.pageContext?.biometricsDeclined.body ?? '',
      'biometrics setup - declined'
    );

    if (modalRef) {
      await lastValueFrom(modalRef.onClose$.pipe(first()));
    }
  }

  private async loadPageContext(): Promise<boolean> {
    if (!this.pageContext) {
      this.pageContext = this.siteService.pageContext.getValue() ?? (await this.siteService.loadPageContext());
    }

    return !!this.pageContext;
  }
}
