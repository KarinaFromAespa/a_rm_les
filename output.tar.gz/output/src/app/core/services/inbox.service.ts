import { Injectable } from '@angular/core';
import { IInboxMessage, IInboxUnread } from '../models/inbox-message.model';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class InboxService extends ApiService {
  constructor() {
    super();
  }

  async getMessages(): Promise<IInboxMessage[]> {
    return await this.httpGet<IInboxMessage[]>({
      path: `in-app-messages/inbox`
    });
  }

  async getUnreadCount(): Promise<IInboxUnread | null> {
    return await this.httpGet<IInboxUnread | null>({
      path: `in-app-messages/count`
    });
  }

  async messageRead(messageId: number): Promise<void> {
    return await this.httpPut({
      path: `in-app-messages/${messageId}/read`,
      body: {}
    });
  }

  async messageAction(messageId: number): Promise<void> {
    return await this.httpPost({
      path: `in-app-messages/${messageId}/events`,
      body: {
        eventType: 'CustomAction'
      }
    });
  }

  async deleteMessage(messageId: number): Promise<void> {
    return await this.httpDelete({
      path: `in-app-messages/${messageId}`
    });
  }
}
