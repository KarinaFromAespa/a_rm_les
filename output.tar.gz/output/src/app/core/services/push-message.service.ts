import { Injectable, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FirebaseMessaging, NotificationActionPerformedEvent } from '@capacitor-firebase/messaging';
import { Device } from '@capacitor/device';
import { filter, first, Subject, takeUntil } from 'rxjs';
import { SiteConstants } from '../constants/site.constants';
import { UserEventAction, UserEventSource } from '../constants/user-event.constants';
import { PlatformHelper } from '../helpers/platform.helper';
import { UserHelper } from '../helpers/user.helper';
import { PushMessage } from '../models/user-event.model';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';
import { ApiService } from './api.service';
import { SiteService } from './site.service';
import { UserEventService } from './user-event.service';
import { UserService } from './user.service';

@Injectable({ providedIn: 'root' })
export class PushMessageService extends ApiService implements OnDestroy {
  private destroy$ = new Subject();
  private registrationInProgress = false;

  constructor(
    protected userHelper: UserHelper,
    private router: Router,
    private storageService: CapacitorStorageService,
    private siteService: SiteService,
    private userService: UserService,
    private userEventService: UserEventService
  ) {
    super();
    this.addNotificationActionPerformedListener();
  }

  async tryRegisterDevice(retrigger = false): Promise<void> {
    if (this.registrationInProgress) {
      return;
    }

    this.registrationInProgress = true;
    if (
      PlatformHelper.isNativeMobile &&
      !this.userHelper.requiresPasswordLogin &&
      !(await this.storageService.get<boolean>(SiteConstants.deviceRegisteredStorageName)) &&
      (await this.checkPermissions(retrigger))
    ) {
      await this.httpPost<void>({
        path: 'push-messages/devices',
        body: { deviceId: (await Device.getId()).identifier, pushToken: (await FirebaseMessaging.getToken()).token }
      });

      this.storageService.set(SiteConstants.deviceRegisteredStorageName, true);
      if (!retrigger) {
        await this.navigateToPushPreferences();
      }
    }

    this.registrationInProgress = false;
  }

  async unregisterDevice(): Promise<void> {
    if (!PlatformHelper.isNativeMobile) {
      return;
    }

    await this.storageService.delete(SiteConstants.deviceRegisteredStorageName);
    await FirebaseMessaging.deleteToken();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private async checkPermissions(retrigger: boolean): Promise<boolean> {
    let permission = (await FirebaseMessaging.checkPermissions()).receive;
    if (permission === 'prompt' || (retrigger && permission == 'prompt-with-rationale')) {
      const userEventSource = `${UserEventSource.pushService} - permission`;
      this.userEventService.pushEvent(userEventSource, UserEventAction.view);
      permission = (await FirebaseMessaging.requestPermissions()).receive;
      this.userEventService.pushEvent(userEventSource, permission !== 'granted' ? UserEventAction.confirm : UserEventAction.cancel);
    }

    return permission !== 'granted' ? false : true;
  }

  private async addNotificationActionPerformedListener(): Promise<void> {
    if (!PlatformHelper.isNativeMobile) {
      return;
    }

    await FirebaseMessaging.addListener('notificationActionPerformed', async (event: NotificationActionPerformedEvent) => {
      const data = event.notification.data as { messageId: number; mappUserId: number; sendoutId: number; target: string };
      if (data.messageId && data.mappUserId && data.sendoutId) {
        await this.httpPut<void>({
          path: `push-messages/${data.messageId}/opened`,
          body: { mappUserId: data.mappUserId, sendoutId: data.sendoutId }
        });

        this.userEventService.pushEvent(
          UserEventSource.pushService,
          UserEventAction.open,
          undefined,
          undefined,
          new PushMessage(data.messageId, data.target)
        );
      }

      if (data.target) {
        const url = new URL(data.target);
        await this.router.navigateByUrl(url.pathname + url.search);
      }
    });
  }

  private async navigateToPushPreferences(): Promise<void> {
    this.siteService.pageContext
      .pipe(
        takeUntil(this.destroy$),
        filter((data) => !!data),
        first()
      )
      .subscribe(async (data) => {
        if (data.pushPreferencesPage) {
          const pushServicePreferences = await this.userService.getPushServicePreferences();
          const pushPromotionPreferences = await this.userService.getPushPromotionPreferences();

          if (!pushServicePreferences?.receiveServicePushMessages && !pushPromotionPreferences?.receivePromotionalPushMessages) {
            // Turn on service push messages by default if the user has given consent in a native permissions dialog.
            if (this.platformHelper.isiOSNative || this.platformHelper.isMinimumAndroidSDKVersion(33)) {
              await this.userService.updatePushServicePreferences({ receiveServicePushMessages: true });
            }

            await this.router.navigate([data?.pushPreferencesPage._url]);
          }
        }
      });
  }
}
