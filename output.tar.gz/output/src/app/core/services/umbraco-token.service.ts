import { Injectable } from '@angular/core';
import { IToken } from '../models/token.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class UmbracoTokenService extends ApiService {
  private previewToken: IToken;

  constructor() {
    super();
  }

  async getPreviewToken(): Promise<IToken> {
    if (!this.previewToken) {
      this.previewToken = await this.httpGet<IToken>({ path: `token/preview` });
    }

    return this.previewToken;
  }
}
