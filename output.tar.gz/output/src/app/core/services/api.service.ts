import { HttpClient } from '@angular/common/http';
import { inject } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IError, IHTTPError, IHttpError, IHttpPostRequest, IHttpRequest } from 'src/app/core/models/http.model';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { environment } from 'src/environments/environment';
import { ErrorHelper } from '../helpers/error.helper';

export abstract class ApiService {
  protected toastService: ToastService;
  protected translateService: TranslateService;
  protected userHelper: UserHelper;
  protected errorHelper: ErrorHelper;
  protected platformHelper: PlatformHelper;

  private http: HttpClient;
  private apiUrl: string;

  constructor() {
    this.http = inject(HttpClient);
    this.toastService = inject(ToastService);
    this.translateService = inject(TranslateService);
    this.userHelper = inject(UserHelper);
    this.errorHelper = inject(ErrorHelper);
    this.platformHelper = inject(PlatformHelper);
    this.apiUrl = environment.apiUrl;
  }

  protected async httpGet<T>(request: IHttpRequest): Promise<T> {
    return await this.handleHttpRequest(request, () => this.http.get<T>(`${this.apiUrl}/${request.path}`, this.requestOptions()));
  }

  protected async httpPost<T>(request: IHttpPostRequest): Promise<T> {
    return await this.handleHttpRequest(request, () =>
      this.http.post<T>(`${this.apiUrl}/${request.path}`, request.body, this.requestOptions())
    );
  }

  protected async httpPut<T>(request: IHttpPostRequest): Promise<T> {
    return await this.handleHttpRequest(request, () =>
      this.http.put<T>(`${this.apiUrl}/${request.path}`, request.body, this.requestOptions())
    );
  }

  protected async httpPatch<T>(request: IHttpPostRequest): Promise<T> {
    return await this.handleHttpRequest(request, () =>
      this.http.patch<T>(`${this.apiUrl}/${request.path}`, request.body, this.requestOptions())
    );
  }

  protected async httpDelete<T>(request: IHttpRequest): Promise<T> {
    /**
     * These `ts-ignore` tags are necessary to pass the payload.
     * Support for sending `DELETE` request with a `body` param was added to Angular in v12.1.0-next2.
     */
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    return await this.handleHttpRequest(request, () =>
      this.http.request<T>('delete', `${this.apiUrl}/${request.path}`, {
        ...this.requestOptions(),
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        body: request.body as unknown
      })
    );
  }

  private requestOptions() {
    return { headers: { ['Content-Type']: 'application/json', ['Client-Version']: this.platformHelper.version } };
  }

  private async handleHttpRequest<T>(request: IHttpRequest, httpRequestAction: () => Observable<T>): Promise<T> {
    const data = await httpRequestAction()
      .toPromise()
      .catch((error: IHttpError | IHTTPError) => {
        if (PlatformHelper.isNativeMobile && error?.error) {
          try {
            error.error = JSON.parse(error.error as string) as IError;
          } catch {}
        }

        this.handleErrorMessage(error as IHttpError, request.suppressErrorCodes, request.suppressAllErrorCodes);
        throw error;
      });

    this.handleSuccessMessage(request.message);

    return data as T;
  }

  private handleSuccessMessage(message?: string): void {
    if (!message) {
      return;
    }

    const toastOptions = new ToastOptions({
      title: this.translateService.instant('general.label.success') as string,
      message,
      type: ToastType.success
    });
    this.toastService.show(toastOptions);
  }

  private handleErrorMessage(error: IHttpError, suppressErrorCodes?: HttpErrorCodes[], suppressAllErrorCodes?: boolean): void {
    const message = this.errorHelper.getErrorMessage(error, suppressErrorCodes, suppressAllErrorCodes);
    if (!message?.length) {
      return;
    }

    const toastOptions = new ToastOptions({
      title: this.translateService.instant('general.label.error') as string,
      message,
      type: ToastType.error,
      id: 'api_error'
    });
    this.toastService.show(toastOptions);
  }
}
