import { Injectable } from '@angular/core';
import { ContentSuggestion, SearchRequest } from 'src/app/features/search/search.model';
import { FileUploadRequest, IFileUpload } from '../models/file.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class ContentService extends ApiService {
  constructor() {
    super();
  }

  async getSuggestions(request: SearchRequest): Promise<ContentSuggestion[]> {
    return await this.httpGet<ContentSuggestion[]>({
      path: `content/suggestions?searchQuery=${encodeURIComponent(request.searchQuery)}&reCaptchaToken=${request.reCaptchaToken}`
    });
  }

  async prepareFileUpload(request: FileUploadRequest): Promise<IFileUpload> {
    return await this.httpPost<IFileUpload>({ path: 'content/files/uploads', body: request });
  }
}
