import { Injectable } from '@angular/core';
import { IDonationOverview, ITransaction, ITransactionOverview } from '../models/transaction.model';
import { ITransferPointsToCharityRequest, TransferPointsFormRequest } from '../models/transfer-points.model';
import { ApiService } from './api.service';
import { BiometricsService } from './biometrics.service';

@Injectable({ providedIn: 'root' })
export class TransactionService extends ApiService {
  constructor(private biometricsService: BiometricsService) {
    super();
  }

  async getTransactionOverview(numberOfTransactions: number): Promise<ITransactionOverview> {
    return await this.httpGet<ITransactionOverview>({
      path: `transactions/overview?numberOfRecentTransactions=${numberOfTransactions}`
    });
  }

  async getTransactions(): Promise<ITransaction[]> {
    return await this.httpGet<ITransaction[]>({
      path: `transactions`
    });
  }

  async expirations(): Promise<ITransaction[] | null> {
    return await this.httpGet<ITransaction[]>({
      path: `transactions/expirations`
    });
  }

  async transferAirmiles(request: TransferPointsFormRequest): Promise<void> {
    return await this.httpPost<void>({ path: 'transactions/transfers', body: request });
  }

  async transferAirmilesToCharity(charityId: string, request: ITransferPointsToCharityRequest): Promise<void> {
    return await this.httpPost<void>({ path: `transactions/charities/${charityId}/donations`, body: request });
  }

  async terminateAccount(): Promise<void> {
    await this.httpDelete<void>({ path: 'users' });
    return await this.biometricsService.reset();
  }

  async getDonationOverview(): Promise<IDonationOverview> {
    const response = await this.httpGet<IDonationOverview>({
      path: `transactions/charities/donations/overview`,
      suppressAllErrorCodes: true
    });
    return response;
  }
}
