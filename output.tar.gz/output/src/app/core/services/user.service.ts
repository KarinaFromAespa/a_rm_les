import { Injectable } from '@angular/core';
import { lastValueFrom, of } from 'rxjs';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import {
  EmailAddressUpdateRequest,
  IEmailVerificationCodeValidationRequest,
  IEmailVerificationRequest,
  IPhoneNumberVerificationCodeValidationRequest,
  IPhoneNumberVerificationRequest,
  IUserAddressFormValues,
  IUserCreateFormValues,
  PhoneNumberUpdateRequest,
  UserAddress,
  UserContactDetails,
  UserCreateRequest,
  UserInboxPreferences,
  UserPersonalizationPreferences,
  UserProfile,
  UserPromotionPreferences,
  UserPushPromotionPreferences,
  UserPushServicePreferences
} from 'src/app/core/models/user.model';
import { IAddressSuggestion, PostalCodeCheckRequest } from 'src/app/features/content-blocks/registration-form/address.model';
import { CardStatusCheckRequest, ICardStatusCheckResponse } from 'src/app/features/content-blocks/registration-form/card-status.model';
import {
  IUserExistenceCheckResponse,
  UserExistenceCheckRequest,
  UserPhoneNumberExistenceCheckRequest
} from 'src/app/features/content-blocks/registration-form/user-existence.model';
import { ShareAccountInvitationRequest } from 'src/app/features/content-blocks/share-account/share-account.model';
import {
  IUserEmailAddress,
  PasswordResetRequest,
  PasswordResetTokenValidationRequest
} from 'src/app/features/password-reset/password-reset.model';
import { PasswordSetCodeValidationRequest, PasswordSetRequest } from 'src/app/features/password-set/password-set.model';
import { UpdatePasswordRequest } from 'src/app/features/personal/personal-details/update-password/update-password.model';
import { UserPasswordResetTokenCreateRequest } from 'src/app/shared/modals/password-reset-modal/password-reset-modal.model';
import { IFileUrl } from '../models/file.response';
import { UpdateUserProfile } from '../models/user.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class UserService extends ApiService {
  constructor() {
    super();
  }

  async createUser(request: UserCreateRequest): Promise<void> {
    return await this.httpPost<void>({ path: 'users', body: request });
  }

  async getUserProfile(): Promise<UserProfile> {
    const profile = await this.httpGet<IUserCreateFormValues>({ path: 'users/profile' });
    return new UserProfile(profile, true);
  }

  async getUserAddress(): Promise<UserAddress> {
    const address = await this.httpGet<IUserAddressFormValues>({ path: 'users/address' });
    return new UserAddress(address);
  }

  async updateUserProfile(request: UpdateUserProfile): Promise<void> {
    return await this.httpPut<void>({ path: 'users/profile', body: request });
  }

  async updateEmailAddress(request: EmailAddressUpdateRequest): Promise<void> {
    return await this.httpPut<void>({ path: 'users/email', body: request });
  }

  async updatePhoneNumber(request: PhoneNumberUpdateRequest): Promise<void> {
    return await this.httpPut<void>({ path: 'users/phone', body: request });
  }

  async getUserContactDetails(): Promise<UserContactDetails> {
    return await this.httpGet<UserContactDetails>({ path: 'users/contact-details' });
  }

  async checkUserExistence(request: UserExistenceCheckRequest): Promise<IUserExistenceCheckResponse> {
    if (request.exclude && request.emailAddress === request.exclude) {
      return lastValueFrom(of({ userExists: false } as IUserExistenceCheckResponse));
    }

    return await this.httpGet<IUserExistenceCheckResponse>({
      path: `users/exists?emailAddress=${encodeURIComponent(request.emailAddress)}&reCaptchaToken=${request.reCaptchaToken}`,
      suppressAllErrorCodes: true
    });
  }

  async checkPhoneNumberExistence(request: UserPhoneNumberExistenceCheckRequest): Promise<IUserExistenceCheckResponse> {
    if (request.exclude && request.phoneNumber === request.exclude) {
      return lastValueFrom(of({ userExists: false } as IUserExistenceCheckResponse));
    }

    return await this.httpGet<IUserExistenceCheckResponse>({
      path: `users/exists?phoneNumber=${encodeURIComponent(request.phoneNumber)}&reCaptchaToken=${request.reCaptchaToken}`,
      suppressAllErrorCodes: true
    });
  }

  async checkCardStatus(request: CardStatusCheckRequest): Promise<ICardStatusCheckResponse> {
    return await this.httpGet<ICardStatusCheckResponse>({
      path: `users/cards/${request.cardNumber}/status?reCaptchaToken=${request.reCaptchaToken}`,
      suppressAllErrorCodes: true
    });
  }

  async createPasswordResetToken(request: UserPasswordResetTokenCreateRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `users/password/token`,
      body: request,
      suppressErrorCodes: [HttpErrorCodes.accountNotFound, HttpErrorCodes.invalidAccount]
    });
  }

  async checkPasswordResetToken(request: PasswordResetTokenValidationRequest): Promise<void> {
    return await this.httpPost<void>({ path: `users/password/token/validation`, body: request });
  }

  async resetPassword(request: PasswordResetRequest): Promise<IUserEmailAddress> {
    return await this.httpPost<IUserEmailAddress>({ path: `users/password`, body: request });
  }

  async updatePassword(request: UpdatePasswordRequest): Promise<IUserEmailAddress> {
    return await this.httpPut<IUserEmailAddress>({ path: `users/password`, body: request });
  }

  async setPassword(request: PasswordSetRequest): Promise<IUserEmailAddress> {
    return await this.httpPost<IUserEmailAddress>({ path: `users/password`, body: request });
  }

  async sendPasswordValidationToken(): Promise<void> {
    return await this.httpPost<void>({ path: `users/password/code`, body: {} });
  }

  async validatePasswordValidationToken(request: PasswordSetCodeValidationRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `users/password/code/validation`,
      body: request,
      suppressErrorCodes: [HttpErrorCodes.invalidPasswordSetVerificationCode]
    });
  }

  async getUserPromotionPreferences(): Promise<UserPromotionPreferences> {
    return await this.httpGet<UserPromotionPreferences>({ path: `users/preferences/promotion` });
  }

  async updateUserPromotionPreferences(request: UserPromotionPreferences): Promise<void> {
    return await this.httpPut<void>({ path: `users/preferences/promotion`, body: request });
  }

  async getUserPersonalizationPreferences(): Promise<UserPersonalizationPreferences> {
    return await this.httpGet<UserPersonalizationPreferences>({ path: `users/preferences/personalization` });
  }

  async updateUserPersonalizationPreferences(request: UserPersonalizationPreferences): Promise<void> {
    return await this.httpPut<void>({ path: `users/preferences/personalization`, body: request });
  }

  async getUserInboxPreferences(): Promise<UserInboxPreferences> {
    return await this.httpGet<UserInboxPreferences>({ path: `users/preferences/inbox` });
  }

  async updateUserInboxPreferences(request: UserInboxPreferences): Promise<void> {
    return await this.httpPut<void>({ path: `users/preferences/inbox`, body: request });
  }

  async sendEmailValidationToken(request: IEmailVerificationRequest): Promise<void> {
    return await this.httpPost({ path: `users/verification-codes/email`, body: request });
  }

  async validateEmailValidationToken(request: IEmailVerificationCodeValidationRequest): Promise<void> {
    return await this.httpPost({
      path: `users/verification-codes/email/validation`,
      body: request,
      suppressErrorCodes: [HttpErrorCodes.invalidVerificationCode]
    });
  }

  async sendPhoneNumberValidationToken(request: IPhoneNumberVerificationRequest): Promise<void> {
    return await this.httpPost({ path: `users/verification-codes/phone`, body: request });
  }

  async validatePhoneNumberValidationToken(request: IPhoneNumberVerificationCodeValidationRequest): Promise<void> {
    return await this.httpPost({
      path: `users/verification-codes/phone/validation`,
      body: request,
      suppressErrorCodes: [HttpErrorCodes.invalidVerificationCode]
    });
  }

  async blockUserCard(): Promise<void> {
    return await this.httpPost<void>({ path: `users/cards`, body: {} });
  }

  async getPushPromotionPreferences(): Promise<UserPushPromotionPreferences> {
    return await this.httpGet<UserPushPromotionPreferences>({ path: `users/preferences/push/promotion` });
  }

  async updatePushPromotionPreferences(request: UserPushPromotionPreferences): Promise<void> {
    return await this.httpPut<void>({ path: `users/preferences/push/promotion`, body: request });
  }

  async getPushServicePreferences(): Promise<UserPushServicePreferences> {
    return await this.httpGet<UserPushServicePreferences>({ path: `users/preferences/push/service` });
  }

  async updatePushServicePreferences(request: UserPushServicePreferences): Promise<void> {
    return await this.httpPut<void>({ path: `users/preferences/push/service`, body: request });
  }

  async sendInvitation(request: ShareAccountInvitationRequest): Promise<void> {
    return await this.httpPost<void>({ path: `users/invitations/send`, body: request });
  }

  async getAddressSuggestion(request: PostalCodeCheckRequest): Promise<IAddressSuggestion> {
    return await this.httpGet<IAddressSuggestion>({
      path: `users/address/suggestion?postalCode=${encodeURIComponent(request.postalCode)}&houseNumber=${
        request.houseNumber
      }&reCaptchaToken=${request.reCaptchaToken}`,
      suppressAllErrorCodes: true
    });
  }

  async getPassbook(): Promise<IFileUrl> {
    return await this.httpGet<IFileUrl>({ path: `users/cards/passbook` });
  }
}
