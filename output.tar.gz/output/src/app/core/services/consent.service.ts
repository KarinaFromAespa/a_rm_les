import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AnimationStates } from 'src/app/core/animations/sheet.animations';

@Injectable({ providedIn: 'root' })
export class ConsentService {
  private readonly consentSheetSubject = new BehaviorSubject<AnimationStates>(AnimationStates.closed);
  readonly onConsentSheetToggle$ = this.consentSheetSubject.asObservable();

  constructor() {}

  open(): void {
    document.body.classList.add('sheet--open');
    this.consentSheetSubject.next(AnimationStates.open);
  }

  close(): void {
    document.body.classList.remove('sheet--open');
    this.consentSheetSubject.next(AnimationStates.closed);
  }
}
