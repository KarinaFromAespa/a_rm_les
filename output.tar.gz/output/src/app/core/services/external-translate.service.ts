import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject } from 'rxjs';
import { SiteConstants } from '../constants/site.constants';
import { IExternalLanguage } from '../models/external-language.model';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';

@Injectable({ providedIn: 'root' })
export class ExternalTranslateService {
  languages$ = new BehaviorSubject<IExternalLanguage[]>([]);
  savedLanguage$ = new BehaviorSubject<string>('nl');
  isForced = false;

  constructor(
    private cookieService: CookieService,
    private capacitorStorageService: CapacitorStorageService
  ) {}

  load(languages: string[] | undefined): void {
    if (!languages?.length) {
      //No languages configured, stop translating
      this.languages$.next([]);
      this.changeLanguage('nl', true);
      return;
    }

    //Load google translate script, if not already loaded
    if (!window['googleTranslateElementInit']) {
      window['googleTranslateElementInit'] = () => {
        new (window as any).google.translate.TranslateElement({ pageLanguage: 'nl', autoDisplay: false }, 'translate-widget');
      };

      const nonce = this.cookieService.get(SiteConstants.nonceCookieName);
      const script = document.createElement('script');
      script.nonce = nonce;
      script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.onload = () => this.handleLanguages(languages);
      document.head.prepend(script);
    } else {
      this.handleLanguages(languages);
    }
  }

  changeLanguage(language: string, force = false, isRepeated = false): void {
    this.setBodyClass(language);

    const select = document.querySelector<HTMLSelectElement>('.goog-te-combo');
    if (select) {
      select.value = language;
      select.dispatchEvent(new Event('change'));
      select.dispatchEvent(new Event('change')); //Fix to make sure the event is captured by Google Translate's script in certain cases
    } else if (!isRepeated) {
      setTimeout(() => this.changeLanguage(language, force, true), 100);
    }

    if (!force && !this.isForced) {
      this.capacitorStorageService.set(SiteConstants.externalTranslateLanguageStorageName, language);
    }
    //A forced language change will cause a new changeLanguage, so save it
    this.isForced = force;
  }

  private handleLanguages(languages: string[]): void {
    if (!languages.includes('nl')) {
      languages = ['nl', ...languages];
    }

    this.languages$.next(languages.map((language) => ({ code: language, name: this.getLanguageName(language) })));
    void this.handleSavedLanguage(languages);
  }

  private getLanguageName(language: string): string {
    const displayNames = new Intl.DisplayNames([language], {
      type: 'language'
    });
    const languageName = displayNames.of(language);
    return languageName ? languageName.charAt(0).toUpperCase() + languageName.slice(1) : '';
  }

  private async handleSavedLanguage(languages: string[]) {
    //Stop translating if saved language is not configured for current page
    const savedLanguage = await this.capacitorStorageService.get<string | null>(SiteConstants.externalTranslateLanguageStorageName);
    if (savedLanguage && !languages.includes(savedLanguage)) {
      this.changeLanguage('nl', true);
      this.savedLanguage$.next('nl');
      return;
    }

    const cookieValue = this.cookieService.get(SiteConstants.googleTranslateCookieName);
    const splittedCookie = cookieValue.split('/');
    const currentLanguage = splittedCookie[splittedCookie.length - 1];

    //Use saved language if it is configured for current page but not currently selected
    if (savedLanguage && savedLanguage !== currentLanguage && languages.includes(savedLanguage)) {
      setTimeout(() => {
        this.changeLanguage(savedLanguage);
        this.savedLanguage$.next(savedLanguage);
      });
      return;
    }

    const language = languages.includes(currentLanguage) ? currentLanguage : 'nl';
    this.setBodyClass(language);
    this.savedLanguage$.next(language);
  }

  private setBodyClass(language: string): void {
    if (language === 'nl') {
      document.body.classList.add('notranslate');
    } else {
      document.body.classList.remove('notranslate');
    }
  }
}
