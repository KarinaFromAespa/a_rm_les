import { Injectable } from '@angular/core';
import { Device } from '@capacitor/device';
import { BasicLoginRequest, PartnerLoginRequest, PasswordLoginRequest, TwoFactorLoginRequest } from 'src/app/core/models/login.request';
import { IPartnerLoginData, IPartnerLoginProfile, IUserBasicLoginData, IUserLoginData } from 'src/app/core/models/login.response';
import {
  TwoFactorAuthenticationToken,
  TwoFactorAuthorizationCodeRequest
} from 'src/app/shared/modals/two-factor-login-modal/two-factor-login-modal.model';
import { HttpErrorCodes } from '../constants/error.constants';
import { PlatformHelper } from '../helpers/platform.helper';
import { ApiService } from './api.service';
import { BiometricsService } from './biometrics.service';
import { PushMessageService } from './push-message.service';
import { XsrfService } from './xsrf.service';

@Injectable({ providedIn: 'root' })
export class TokenService extends ApiService {
  constructor(
    private biometricsService: BiometricsService,
    private xsrfService: XsrfService,
    private pushMessageService: PushMessageService
  ) {
    super();
  }

  async createBasicLoginToken(request: BasicLoginRequest, suppressAllErrorCodes = false): Promise<void> {
    const user = await this.httpPost<IUserBasicLoginData>({
      path: 'token/login/basic',
      body: request,
      suppressAllErrorCodes
    });
    await this.handleLogin(user);
  }

  async createPasswordLoginToken(request: PasswordLoginRequest): Promise<void> {
    const triggerBiometrics = request.triggerBiometrics;
    request.triggerBiometrics = false;

    if (PlatformHelper.isNativeMobile) {
      request.deviceId = (await Device.getId()).identifier;
    }

    const user = await this.httpPost<IUserLoginData>({ path: 'token/login/password', body: request });
    await this.handleLogin(user);

    if (!triggerBiometrics) {
      return;
    }

    void (async () => {
      await this.biometricsService.resetOnUserChange(user.memberId);

      if (request.emailAddress.toLowerCase() === user.emailAddress.toLowerCase()) {
        await this.biometricsService.setPasswordLogin(user.memberId, request);
      }
    })();
  }

  async createTwoFactorLoginToken(request: TwoFactorLoginRequest): Promise<void> {
    const triggerBiometrics = request.triggerBiometrics;
    request.triggerBiometrics = false;

    const user = await this.httpPost<IUserLoginData>({
      path: 'token/login/2fa',
      body: request,
      suppressErrorCodes: [HttpErrorCodes.forbidden]
    });
    await this.handleLogin(user);

    if (triggerBiometrics) {
      void this.biometricsService.setTwoFactorLogin(user.memberId, request, this.createTwoFactorAuthenticationToken.bind(this));
    }
  }

  async createTwoFactorAuthenticationCode(request: TwoFactorAuthorizationCodeRequest): Promise<void> {
    return await this.httpPost<void>({ path: `token/login/2fa/code`, body: request });
  }

  async createTwoFactorAuthenticationToken(): Promise<TwoFactorAuthenticationToken> {
    return await this.httpPost<TwoFactorAuthenticationToken>({ path: `token/login/2fa/token`, body: {} });
  }

  async getPartnerProfile(profileName: string): Promise<IPartnerLoginProfile> {
    return this.httpGet<IPartnerLoginProfile>({ path: `token/login/partner/profile/${encodeURIComponent(profileName)}` });
  }

  async createPartnerLoginToken(request: PartnerLoginRequest): Promise<IPartnerLoginData> {
    return this.httpPost<IPartnerLoginData>({ path: 'token/login/partner', body: request, suppressAllErrorCodes: true });
  }

  async logout(): Promise<void> {
    await this.httpDelete<void>({ path: 'token/login' });
    await this.userHelper.setCurrentUser(undefined);
    await this.pushMessageService.unregisterDevice();
  }

  private async handleLogin(user: IUserBasicLoginData): Promise<void> {
    await this.userHelper.setCurrentUser(user);
    await this.xsrfService.setClientCookie();
  }
}
