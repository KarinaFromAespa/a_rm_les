import { Inject, Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { SiteConstants, WINDOW_TOKEN } from 'src/app/core/constants/site.constants';
import { SiteService } from './site.service';

declare global {
  interface Window {
    COOSTO_WEBCHAT_OPTIONS: unknown;
  }
}

@Injectable({ providedIn: 'root' })
export class ChatService {
  private chatScriptBlockId = 'coostoChat';

  constructor(
    @Inject(WINDOW_TOKEN) private window: Window,
    private siteService: SiteService,
    private cookieService: CookieService
  ) {}

  load(): void {
    const coostoAppId = this.siteService.siteSettings.coostoAppId;
    const coostoWelcomeMessage = this.siteService.siteSettings.coostoWelcomeMessage;
    if (!coostoAppId?.length || !coostoWelcomeMessage?.length || document.getElementById(this.chatScriptBlockId) != null) {
      return;
    }

    this.window.COOSTO_WEBCHAT_OPTIONS = {
      appId: coostoAppId,
      companyName: 'Air Miles klantenservice',
      companyLogo: '/assets/images/logo/logo_air-miles.png',
      welcomeMessage: {
        default: {
          'nl-NL': coostoWelcomeMessage
        }
      },
      locale: 'nl-NL',
      customerRole: 'airmiles',
      autoOpen: 'never',
      keepOpen: true,
      launcher: 'always'
    };

    const nonce = this.cookieService.get(SiteConstants.nonceCookieName);
    const script = document.createElement('script');
    script.id = this.chatScriptBlockId;
    script.nonce = nonce;
    script.src = '/assets/js/coosto.js';
    document.head.prepend(script);
  }
}
