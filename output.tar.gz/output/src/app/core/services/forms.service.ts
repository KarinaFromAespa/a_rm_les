import { Injectable } from '@angular/core';
import { ContactFormRequest, PublicContactFormRequest } from '../models/contact-form.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class FormsService extends ApiService {
  constructor() {
    super();
  }

  async contact(values: ContactFormRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `forms/contact`,
      body: values
    });
  }

  async publicContact(values: PublicContactFormRequest): Promise<void> {
    return await this.httpPost<void>({
      path: `forms/contact/public`,
      body: values
    });
  }
}
