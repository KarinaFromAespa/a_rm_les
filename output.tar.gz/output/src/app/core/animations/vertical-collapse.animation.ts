import { animate, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from './animation.constants';

export const verticalCollapseAnimation = trigger('verticalCollapse', [
  state(
    '*',
    style({
      height: '*'
    })
  ),
  state(
    'void',
    style({
      height: '0'
    })
  ),
  transition('* => void', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);
