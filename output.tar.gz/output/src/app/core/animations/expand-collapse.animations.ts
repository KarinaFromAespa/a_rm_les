import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from './animation.constants';

export class AnimationStates {
  public static expanded = 'true';
  public static collapsed = 'false';
}

export const animationExpandCollapse = trigger('expanded', [
  state(AnimationStates.expanded, style({ height: AUTO_STYLE, visibility: AUTO_STYLE, marginBottom: '0.5rem' })),
  state(AnimationStates.collapsed, style({ height: 0, visibility: 'hidden' })),
  transition('true => false', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)),
  transition('false => true', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);
