export default class AnimationConstants {
  public static baseDuration = 350;
  public static baseDelay = 600;
  public static baseEasing = 'cubic-bezier(.25, 0, 0, 1)';
}
