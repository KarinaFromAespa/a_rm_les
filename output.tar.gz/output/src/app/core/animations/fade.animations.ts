import { animate, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from './animation.constants';

export const animationFadeInOut = trigger('fadeInOut', [
  state(
    '*',
    style({
      opacity: 1
    })
  ),
  state(
    'void',
    style({
      opacity: 0
    })
  ),
  transition('void => *', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)),
  transition('* => void', animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`))
]);
