import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import AnimationConstants from './animation.constants';

export class AnimationStates {
  public static closed = 'closed';
  public static open = 'open';
}

export const animationSheetUp = trigger('sheetUp', [
  state(AnimationStates.closed, style({ transform: 'translateY(100%)', opacity: 0, display: 'none' })),
  state(AnimationStates.open, style({ transform: 'translateY(0%)', opacity: 1 })),
  transition('void => *', [style({ transform: 'translateY(100%)' })], {
    delay: AnimationConstants.baseDelay
  }),
  transition('open <=> closed', [animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)])
]);

export const animationSheetDown = trigger('sheetDown', [
  state(AnimationStates.closed, style({ transform: 'translateY(-100%)' })),
  state(AnimationStates.open, style({ transform: 'translateY(0%)' })),
  transition('void => *', [style({ transform: 'translateY(-100%)' })], {
    delay: AnimationConstants.baseDelay
  }),
  transition('open <=> closed', [animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)])
]);

export const animationSheetCollapse = trigger('sheetCollapse', [
  state(AnimationStates.closed, style({ height: 0 })),
  state(AnimationStates.open, style({ height: AUTO_STYLE })),
  transition('void => *', [style({ height: 0 })], {
    delay: AnimationConstants.baseDelay
  }),
  transition('open <=> closed', [animate(`${AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`)])
]);
