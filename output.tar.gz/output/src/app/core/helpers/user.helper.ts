import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { SiteConstants } from 'src/app/core/constants/site.constants';
import { IUserBasicLoginData, IUserLoginData } from 'src/app/core/models/login.response';
import { AuthorizationLevel } from '../constants/user.constants';
import { UserProfile } from '../models/user.model';
import { BiometricsCredentialsService } from '../services/biometrics-credentials.service';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';
import { DateHelper } from './date.helper';

@Injectable({ providedIn: 'root' })
export class UserHelper {
  currentUser: IUserBasicLoginData | IUserLoginData | undefined = undefined;

  private readonly currentUserSubject = new BehaviorSubject<IUserBasicLoginData | IUserLoginData | undefined>(undefined);
  readonly currentUser$ = this.currentUserSubject.asObservable();

  private readonly isLoggedInBehaviorSubject = new BehaviorSubject<boolean>(false);
  readonly isLoggedIn$ = this.isLoggedInBehaviorSubject.asObservable();

  private readonly isLoggedInEmitter = new EventEmitter<AuthorizationLevel | null>();
  readonly isLoggedInChanged$ = this.isLoggedInEmitter.asObservable();

  readonly profileCompleted$ = new Subject<void>();

  get isLoggedIn(): boolean {
    return this.isLoggedInBehaviorSubject.getValue() && !this.isExpired();
  }

  get canTransferPoints(): boolean {
    return !!this.currentUser?.balance && !!(this.currentUser as IUserLoginData)?.canTransferPoints;
  }

  get currentAuthorizationLevel(): AuthorizationLevel | null {
    return this.currentUser?.authorizationLevel ?? null;
  }

  get requiresPasswordLogin(): boolean {
    return (
      !this.isLoggedIn ||
      (this.currentAuthorizationLevel !== AuthorizationLevel.twoFactor && this.currentAuthorizationLevel !== AuthorizationLevel.password)
    );
  }

  get emailAddress(): string | undefined {
    return (this.currentUser as IUserLoginData)?.emailAddress ?? undefined;
  }

  get isAccessTokenAlmostExpired(): boolean {
    return this.currentUser?.accessTokenExpireDate ? DateHelper.isAlmostExpired(this.currentUser.accessTokenExpireDate) : false;
  }

  constructor(
    private biometricsCredentialsService: BiometricsCredentialsService,
    private storageService: CapacitorStorageService
  ) {
    void this.init();
  }

  async setCurrentUser(user?: IUserBasicLoginData): Promise<void> {
    if (user) {
      if (
        (this.currentUser as IUserLoginData)?.emailAddress?.length &&
        (user as IUserLoginData)?.emailAddress?.length &&
        (this.currentUser as IUserLoginData).emailAddress !== (user as IUserLoginData).emailAddress
      ) {
        await this.biometricsCredentialsService.updateCredentials(user.memberId, (user as IUserLoginData).emailAddress);
      }

      await this.storageService.set(SiteConstants.userStorageName, user);
    } else {
      await this.storageService.delete(SiteConstants.userStorageName);
    }

    this.currentUser = user;
    this.setCurrentLoggedInStatus();
    this.currentUserSubject.next(this.currentUser);
  }

  async updateCurrentUser(profile: UserProfile): Promise<void> {
    if (!this.currentUser && !profile?.emailAddress?.length) {
      return;
    }

    const user = { ...this.currentUser } as IUserLoginData;
    if (user.emailAddress === profile.emailAddress && user.firstName === profile.firstName && user.lastName === profile.lastName) {
      return;
    }

    user.emailAddress = profile.emailAddress;
    user.firstName = profile.firstName;
    user.lastName = profile.lastName;

    await this.setCurrentUser(user);
  }

  async updateBalance(balance: number): Promise<void> {
    if (!this.currentUser) {
      return;
    }
    const user = { ...this.currentUser } as IUserLoginData;
    user.balance = balance;
    await this.setCurrentUser(user);
  }

  isUserLoggedIn(): boolean {
    return !!this.currentUser?.memberId?.length && !this.isExpired();
  }

  setCurrentLoggedInStatus(): void {
    const currentLoggedInStatus = this.isUserLoggedIn() && !this.isExpired();

    this.isLoggedInBehaviorSubject.next(currentLoggedInStatus);
    this.isLoggedInEmitter.emit(currentLoggedInStatus && this.currentUser ? this.currentUser.authorizationLevel : null);
  }

  private isExpired(): boolean {
    return this.currentUser && this.currentUser.refreshTokenExpireDate
      ? DateHelper.isExpired(this.currentUser.refreshTokenExpireDate)
      : false;
  }

  private async init(): Promise<void> {
    this.currentUser = await this.storageService.get<IUserBasicLoginData>(SiteConstants.userStorageName);
    this.currentUserSubject.next(this.currentUser);
    this.setCurrentLoggedInStatus();
  }
}
