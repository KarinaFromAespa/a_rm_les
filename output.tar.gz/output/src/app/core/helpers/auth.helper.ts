import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { UserHelper } from 'src/app/core/helpers/user.helper';

@Injectable({ providedIn: 'root' })
export class AuthHelper {
  constructor(
    private readonly userHelper: UserHelper,
    private router: Router
  ) {}

  canActivate(): boolean {
    if (this.userHelper.isLoggedIn) {
      return true;
    }

    void this.router.navigateByUrl('/');
    return false;
  }
}
