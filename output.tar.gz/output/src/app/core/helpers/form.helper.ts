import { AbstractControl, ValidationErrors } from '@angular/forms';
import { IFormValidator } from '../models/form.model';
import { FormValidatorTypeKeys } from '../constants/form.constants';
import { FormValidatorType } from '../models/form-validator.model';
import { isObservable, lastValueFrom } from 'rxjs';

export class FormHelper {
  static getErrorMessages(formControl: AbstractControl | null, controlValidators: IFormValidator[], filter?: string[]): string[] {
    const errorMessages: string[] = [];
    for (const item in formControl?.errors) {
      if (!filter || filter.indexOf(item) > -1) {
        const validatorError = controlValidators.find((x: IFormValidator) => x.validator.getKey() === item);
        if (validatorError) {
          const message = validatorError?.errorMessage;
          if (message) {
            errorMessages.push(message);
          }

          continue;
        }

        const wrapperValidatorError = controlValidators.find((x: IFormValidator) => x.validator.getKey() === FormValidatorTypeKeys.wrapper);
        if (wrapperValidatorError) {
          const message = wrapperValidatorError.errorMessages?.[item];
          if (message) {
            errorMessages.push(message);
          }
        }
      }
    }

    return errorMessages;
  }

  static getHtmlErrorMessages(
    formControl: AbstractControl | null,
    controlValidators: IFormValidator[],
    filter?: string[]
  ): { withHtml: string[]; withoutHtml: string[] } {
    const checkForHtmlTags = /<\/?[a-z][\s\S]*>/i;
    const errorMessages = FormHelper.getErrorMessages(formControl, controlValidators, filter);

    return errorMessages.reduce(
      (result, errorMessage) => {
        if (checkForHtmlTags.test(errorMessage)) {
          result.withHtml.push(errorMessage);
        } else {
          result.withoutHtml.push(errorMessage);
        }
        return result;
      },
      { withHtml: [] as string[], withoutHtml: [] as string[] }
    );
  }

  static wrapValidators(validators: FormValidatorType[]) {
    return async (control: AbstractControl): Promise<ValidationErrors | null> => {
      const result: ValidationErrors = {};
      validators.map(async (v) => {
        const response = v.getValidator()(control);
        let errors: ValidationErrors;

        if (isObservable(response)) {
          errors = (await lastValueFrom(response)) as ValidationErrors;
        } else if (!!response && typeof response.then === 'function') {
          errors = (await response) as ValidationErrors;
        } else {
          errors = response as ValidationErrors;
        }

        Object.assign(result, errors);
        control.setErrors(Object.keys(result).length ? result : null);
      });

      return Object.keys(result).length ? result : null;
    };
  }
}
