export const setCanonicalLink = (canonicalUrl: string) => {
  const existingCanonicalLink = document.head.querySelector('link[rel="canonical"]');

  if (existingCanonicalLink) {
    existingCanonicalLink.setAttribute('href', canonicalUrl);
  } else {
    const newCanonicalLink = window.document.createElement('link');
    newCanonicalLink.setAttribute('rel', 'canonical');
    newCanonicalLink.setAttribute('href', canonicalUrl);
    newCanonicalLink.setAttribute('href', canonicalUrl);
    document.head.appendChild(newCanonicalLink);
  }
};

export const removeCanonicalLink = () => {
  const existingCanonicalLink = document.head.querySelector('link[rel="canonical"]');
  existingCanonicalLink?.remove();
};
