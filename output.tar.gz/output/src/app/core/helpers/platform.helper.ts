import { PlatformLocation } from '@angular/common';
import { Inject, Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AppVersion } from '@awesome-cordova-plugins/app-version/ngx';
import { Capacitor } from '@capacitor/core';
import { Device } from '@capacitor/device';
import { Network } from '@capacitor/network';
import { Platform } from '@ionic/angular';
import { BehaviorSubject, fromEvent, merge, of } from 'rxjs';
import { distinctUntilChanged, mapTo } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { NAVIGATOR_TOKEN, WINDOW_TOKEN } from '../constants/site.constants';

@Injectable({ providedIn: 'root' })
export class PlatformHelper {
  private nativeVersion: string;
  private androidSDKVersion?: number;
  private readonly onlineStateSubject = new BehaviorSubject<boolean>(false);
  readonly onlineState$ = this.onlineStateSubject.asObservable();

  static get isNativeMobile(): boolean {
    return Capacitor.isNativePlatform();
  }

  get isMobile(): boolean {
    // Includes mobile browser
    return this.platform.is('mobile');
  }

  get isiOSMobile(): boolean {
    return this.platform.is('ios') && !this.platform.is('ipad');
  }

  get isAndroidMobile(): boolean {
    return this.platform.is('android');
  }

  get isiOSNative(): boolean {
    return PlatformHelper.isNativeMobile && this.platform.is('ios');
  }

  get isAndroidNative(): boolean {
    return PlatformHelper.isNativeMobile && this.isAndroidMobile;
  }

  get isOnline(): boolean {
    return this.onlineStateSubject.getValue();
  }

  get platformString(): string {
    return this.platform.platforms().join(' ');
  }

  get version(): string {
    return this.nativeVersion ? `${this.nativeVersion} - ${environment.clientVersion}` : environment.clientVersion;
  }

  set onlineState(value: boolean) {
    this.onlineStateSubject.next(value);
  }

  constructor(
    @Inject(WINDOW_TOKEN) private window: Window,
    @Inject(NAVIGATOR_TOKEN) private navigator: Navigator,
    private platform: Platform,
    private platformLocation: PlatformLocation,
    private appVersion: AppVersion,
    private router: Router,
    private ngZone: NgZone
  ) {
    if (PlatformHelper.isNativeMobile) {
      void this.appVersion.getVersionNumber().then((version) => {
        this.nativeVersion = version;
      });

      void this.platform.ready().then(() => {
        void Network.addListener('networkStatusChange', (status) => {
          this.ngZone.run(() => {
            this.onlineStateSubject.next(status.connected);
          });
        });

        void Device.getInfo().then((info) => {
          this.androidSDKVersion = info.androidSDKVersion;
        });
      });
    } else {
      merge(
        of(this.navigator.onLine),
        fromEvent(this.window, 'online').pipe(mapTo(true)),
        fromEvent(this.window, 'offline').pipe(mapTo(false))
      )
        .pipe(distinctUntilChanged())
        .subscribe((isOnline) => {
          this.onlineStateSubject.next(isOnline);
        });
    }
  }

  getCurrentAbsoluteUrl(): string {
    return `${this.getCurrentAbsoluteBaseUrl()}${this.router.url}`;
  }

  getCurrentAbsoluteBaseUrl(): string {
    return `https://${this.platformLocation.hostname}${this.platformLocation.port ? ':' + this.platformLocation.port : ''}`;
  }

  isMinimumAndroidSDKVersion(version: number): boolean {
    return !!this.androidSDKVersion && this.androidSDKVersion >= version;
  }
}
