import { IUserBasicLoginData } from '../models/login.response';

export class UrlHelper {
  static isExternalLink(url = ''): boolean {
    return (url.indexOf('http') > -1 && url.indexOf(location.hostname) === -1) || url.startsWith('tel:') || url.startsWith('mailto:');
  }

  static trimLeadingSlash(url: string): string {
    return url.startsWith('/') && url.length > 1 ? url.slice(1) : url;
  }

  static trimTrailingSlash(url: string): string {
    return url.endsWith('/') && url.length > 1 ? url.slice(0, -1) : url;
  }

  static insertUserProperties(url: string, user?: IUserBasicLoginData): string {
    if (!user) {
      return url;
    }

    return url?.replace('{encryptedMemberId}', user.memberId).replace('{memberId}', user.memberId);
  }
}
