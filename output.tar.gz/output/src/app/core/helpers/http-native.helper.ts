import { HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HTTP } from '@awesome-cordova-plugins/http/ngx';
import { Platform } from '@ionic/angular';

@Injectable({ providedIn: 'root' })
export class HttpNativeHelper {
  constructor(
    private platform: Platform,
    private httpNative: HTTP
  ) {}

  async handleRequest(request: HttpRequest<any>): Promise<HttpResponse<unknown>> {
    const headerKeys = request.headers.keys();
    const headers: Record<string, string> = {};

    headerKeys.forEach((key) => {
      const header = request.headers.get(key);
      if (header) {
        headers[key] = header;
      }
    });

    try {
      await this.platform.ready();

      const method = request.method.toLowerCase() as
        | 'get'
        | 'post'
        | 'put'
        | 'patch'
        | 'head'
        | 'delete'
        | 'options'
        | 'upload'
        | 'download';

      const nativeHttpResponse = await this.httpNative.sendRequest(request.url, {
        method,
        data: request.body,
        headers,
        serializer: 'json'
      });

      let body: unknown;

      try {
        body = JSON.parse(nativeHttpResponse.data as string);
      } catch {
        body = { response: nativeHttpResponse.data as unknown };
      }

      const response = new HttpResponse({
        body,
        status: nativeHttpResponse.status,
        headers: new HttpHeaders(nativeHttpResponse.headers),
        url: nativeHttpResponse.url
      });

      return Promise.resolve(response);
    } catch (error: unknown) {
      return Promise.reject(error);
    }
  }
}

// https://manuel-heidrich.dev/blog/an-elegant-way-to-handle-native-http-requests-with-cordova-advanced-http-in-an-ionic-app/
