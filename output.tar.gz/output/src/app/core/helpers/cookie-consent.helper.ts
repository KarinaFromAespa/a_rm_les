import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { SiteConstants } from '../constants/site.constants';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';

@Injectable({ providedIn: 'root' })
export class CookieConsentHelper {
  private readonly cookieConsentValue = new Subject<boolean>();
  cookieConsentValue$: Observable<boolean> = this.cookieConsentValue.asObservable();

  constructor(private storageService: CapacitorStorageService) {}

  async allCookiesAccepted(): Promise<boolean> {
    return (await this.getCookieConsentValue()) ? true : false;
  }

  async functionalCookiesAccepted(): Promise<boolean> {
    return (await this.getCookieConsentValue()) != null ? true : false;
  }

  async setCookieConsentValue(value: boolean): Promise<void> {
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    await this.storageService.set(SiteConstants.consentCookieName, JSON.stringify(value));
    this.cookieConsentValue.next(value);
  }

  async getCookieConsentValue(): Promise<boolean> {
    const value = await this.storageService.get(SiteConstants.consentCookieName);
    return JSON.parse(value as string) as boolean;
  }
}
