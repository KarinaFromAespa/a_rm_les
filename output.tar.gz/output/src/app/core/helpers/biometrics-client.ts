import { Injectable } from '@angular/core';
import { AvailableResult, BiometricOptions, Credentials, IsAvailableOptions, NativeBiometric } from 'capacitor-native-biometric';

@Injectable({ providedIn: 'root' })
export class BiometricsClient {
  isAvailable(options?: IsAvailableOptions): Promise<AvailableResult> {
    return NativeBiometric.isAvailable(options);
  }

  verifyIdentity(options?: BiometricOptions): Promise<any> {
    return NativeBiometric.verifyIdentity(options);
  }

  async getCredentials(type: BiometricsRequestType, server: string): Promise<Credentials | null> {
    const credentials = await NativeBiometric.getCredentials({ server }).catch(() => null);
    if (!credentials?.password?.length) {
      return null;
    }

    switch (type) {
      case BiometricsRequestType.password:
        credentials.username = credentials.username.split(':')?.[1];
        credentials.password = credentials.password.split(':')?.[0];
        break;
      case BiometricsRequestType.twoFactor:
        credentials.username = '';
        credentials.password = credentials.password.split(':')?.[1];
        break;
    }

    return credentials?.password?.length ? credentials : null;
  }

  async getMemberId(server: string): Promise<string | null> {
    const credentials = await NativeBiometric.getCredentials({ server }).catch(() => null);
    return credentials?.username?.split(':')?.[0] ?? null;
  }

  async setCredentials(
    type: BiometricsRequestType,
    server: string,
    memberId: string,
    username: string | null,
    password: string
  ): Promise<void> {
    let credentials = await NativeBiometric.getCredentials({ server }).catch(() => null);
    if (!credentials) {
      credentials = { username: '', password: '' };
    } else {
      // Clear to prevent iOS key chain issues
      await this.deleteCredentials(server);
    }

    const id = credentials.username?.split(':')?.[0];
    const keepPreviousCredentials = !id?.length || id === memberId;

    switch (type) {
      case BiometricsRequestType.password: {
        credentials.username = `${memberId ?? ''}:${username ?? ''}`;
        credentials.password = `${password ?? ''}:${(keepPreviousCredentials ? credentials.password?.split(':')?.[1] : '') ?? ''}`;
        break;
      }
      case BiometricsRequestType.twoFactor:
        credentials.username = `${memberId ?? ''}:${(keepPreviousCredentials ? credentials.username?.split(':')?.[1] : '') ?? ''}`;
        credentials.password = `${(keepPreviousCredentials ? credentials.password?.split(':')?.[0] : '') ?? ''}:${password ?? ''}`;
        break;
    }

    await NativeBiometric.setCredentials({ server, username: credentials.username, password: credentials.password }).catch(() => null);
  }

  async deleteCredentials(server: string): Promise<void> {
    await NativeBiometric.deleteCredentials({ server }).catch(() => null);
  }
}

export enum BiometricsRequestType {
  password = 'Password',
  twoFactor = 'TwoFactor'
}
