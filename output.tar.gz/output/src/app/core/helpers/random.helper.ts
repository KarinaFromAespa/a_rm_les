export class RandomHelper {
  static generateRandomId(): string {
    return crypto.getRandomValues(new Uint32Array(5)).toString().replaceAll(',', '-');
  }
}
