import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SiteConstants } from '../constants/site.constants';
import { PromotionService } from '../services/promotion.service';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';

@Injectable({ providedIn: 'root' })
export class PromotionHelper {
  unactivatedPromotionsCount$ = new BehaviorSubject<number>(0);

  constructor(
    private promotionService: PromotionService,
    private storageService: CapacitorStorageService
  ) {
    void this.init();
  }

  async refreshUnactivatedPromotionsCounter(): Promise<void> {
    const result = await this.promotionService.getUnactivatedPromotionsCount();
    if (result?.numberOfUnactivatedPromotions == null) {
      return;
    }

    await this.storageService.set(SiteConstants.promotionCountStorageName, result.numberOfUnactivatedPromotions);
    this.unactivatedPromotionsCount$.next(result.numberOfUnactivatedPromotions);
  }

  clear(): void {
    this.unactivatedPromotionsCount$.next(0);
  }

  private async init(): Promise<void> {
    const numberOfUnactivatedPromotions = await this.storageService.get<number>(SiteConstants.promotionCountStorageName);
    this.unactivatedPromotionsCount$.next(numberOfUnactivatedPromotions);
  }
}
