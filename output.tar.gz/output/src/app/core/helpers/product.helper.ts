import { ProductType } from '../constants/product.constants';
import {
  IBaseProduct,
  ICombinedProduct,
  IExternalProduct,
  IImportedProduct,
  IPhysicalProduct,
  IProduct,
  IProductCategory,
  IProductCost,
  IProductSubcategory
} from '../models/product.model';
import { ObjectHelper } from './object.helper';

export class ProductHelper {
  static getCategoriesNames(categories: IProductCategory | IProductCategory[]): string[] {
    const unifiedCategories = ObjectHelper.wrapFieldToArray(categories);

    return unifiedCategories.map((cat) => cat.name?.toLowerCase()).filterEmpty();
  }

  static getSubcategoriesNames(categories: IProductSubcategory | IProductSubcategory[]): string[] {
    const unifiedCategories = ObjectHelper.wrapFieldToArray(categories);

    return unifiedCategories.map((cat) => cat.title?.toLowerCase()).filterEmpty();
  }

  static isExternalProduct(product: IBaseProduct): boolean {
    return product && product.contentTypeAlias === ProductType.externalProduct;
  }
  static isCombinedProduct(product: IBaseProduct): boolean {
    return product && product.contentTypeAlias === ProductType.combinedProduct;
  }
  static isPhysicalProduct(product: IBaseProduct): boolean {
    return product && product.contentTypeAlias === ProductType.physicalProduct;
  }
  static isProduct(product: IBaseProduct): boolean {
    return product && product.contentTypeAlias === ProductType.product;
  }
  static isCharity(product: IBaseProduct): boolean {
    return product && product.contentTypeAlias === ProductType.charity;
  }
  static isProductCard(product: IBaseProduct): boolean {
    return product && (product.contentTypeAlias === ProductType.card || product.contentTypeAlias === ProductType.importedCard);
  }

  static getSupplierCode(product: IBaseProduct): string | null {
    return (
      ((product as IProduct).importedProduct?.supplierCode ||
        (product as IExternalProduct).supplierCode ||
        (product as ICombinedProduct).variants?.find((x) => x !== undefined)?.importedProduct?.supplierCode) ??
      null
    );
  }

  static getLowestCostForProduct(product: IBaseProduct): IProductCost {
    switch (product.contentTypeAlias) {
      case ProductType.product:
        return {
          points: (product as IProduct).importedProduct?.points,
          price: (product as IProduct).importedProduct?.price
        };

      case ProductType.combinedProduct:
        return ProductHelper.getLowestCostForCombinedProduct(product as ICombinedProduct);

      case ProductType.externalProduct:
        return {
          points: (product as IExternalProduct).points,
          price: (product as IExternalProduct).price
        };

      case ProductType.physicalProduct:
        return ProductHelper.getLowestCostForPhysicalProduct(product as IPhysicalProduct);

      default:
        return { price: 0, points: 0 };
    }
  }

  static getLowestCostForCombinedProduct(product: ICombinedProduct): IProductCost {
    if (!product.variants || product.variants.length === 0) {
      return { price: 0, points: 0 };
    }

    const lowestPointsVariant = [...product.variants].sort((a, b) => a.importedProduct.points - b.importedProduct.points)[0];

    return {
      points: lowestPointsVariant?.importedProduct.points ?? 0,
      price: lowestPointsVariant?.importedProduct.price ?? 0
    };
  }

  static getLowestCostForPhysicalProduct(product: IPhysicalProduct): IProductCost {
    if (!product.variants || product.variants.length === 0) {
      return { price: 0, points: 0 };
    }

    const lowestPointsVariant = [...product.variants].sort((a, b) => a.points - b.points)[0];

    return {
      points: lowestPointsVariant?.points ?? 0,
      price: lowestPointsVariant?.price ?? 0
    };
  }

  static isAvailable(product: IBaseProduct): boolean {
    switch (product?.contentTypeAlias) {
      case ProductType.product:
        return !!(product as IProduct).importedProduct?.isInStock;

      case ProductType.combinedProduct:
        return !!(product as ICombinedProduct).variants?.some((variant) => variant.importedProduct.isInStock);

      case ProductType.externalProduct:
      case ProductType.charity:
      case ProductType.card:
      case ProductType.importedCard:
      case ProductType.physicalProduct:
        return true;

      default:
        return false;
    }
  }

  static isMilesOnly(product: IImportedProduct): boolean {
    return product.points > 0 && product.price === 0;
  }

  static splitMilesOnlyProducts(products: IBaseProduct[]): IBaseProduct[] {
    products.forEach((x) => {
      const product = x as ICombinedProduct;
      if (
        product.contentTypeAlias !== ProductType.physicalProduct &&
        product.variants &&
        product.variants.length >= 2 &&
        product.variants.some((x) => ProductHelper.isMilesOnly(x.importedProduct)) &&
        product.variants.some((x) => !ProductHelper.isMilesOnly(x.importedProduct))
      ) {
        const splitProduct = ObjectHelper.deepCopy(product) as ICombinedProduct;
        //Remove all variants that are not miles only
        splitProduct.variants = splitProduct.variants!.filter((x) => ProductHelper.isMilesOnly(x.importedProduct));

        //Remove all variants that are miles only
        product.variants = product.variants.filter((x) => !ProductHelper.isMilesOnly(x.importedProduct));

        products.push(splitProduct);
      }
    });

    return products;
  }

  static preprocessProducts(productsData: IBaseProduct[]): IBaseProduct[] {
    const products = ObjectHelper.deepCopy(productsData) as IBaseProduct[];
    products.forEach((product) => {
      //Add primary image to physical products
      if (product.contentTypeAlias === ProductType.physicalProduct) {
        product.primaryImage = { _url: (product as IPhysicalProduct).primaryImageUrl ?? '' };
      }
    });
    return products;
  }
}
