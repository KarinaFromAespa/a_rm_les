import orderBy from 'lodash-es/orderBy';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { ProductType } from '../constants/product.constants';
import { IPartner } from '../models/partner.response';
import { IBaseProduct, IProduct } from '../models/product.model';

export enum SortOrder {
  asc = 'asc',
  desc = 'desc'
}

export class SorterHelper {
  static sortProductsByMostRecommended(products: IBaseProduct[]): IBaseProduct[] {
    return orderBy(
      products,
      [
        'priority',
        'title',
        (product: IBaseProduct) => {
          return ProductHelper.getLowestCostForProduct(product).price;
        }
      ],
      SortOrder.desc
    );
  }

  static sortProductsByMiles(products: IBaseProduct[], sortOrder: SortOrder): IBaseProduct[] {
    return orderBy(
      products,
      [
        (result: IProduct) => {
          if (result.contentTypeAlias === ProductType.charity) {
            return Number.MAX_SAFE_INTEGER;
          }
          return ProductHelper.getLowestCostForProduct(result).points;
        }
      ],
      sortOrder
    ) as IProduct[];
  }

  static sortProductsByRecentDate(products: IBaseProduct[]): IBaseProduct[] {
    return orderBy(products, [(result: IBaseProduct) => new Date(result.updateDate).getTime()], SortOrder.desc);
  }

  static sortPartnersByMostRecommended(partners: IPartner[]): IPartner[] {
    return orderBy(partners, ['priority'], SortOrder.desc);
  }

  static sortPartnersByNameAscending(partners: IPartner[]): IPartner[] {
    return orderBy(partners, [(result: IPartner) => result.title.toLowerCase()], SortOrder.asc);
  }
}
