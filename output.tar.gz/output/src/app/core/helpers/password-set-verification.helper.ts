import { Injectable } from '@angular/core';
import { ModalHelper } from 'src/app/features/modal/modal.helper';
import { PasswordSetCodeValidationRequest } from 'src/app/features/password-set/password-set.model';
import {
  IPasswordVerificationModal,
  IPasswordVerificationRequest
} from 'src/app/shared/modals/password-verification-modal/password-verification-modal.model';
import { UserService } from '../services/user.service';

@Injectable({ providedIn: 'root' })
export class PasswordSetVerificationHelper {
  constructor(
    private userService: UserService,
    private modalHelper: ModalHelper
  ) {}

  private async sendCode(): Promise<void> {
    await this.userService.sendPasswordValidationToken();
  }

  private async verifyCode(verificationCode: string): Promise<void> {
    const request = {
      code: verificationCode
    } as PasswordSetCodeValidationRequest;

    await this.userService.validatePasswordValidationToken(request);
  }

  async triggerVerificationModal(request: IPasswordVerificationRequest): Promise<void> {
    const verificationModal = {
      verificationText: request.verificationText,
      sendCode: this.sendCode.bind(this) as () => Promise<void>,
      verifyAction: this.verifyCode.bind(this) as () => Promise<void>,
      verifyCallback: request.verifyCallback.bind(this) as () => Promise<void>,
      userEventSource: request.userEventSource
    } as IPasswordVerificationModal;

    return this.modalHelper.triggerPasswordVerificationModal(verificationModal, request.closeCallback);
  }
}
