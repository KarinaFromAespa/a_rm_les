export class DateHelper {
  static toNullableDate(value?: Date): Date | undefined {
    if (
      !value ||
      value.toString() === '0001-01-01T00:00:00' ||
      value.toString() === '0001-01-01T00:00:00Z' ||
      value.toString() === '9999-12-31T23:59:59' ||
      value.toString() === '9999-12-31T23:59:59Z'
    ) {
      return undefined;
    }

    return value;
  }

  static remainingDays(endDate: Date): number {
    const currentDate = new Date();
    endDate = new Date(endDate);

    if (endDate < currentDate) {
      return 0;
    }

    const milliseconds = endDate.valueOf() - currentDate.valueOf();
    return Math.ceil(milliseconds / (1000 * 3600 * 24));
  }

  static isAlmostExpired(expireDate: Date): boolean {
    // Expired is true when the expire date is within 5 minutes from now
    return this.isExpired(new Date(expireDate.valueOf() - 300000));
  }

  static isExpired(expireDate: Date): boolean {
    const currentDate = new Date();
    expireDate = new Date(expireDate);

    return expireDate.valueOf() - currentDate.valueOf() <= 0;
  }
}
