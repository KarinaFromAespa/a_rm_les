import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { ModalHelper } from 'src/app/features/modal/modal.helper';
import { IConfirmationModal } from 'src/app/shared/modals/confirmation-modal/confirmation-modal.model';
import {
  IVerificationInitializeRequest,
  IVerificationModal,
  IVerificationRequest,
  VerificationCodeMessageType
} from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { IText, IVerifyContentBlock } from '../models/content.model';
import { ReCaptchaAction } from '../models/reCaptcha.request';
import {
  IEmailVerificationCodeValidationRequest,
  IEmailVerificationRequest,
  IPhoneNumberVerificationCodeValidationRequest
} from '../models/user.model';
import { ReCaptchaService } from '../services/re-captcha.service';
import { UserService } from '../services/user.service';
import { ObjectHelper } from './object.helper';

@Injectable({ providedIn: 'root' })
export class VerificationHelper {
  readonly emailAddressVerificationCode$ = new Subject<string>();
  readonly phoneNumberVerificationCode$ = new Subject<string>();

  verifiedEmailAddress?: string;
  verifiedPhoneNumber?: string;

  private userEventSource: string;
  private content: IVerifyContentBlock;
  private request: IVerificationRequest;

  constructor(
    private userService: UserService,
    private translateService: TranslateService,
    private reCaptchaService: ReCaptchaService,
    private modalHelper: ModalHelper
  ) {}

  initialize(request: IVerificationInitializeRequest): void {
    this.userEventSource = request.userEventSource;
    this.content = request.content;
  }

  patchValues(emailAddress: string, phoneNumber?: string, isPhoneNumberVerified?: boolean): void {
    this.verifiedEmailAddress = emailAddress;
    this.verifiedPhoneNumber = isPhoneNumberVerified ? phoneNumber : undefined;
  }

  async triggerVerificationModal(request: IVerificationRequest): Promise<void> {
    this.request = request;

    let formattedVerificationText: IText | undefined;
    if (request.verifyType === VerificationCodeMessageType.email && this.content.emailVerificationText) {
      formattedVerificationText = ObjectHelper.deepCopy(this.content.emailVerificationText) as IText;
      formattedVerificationText.body = formattedVerificationText.body?.format([request.emailAddress ?? '']);
    } else if (this.content.phoneVerificationText) {
      formattedVerificationText = ObjectHelper.deepCopy(this.content.phoneVerificationText) as IText;
      formattedVerificationText.body = formattedVerificationText.body?.format([request.phoneNumber ?? '']);
    }

    const verificationModal = {
      text: formattedVerificationText,
      alternateReCaptchaText: this.content.emailVerificationFallbackText,
      verificationCodeMessageType: request.verifyType,
      verifyButtonText: this.translateService.instant('account.label.verify') as string,
      sendCodeAction: this.sendCode.bind(this) as () => Promise<void>,
      verifyAction: this.verifyCode.bind(this) as () => Promise<void>,
      verifyCallback: (request.keepOpenAfterVerify
        ? this.triggerEmailAddressSuccessModal.bind(this)
        : request.verifyCallback.bind(this)) as () => Promise<void>,
      keepOpenAfterVerify: request.keepOpenAfterVerify,
      userEventSource: this.userEventSource
    } as IVerificationModal;

    return this.modalHelper.triggerVerificationModal(verificationModal, request.closeCallback);
  }

  private async sendCode(): Promise<void> {
    if (this.request.verifyType === VerificationCodeMessageType.email) {
      const request: IEmailVerificationRequest = { emailAddress: this.request.emailAddress ?? '', reCaptchaToken: '' };
      await this.reCaptchaService.verify(
        ReCaptchaAction.sendEmailAddressVerificationCode,
        request,
        this.userService.sendEmailValidationToken.bind(this.userService)
      );
    } else {
      await this.userService.sendPhoneNumberValidationToken({ phoneNumber: this.request.phoneNumber ?? '' });
    }
  }

  private async verifyCode(verificationCode: string): Promise<void> {
    if (this.request.verifyType === VerificationCodeMessageType.email) {
      const request = {
        verificationCode,
        emailAddress: this.request.emailAddress
      } as IEmailVerificationCodeValidationRequest;
      await this.reCaptchaService.verify(
        ReCaptchaAction.emailAddressVerificationCodeValidation,
        request,
        this.userService.validateEmailValidationToken.bind(this.userService)
      );
      this.emailAddressVerificationCode$.next(verificationCode);
    } else {
      await this.userService.validatePhoneNumberValidationToken({
        verificationCode,
        phoneNumber: this.request.phoneNumber
      } as IPhoneNumberVerificationCodeValidationRequest);
      this.phoneNumberVerificationCode$.next(verificationCode);
    }
  }

  private async triggerEmailAddressSuccessModal(): Promise<void> {
    return this.modalHelper.triggerConfirmationModal(
      {
        text: this.content.emailVerificationSuccess,
        action: () => this.triggerAfterSuccessModal(VerificationCodeMessageType.sms),
        confirmText: this.translateService.instant('general.label.next') as string,
        hideCancelButton: true,
        userEventSource: this.userEventSource,
        userEventSourceTopic: 'email'
      } as IConfirmationModal,
      this.request.closeCallback
    );
  }

  private async triggerAfterSuccessModal(type: VerificationCodeMessageType): Promise<void> {
    const request = { ...this.request };
    request.verifyType = type;
    request.keepOpenAfterVerify = false;

    return this.triggerVerificationModal(request);
  }
}
