export class ObjectHelper {
  // Check whether all property values are equal
  static isEqual(a: object, b: object): boolean {
    const aProps = Object.getOwnPropertyNames(a);
    const bProps = Object.getOwnPropertyNames(b);

    if (aProps.length !== bProps.length) {
      return false;
    }

    for (const prop of aProps) {
      if (a[prop] !== b[prop]) {
        if (a[prop] instanceof Date && b[prop] instanceof Date && (a[prop] as Date).getTime() === (b[prop] as Date).getTime()) {
          continue;
        }
        return false;
      }
    }

    return true;
  }

  static deepCopy(obj: unknown): unknown {
    return JSON.parse(JSON.stringify(obj));
  }

  static wrapFieldToArray<T>(field: T | T[]): T[] {
    if (field === null || field === void 0) {
      return [];
    }

    return Array.isArray(field) ? field : [field];
  }

  static wrapArrayToField<T>(array?: T[]): T | undefined {
    return Array.isArray(array) ? array?.[0] : array;
  }
}
