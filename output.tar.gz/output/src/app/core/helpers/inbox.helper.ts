import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SiteConstants } from '../constants/site.constants';
import { InboxService } from '../services/inbox.service';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';

@Injectable({ providedIn: 'root' })
export class InboxHelper {
  unreadInboxCount$ = new BehaviorSubject<number>(0);

  constructor(
    private inboxService: InboxService,
    private storageService: CapacitorStorageService
  ) {
    void this.init();
  }

  async refreshUnreadInboxCount(): Promise<void> {
    const result = await this.inboxService.getUnreadCount();
    if (result?.numberOfUnreadInboxMessages == null) {
      return;
    }

    await this.storageService.set(SiteConstants.unreadInboxCountStorageName, result.numberOfUnreadInboxMessages);
    this.unreadInboxCount$.next(result.numberOfUnreadInboxMessages);
  }

  clear(): void {
    this.unreadInboxCount$.next(0);
  }

  private async init(): Promise<void> {
    const unreadInboxFromStorage = await this.storageService.get<number>(SiteConstants.unreadInboxCountStorageName);
    this.unreadInboxCount$.next(unreadInboxFromStorage);
  }
}
