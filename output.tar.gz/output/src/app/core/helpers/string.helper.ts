export class StringHelper {
  static toKebabCase(text: string): string {
    return text
      .replace(/[^\w\d\s_]/g, '')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .replace(/[\s_]+/g, '-')
      .toLowerCase();
  }

  static convertCamelCaseToSpaces(text: string): string {
    return text
      .replace(/([A-Z])/g, ' $1')
      .toLowerCase()
      .trim();
  }

  static toDate(text?: string): Date | undefined {
    const dateParts = text?.split('-');
    // Try to convert to date
    if (!dateParts || dateParts.length !== 3) {
      return undefined;
    }

    return new Date(Date.UTC(+dateParts[2], +dateParts[1] - 1, +dateParts[0]));
  }

  static firstToLower(text?: string): string {
    if (!text?.length) {
      return '';
    }
    return `${text[0].toLowerCase()}${text.length > 1 ? text.substr(1) : ''}`;
  }

  static convertPositiveInteger(value: string): number {
    const parsedInt = parseInt(value, 10);
    return parsedInt >= 0 ? parsedInt : 0;
  }

  static isEmpty(text: string): boolean {
    return !text || text === '';
  }
}
