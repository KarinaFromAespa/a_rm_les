import { PageType } from '../constants/page.constants';
import { IPageResponse } from '../models/page.response';

export class PageHelper {
  static stripUrl(url: string): string {
    // Strip urls from query parameters and anchors
    const strippedUrl = url?.split('#')[0].split('?')[0];
    return strippedUrl;
  }

  static isAuthorizedPage(page: IPageResponse): boolean {
    return (
      page?.contentTypeAlias === PageType.personalPageBasic ||
      page.contentTypeAlias === PageType.personalPagePassword ||
      page.contentTypeAlias === PageType.personalPageTwoFactor ||
      page.contentTypeAlias === PageType.campaignPage
    );
  }
}
