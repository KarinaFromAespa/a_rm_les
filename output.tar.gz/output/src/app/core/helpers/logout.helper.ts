import { Injectable } from '@angular/core';
import { SiteConstants } from '../constants/site.constants';
import { BiometricsService } from '../services/biometrics.service';
import { SiteService } from '../services/site.service';
import { TokenService } from '../services/token.service';
import { CapacitorStorageService } from '../storage/capacitor-storage.service';
import { InboxHelper } from './inbox.helper';
import { PromotionHelper } from './promotion.helper';

@Injectable({ providedIn: 'root' })
export class LogoutHelper {
  constructor(
    private tokenService: TokenService,
    private siteService: SiteService,
    private biometricsService: BiometricsService,
    private storageService: CapacitorStorageService,
    private inboxHelper: InboxHelper,
    private promotionHelper: PromotionHelper
  ) {}

  async logout(): Promise<void> {
    //Clear token
    await this.tokenService.logout();

    //Clear biometrics when enabled
    if (!this.siteService.siteSettings.preserveBiometrics) {
      void this.biometricsService.reset();
    }

    //Clear storage
    const keys = await this.storageService.keys();
    keys.forEach((key) => {
      //Preserve biometrics and cookie consent
      if (
        key === SiteConstants.biometricsPreferencesStorageName ||
        key === SiteConstants.biometricsCancelCountStorageName ||
        key === SiteConstants.consentCookieName
      ) {
        return;
      }

      void this.storageService.delete(key);
    });

    //Clear memory
    this.inboxHelper.clear();
    this.promotionHelper.clear();
  }
}
