import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ERROR_CODES_WITH_MESSAGES, HttpErrorCodes, SUPPRESS_ERROR_CODE_MESSAGES } from '../constants/error.constants';
import { IHttpError } from '../models/http.model';

@Injectable({ providedIn: 'root' })
export class ErrorHelper {
  constructor(private translateService: TranslateService) {}

  getErrorMessage(error: IHttpError, suppressErrorCodes?: HttpErrorCodes[], suppressAllErrorCodes?: boolean): string | null {
    const errorCode = error?.error?.code
      ? SUPPRESS_ERROR_CODE_MESSAGES.includes(error.error.code)
        ? false
        : error.error.code
      : ERROR_CODES_WITH_MESSAGES.includes(error?.status)
        ? error.status.toString()
        : 'default';

    if (!errorCode || suppressAllErrorCodes || suppressErrorCodes?.find((x) => x === errorCode)) {
      return null;
    }

    return this.translateService.instant(`http.error.${errorCode}`) as string;
  }
}
