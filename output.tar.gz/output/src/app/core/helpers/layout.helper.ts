export const scrollIntoViewIfNeeded = (target: HTMLElement) => {
  if (target.getBoundingClientRect().bottom > window.innerHeight) {
    target.scrollIntoView({ behavior: 'smooth' });
  }

  if (target.getBoundingClientRect().top < 0) {
    target.scrollIntoView({ behavior: 'smooth' });
  }
};
