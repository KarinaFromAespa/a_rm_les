export interface IReCaptchaRequest {
  reCaptchaToken: string;
  alternateReCaptchaToken?: string;
}

export enum ReCaptchaAction {
  createUser = 'CreateUser',
  createPasswordLoginToken = 'CreatePasswordLoginToken',
  createTwoFactorLoginToken = 'CreateTwoFactorLoginToken',
  sendPasswordResetToken = 'SendPasswordResetToken',
  resetPasswordTokenValidation = 'ResetPasswordTokenValidation',
  resetPassword = 'ResetPassword',
  checkCardStatus = 'CheckCardStatus',
  checkUserExistence = 'CheckUserExistence',
  sendPublicContactForm = 'SendPublicContactForm',
  getContentSuggestions = 'GetContentSuggestions',
  activateRegistrationCampaign = 'ActivateRegistrationCampaign',
  createCampaignUser = 'CreateCampaignUser',
  createLightCampaignUser = 'CreateLightCampaignUser',
  getAddressSuggestion = 'GetAddressSuggestion',
  sendEmailAddressVerificationCode = 'SendEmailAddressVerificationCode',
  sendPasswordVerificationCode = 'SendPasswordResetCode',
  emailAddressVerificationCodeValidation = 'EmailAddressVerificationCodeValidation',
  prepareFileUpload = 'PrepareFileUpload'
}
