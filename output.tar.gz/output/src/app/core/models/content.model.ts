import { BookingWidgetType } from '../constants/booking-widget.constants';
import { OrganizationType } from '../constants/organization.constants';
import { ICustomCard } from './custom-card.model';
import { IContentPageResponse } from './page.response';
import { IBaseProduct, IDonationSuggestions, IProductCategory, IProductSubcategory } from './product.model';
import { ICampaign } from './promotion.model';
import { IReferralRegistrationSettings } from './referral-registration.model';
import { RegistrationStepSection } from './registration.model';
import { IImage, IPage, IPageLink } from './site.response';

export enum ContentBlockType {
  text = 'text',
  actionList = 'actionList',
  cardList = 'cardList',
  formattedText = 'formattedText',
  captionedImage = 'captionedImage',
  textList = 'textList',
  partnerLogos = 'partnerLogos',
  highlightedProducts = 'highlightedProducts',
  productOverview = 'productOverview',
  registrationForm = 'registrationForm',
  campaignRegistration = 'campaignRegistration',
  passwordReset = 'passwordReset',
  dashboardOverview = 'dashboardOverview',
  updateProfile = 'updateProfile',
  updatePassword = 'updatePassword',
  updatePromotionPreferences = 'updatePromotionPreferences',
  updatePersonalizationPreferences = 'updatePersonalizationPreferences',
  updateInboxPreferences = 'updateInboxPreferences',
  updatePushPromotionPreferences = 'updatePushPromotionPreferences',
  updatePushServicePreferences = 'updatePushServicePreferences',
  updateBiometricsPreferences = 'updateBiometricsPreferences',
  vouchers = 'vouchers',
  expirations = 'expirations',
  highlightedPromotions = 'highlightedPromotions',
  transactions = 'transactions',
  login = 'login',
  partnerLogin = 'partnerLogin',
  passwordToken = 'passwordToken',
  contactForm = 'contactForm',
  transferPoints = 'transferPoints',
  terminateAccount = 'terminateAccount',
  organizationLogos = 'organizationLogos',
  blockCard = 'blockCard',
  personalData = 'personalData',
  featuredProducts = 'featuredProducts',
  shareAccount = 'shareAccount',
  video = 'video',
  bookingWidget = 'bookingWidget',
  playableWidget = 'playableWidget',
  donationCounter = 'donationCounter',
  banner = 'banner',
  setPassword = 'setPassword',
  shareReferralLink = 'shareReferralLink',
  referralRewards = 'referralRewards',
  inbox = 'inbox',
  typeform = 'typeform'
}

export enum ContentBlockRegion {
  primary = 'primary',
  secondary = 'secondary',
  highlighted = 'highlighted',
  partnerPrimary = 'partnerPrimary'
}

export enum Channel {
  web = 'Web',
  app = 'App'
}

export interface IContentBlock {
  contentTypeAlias: string;
  componentName?: string;
  channels?: Channel[];
}

export interface IText extends IContentBlock {
  title: string;
  body: string;
}

export interface IColor {
  color: string;
  label: string;
}

export interface IFormattedText extends IText {
  alignedImage: IAlignedImage | IAlignedImage[];
  links: IPageLink[];
  emphasizeLinks: boolean;
}

export interface IImageBlock extends IContentBlock {
  caption?: string;
  image: IImage;
}

export enum Alignment {
  before = 'Before',
  after = 'After'
}

export interface ITitleDescriptionContentBlock extends IContentBlock {
  title: string;
  description: string;
}

export interface IAlignedImage {
  image: IImage;
  alignment: string;
}

export interface ITextList extends IContentBlock {
  title?: string;
  texts: ITextListText[];
  enableFeedback: boolean;
  feedbackSuccessText: IText[];
}

export interface ITextListText extends IContentBlock {
  title: string;
  body: string;
}

export interface ICardList extends IContentBlock {
  title: string;
  cards: IImageCard[];
  link: IPageLink[];
  includeNumbers: boolean;
}

export interface IActionList extends IContentBlock {
  title: string;
  actions: IActionCard[];
  link: IPageLink[];
  includeNumbers: boolean;
}

export interface IImageCard extends ITitleDescriptionContentBlock {
  image: IImage;
}

export interface IActionCard extends Omit<ITitleDescriptionContentBlock, 'description'> {
  description?: string;
  image: IImage;
  link: IPageLink | IPageLink[];
}

export interface ICard extends Omit<IImageCard, 'description'>, Omit<IActionCard, 'link'> {
  link?: IPageLink | IPageLink[];
}

export interface IHighlightedProducts extends IContentBlock {
  title?: string;
  numberOfProducts: number;
  productOverviewPage?: IContentPageResponse | IContentPageResponse[];
  supplierCode?: string;
}

export interface IFeaturedProducts extends IContentBlock {
  title?: string;
  products: (IBaseProduct | ICustomCard)[];
}

export interface IProductOverview extends IContentBlock {
  title?: string;
  category?: IProductCategory;
  subcategory?: IProductSubcategory;
  isSpotlighted: boolean;
}

export interface IBaseRegistrationForm extends IContentBlock, IVerifyContentBlock {
  newsletterBenefitsText: IText[];
  newsletterApproval: string;
  terms: string;
  dataNotice: string;
  links: IPageLink[];
  origin: string;
  emailVerificationNotice?: string;
  emailVerificationFallbackText?: IText;
  referralNotice?: string;
  addressInvalidNotice: string;
  steps?: IRegistrationStep[];
}

export interface IRegistrationStep {
  sections: RegistrationStepSection[];
  stepText?: IText[];
}

export interface IRegistrationForm extends IBaseRegistrationForm {
  successPage: IPage;
}

export interface IRedirectForm extends IContentBlock {
  successPage: IPage;
}

export interface ILogin extends IRedirectForm {
  completeProfilePage?: IPage;
}

export interface IPartnerLogin extends IContentBlock {
  profileName: string;
  loginUsernameNotice?: string;
  partnerNotice?: string;
  twoFactorVerification?: IText[];
  color?: IColor;
}

export interface IFormContentBlock extends IContentBlock {
  title: string;
  successText?: IText;
  successPage?: IPage;
  triggerValidation?: boolean;
}

export interface IUpdateProfileContentBlock extends IVerifyContentBlock {
  title: string;
  triggerValidation?: boolean;
  emailVerificationNotice?: string;
  phoneVerificationNotice?: string;
  addressChangeNotice: string;
  addressChangeDateNotice?: string;
  addressInvalidNotice: string;
  successText?: IText;
}

export interface IDashboardOverview extends IContentBlock {
  numberOfTransactions: number;
  transactionsPage?: IPage;
  expirationsPage?: IPage;
  inboxPage?: IPage;
}

export interface IHighlightedPromotions extends IContentBlock {
  title?: string;
  numberOfPromotions: number;
}

export interface IBlockCard extends IContentBlock {
  title?: string;
  description: string;
  confirmationText?: IText;
  successPage?: IPage;
}

export interface IHighlightedPromotion {
  id: string;
  title: string;
  image: IImage;
  points?: number;
  validTo?: Date;
  alternativeTarget?: IPageLink[];
  isActivated: boolean;
  requiresActivation: boolean;
  priority: number;
  url: string;
}

export interface IHighlightedCampaign extends ICampaign {
  isActivated: boolean;
  url: string;
  individualEndDate?: Date;
}

export interface IContactForm extends IContentBlock {
  title: string;
  category: string;
  includeBirthDate: boolean;
  includeAddress: boolean;
  includeCardNumber: boolean;
  successPage: IPage;
}

export interface ITransferPoints extends ITitleDescriptionContentBlock {
  alternateDescription: string;
  donationSuggestions: IDonationSuggestions[];
  confirmationText: IText;
  successText: IText;
}

export interface ITerminateAccount extends ITitleDescriptionContentBlock {
  confirmationText: IText;
  successPage: IPage;
  transferDescription: string;
}

export interface IShareAccount extends IContentBlock {
  title: string;
  description: string;
  incompleteAccount: IText;
  sentInvitationText: IText;
  receivedInvitationText: IText;
  cancelledInvitationText: IText;
  stopText: IText;
  acceptConfirmationText: IText;
  stopConfirmationText: IText;
  invitationSuccessText: IText;
  acceptSuccessText: IText;
  rejectSuccessText: IText;
  cancelSuccessText: IText;
  stopSuccessText: IText;
}

export interface IOrganizationOverview extends IContentBlock {
  title: string;
  organizationTypes?: OrganizationType[];
}

export interface IPartnerLogos extends IContentBlock {
  title?: string;
}

export interface IUserActionContentBlock extends IFormContentBlock {
  title: string;
  description: string;
}

export interface IPersonalData extends ITitleDescriptionContentBlock {
  requestSuccessText: IText;
}

export interface ITransactions extends IContentBlock {
  title: string;
  numberOfTransactions: number;
}
export interface IPurchasedVouchers extends IContentBlock {
  numberOfOrders: number;
  generationSuccessText: IText;
  generationConfirmationText: IText;
  emptyState: IActionText;
}

export interface IExpirations extends ITitleDescriptionContentBlock {
  numberOfExpirations: number;
}

export interface IActionText {
  title?: string;
  body: string;
  link: IPageLink | IPageLink[];
}

export interface IVerifyContentBlock extends IContentBlock {
  emailVerificationText?: IText;
  phoneVerificationText?: IText;
  emailVerificationSuccess?: IText;
  emailVerificationFallbackText?: IText;
}

export interface IVideo extends IContentBlock {
  videoUrl: string;
  caption: string;
}

export interface IBookingWidget extends IContentBlock {
  affiliateId: string;
  widgetId: string;
  type: BookingWidgetType;
  settings: string[];
}

export interface IPlayableWidget extends IContentBlock {
  widgetHash: string;
  desktopHeight?: number;
  mobileHeight?: number;
}

export interface IDonationCounter extends IContentBlock {
  title: string;
  description: string;
  link?: IPageLink[];
}

export interface IBanner extends IContentBlock {
  title: string;
  subtitle: string;
  link?: IPageLink[];
  body: string;
  image: IImage;
}

export interface IReferralRewards extends IContentBlock {
  title: string;
  description?: string;
  referralRegistrationSettings: IReferralRegistrationSettings;
  shareLinkPage?: IPage;
}

export interface IShareReferralLink extends IContentBlock {
  title: string;
  description?: string;
  referralRegistrationSettings: IReferralRegistrationSettings;
  messageTitle?: string;
  messageDescription?: string;
  successText?: IText;
}

export interface IInbox extends IContentBlock {
  title: string;
  deleteConfirmationText: IText;
  deleteSuccessText: IText;
  disabledDescription: string;
}

export interface ITypeform extends IContentBlock {
  formId: string;
}
