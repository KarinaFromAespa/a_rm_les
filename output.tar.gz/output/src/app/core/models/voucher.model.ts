export interface IOrderVouchers {
  partnerName: string;
  showGenerateLink: boolean;
  vouchers: IVoucher[];
}

export interface IVoucher {
  voucherCode: string;
  description: string;
  validity?: string;
  expired?: boolean;
  downloadUrl: string;
}

export class VoucherDeliveryRequest {
  constructor(voucherCodes: string[]) {
    this.voucherCodes = voucherCodes;
  }

  voucherCodes: string[];
}
