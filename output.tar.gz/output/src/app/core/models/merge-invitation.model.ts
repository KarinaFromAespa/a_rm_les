export enum MergeInvitationStatus {
  pending,
  accepted,
  rejected,
  cancelled
}

export enum InvitationBlockType {
  sent,
  received,
  stop,
  cancelled
}

export interface IInvitationBlock {
  invitationId: string;
  isLoading: boolean;
}

export interface IMergeInvitationFormValues {
  emailAddress: string;
  cardNumber: string;
}

export class SentMergeInvitation {
  constructor(invitationId: string, memberEmailAddress: string) {
    this.invitationId = invitationId;
    this.invitedEmailAddress = memberEmailAddress;
  }

  invitationId: string;
  invitedEmailAddress: string;
}

export class ReceivedMergeInvitation {
  invitationId: string;
  senderEmailAddress: string;
  isCancelled: boolean;
}

export class MergeInvitationStatusRequest {
  constructor(status: MergeInvitationStatus) {
    this.status = status;
  }

  status: MergeInvitationStatus;
}

export class MergeInvitationRequest {
  constructor(values: IMergeInvitationFormValues) {
    this.invitedEmailAddress = values.emailAddress;
    this.invitedCardNumber = values.cardNumber;
  }

  invitedEmailAddress: string;
  invitedCardNumber: string;
}
