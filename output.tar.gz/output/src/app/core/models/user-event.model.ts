import { FormType } from '../constants/form.constants';
import { ProductType } from '../constants/product.constants';
import { ProductHelper } from '../helpers/product.helper';
import { StringHelper } from '../helpers/string.helper';
import { IHighlightedPromotion } from './content.model';
import { ICustomCard } from './custom-card.model';
import { IFormControl } from './form.model';
import { IInboxMessage } from './inbox-message.model';
import { IBaseProduct, ICharity, ICombinedProduct, IProduct } from './product.model';
import { IPage } from './site.response';

export abstract class CommerceBaseItem {
  id?: string;
  title: string;
  type: string;
  points?: number;
  price?: number;
  supplierCode?: string;
  category?: string;
  subcategory?: string;
  imageUrl: string;
  shortDescription?: string;

  constructor(product?: IBaseProduct | ICustomCard, promotion?: IHighlightedPromotion, getLowestCost?: boolean) {
    if (product) {
      this.id = product._id ?? product.id;
      this.title = product.title;
      this.type = StringHelper.convertCamelCaseToSpaces(product.contentTypeAlias);

      if (product.contentTypeAlias === 'customCard') {
        this.points = product.points;
        this.imageUrl = product.image.url ?? product.image._url;
      } else {
        this.category = product.category?.title;
        this.subcategory = product.subcategory?.title;
        this.imageUrl = product.primaryImage.url ?? product.primaryImage._url;
        this.shortDescription = product.shortDescription;

        if (product.contentTypeAlias !== ProductType.charity && getLowestCost) {
          const productCost = ProductHelper.getLowestCostForProduct(product);
          this.points = productCost.points;
          this.price = productCost.price;
        }

        if (product.contentTypeAlias === ProductType.product) {
          this.supplierCode = (product as IProduct).importedProduct?.supplierCode;
        }

        if (product.contentTypeAlias === ProductType.combinedProduct) {
          this.supplierCode = (product as ICombinedProduct).variants?.find((x) => x)?.importedProduct?.supplierCode;
        }
      }
    }

    if (promotion) {
      this.id = promotion.id;
      this.title = promotion.title;
      this.type = 'campaign';
      this.points = promotion.points;
      this.imageUrl = promotion.image.url ?? promotion.image._url;
    }
  }
}

export class CommerceHighlight extends CommerceBaseItem {
  position: number;

  constructor(position: number, product?: IBaseProduct | ICustomCard, promotion?: IHighlightedPromotion) {
    super(product, promotion, true);
    this.position = position;
  }
}

export class CommerceItem extends CommerceBaseItem {
  quantity?: number;
  available: boolean;
  variant?: string;

  constructor(product: IProduct | ICombinedProduct | ICharity, amount: number, variantId?: string) {
    super(product);

    switch (product.contentTypeAlias) {
      case ProductType.charity:
        this.points = amount;
        this.available = true;
        break;
      case ProductType.product: {
        const castedProduct = product as IProduct;
        this.quantity = amount;
        this.points = castedProduct.importedProduct?.points;
        this.price = castedProduct.importedProduct?.price;
        this.available = !!castedProduct.importedProduct?.isInStock;
        break;
      }
      case ProductType.combinedProduct: {
        const productVariant = (product as ICombinedProduct).variants?.find((v) => v.importedProduct?.productId === variantId);
        this.quantity = amount;
        this.points = productVariant?.importedProduct?.points;
        this.price = productVariant?.importedProduct?.price;
        this.available = !!productVariant?.importedProduct?.isInStock;
        this.variant = variantId;
        break;
      }
    }
  }
}

export class CommerceOrder {
  items: CommerceItem[];

  constructor(items: CommerceItem[]) {
    this.items = items ?? [];
  }
}

export class CommerceOrderPair {
  previous: CommerceOrder;
  current: CommerceOrder;

  constructor(previous: CommerceOrder, current: CommerceOrder) {
    this.previous = previous;
    this.current = current;
  }

  get changedItems(): CommerceItem[] {
    return this.current.items
      .map((i) => {
        const previousItem = this.previous.items.find((j) => j.id === i.id && j.variant === i.variant);
        const result = Object.assign(Object.create(Object.getPrototypeOf(i)) as CommerceItem, i);
        result.quantity = i.quantity && previousItem?.quantity ? i.quantity - previousItem.quantity : undefined;
        return result;
      })
      .filter((i) => i.quantity !== 0);
  }
}

export class FormInput {
  name: string;
  label?: string;
  value?: string | number | boolean;

  constructor(control: IFormControl, value?: string | number) {
    this.name = control.name;
    this.label = control.label;
    this.value = value;

    if (control.type === FormType.checkbox && this.value === '') {
      this.value = false;
    }
  }
}

export class PageHighlight {
  title?: string;
  url?: string;
  position: number;

  constructor(position: number, page: IPage) {
    this.title = page.title;
    this.url = page.url;
    this.position = position;
  }
}

export class InboxMessage {
  id: number;
  subject: string;
  read: boolean;
  position?: number;

  constructor(message: IInboxMessage, position?: number) {
    this.id = message.id;
    this.subject = message.subject;
    this.read = message.isRead;
    this.position = position;
  }
}

export class PushMessage {
  id: number;
  target?: string;

  constructor(id: number, target?: string) {
    this.id = id;
    this.target = target;
  }
}
