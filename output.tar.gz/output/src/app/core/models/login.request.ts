import { PlatformHelper } from '../helpers/platform.helper';
import { IReCaptchaRequest } from './reCaptcha.request';

export class BasicLoginRequest {
  constructor(memberId: string) {
    this.memberId = memberId;
    this.clientType = PlatformHelper.isNativeMobile ? ClientType.app : ClientType.web;
  }

  memberId: string;
  clientType: ClientType;
}

export class PasswordLoginRequest implements IReCaptchaRequest {
  constructor(emailAddress: string, password: string, triggerBiometrics = true) {
    this.emailAddress = emailAddress;
    this.password = password;
    this.clientType = PlatformHelper.isNativeMobile ? ClientType.app : ClientType.web;

    this.triggerBiometrics = triggerBiometrics;
  }

  emailAddress: string;
  password: string;
  clientType: ClientType;
  reCaptchaToken: string;
  deviceId?: string;

  triggerBiometrics: boolean;
}

export class TwoFactorLoginRequest implements IReCaptchaRequest {
  constructor(refreshToken?: string, authenticationCode?: string, authenticationToken?: string, triggerBiometrics = true) {
    this.refreshToken = refreshToken;
    this.authenticationCode = authenticationCode;
    this.authenticationToken = authenticationToken;

    this.triggerBiometrics = triggerBiometrics;
  }

  refreshToken?: string;
  authenticationCode?: string;
  authenticationToken?: string;
  reCaptchaToken: string;

  triggerBiometrics: boolean;
}

export class PartnerLoginRequest {
  constructor(profileName: string, userId: string) {
    this.profileName = profileName;
    this.userId = userId;
  }

  profileName: string;
  userId: string;
}

export enum ClientType {
  web = 0,
  app = 1
}
