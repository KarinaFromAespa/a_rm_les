export interface ITransferPointsFormValues {
  emailAddress: string;
  cardNumber: string;
  points: number;
}

export class TransferPointsFormRequest {
  constructor(values: ITransferPointsFormValues) {
    this.receiverEmailAddress = values.emailAddress;
    this.receiverCardNumber = values.cardNumber;
    this.points = values.points;
  }

  receiverEmailAddress: string;
  receiverCardNumber: string;
  points: number;
}

export interface ITransferPointsToCharityRequest {
  points: number;
}
