import { ObjectHelper } from '../helpers/object.helper';
import { Channel, IColor, IText } from './content.model';
import { ICharity } from './product.model';

export enum TriggerType {
  login = 'Login',
  consent = 'Consent',
  cards = 'Cards'
}

export enum LinkType {
  pageLink = 'pageLink',
  externalLink = 'externalLink',
  trigger = 'trigger'
}

export interface ILink {
  contentTypeAlias: string;
  linkSections?: ILinkSection[];
  links: IPageLink[];
  channels?: Channel[];
}

export interface ILinkSection {
  contentTypeAlias: string;
  linkLists: ILink[];
  title: string;
  icon?: string;
}

export interface IPage {
  id?: string;
  ancestors?: {
    items: IPage[];
  };
  contentTypeAlias: string;
  title?: string;
  name?: string;
  parentId?: string;
  sortOrder?: number;
  _url: string;
  url?: string;
  mobileMessage?: string;
  seoDescription?: string;
}

export interface IPageLink {
  contentTypeAlias: string;
  icon?: string;
  label: string;
  url?: string;
  page?: IPage | IPage[];
  bypassInAppBrowser?: boolean;
}

export interface ITrigger {
  contentTypeAlias: string;
  icon?: string;
  label: string;
  type: TriggerType;
}

export interface IImage {
  _url: string;
  url?: string; // GraphQL queries put the _url on the url spot, so defining as optional for parsing pass.
  umbracoFile?: IImageCropped;
  alt?: string;
}

export interface IImageCropped {
  focalPoint: IFocalPoint;
  focalPointUrlTemplate: string;
  // we use cropUrls in certain places
  cropUrls: Record<string, string>;
  // but cropUrl is in Umbraco's schema
  cropUrl?: Record<string, string>;
}

export interface IFocalPoint {
  left: number;
  top: number;
}

export interface ISimpleLink {
  contentTypeAlias: string;
  title: string;
  url: string;
}

export enum PageTheme {
  default = 'default',
  shell = 'Shell'
}

export class PageContext {
  contentTypeAlias: string;
  cookieConsent: IText;
  appConsent: IText;
  footerLinks: ILink[];
  mobileMenuLinks: ILink[];
  name: string;
  personalMenuLinks: ILink[];
  publicMenuLinks: ILink[];
  policyLinks: ILink[];
  defaultRegistrationPage: IPage;
  orderTerms: string;
  orderSuccess: IText;
  orderFailed: IText;
  orderFailedPayment: IText;
  orderFailedPaymentDeepLink: IText;
  orderFailedFunds: IText;
  donationImpossible: IText;
  donationTerms: string;
  donationSuccess: IText;
  donationFailed: IText;
  donationFailedAccount: IText;
  donationFailedFunds: IText;
  donationCampaignCharity?: ICharity;
  donationCampaignText?: IText[];
  donationCampaignMaximum?: number;
  donationCampaignStepSize?: number;
  donationCampaignIncrementSize?: number;
  donationCampaignProductLabel?: string;
  donationCampaignProductPoints?: number;
  inboxPage: IPage;
  passwordTokenNoAccount: IText;
  passwordTokenBlockedAccount: IText;
  passwordTokenSuccess: IText;
  passwordResetPage: IPage;
  promotionsPage: IPage;
  twoFactorOptions: IText;
  twoFactorIncompleteAccount: IText;
  twoFactorVerification: IText;
  biometricsSetup: IText;
  biometricsDeclined: IText;
  biometricsCanceled: IText;
  biometricsLoginDescription: string;
  sortOrder: number;
  _url: string;
  loginSuccessPage: IPage;
  completeProfilePage: IPage;
  maintenancePage: IPage;
  maintenanceMessage: string;
  mobileMaintenanceMessage: string;
  loginUsernameNotice: string;
  partnerNotice: string;
  color: IColor;
  pushPreferencesPage: IPage;

  get defaultRegistrationPageUrl(): string {
    return this.defaultRegistrationPage._url;
  }

  get passwordResetPageUrl(): string {
    return this.passwordResetPage._url;
  }

  get donationCampaignContent(): IText | undefined {
    return ObjectHelper.wrapArrayToField(this.donationCampaignText);
  }
}

export class SiteSettings {
  homePage: IPage;
  appHomePage?: IPage;
  errorPage: IPage;
  defaultPageContext: PageContext;
  gtmContainerId: string;
  vwoAccountId: string;
  coostoAppId: string;
  coostoWelcomeMessage: string;
  enableConsoleEvents: boolean;
  preserveBiometrics: boolean;

  public get homePageUrl(): string {
    return this.homePage._url;
  }

  public get appHomePageUrl(): string | undefined {
    return this.appHomePage?._url;
  }

  public get errorPageUrl(): string {
    return this.errorPage._url;
  }
}
