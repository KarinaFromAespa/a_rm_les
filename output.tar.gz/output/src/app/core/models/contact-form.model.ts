import { FormBoolean } from '../constants/form.constants';
import { StringHelper } from '../helpers/string.helper';
import { IUploadedFile } from './file.model';
import { IReCaptchaRequest } from './reCaptcha.request';

export interface IContactFormValues {
  question: string;
  uploadedFiles?: IUploadedFile[];

  hasAccount: FormBoolean;
  emailAddress: string;
  gender: string;
  lastName: string;

  birthDate?: string;
  streetName?: string;
  houseNumber?: string;
  houseNumberSupplement?: string;
  postalCode?: string;
  city?: string;
  cardNumber?: string;
}

export class ContactFormQuestion {
  constructor(values: IContactFormValues, category: string) {
    this.question = values.question.htmlEncode();
    this.category = category;
    this.uploadedFiles = values.uploadedFiles;
  }

  question: string;
  category: string;
  uploadedFiles?: IUploadedFile[];
}

export class ContactFormRequest extends ContactFormQuestion {
  constructor(values: IContactFormValues, category: string) {
    super(values, category);
    this.emailAddress = values.emailAddress;
  }

  emailAddress: string;
}

export class PublicContactFormRequest extends ContactFormRequest implements IReCaptchaRequest {
  constructor(values: IContactFormValues, category: string) {
    super(values, category);
    this.gender = values.gender;
    this.lastName = values.lastName;
    this.birthDate = StringHelper.toDate(values.birthDate);
    this.streetName = values.streetName;
    this.houseNumber = values.houseNumber;
    this.houseNumberSupplement = values.houseNumberSupplement;
    this.postalCode = values.postalCode;
    this.city = values.city;
    this.cardNumber = values.cardNumber;
  }

  gender: string;
  lastName: string;

  birthDate?: Date;
  streetName?: string;
  houseNumber?: string;
  houseNumberSupplement?: string;
  postalCode?: string;
  city?: string;
  cardNumber?: string;

  reCaptchaToken: string;
}
