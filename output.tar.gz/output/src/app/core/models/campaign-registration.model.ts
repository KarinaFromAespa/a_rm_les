import { IBaseRegistrationForm, IText } from 'src/app/core/models/content.model';
import { IImportedCampaign } from 'src/app/core/models/promotion.model';
import { IPage } from 'src/app/core/models/site.response';

export enum NewsletterApprovalMode {
  required = 'Required',
  optionalStep1 = 'Optional (step 1)',
  optionalStep2 = 'Optional (step 2)'
}

export interface ICampaignRegistrationOption {
  title: string;
  importedCampaign: IImportedCampaign;
  registrationSuccessPage: IPage;
  activationSuccessPage: IPage;
}

export interface ICampaignRegistrationSettings {
  _id: string;
  campaignRegistrationOptions: ICampaignRegistrationOption[];
  mappTemplateId: string;
  newsletterApprovalMode: NewsletterApprovalMode;
  allowLightRegistration: boolean;
}

export interface ICampaignRegistration extends IBaseRegistrationForm {
  campaignRegistrationSettings: ICampaignRegistrationSettings | ICampaignRegistrationSettings[];
  defaultOption?: IImportedCampaign;
  newsletterApprovalSuggestion: IText;
  registrationText?: IText;
}
