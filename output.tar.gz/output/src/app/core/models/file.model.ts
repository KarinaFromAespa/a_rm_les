import { IReCaptchaRequest } from './reCaptcha.request';

export class FileUploadRequest implements IReCaptchaRequest {
  reCaptchaToken: string;
}

export interface IFileUpload extends IUploadedFile {
  url: string;
}

export interface IUploadedFile {
  fileId: string;
  sasToken: string;
}

export interface IUploadedFileForm extends IUploadedFile {
  name: string;
  progress: number;
  size: number;
}

export class FileType {
  static unknown: IFileType = { extension: '', contentType: 'application/octet-stream' };
  static aac: IFileType = { extension: '.aac', contentType: 'audio/aac' };
  static abw: IFileType = { extension: '.abw', contentType: 'application/x-abiword' };
  static arc: IFileType = { extension: '.arc', contentType: 'application/x-freearc' };
  static avif: IFileType = { extension: '.avif', contentType: 'image/avif' };
  static avi: IFileType = { extension: '.avi', contentType: 'video/x-msvideo' };
  static azw: IFileType = { extension: '.azw', contentType: 'application/vnd.amazon.ebook' };
  static bin: IFileType = { extension: '.bin', contentType: 'application/octet-stream' };
  static bmp: IFileType = { extension: '.bmp', contentType: 'image/bmp' };
  static bz: IFileType = { extension: '.bz', contentType: 'application/x-bzip' };
  static bz2: IFileType = { extension: '.bz2', contentType: 'application/x-bzip2' };
  static cda: IFileType = { extension: '.cda', contentType: 'application/x-cdf' };
  static csh: IFileType = { extension: '.csh', contentType: 'application/x-csh' };
  static css: IFileType = { extension: '.css', contentType: 'text/css' };
  static csv: IFileType = { extension: '.csv', contentType: 'text/csv' };
  static doc: IFileType = { extension: '.doc', contentType: 'application/msword' };
  static docx: IFileType = { extension: '.docx', contentType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' };
  static eot: IFileType = { extension: '.eot', contentType: 'application/vnd.ms-fontobject' };
  static epub: IFileType = { extension: '.epub', contentType: 'application/epub+zip' };
  static gz: IFileType = { extension: '.gz', contentType: 'application/gzip' };
  static gif: IFileType = { extension: '.gif', contentType: 'image/gif' };
  static htm: IFileType = { extension: '.htm', contentType: 'text/html' };
  static html: IFileType = { extension: '.html', contentType: 'text/html' };
  static ico: IFileType = { extension: '.ico', contentType: 'image/vnd.microsoft.icon' };
  static ics: IFileType = { extension: '.ics', contentType: 'text/calendar' };
  static jar: IFileType = { extension: '.jar', contentType: 'application/java-archive' };
  static jpeg: IFileType = { extension: '.jpeg', contentType: 'image/jpeg' };
  static jpg: IFileType = { extension: '.jpg', contentType: 'image/jpeg' };
  static js: IFileType = { extension: '.js', contentType: 'text/javascript' };
  static json: IFileType = { extension: '.json', contentType: 'application/json' };
  static jsonld: IFileType = { extension: '.jsonld', contentType: 'application/ld+json' };
  static mid: IFileType = { extension: '.mid', contentType: 'audio/midi' };
  static midi: IFileType = { extension: '.midi', contentType: 'audio/midi' };
  static mjs: IFileType = { extension: '.mjs', contentType: 'text/javascript' };
  static mp3: IFileType = { extension: '.mp3', contentType: 'audio/mpeg' };
  static mp4: IFileType = { extension: '.mp4', contentType: 'video/mp4' };
  static mpeg: IFileType = { extension: '.mpeg', contentType: 'video/mpeg' };
  static mpkg: IFileType = { extension: '.mpkg', contentType: 'application/vnd.apple.installer+xml' };
  static odp: IFileType = { extension: '.odp', contentType: 'application/vnd.oasis.opendocument.presentation' };
  static ods: IFileType = { extension: '.ods', contentType: 'application/vnd.oasis.opendocument.spreadsheet' };
  static odt: IFileType = { extension: '.odt', contentType: 'application/vnd.oasis.opendocument.text' };
  static oga: IFileType = { extension: '.oga', contentType: 'audio/ogg' };
  static ogv: IFileType = { extension: '.ogv', contentType: 'video/ogg' };
  static ogx: IFileType = { extension: '.ogx', contentType: 'application/ogg' };
  static opus: IFileType = { extension: '.opus', contentType: 'audio/opus' };
  static otf: IFileType = { extension: '.otf', contentType: 'font/otf' };
  static png: IFileType = { extension: '.png', contentType: 'image/png' };
  static pdf: IFileType = { extension: '.pdf', contentType: 'application/pdf' };
  static php: IFileType = { extension: '.php', contentType: 'application/x-httpd-php' };
  static ppt: IFileType = { extension: '.ppt', contentType: 'application/vnd.ms-powerpoint' };
  static pptx: IFileType = { extension: '.pptx', contentType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' };
  static rar: IFileType = { extension: '.rar', contentType: 'application/vnd.rar' };
  static rtf: IFileType = { extension: '.rtf', contentType: 'application/rtf' };
  static sh: IFileType = { extension: '.sh', contentType: 'application/x-sh' };
  static svg: IFileType = { extension: '.svg', contentType: 'image/svg+xml' };
  static swf: IFileType = { extension: '.swf', contentType: 'application/x-shockwave-flash' };
  static tar: IFileType = { extension: '.tar', contentType: 'application/x-tar' };
  static tif: IFileType = { extension: '.tif', contentType: 'image/tiff' };
  static tiff: IFileType = { extension: '.tiff', contentType: 'image/tiff' };
  static ts: IFileType = { extension: '.ts', contentType: 'video/mp2t' };
  static ttf: IFileType = { extension: '.ttf', contentType: 'font/ttf' };
  static txt: IFileType = { extension: '.txt', contentType: 'text/plain' };
  static vsd: IFileType = { extension: '.vsd', contentType: 'application/vnd.visio' };
  static wav: IFileType = { extension: '.wav', contentType: 'audio/wav' };
  static weba: IFileType = { extension: '.weba', contentType: 'audio/webm' };
  static webm: IFileType = { extension: '.webm', contentType: 'video/webm' };
  static webp: IFileType = { extension: '.webp', contentType: 'image/webp' };
  static woff: IFileType = { extension: '.woff', contentType: 'font/woff' };
  static woff2: IFileType = { extension: '.woff2', contentType: 'font/woff2' };
  static xhtml: IFileType = { extension: '.xhtml', contentType: 'application/xhtml+xml' };
  static xls: IFileType = { extension: '.xls', contentType: 'application/vnd.ms-excel' };
  static xlsx: IFileType = { extension: '.xlsx', contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
  static xml: IFileType = { extension: '.xml', contentType: 'application/xml' };
  static xul: IFileType = { extension: '.xul', contentType: 'application/vnd.mozilla.xul+xml' };
  static zip: IFileType = { extension: '.zip', contentType: 'application/zip' };
  static '3gp': IFileType = { extension: '.3gp', contentType: 'video/3gpp' };
  static '3g2': IFileType = { extension: '.3g2', contentType: 'video/3gpp2' };
  static '7z': IFileType = { extension: '.7z', contentType: 'application/x-7z-compressed' };
}

export interface IFileType {
  extension: string;
  contentType: string;
}
