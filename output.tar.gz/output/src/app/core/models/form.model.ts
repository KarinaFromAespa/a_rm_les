import { FormBoolean, FormType } from '../constants/form.constants';
import { IColor } from './content.model';
import { IFileType } from './file.model';
import { FormValidatorType } from './form-validator.model';

export interface IFormValidator {
  validator: FormValidatorType;
  errorMessage?: string;
  errorMessages?: Record<string, string>;
  hideFromChecklist?: boolean;
  hasError?: boolean;
}

export interface IFormSection {
  isGrid?: boolean;
  additionalClass?: string;
  title?: string;
  body?: string;
  controls: IFormControl[];
  hidden?: boolean;
  sectionType?: string;
}

export interface IFormState {
  submitted: boolean; // In object so it can be passed by reference and modified by form control components
}

export interface IFormControl {
  type: FormType;
  label?: string;
  name: string;
  value?: string | number;
  containerClass?: string;

  showWhen?: IShowCondition;
  hidden?: boolean;
  disabled?: boolean;

  description?: string;
  textOnlyDescription?: boolean;
  showOnlyDescription?: boolean;

  runValidatorsSequentially?: boolean; // Sequentially runs validators and stops when an error is found

  validators?: IFormValidator[];
  asyncValidators?: IFormValidator[];
  hasError?: boolean;
  isValid?: boolean;
  updateOn?: 'change' | 'blur' | 'submit';
  typingStarted?: boolean;
  trim?: boolean;

  verify?: boolean;
  verifyLabel?: string;

  errorMessages?: string[];
  htmlErrorMessages?: string[];
}

export enum FormValidityStatus {
  valid = 'VALID',
  invalid = 'INVALID',
  pending = 'PENDING'
}

export type IUserActionFormValue = Record<string, FormBoolean>;

export interface IShowCondition {
  controlName: string;
  value: any;
}

export interface IFormValidationError {
  error: boolean;
  response?: unknown;
}

export interface IOption {
  // Used for select, checkbox, radio
  value: string | number; // No spaces
  text: string;
  selected?: boolean;
}

export interface IOptionControl extends IFormControl {
  // Used for select, checkbox, radio
  options: IOption[];
}

export enum RadioDisplayType {
  default = 'default',
  tabs = 'tabs',
  horizontal = 'radio',
  list = 'list'
}

export interface IRadioControl extends IOptionControl {
  displayType: RadioDisplayType;
  color: IColor;
}

export interface ISelectControl extends IOptionControl {
  placeholder: string;
}

export interface ITextControl extends IFormControl {
  maxLength?: number;
  placeholder?: string;
  autocomplete?: string;
}

export interface IPasswordControl extends ITextControl {
  passwordControl: ITextControl;
  enableShowPassword?: boolean;
  emitChange?: boolean;
  autocomplete?: string;
  eyeColor?: IColor;
}

export interface IRepeatControl extends IFormControl {
  fullWidth: boolean;
  repeatControlLabel: string;
  repeatErrorMessage: string;
  repeatChecklistMessage?: string;
  controlType: FormType.text | FormType.password | FormType.email;
  enableShowPassword?: boolean;

  mainControl?: IFormControl;
  repeatControl?: IFormControl;

  validationChecklistTitle?: string;
  showValidationChecklist?: boolean;
  autocomplete?: string;
}

export interface IFileControl extends IFormControl {
  allowedTypes?: IFileType[];
  maxUploadSizeMB?: number;
}
