import { StringHelper } from 'src/app/core/helpers/string.helper';
import { IVerificationCodeValidationRequest } from 'src/app/shared/modals/verification-modal/verification-modal.model';
import { Gender } from '../constants/form.constants';
import { ICampaignRegistrationOption } from './campaign-registration.model';
import { IReCaptchaRequest } from './reCaptcha.request';

export class UserContactDetails {
  emailAddress: string;
  phoneNumber?: string;
}

export class UpdateUserProfile extends UserContactDetails implements IReCaptchaRequest {
  constructor(values: IUserProfileFormValues, unformattedDate = false) {
    super();

    this.gender = values.gender
      ? isNaN(parseFloat(values.gender))
        ? Gender[StringHelper.firstToLower(values.gender)]
        : (values.gender as keyof typeof Gender)
      : undefined;
    this.firstName = values.firstName;
    this.lastName = values.lastName;
    this.birthDate = unformattedDate ? (values.birthDate ? new Date(values.birthDate) : undefined) : StringHelper.toDate(values.birthDate);
    this.streetName = values.streetName;
    this.houseNumber = values.houseNumber;
    this.houseNumberSupplement = values.houseNumberSupplement;
    this.postalCode = values.postalCode;
    this.city = values.city;
    this.addressChangeDate = unformattedDate
      ? values.addressChangeDate
        ? new Date(values.addressChangeDate)
        : undefined
      : (StringHelper.toDate(values.addressChangeDate) ?? undefined);
    this.emailAddress = values.emailAddress;
    this.phoneNumber = values.phoneNumber;
    this.emailAddressVerificationCode = values.emailAddressVerificationCode;
    this.phoneNumberVerificationCode = values.phoneNumberVerificationCode;
    this.reCaptchaToken = '';
  }

  gender?: Gender;
  firstName: string;
  lastName: string;
  birthDate?: Date;
  streetName: string;
  houseNumber: string;
  houseNumberSupplement?: string;
  postalCode: string;
  city: string;
  addressChangeDate?: Date;
  emailAddressVerificationCode?: string;
  phoneNumberVerificationCode?: string;
  reCaptchaToken: string;
}

export class UserProfile extends UpdateUserProfile {
  constructor(values: IUserProfileFormValues, unformattedDate = false) {
    super(values, unformattedDate);

    this.emailAddress = values.emailAddress;
    this.phoneNumber = values.phoneNumber;
    this.isPhoneNumberVerified = values.isPhoneNumberVerified;
    this.reCaptchaToken = '';
  }

  isPhoneNumberVerified?: boolean;
}

export class UserAddress {
  constructor(values?: IUserAddressFormValues) {
    if (!values) {
      return;
    }

    this.streetName = values.streetName;
    this.houseNumber = values.houseNumber;
    this.houseNumberSupplement = values.houseNumberSupplement;
    this.postalCode = values.postalCode;
    this.city = values.city;
  }

  streetName: string;
  houseNumber: string;
  houseNumberSupplement?: string;
  postalCode: string;
  city: string;

  get isAddressComplete(): boolean {
    return !!(this.streetName && this.houseNumber && this.postalCode && this.city);
  }
}

export class UserCreateRequest extends UserProfile {
  constructor(values: IUserCreateFormValues, referralCode?: string) {
    super(values);

    this.receivePromotionalEmails = !!values.receivePromotionalEmails;
    this.password = values.password;
    this.cardNumber = values.cardNumber;
    this.referralCode = referralCode;
    this.origin = values.origin;
    this.reCaptchaToken = '';
  }

  receivePromotionalEmails: boolean;
  password: string;
  cardNumber?: string;
  referralCode?: string;
  origin: string;

  reCaptchaToken: string;
}

export class UserCampaignCreateRequest extends UserCreateRequest {
  constructor(values: IUserCreateFormValues, campaignId: string, campaignRegistrationSettingsId: string, referralCode?: string) {
    super(values, referralCode);

    this.campaignId = campaignId;
    this.campaignRegistrationSettingsId = campaignRegistrationSettingsId;
  }

  campaignId: string;
  campaignRegistrationSettingsId?: string;
}

export class UserCampaignRegistrationRequest implements IReCaptchaRequest {
  constructor(values: IUserCampaignRegistrationFormValues) {
    this.campaignId = values.campaignId;
    this.campaignRegistrationSettingsId = values.campaignRegistrationSettingsId;
    this.emailAddress = values.emailAddress;
    this.receivePromotionalEmails = values.receivePromotionalEmails;
  }

  campaignId: string;
  campaignRegistrationSettingsId: string;
  emailAddress: string;
  emailAddressVerificationCode?: string;
  receivePromotionalEmails: boolean;
  reCaptchaToken: string;
}

export class EmailAddressUpdateRequest {
  emailAddress: string;
  emailAddressVerificationCode?: string;
}

export class PhoneNumberUpdateRequest {
  phoneNumber?: string;
  phoneNumberVerificationCode?: string;
}

export interface IUserCampaignRegistrationFormValues extends UserCampaignRegistrationRequest {
  selectedCampaignRegistrationOption?: ICampaignRegistrationOption;
}

export class LightUserCampaignCreateRequest extends UserCampaignRegistrationRequest {
  constructor(values: UserCampaignRegistrationRequest, origin: string) {
    super(values);

    this.origin = origin;
  }

  origin: string;
}

export interface IUserProfileFormValues {
  gender?: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  streetName: string;
  houseNumber: string;
  houseNumberSupplement?: string;
  postalCode: string;
  city: string;
  addressChangeDate: string;
  emailAddress: string;
  phoneNumber?: string;
  emailAddressVerificationCode?: string;
  phoneNumberVerificationCode?: string;
  isPhoneNumberVerified?: boolean;
}

export interface IUserAddressFormValues {
  streetName: string;
  houseNumber: string;
  houseNumberSupplement: string;
  postalCode: string;
  city: string;
}

export interface IUserCreateFormValues extends IUserProfileFormValues {
  receivePromotionalEmails: boolean;
  password: string;
  hasCard: string;
  cardNumber?: string;
  origin: string;
}

export interface IEmailVerificationRequest extends IReCaptchaRequest {
  emailAddress: string;
}

export interface IPhoneNumberVerificationRequest {
  phoneNumber: string;
}

export interface IEmailVerificationCodeValidationRequest extends IVerificationCodeValidationRequest, IEmailVerificationRequest {}

export interface IPhoneNumberVerificationCodeValidationRequest
  extends IVerificationCodeValidationRequest,
    IPhoneNumberVerificationRequest {}

export class UserToggleValue {}

export class UserPersonalizationPreferences extends UserToggleValue {
  constructor(allowPersonalization: boolean) {
    super();
    this.allowPersonalization = allowPersonalization;
  }

  allowPersonalization: boolean;
}

export class UserPromotionPreferences extends UserToggleValue {
  constructor(receivePromotionalEmails: boolean) {
    super();
    this.receivePromotionalEmails = receivePromotionalEmails;
  }

  receivePromotionalEmails: boolean;
}

export class UserInboxPreferences extends UserToggleValue {
  constructor(enableInbox: boolean) {
    super();
    this.enableInbox = enableInbox;
  }

  enableInbox: boolean;
}

export class UserPushPromotionPreferences extends UserToggleValue {
  constructor(receivePromotionalPushMessages: boolean) {
    super();
    this.receivePromotionalPushMessages = receivePromotionalPushMessages;
  }

  receivePromotionalPushMessages: boolean;
}

export class UserPushServicePreferences extends UserToggleValue {
  constructor(receiveServicePushMessages: boolean) {
    super();
    this.receiveServicePushMessages = receiveServicePushMessages;
  }

  receiveServicePushMessages: boolean;
}

export enum PersonalDataStatus {
  notFound = 'NotFound',
  pending = 'Pending',
  available = 'Available',
  downloaded = 'Downloaded',
  expired = 'Expired'
}

export enum PersonalDataState {
  request,
  processing,
  download,
  downloadExpired
}

export class PersonalDataStatusCheck {
  personalDataExportStatus: PersonalDataStatus;
}
