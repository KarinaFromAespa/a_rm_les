export enum RegistrationStepSection {
  Address = 'address',
  CurrentCard = 'currentCard',
  EmailAddress = 'emailAddress',
  Newsletter = 'newsletter',
  Password = 'password',
  PersonalData = 'personalData'
}
