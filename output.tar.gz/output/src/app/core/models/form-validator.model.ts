import { AsyncValidatorFn, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { IAddressSuggestion, PostalCodeCheckRequest } from 'src/app/features/content-blocks/registration-form/address.model';
import { CardStatusCheckRequest, ICardStatusCheckResponse } from 'src/app/features/content-blocks/registration-form/card-status.model';
import {
  IUserExistenceCheckResponse,
  UserExistenceCheckRequest,
  UserPhoneNumberExistenceCheckRequest
} from 'src/app/features/content-blocks/registration-form/user-existence.model';
import { addressLineAutoComplete } from 'src/app/features/form/validators/address-line-autocomplete.validator';
import { addressSuggestionValidator } from 'src/app/features/form/validators/address-suggestion.validator';
import { createBirthDateValidator } from 'src/app/features/form/validators/birth-date.validator';
import { checkCardStatusValidator } from 'src/app/features/form/validators/check-card-status.validator';
import { createCheckUserExistenceValidator } from 'src/app/features/form/validators/check-user-existence.validator';
import { createCheckVerificationValidator } from 'src/app/features/form/validators/check-verification.validator';
import { createEmailAddressOrPatternValidator } from 'src/app/features/form/validators/email-address-or-pattern.validator';
import { createMultiPatternValidator } from 'src/app/features/form/validators/multi-pattern.validator';
import { createNoFunctionValidator } from 'src/app/features/form/validators/no-function.validator';
import { createPasswordRequirementValidator } from 'src/app/features/form/validators/password-requirement.validator';
import { createPatternWithReplaceValidator } from 'src/app/features/form/validators/pattern-with-replace.validator';
import { createRepeatFieldValidator } from 'src/app/features/form/validators/repeat-field.validator';
import { createTypedPatternValidator } from 'src/app/features/form/validators/typed-pattern.validator';
import { FormValidatorTypeKeys } from '../constants/form.constants';
import { createCheckPhoneNumberExistenceValidator } from 'src/app/features/form/validators/check-phone-number-existence.validator';
import { FormHelper } from '../helpers/form.helper';

export class FormRegex {
  static readonly authenticationCode = new FormRegex('authenticationCode', /^[0-9]{6}$/);
  static readonly humanName = new FormRegex('humanName', /^[\p{L}\-' ]{0,60}$/u);
  static readonly address = new FormRegex('address', /^(?!.*www)[\p{L}\p{N}\-'. ]{0,60}$/u);
  static readonly houseNumber = new FormRegex('houseNumber', /^[0-9]{0,10}$/);
  static readonly houseNumberSupplement = new FormRegex('houseNumberSupplement', /^[A-Za-z0-9]{0,10}$/);
  static readonly postalCode = new FormRegex('postalCode', /^[0-9]{4} [A-Z]{2}$/);
  static readonly phoneNumber = new FormRegex('phoneNumber', /^06[0-9]{8}$/);
  static readonly password = new FormRegex('password', /^[A-Za-z0-9#@$!%*?&^()_+={}><[\]~/\\.-]{0,60}$/);
  static readonly cardNumber = new FormRegex('cardNumber', /^(|[0-9]{9})$/);
  static readonly date = new FormRegex('date', /^([0-2][0-9]|(3)[0-1])(-)(((0)[0-9])|((1)[0-2]))(-)\d{4}$/);
  static readonly digitOnly = new FormRegex('digitOnly', /^\d+$/);
  static readonly atLeastOneDigit = new FormRegex('atLeastOneDigit', /\d/);
  static readonly atLeastOneLowercase = new FormRegex('atLeastOneLowercase', /[a-z]+/);
  static readonly atLeastOneUppercase = new FormRegex('atLeastOneUppercase', /[A-Z]+/);
  static readonly atLeastOneSymbol = new FormRegex('passwordSymbols', /[#@$!%*?&^()_+={}><[\]~/\\.-]+/);
  static readonly symbols = new FormRegex('symbols', /^[A-Za-z0-9#@$!%*?&^()_+={}><[\]~/\\.-]+$/);
  static readonly searchQuery = new FormRegex('searchQuery', /^(?!.*www)[\p{L}\p{N}\-'. ]{0,60}$/u);
  static readonly question = new FormRegex('question', /^[\p{L}\p{N}\p{Sc}\p{P}\s+=]*$/u);
  static readonly replaceQuotes = /["“”„‟‘’‚‛〝〞〟`´]/g;
  static readonly replacementQuote = "'";

  private constructor(
    private key: string,
    private regExp: RegExp
  ) {}

  getKey(): string {
    return this.key;
  }

  getRegExp(): RegExp {
    return this.regExp;
  }

  test(testString: string): boolean {
    return this.regExp.test(testString);
  }
}

export class FormValidatorType {
  static readonly required = new FormValidatorType(FormValidatorTypeKeys.required, Validators.required);
  static readonly requiredTrue = new FormValidatorType(FormValidatorTypeKeys.required, Validators.requiredTrue);
  static readonly email = new FormValidatorType(FormValidatorTypeKeys.email, Validators.email);
  static readonly birthDateWithMinimumAge = new FormValidatorType(FormValidatorTypeKeys.birthDate, createBirthDateValidator(16, 120));
  static readonly birthDate = new FormValidatorType(FormValidatorTypeKeys.birthDate, createBirthDateValidator(0, 120));
  static readonly verificationCode = new FormValidatorType(FormValidatorTypeKeys.verificationCode, createNoFunctionValidator());

  static repeat(group: UntypedFormGroup, controlName: string): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.repeat, createRepeatFieldValidator(group, controlName));
  }

  static checkVerification(group: UntypedFormGroup, controlName: string): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.verification, createCheckVerificationValidator(group, controlName));
  }

  static pattern(pattern: RegExp): FormValidatorType {
    if (pattern.source.includes(FormRegex.replacementQuote)) {
      return new FormValidatorType(
        FormValidatorTypeKeys.pattern,
        createPatternWithReplaceValidator(pattern, FormRegex.replaceQuotes, FormRegex.replacementQuote)
      );
    }

    return new FormValidatorType(FormValidatorTypeKeys.pattern, Validators.pattern(pattern));
  }

  static emailAddressOrPattern(pattern: RegExp): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.emailAddressOrPattern, createEmailAddressOrPatternValidator(pattern));
  }

  static typedPattern(key: string, formRegex: FormRegex): FormValidatorType {
    return new FormValidatorType(key, createTypedPatternValidator(key, formRegex));
  }

  // For when one control needs to be checked against multiple separate regex's
  static multiPattern(pattern: FormRegex): FormValidatorType {
    return new FormValidatorType(`${FormValidatorTypeKeys.pattern}_${pattern.getKey()}`, createMultiPatternValidator(pattern));
  }

  static minLength(length: number): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.minLength, Validators.minLength(length));
  }

  static maxLength(length: number): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.maxLength, Validators.maxLength(length));
  }

  static passwordRequirements(): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.passwordRequirements, createPasswordRequirementValidator());
  }

  static checkUserExistence(
    verifyFn: (
      action: string,
      request: UserExistenceCheckRequest,
      callback: (request: UserExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>
    ) => Promise<IUserExistenceCheckResponse>,
    checkUserExistenceFn: (request: UserExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>,
    exclude?: string
  ): FormValidatorType {
    return new FormValidatorType(
      FormValidatorTypeKeys.checkUserExistence,
      createCheckUserExistenceValidator(verifyFn, checkUserExistenceFn, exclude)
    );
  }

  static checkPhoneNumberExistence(
    verifyFn: (
      action: string,
      request: UserPhoneNumberExistenceCheckRequest,
      callback: (request: UserPhoneNumberExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>
    ) => Promise<IUserExistenceCheckResponse>,
    checkPhoneNumberExistenceFn: (request: UserPhoneNumberExistenceCheckRequest) => Promise<IUserExistenceCheckResponse>,
    exclude?: string
  ): FormValidatorType {
    return new FormValidatorType(
      FormValidatorTypeKeys.checkPhoneNumberExistence,
      createCheckPhoneNumberExistenceValidator(verifyFn, checkPhoneNumberExistenceFn, exclude)
    );
  }

  static checkCardStatus(
    verifyFn: (
      action: string,
      request: CardStatusCheckRequest,
      callback: (request: CardStatusCheckRequest) => Promise<ICardStatusCheckResponse>
    ) => Promise<ICardStatusCheckResponse>,
    checkCardStatusFn: (request: CardStatusCheckRequest) => Promise<ICardStatusCheckResponse>
  ): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.checkCardStatus, checkCardStatusValidator(verifyFn, checkCardStatusFn));
  }

  static addressSuggestion(
    verifyFn: (
      action: string,
      request: PostalCodeCheckRequest,
      callback: (request: PostalCodeCheckRequest) => Promise<IAddressSuggestion>
    ) => Promise<IAddressSuggestion>,
    checkPostalCodeFn: (request: PostalCodeCheckRequest) => Promise<IAddressSuggestion>,
    suppressErrors = true
  ): FormValidatorType {
    return new FormValidatorType(
      FormValidatorTypeKeys.getAddressSuggestion,
      addressSuggestionValidator(verifyFn, checkPostalCodeFn, suppressErrors)
    );
  }

  static wrapValidators(validators: FormValidatorType[]): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.wrapper, FormHelper.wrapValidators(validators));
  }

  static addressLineAutoComplete(): FormValidatorType {
    return new FormValidatorType(FormValidatorTypeKeys.addressLineAutoComplete, addressLineAutoComplete());
  }

  private constructor(
    private key: string,
    private validator: ValidatorFn | AsyncValidatorFn
  ) {}

  getKey(): string {
    return this.key;
  }

  getValidator(): ValidatorFn | AsyncValidatorFn {
    return this.validator;
  }
}
