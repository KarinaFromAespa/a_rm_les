import { Component, ElementRef, HostListener, OnDestroy, OnInit, Renderer2, ViewChild } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { TextZoom } from '@capacitor/text-zoom';
import { ModalAnchorDirective } from 'src/app/features/modal/modal.directive';
import { PageService } from 'src/app/features/page/page.service';
import { SearchService } from 'src/app/features/search/search.service';
import { MyCardSheetService } from 'src/app/shared/components/my-card-sheet/my-card-sheet.service';
import { PageType } from '../constants/page.constants';
import { ObjectHelper } from '../helpers/object.helper';
import { PlatformHelper } from '../helpers/platform.helper';
import { StringHelper } from '../helpers/string.helper';
import { PageTheme } from '../models/site.response';
import { ModalService } from 'src/app/features/modal/modal.service';
import { App } from '@capacitor/app';

@Component({
  selector: 'air-layout',
  templateUrl: './layout.component.html',
  standalone: false
})
export class LayoutComponent implements OnInit, OnDestroy {
  @ViewChild('ionContent', { static: true, read: ElementRef }) ionContent: ElementRef<HTMLIonContentElement>;
  @ViewChild(ModalAnchorDirective, { static: true })
  modalAnchor: ModalAnchorDirective;
  destroy$ = new Subject();
  pageTheme = PageTheme;
  theme?: PageTheme;

  isFooterVisible: boolean;
  isNativeMobile: boolean;
  isMobile: boolean;
  isEmbeddedPage: boolean;
  isModalOpen = false;

  searchActivated: boolean;

  @HostListener('window:ionKeyboardDidShow')
  onKeyboardShow(): void {
    //Skip if Coosto chat input is focused
    if (document.activeElement?.getAttribute('name') === '____talkjs__chat__ui_internal') {
      return;
    }

    document.body.classList.add('keyboard--open');
    setTimeout(() => {
      if (document.activeElement?.tagName.toLowerCase() === 'input') {
        const rect = document.activeElement.getBoundingClientRect();
        const visible =
          rect.top >= 0 &&
          rect.left >= 0 &&
          rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
          rect.right <= (window.innerWidth || document.documentElement.clientWidth);
        if (!visible) {
          document.activeElement.scrollIntoView(false);
        }
      }
    }, 100);
  }

  @HostListener('window:ionKeyboardDidHide')
  onKeyboardHide(): void {
    if (!(document.activeElement?.tagName.toLowerCase() === 'input')) {
      document.body.classList.remove('keyboard--open');
    }
  }

  constructor(
    private myCardSheetService: MyCardSheetService,
    private platformHelper: PlatformHelper,
    private router: Router,
    private pageService: PageService,
    private modalService: ModalService,
    private renderer2: Renderer2,
    private searchService: SearchService
  ) {}

  async ngOnInit(): Promise<void> {
    this.isNativeMobile = PlatformHelper.isNativeMobile;
    this.isMobile = this.platformHelper.isMobile;

    if (this.isMobile) {
      this.handleConnectionStatus();
    }

    this.searchService.active$.subscribe((state) => {
      this.searchActivated = state;
    });

    // Subscribe to routing events to scroll to top
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof NavigationEnd) {
        document.querySelector<HTMLElement>('.header__skip')?.focus();
        this.scrollToTop();
      }
    });

    this.pageService.pageData$.pipe(takeUntil(this.destroy$)).subscribe((page) => {
      if (!page) {
        this.isFooterVisible = false;
        return;
      }

      const existingThemeClass = document.documentElement.classList.value.split(' ').find((x) => x.startsWith('theme--'));
      const [themes] = ObjectHelper.wrapFieldToArray(page?.pageTheme);

      this.theme = themes?.theme;

      if (this.theme) {
        const currentTheme = `theme--${StringHelper.toKebabCase(this.theme)}`;
        if (existingThemeClass !== currentTheme) {
          if (existingThemeClass) {
            this.renderer2.removeClass(document.documentElement, existingThemeClass);
          }
          this.renderer2.addClass(document.documentElement, currentTheme);
        }
      } else if (existingThemeClass) {
        this.renderer2.removeClass(document.documentElement, existingThemeClass);
      }

      if (page.contentTypeAlias === PageType.embeddedPage) {
        this.isEmbeddedPage = true;
      }

      this.isFooterVisible = true;
    });

    this.modalService.isOpen.pipe(takeUntil(this.destroy$)).subscribe((isOpen) => {
      this.isModalOpen = isOpen;
    });

    if (this.platformHelper.isiOSNative) {
      await this.setTextZoom();
      App.addListener('resume', async () => {
        await this.setTextZoom();
      });
    }

    document.addEventListener('keydown', (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        this.modalService.close();
      }
    });
  }

  scrollToTop(): void {
    // Always scroll page (ion-content) to top
    if (this.ionContent) {
      void this.ionContent.nativeElement.scrollToTop(250);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private handleConnectionStatus(): void {
    this.platformHelper.onlineState$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((isOnline) => {
      if (isOnline) {
        return;
      }

      this.myCardSheetService.open();
    });
  }

  private async setTextZoom(): Promise<void> {
    const zoomLevel = await TextZoom.getPreferred();
    TextZoom.set({ value: zoomLevel.value });
  }
}
