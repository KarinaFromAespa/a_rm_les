declare global {
  interface String {
    format(replacements: string[]): string;
    htmlEncode(): string;
  }
}

if (!String.prototype.format) {
  String.prototype.format = function (args: string[]): string {
    const value = this as string;

    return value.replace(/{(\d+)}/g, (match: string, index: number) => (typeof args[index] != 'undefined' ? args[index] : match));
  };
}

if (!String.prototype.htmlEncode) {
  String.prototype.htmlEncode = function (): string {
    const value = this as string;

    return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/'/g, '&#39;').replace(/"/g, '&#34;');
  };
}

export {};
