declare global {
  interface Array<T> {
    filterEmpty(): T extends undefined | null ? never : T[];
  }
}

if (!Array.prototype.filterEmpty) {
  Array.prototype.filterEmpty = function <T>(this: T[]): T[] {
    return this.filter((item): item is T => !!item);
  };
}

export {};
