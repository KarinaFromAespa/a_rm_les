declare global {
  interface Event {
    text(): string | undefined;
  }
}

if (!Event.prototype.text) {
  Event.prototype.text = function (): string | undefined {
    const target = (this as Event)?.target;
    return (target as HTMLElement)?.textContent?.trim();
  };
}

export {};
