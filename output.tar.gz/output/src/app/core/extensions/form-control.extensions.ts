import { AbstractControl } from '@angular/forms';
import { FormValidatorTypeKeys } from '../constants/form.constants';
import { FormValidatorType } from '../models/form-validator.model';

declare module '@angular/forms' {
  interface AbstractControl {
    isInvalidWithoutSpecifiedKeys: (keys: FormValidatorTypeKeys[]) => boolean;
    updateValueWithSpecifiedValidators: (validators?: FormValidatorType[], asyncValidators?: FormValidatorType[]) => void;
  }
}

AbstractControl.prototype.isInvalidWithoutSpecifiedKeys = function (keys: FormValidatorTypeKeys[]): boolean {
  if (!this.errors) {
    return false;
  }

  const remainingErrors = { ...this.errors };
  for (const key of keys) {
    delete remainingErrors[key];
  }

  return Object.keys(remainingErrors).length > 0;
};

AbstractControl.prototype.updateValueWithSpecifiedValidators = function (
  validators: FormValidatorType[] = [],
  asyncValidators: FormValidatorType[] = []
): void {
  const originalValidator = this.validator;
  const originalAsyncValidator = this.asyncValidator;

  this.setValidators(validators.map((x) => x.getValidator()));
  this.setAsyncValidators(asyncValidators.map((x) => x.getValidator()));

  this.updateValueAndValidity({ onlySelf: true });

  this.setValidators(originalValidator);
  this.setAsyncValidators(originalAsyncValidator);
};
