import { Component, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AnimationStates, animationSheetUp } from '../../animations/sheet.animations';
import { UserEventAction, UserEventSource } from '../../constants/user-event.constants';
import { CookieConsentHelper } from '../../helpers/cookie-consent.helper';
import { PlatformHelper } from '../../helpers/platform.helper';
import { IText } from '../../models/content.model';
import { ConsentService } from '../../services/consent.service';
import { SiteService } from '../../services/site.service';
import { UserEventService } from '../../services/user-event.service';
import AnimationConstants from '../../animations/animation.constants';

@Component({
  selector: 'air-cookie-banner',
  templateUrl: './cookie-banner.component.html',
  animations: [animationSheetUp],
  standalone: false
})
export class CookieBannerComponent implements OnInit, OnDestroy {
  cookieConsentData?: IText;
  isCookieConsented = false;
  animationState: string = AnimationStates.closed;
  userEventSource = UserEventSource.consentSheet;
  lastFocusedElement: HTMLElement | null = null;

  destroy$ = new Subject();

  constructor(
    private element: ElementRef<HTMLElement>,
    private siteService: SiteService,
    private cookieConsentHelper: CookieConsentHelper,
    private consentService: ConsentService,
    private userEventService: UserEventService
  ) {}

  get isVisible(): boolean {
    return !PlatformHelper.isNativeMobile && !this.siteService.isSsr && !window.navigator.userAgent.includes('HeadlessChrome');
  }

  async ngOnInit(): Promise<void> {
    if (!this.isVisible) {
      return;
    }

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.cookieConsentData = data?.cookieConsent;
    });

    this.isCookieConsented = await this.cookieConsentHelper.functionalCookiesAccepted();

    this.consentService.onConsentSheetToggle$.pipe(takeUntil(this.destroy$)).subscribe((state: AnimationStates) => {
      if (state === this.animationState) {
        return;
      }

      this.animationState = state as string;
      if (state === 'open') {
        setTimeout(() => {
          this.lastFocusedElement = document.activeElement as HTMLElement;
          this.element.nativeElement.querySelector('button')?.focus();
        }, AnimationConstants.baseDuration);
      } else {
        this.lastFocusedElement?.focus();
        this.lastFocusedElement = null;
      }
    });

    if (!this.isCookieConsented) {
      this.consentService.open();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async consentCookies(event: Event, accept: boolean): Promise<void> {
    this.userEventService.pushEvent(this.userEventSource, UserEventAction.submit, event.text());
    await this.cookieConsentHelper.setCookieConsentValue(accept);
    this.isCookieConsented = true;
    this.consentService.close();
  }
}
