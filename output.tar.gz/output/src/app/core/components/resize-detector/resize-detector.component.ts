import { AfterViewInit, Component, ElementRef, HostListener, Inject, OnDestroy } from '@angular/core';
import { Platform } from '@ionic/angular';
import { Subject } from 'rxjs';
import { WINDOW_TOKEN } from '../../constants/site.constants';
import { ReCaptchaService } from '../../services/re-captcha.service';
import { ResizeService } from '../../services/resize.service';
import { ScreenSize } from './resize-detector.model';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'resize-detector',
  templateUrl: './resize-detector.component.html',
  standalone: false
})
export class ResizeDetectorComponent implements AfterViewInit, OnDestroy {
  prefix = 'rs-';
  el?: Element;
  sizes = [
    {
      id: ScreenSize.xsm,
      name: 'xsm',
      css: `d--none d--block--xsm`
    },
    {
      id: ScreenSize.sm,
      name: 'sm',
      css: `d--none d--none--xsm d--block--sm`
    },
    {
      id: ScreenSize.md,
      name: 'md',
      css: `d--none d--none--sm d--block--md`
    },
    {
      id: ScreenSize.lg,
      name: 'lg',
      css: `d--none--md`
    }
  ];

  destroy$ = new Subject();

  @HostListener('window:resize', [])
  onResize(): void {
    this.detectScreenSize();
  }

  @HostListener('window:ionKeyboardDidShow')
  @HostListener('window:ionKeyboardDidHide')
  onKeyboardEvent(): void {
    this.setAppHeight();
  }

  constructor(
    @Inject(WINDOW_TOKEN) private window: Window,
    private elementRef: ElementRef<HTMLElement>,
    private resizeService: ResizeService,
    private platform: Platform,
    private reCaptchaService: ReCaptchaService
  ) {}

  ngAfterViewInit(): void {
    this.detectScreenSize();

    void this.platform.ready().then(() => {
      this.setAppHeight();
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  private detectScreenSize(): void {
    const currentSize = this.sizes.find((x) => {
      // get the HTML element
      this.el = this.elementRef.nativeElement.querySelector(`.${this.prefix}${x.id}`) ?? undefined;
      if (!this.el) {
        return false;
      }

      return typeof this.window !== 'undefined' && this.window.getComputedStyle(this.el).display !== 'none';
    });

    if (currentSize) {
      this.resizeService.onResize(currentSize.id);
    }
    this.setAppHeight();
  }

  private setAppHeight(): void {
    const doc = document.documentElement;
    doc.style.setProperty('--app-height', `${this.platform.height()}px`);
  }
}
