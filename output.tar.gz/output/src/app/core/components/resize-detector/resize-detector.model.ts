export enum ScreenSize {
  xsm,
  sm,
  md,
  lg
}
