import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
  AfterViewChecked
} from '@angular/core';
import { ActivationStart, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject, combineLatest } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { PageService } from 'src/app/features/page/page.service';
import { SearchService } from 'src/app/features/search/search.service';
import { NavigationComponent } from '../../../shared/components/navigation/navigation.component';
import { UserEventAction, UserEventSource } from '../../constants/user-event.constants';
import { InboxHelper } from '../../helpers/inbox.helper';
import { ObjectHelper } from '../../helpers/object.helper';
import { PromotionHelper } from '../../helpers/promotion.helper';
import { UserHelper } from '../../helpers/user.helper';
import { IUserBasicLoginData } from '../../models/login.response';
import { ILink, IPage, IPageLink, LinkType } from '../../models/site.response';
import { ResizeService } from '../../services/resize.service';
import { SiteService } from '../../services/site.service';
import { UserEventService } from '../../services/user-event.service';
import { ScreenSize } from '../resize-detector/resize-detector.model';

@Component({
  selector: 'air-header',
  templateUrl: './header.component.html',
  standalone: false
})
export class HeaderComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChildren(NavigationComponent) navigationComponents: QueryList<NavigationComponent>;
  @ViewChild('personalNavigationTrigger') set content(content: Element) {
    this.personalNavigationTrigger = content;
  }
  @ViewChild('personalNavigation') personalNavigation: NavigationComponent;
  @ViewChild('searchBar', { read: ElementRef }) searchBar: ElementRef<HTMLDivElement>;

  isVisible: boolean;
  isInMaintenance: boolean;
  currentScreenSize: ScreenSize;

  loading: boolean;
  personalNavigationTrigger: Element;
  publicMenuLinks: ILink[] = [];
  personalMenuLinks: ILink[] = [];
  userEventSource = UserEventSource;

  currentUser?: IUserBasicLoginData;
  isLoggedIn: boolean;
  showSkipToMainContent = false;

  completeProfilePage?: IPage;
  loginSuccessPage?: IPage;

  promotionsPageUrl?: string;
  unactivatedPromotionsCount: number;
  inboxPageUrl?: string;
  unreadInboxCount: number;

  destroy$ = new Subject();

  constructor(
    private siteService: SiteService,
    private router: Router,
    private modalLoginHelper: ModalLoginHelper,
    private userHelper: UserHelper,
    private translateService: TranslateService,
    private pageService: PageService,
    private cdRef: ChangeDetectorRef,
    private userEventService: UserEventService,
    private searchService: SearchService,
    private promotionHelper: PromotionHelper,
    private inboxHelper: InboxHelper,
    private resizeService: ResizeService
  ) {}

  get isSearchActive(): boolean {
    return this.searchService.active$.getValue();
  }

  get showPromotionsNotification(): boolean {
    return this.isLoggedIn && this.unactivatedPromotionsCount > 0 && !!this.promotionsPageUrl?.length;
  }

  get showUnreadInboxNotification(): boolean {
    if ((this.currentScreenSize === ScreenSize.sm || this.currentScreenSize === ScreenSize.xsm) && this.showPromotionsNotification) {
      return false;
    }

    return this.isLoggedIn && this.unreadInboxCount > 0 && !!this.inboxPageUrl?.length;
  }

  ngOnInit(): void {
    this.loading = true;

    // Wait for page data to finish loading too
    combineLatest([this.siteService.pageContext, this.pageService.pageData$])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([data, pageData]) => {
        if (!pageData) {
          return;
        }
        this.isVisible = !!data;
        this.isInMaintenance = this.siteService.isInMaintenance;
        if (data !== undefined && pageData !== undefined) {
          this.loading = false;
          this.cdRef.detectChanges();
        }
        this.personalMenuLinks = data?.personalMenuLinks ? (ObjectHelper.deepCopy(data.personalMenuLinks) as ILink[]) : [];
        this.publicMenuLinks = data?.publicMenuLinks ? [...data.publicMenuLinks] : [];
        void this.addLogoutButton();

        this.completeProfilePage = data?.completeProfilePage;
        this.loginSuccessPage = data?.loginSuccessPage;

        this.promotionsPageUrl = data?.promotionsPage?._url;

        this.inboxPageUrl = data?.inboxPage?._url;
      });

    this.userHelper.currentUser$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((user) => {
      this.currentUser = user;
      this.isLoggedIn = this.userHelper.isUserLoggedIn();
      this.cdRef.detectChanges();
    });

    // On route, close all open navigation elements
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof ActivationStart) {
        this.navigationComponents.forEach((navigation) => {
          navigation.close();
        });
      }
    });

    this.resizeService.onResize$.pipe(takeUntil(this.destroy$)).subscribe((size) => {
      this.currentScreenSize = size;
    });

    this.promotionHelper.unactivatedPromotionsCount$.pipe(takeUntil(this.destroy$)).subscribe((numberOfUnactivatedPromotions) => {
      this.unactivatedPromotionsCount = numberOfUnactivatedPromotions;
    });

    this.inboxHelper.unreadInboxCount$.pipe(takeUntil(this.destroy$)).subscribe((unreadInboxCount) => {
      this.unreadInboxCount = unreadInboxCount;
    });
  }

  ngAfterViewChecked(): void {
    this.showSkipToMainContent = document.querySelector('#main-content') !== null;
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async addLogoutButton(): Promise<void> {
    const logoutLabel = (await this.translateService.get('general.label.logout').toPromise()) as string;

    const logoutLinkItem = {
      contentTypeAlias: LinkType.pageLink,
      label: logoutLabel,
      icon: 'ui-logout',
      url: this.router.createUrlTree(['logout']).toString()
    } as IPageLink;

    this.personalMenuLinks.push({
      links: [logoutLinkItem]
    } as ILink);
  }

  onPersonalButtonClick(event: Event): void {
    if (!this.isLoggedIn) {
      this.userEventService.pushEvent(this.userEventSource.personalMenu, UserEventAction.link, event.text(), 'login');

      this.triggerLoginModal();
    } else {
      this.personalNavigation.open();
    }
  }

  onSearchButtonClick(): void {
    this.userEventService.pushEvent(this.userEventSource.search, UserEventAction.open);
    this.searchService.active$.next(true);
    setTimeout(() => {
      document.querySelector<HTMLInputElement>('#search-query')?.focus();
    }, 0);
  }

  skipToMainContent(): void {
    let element: HTMLElement | null = null;

    if (this.resizeService.getCurrentSize() === ScreenSize.xsm || this.resizeService.getCurrentSize() === ScreenSize.sm) {
      element = document.querySelector<HTMLElement>('.nav--personal-page--mobile');
    } else {
      element = document.querySelector<HTMLElement>('.nav--personal-page');
    }
    if (!element) {
      element = document.querySelector<HTMLElement>('#main-content');
    }

    element?.focus();
    element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  private triggerLoginModal(): void {
    void this.modalLoginHelper.triggerPasswordLoginModal(
      this.userEventSource.personalMenu,
      undefined,
      () => {
        if (this.loginSuccessPage && this.userHelper.isLoggedIn) {
          void this.router.navigate([this.loginSuccessPage._url]);
        }
      },
      undefined,
      this.completeProfilePage,
      this.loginSuccessPage
    );
  }
}
