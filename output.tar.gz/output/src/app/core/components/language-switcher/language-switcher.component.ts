import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { flagsForLanguage } from '../../helpers/translation.helper';
import { IExternalLanguage } from '../../models/external-language.model';
import { ExternalTranslateService } from '../../services/external-translate.service';

@Component({
  selector: 'air-language-switcher',
  templateUrl: './language-switcher.component.html',
  standalone: false
})
export class LanguageSwitcherComponent implements OnInit, OnDestroy {
  destroy$ = new Subject();
  languages: IExternalLanguage[] = [];
  languageControl = new FormControl<string>('nl');

  constructor(private externalTranslateService: ExternalTranslateService) {}

  ngOnInit(): void {
    this.externalTranslateService.languages$.pipe(takeUntil(this.destroy$)).subscribe((languages) => {
      this.languages = languages;
    });
    this.externalTranslateService.savedLanguage$.pipe(takeUntil(this.destroy$)).subscribe((savedLanguage) => {
      this.languageControl.setValue(savedLanguage);
    });
    this.languageControl.valueChanges.pipe(takeUntil(this.destroy$)).subscribe((language) => {
      this.externalTranslateService.changeLanguage(language ?? 'nl');
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  getFlagCode(language: string): string {
    return flagsForLanguage[language] ?? 'xx';
  }

  trackLanguage(index: number, language: IExternalLanguage) {
    return language.code;
  }
}
