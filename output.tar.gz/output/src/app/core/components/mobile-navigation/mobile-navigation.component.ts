import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivationStart, Router } from '@angular/router';
import { Subject, combineLatest } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { PageService } from 'src/app/features/page/page.service';
import { NavigationComponent } from '../../../shared/components/navigation/navigation.component';
import { AnimationStates, animationSheetUp } from '../../animations/sheet.animations';
import { UserEventSource } from '../../constants/user-event.constants';
import { ObjectHelper } from '../../helpers/object.helper';
import { PlatformHelper } from '../../helpers/platform.helper';
import { Channel } from '../../models/content.model';
import { ILink } from '../../models/site.response';
import { SiteService } from '../../services/site.service';

@Component({
  selector: 'air-mobile-navigation',
  templateUrl: './mobile-navigation.component.html',
  animations: [animationSheetUp],
  standalone: false
})
export class MobileNavigationComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(NavigationComponent) set navigationComponent(component: NavigationComponent) {
    if (component) {
      this.navigationComponentRef = component;
      this.navigationComponentRef.isOpen$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((isOpen) => {
        this.toggleChat(isOpen);
      });
    }
  }
  @ViewChild(NavigationComponent, { read: ElementRef }) set navigationElement(element: ElementRef<HTMLElement>) {
    if (!this.navigationComponentRef) {
      return;
    }

    if (element) {
      // To fix correct cleanup of bound manual eventListeners, bind them and store in references for correct removal.
      this.boundTouchEndHandler = this.onTouchEnd.bind(this) as EventListenerOrEventListenerObject;

      this.navigationElementRef = element.nativeElement;
      this.navigationElementRef.addEventListener('click', this.boundTouchEndHandler);
    } else {
      if (this.boundTouchEndHandler) {
        this.navigationElementRef.removeEventListener('click', this.boundTouchEndHandler);
        this.boundTouchEndHandler = undefined;
      }
    }
  }

  isInit: boolean;
  mobileMenuLinks: ILink[] = [];
  navigationComponentRef: NavigationComponent;
  navigationElementRef: HTMLElement;
  animationState: string = AnimationStates.closed;
  userEventSource = UserEventSource.mobileMenu;

  boundTouchEndHandler?: EventListenerOrEventListenerObject;
  boundMouseEventHandler: EventListenerOrEventListenerObject;

  destroy$ = new Subject();

  constructor(
    private element: ElementRef<HTMLElement>,
    private siteService: SiteService,
    private pageService: PageService,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    combineLatest([this.siteService.pageContext, this.pageService.pageData$])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([data, pageData]) => {
        if (!pageData) {
          return;
        }
        const channel = PlatformHelper.isNativeMobile ? Channel.app : Channel.web;
        let mobileMenuLinks: ILink[] = [];

        this.isInit = !!data && !!pageData;
        this.cdRef.detectChanges();
        this.animationState = AnimationStates.open;

        if (pageData.pageTheme) {
          const [pageTheme] = ObjectHelper.wrapFieldToArray(pageData.pageTheme);
          mobileMenuLinks = pageTheme.mobileMenuLinks ? [...pageTheme.mobileMenuLinks] : [];
        } else {
          mobileMenuLinks = data?.mobileMenuLinks ? [...data.mobileMenuLinks] : [];
        }

        this.mobileMenuLinks = mobileMenuLinks.filter((link) => !link.channels?.length || link.channels.includes(channel));
      });

    // On route, remove nav--open class to hide all open navigation elements
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof ActivationStart) {
        this.navigationComponentRef?.close();
      }
    });
  }

  ngAfterViewInit(): void {
    // To fix correct cleanup of bound manual eventListeners, bind them and store in references for correct removal.
    this.boundMouseEventHandler = this.onMouseEvent.bind(this) as EventListenerOrEventListenerObject;

    this.element.nativeElement.addEventListener('mouseover', this.boundMouseEventHandler, true);
    this.element.nativeElement.addEventListener('mouseout', this.boundMouseEventHandler, true);
  }

  toggleChat(isOpen: boolean): void {
    const chatLauncher = document.querySelector('body');
    if (chatLauncher) {
      if (isOpen) {
        chatLauncher.classList.add('mobile-nav--open');
      } else {
        chatLauncher.classList.remove('mobile-nav--open');
      }
    }
  }

  onMouseEvent(event: Event): void {
    event.stopPropagation();
    event.preventDefault();
  }

  onTouchEnd(event: Event): void {
    const currentTarget = event.currentTarget;
    setTimeout(() => {
      const openSections = (currentTarget as HTMLElement).querySelectorAll('.section--open');
      if (!openSections || Array.from(openSections).length === 0) {
        this.navigationComponentRef.close();
      } else {
        this.navigationComponentRef.open();
        this.navigationComponentRef.cdRef.detectChanges();
      }
    }, 20);
  }

  ngOnDestroy(): void {
    if (this.navigationElementRef && this.boundTouchEndHandler) {
      this.navigationElementRef.removeEventListener('touchend', this.boundTouchEndHandler, true);
    }
    this.element.nativeElement.removeEventListener('mouseover', this.boundMouseEventHandler, true);
    this.element.nativeElement.removeEventListener('mouseout', this.boundMouseEventHandler, true);
    this.destroy$.next(void 0);
  }
}
