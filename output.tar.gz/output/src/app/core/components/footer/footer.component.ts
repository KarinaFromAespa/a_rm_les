import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, Subscription, combineLatest } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ILink, PageTheme } from 'src/app/core/models/site.response';
import { SiteService } from 'src/app/core/services/site.service';
import { PageService } from 'src/app/features/page/page.service';
import { UserEventSource } from '../../constants/user-event.constants';
import { ObjectHelper } from '../../helpers/object.helper';
import { IText } from '../../models/content.model';

@Component({
  selector: 'air-footer',
  templateUrl: './footer.component.html',
  standalone: false
})
export class FooterComponent implements OnInit, OnDestroy {
  isVisible: boolean;
  footerLinks?: ILink[];
  footerText?: IText;
  policyLinks?: ILink[];
  theme?: PageTheme;
  userEventSource = UserEventSource.footer;

  pageContextSubscription: Subscription;
  destroy$ = new Subject();

  get year(): string {
    return new Date().getFullYear().toString();
  }

  constructor(
    private siteService: SiteService,
    private pageService: PageService
  ) {}

  ngOnInit(): void {
    combineLatest([this.siteService.pageContext, this.pageService.pageData$])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([data, pageData]) => {
        if (data === undefined || !pageData) {
          return;
        }

        this.isVisible = !!data && !!pageData && !this.siteService.isInMaintenance;
        if (pageData?.pageTheme) {
          const [pageTheme] = ObjectHelper.wrapFieldToArray(pageData.pageTheme);
          this.theme = pageTheme.theme;
          this.footerText = pageTheme.footerText;
          this.footerLinks = pageTheme.footerLinks;
          this.policyLinks = pageTheme.policyLinks;
        } else {
          this.theme = undefined;
          this.footerText = undefined;
          this.footerLinks = data?.footerLinks;
          this.policyLinks = data?.policyLinks;
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
