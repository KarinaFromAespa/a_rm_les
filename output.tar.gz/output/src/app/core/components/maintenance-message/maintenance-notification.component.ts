import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchService } from 'src/app/features/search/search.service';
import { animationSheetCollapse, AnimationStates } from '../../animations/sheet.animations';
import { UserEventAction, UserEventSource } from '../../constants/user-event.constants';
import { StringHelper } from '../../helpers/string.helper';
import { SiteService } from '../../services/site.service';
import { UserEventService } from '../../services/user-event.service';

@Component({
  selector: 'air-maintenance-notification',
  templateUrl: './maintenance-notification.component.html',
  animations: [animationSheetCollapse],
  standalone: false
})
export class MaintenanceNotificationComponent implements OnInit, AfterViewInit {
  isVisible: boolean;
  message: string;
  animationState = AnimationStates.closed;
  userEventSource = UserEventSource.maintenanceNotification;

  destroy$ = new Subject();

  constructor(
    private siteService: SiteService,
    private userEventService: UserEventService,
    private searchService: SearchService
  ) {}

  ngOnInit(): void {
    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((pageContext) => {
      if (pageContext) {
        this.message = pageContext.maintenanceMessage;
        this.isVisible = !StringHelper.isEmpty(this.message);
      }
    });
  }

  ngAfterViewInit(): void {
    this.animationState = AnimationStates.open;
  }

  closeNotification(): void {
    this.userEventService.pushEvent(this.userEventSource, UserEventAction.close);
    this.animationState = AnimationStates.closed;
  }
}
