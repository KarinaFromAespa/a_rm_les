import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AppTrackingTransparency } from 'capacitor-plugin-app-tracking-transparency';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AnimationStates, animationSheetUp } from '../../animations/sheet.animations';
import { UserEventAction, UserEventSource } from '../../constants/user-event.constants';
import { CookieConsentHelper } from '../../helpers/cookie-consent.helper';
import { PlatformHelper } from '../../helpers/platform.helper';
import { IText } from '../../models/content.model';
import { ConsentService } from '../../services/consent.service';
import { SiteService } from '../../services/site.service';
import { UserEventService } from '../../services/user-event.service';

@Component({
  selector: 'air-app-consent-sheet',
  templateUrl: './app-consent-sheet.component.html',
  animations: [animationSheetUp],
  standalone: false
})
export class AppConsentSheetComponent implements OnInit, OnDestroy {
  accept: boolean;
  label: string;
  appConsentData?: IText;
  isLoading = true;
  isAppConsented: boolean;
  animationState: string = AnimationStates.closed;
  userEventSource = UserEventSource.consentSheet;

  destroy$ = new Subject();

  constructor(
    private siteService: SiteService,
    private cookieConsentHelper: CookieConsentHelper,
    private consentService: ConsentService,
    private platformHelper: PlatformHelper,
    private translateService: TranslateService,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.label = this.translateService.instant('general.label.i_give_permission') as string;
      this.appConsentData = data?.appConsent;
      this.isLoading = false;
      void this.checkConsent();
    });

    this.consentService.onConsentSheetToggle$.pipe(takeUntil(this.destroy$)).subscribe((state: AnimationStates) => {
      if (state === this.animationState) {
        return;
      }

      this.animationState = state as string;
    });
  }

  async checkConsent(): Promise<void> {
    this.accept = await this.cookieConsentHelper.allCookiesAccepted();
    this.isAppConsented = await this.cookieConsentHelper.functionalCookiesAccepted();

    if (!this.isAppConsented) {
      if (this.platformHelper.isiOSNative) {
        const { status } = await AppTrackingTransparency.getStatus();
        if (status === 'denied' || status === 'restricted') {
          await this.cookieConsentHelper.setCookieConsentValue(false);
          this.isAppConsented = true;
          return;
        }
      }

      this.accept = true;
      this.consentService.open();
    }
  }

  onToggleChange(): void {
    this.pushUserEvent(UserEventAction.set, this.label, this.accept.toString());
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async close(): Promise<void> {
    this.pushUserEvent(UserEventAction.close);

    if (this.accept) {
      // On iOS, it is mandatory to (also) use the native App Tracking Transparency framework to request permission.
      if (this.platformHelper.isiOSNative) {
        const status = await AppTrackingTransparency.requestPermission();
        this.accept = status.status === 'authorized';
        this.userEventService.pushEvent(
          `${this.userEventSource} - app tracking transparency`,
          UserEventAction.set,
          undefined,
          this.accept.toString()
        );
      }
    }

    await this.cookieConsentHelper.setCookieConsentValue(this.accept);
    this.isAppConsented = true;
    this.consentService.close();
  }

  private pushUserEvent(action: UserEventAction, label?: string, value?: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, label, value);
  }
}
