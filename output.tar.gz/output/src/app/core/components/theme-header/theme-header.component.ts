import { Component, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { ActivationStart, Router } from '@angular/router';
import { Subject, combineLatest } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PageService } from 'src/app/features/page/page.service';
import { NavigationComponent } from 'src/app/shared/components/navigation/navigation.component';
import { UserEventSource } from '../../constants/user-event.constants';
import { ObjectHelper } from '../../helpers/object.helper';
import { ILink } from '../../models/site.response';
import { ScrollService } from '../../services/scroll.service';
import { SiteService } from '../../services/site.service';

@Component({
  selector: 'air-theme-header',
  templateUrl: './theme-header.component.html',
  standalone: false
})
export class ThemeHeaderComponent implements OnInit, OnDestroy {
  @ViewChildren(NavigationComponent) navigationComponents: QueryList<NavigationComponent>;
  isVisible: boolean;
  loading: boolean;
  publicMenuLinks: ILink[] = [];
  isScrolling = false;
  theme: string;
  themeHomePageUrl?: string;
  userEventSource = UserEventSource.themeMenu;

  destroy$ = new Subject();

  constructor(
    private siteService: SiteService,
    private router: Router,
    private scrollService: ScrollService,
    private pageService: PageService
  ) {}

  ngOnInit(): void {
    this.loading = true;

    combineLatest([this.siteService.pageContext, this.pageService.pageData$])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([data, pageData]) => {
        if (data === undefined || !pageData) {
          this.loading = false;
          return;
        }

        this.isVisible = !!data && !!pageData;

        if (pageData?.pageTheme) {
          const [pageTheme] = ObjectHelper.wrapFieldToArray(pageData.pageTheme);
          this.publicMenuLinks = pageTheme.publicMenuLinks ? [...pageTheme.publicMenuLinks] : [];

          this.themeHomePageUrl = pageTheme.homePage._url;
        } else {
          this.publicMenuLinks = data?.publicMenuLinks ? [...data.publicMenuLinks] : [];
        }
        this.loading = false;
      });

    // On route, close all open navigation elements
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof ActivationStart) {
        this.navigationComponents.forEach((navigation) => {
          navigation.close();
        });
      }
    });

    this.scrollService.onScroll$.pipe(takeUntil(this.destroy$)).subscribe((scrollTop: number) => {
      this.isScrolling = scrollTop > 0;
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
