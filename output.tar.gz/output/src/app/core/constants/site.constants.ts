import { InjectionToken } from '@angular/core';

export const WINDOW_TOKEN = new InjectionToken<Window>('Window');
export const windowFactory = (): Window => window;

export const NAVIGATOR_TOKEN = new InjectionToken<Navigator>('Navigator');
export const navigatorFactory = (): Navigator => navigator;

export class SiteConstants {
  public static consentCookieName = 'air_consent_cookie';
  public static nonceCookieName = 'nonce';
  public static gaCookieName = '_ga';
  public static googleTranslateCookieName = 'googtrans';
  public static userStorageName = 'user';
  public static xsrfHeaderName = 'X-XSRF-TOKEN';
  public static rootRoute = '/home';
  public static wideContentTypes = [
    'actionList',
    'cardList',
    'highlightedProducts',
    'productOverview',
    'transactions',
    'vouchers',
    'expirations',
    'featuredProducts',
    'inbox'
  ];
  public static indexedContentTypes = ['page', 'plainPage', 'partner', 'product', 'combinedProduct'];
  public static promotionCountStorageName = 'promotion-count';
  public static unreadInboxCountStorageName = 'unread-inbox-count';
  public static biometricsPreferencesStorageName = 'biometrics-accepted';
  public static biometricsCancelCountStorageName = 'biometrics-cancel-count';
  public static purchaseStorageName = 'purchase';
  public static externalTranslateLanguageStorageName = 'external-translate-language';
  public static deviceRegisteredStorageName = 'device-registered';
}
