export enum AuthorizationLevel {
  basic = 'Basic',
  password = 'Password',
  twoFactor = 'TwoFactor'
}
