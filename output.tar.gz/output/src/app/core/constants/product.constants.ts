export enum ProductType {
  product = 'product',
  combinedProduct = 'combinedProduct',
  externalProduct = 'externalProduct',
  charity = 'charity',
  card = 'card',
  importedCard = 'importedCard',
  physicalProduct = 'physicalProduct'
}

export enum ProductVariantMode {
  multicount = 'multicount',
  select = 'select'
}
