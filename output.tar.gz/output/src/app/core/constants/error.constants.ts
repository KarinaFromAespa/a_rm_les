export enum StatusCode {
  notFound = 404,
  permanentRedirect = 301
}

export enum HttpErrorCodes {
  badRequest = '400_1',
  invalidCardForEnrollment = '400_2',
  invalidAddress = '400_4',
  insufficientFunds = '400_7',
  invalidAccountForTransfer = '400_8',

  loginRequired = '401_1',
  twoFactorLoginRequired = '401_2',
  twoFactorUpgradeRequired = '401_3',

  forbidden = '403_1',
  invalidCredentials = '403_2',
  invalidAccount = '403_3',
  invalidPassword = '403_4',
  invalidVerificationCode = '403_7',
  insufficientReCaptchaScore = '403_9',
  invalidPasswordSetVerificationCode = '403_10',

  notFound = '404_1',
  accountNotFound = '404_2',

  tooManyRequests = '429_1',

  serverError = '500',
  internalServerError = '500_0',
  internalServerTimeout = '500_1'
}

export const ERROR_CODES_WITH_MESSAGES = [400, 401, 403, 404, 429, 500, 502, 504];
export const SUPPRESS_ERROR_CODE_MESSAGES = [
  HttpErrorCodes.loginRequired,
  HttpErrorCodes.twoFactorLoginRequired,
  HttpErrorCodes.twoFactorUpgradeRequired,
  HttpErrorCodes.insufficientReCaptchaScore
];
