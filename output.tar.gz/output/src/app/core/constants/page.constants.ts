export enum PageType {
  page = 'page',
  plainPage = 'plainPage',
  partnerPage = 'partner',
  supplierPage = 'supplier',
  productPage = 'product',
  productPageCombined = 'combinedProduct',
  personalPageBasic = 'personalPageBasic',
  personalPagePassword = 'personalPagePassword',
  personalPageTwoFactor = 'personalPageTwoFactor',
  ticketTemplatePage = 'ticketTemplate',
  campaignPage = 'campaign',
  pageContext = 'pageContext',
  charity = 'charity',
  maintenancePage = 'maintenancePage',
  embeddedPage = 'embeddedPage'
}
