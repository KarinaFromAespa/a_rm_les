export enum UserEventCategory {
  // Based on the Umbraco page type.
  public = 'public',
  personal = 'personal',
  campaign = 'campaign',
  charity = 'charity',
  product = 'product',
  partner = 'partner',
  supplier = 'supplier'
}

// By default event sources are set automatically based on a component's Umbraco contentTypeAlias and content block region.
// However, not all components originate from Umbraco. In those cases the event source is chosen from the values below.
export enum UserEventSource {
  hero = 'hero',
  breadcrumb = 'breadcrumb',
  footer = 'footer',
  publicMenu = 'public menu',
  personalMenu = 'personal menu',
  heroMenu = 'hero menu',
  mobileMenu = 'mobile menu',
  themeMenu = 'theme menu',
  consentSheet = 'consent sheet',
  partnerLogos = 'partner logos',
  highlightedProducts = 'highlighted products',
  cardDetails = 'card details',
  recentTransactions = 'recent transactions',
  details = 'details',
  maintenanceNotification = 'maintenance notification',
  carousel = 'carousel',
  toast = 'toast',
  search = 'search',
  page = 'page',
  pushService = 'push service'
}

export enum UserEventAction {
  view = 'view',
  link = 'link',
  download = 'download',
  submit = 'submit',
  confirm = 'confirm',
  cancel = 'cancel',
  open = 'open',
  close = 'close',
  sort = 'sort',
  sortAscending = 'sort ascending',
  sortDescending = 'sort descending',
  filter = 'filter',
  paging = 'paging',
  set = 'set',
  typing = 'typing',
  error = 'error',
  add = 'add',
  remove = 'remove',
  success = 'success'
}
