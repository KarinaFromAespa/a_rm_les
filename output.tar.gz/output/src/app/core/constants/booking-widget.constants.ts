export enum BookingWidgetType {
  searchBox = 'Search box',
  inspiringSearchBox = 'Inspiring search box',
  map = 'Map'
}
