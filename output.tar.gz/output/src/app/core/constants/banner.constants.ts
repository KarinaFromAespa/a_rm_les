export enum BannerTheme {
  redLight = 'red-light',
  pink = 'pink'
}
