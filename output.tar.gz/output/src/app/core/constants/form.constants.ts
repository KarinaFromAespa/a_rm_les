export enum FormValidatorTypeKeys {
  required = 'required',
  email = 'email',
  pattern = 'pattern',
  minLength = 'minlength',
  maxLength = 'maxlength',
  repeat = 'repeat',
  birthDate = 'birthDate',
  birthDateMinimum = 'birthDateMinimum',
  checkUserExistence = 'checkUserExistence',
  checkPhoneNumberExistence = 'checkPhoneNumberExistence',
  checkCardStatus = 'checkCardStatus',
  verificationCode = 'verificationCode',
  getAddressSuggestion = 'getAddressSuggestion',
  verification = 'verification',
  emailAddressOrPattern = 'emailAddressOrPattern',
  passwordRequirements = 'passwordRequirements',
  addressLineAutoComplete = 'addressLineAutoComplete',
  wrapper = 'wrapper'
}

export const repeatErrorPrefix = 'repeat_';
export const repeatControlSuffix = '_repeat';
export const verifyErrorPrefix = 'verify_';
export const verifyControlSuffix = '_verify';

export enum FormType {
  text = 'text',
  date = 'date',
  postalCode = 'postalCode',
  email = 'email',
  phoneNumber = 'phoneNumber',
  password = 'password',
  textarea = 'textarea',
  select = 'select',
  checkbox = 'checkbox',
  radio = 'radio',
  repeat = 'repeat',
  numeric = 'numeric',
  numberOnly = 'numberOnly',
  file = 'file'
}

export enum Gender {
  female = 1,
  male = 2,
  neutral = 3
}

export enum FormBoolean {
  yes = 'yes',
  no = 'no'
}

export enum FormFieldName {
  gender = 'gender',
  firstName = 'firstName',
  lastName = 'lastName',
  birthDate = 'birthDate',
  streetName = 'streetName',
  houseNumber = 'houseNumber',
  houseNumberSupplement = 'houseNumberSupplement',
  postalCode = 'postalCode',
  city = 'city',
  addressChangeDate = 'addressChangeDate',
  emailAddress = 'emailAddress',
  receivePromotionalEmails = 'receivePromotionalEmails',
  phoneNumber = 'phoneNumber',
  password = 'password',
  cardNumber = 'cardNumber',
  hasCard = 'hasCard',
  optIn = 'optIn',
  acceptTerms = 'acceptTerms',
  hasAccount = 'hasAccount',
  question = 'question',
  points = 'points',
  value = 'value',
  verificationCode = 'verificationCode',
  file = 'file',
  message = 'message'
}
