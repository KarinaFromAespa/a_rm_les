export enum CardType {
  customCard = 'customCard'
}
