export enum BarcodeType {
  ean128 = 'EAN-128',
  ean13 = 'EAN-13',
  qr = 'QR'
}
