export enum PaymentFeedbackType {
  failed = 'failed',
  failedPayment = 'failedPayment',
  failedPaymentDeepLink = 'failedPaymentDeepLink',
  failedFunds = 'failedFunds',
  failedAccount = 'failedAccount',
  success = 'success'
}

export enum PaymentIssuerResponseStatus {
  success = 'Success',
  failure = 'Failure',
  expired = 'Expired',
  cancelled = 'Cancelled'
}
