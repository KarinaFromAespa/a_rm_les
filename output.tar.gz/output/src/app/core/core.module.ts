import { CommonModule, registerLocaleData } from '@angular/common';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import localeNL from '@angular/common/locales/nl';
import { LOCALE_ID, NgModule, Optional, SkipSelf } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Brightness } from '@awesome-cordova-plugins/brightness/ngx';
import { IonicModule } from '@ionic/angular';
import { NgxPaginationModule, PaginatePipe } from 'ngx-pagination';
import { ModalModule } from 'src/app/features/modal/modal.module';
import { ToastModule } from 'src/app/features/toasts/toast.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { PaymentModule } from '../features/payment/payment.module';
import { SearchModule } from '../features/search/search.module';
import { MyCardSheetComponent } from '../shared/components/my-card-sheet/my-card-sheet.component';
import { AppConsentSheetComponent } from './components/app-consent-sheet/app-consent-sheet.component';
import { CookieBannerComponent } from './components/cookie-banner/cookie-banner.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { LanguageSwitcherComponent } from './components/language-switcher/language-switcher.component';
import { MaintenanceNotificationComponent } from './components/maintenance-message/maintenance-notification.component';
import { MobileNavigationComponent } from './components/mobile-navigation/mobile-navigation.component';
import { ResizeDetectorComponent } from './components/resize-detector/resize-detector.component';
import { ThemeHeaderComponent } from './components/theme-header/theme-header.component';
import { NAVIGATOR_TOKEN, WINDOW_TOKEN, navigatorFactory, windowFactory } from './constants/site.constants';
import { TokenInterceptor } from './interceptors/token.interceptor';
import { UmbracoInterceptor } from './interceptors/umbraco.interceptor';
import { LayoutComponent } from './layout/layout.component';
import { GraphQLModule } from './services/apollo.config';

registerLocaleData(localeNL);

@NgModule({
  declarations: [
    HeaderComponent,
    ThemeHeaderComponent,
    FooterComponent,
    LayoutComponent,
    CookieBannerComponent,
    AppConsentSheetComponent,
    MobileNavigationComponent,
    ResizeDetectorComponent,
    MyCardSheetComponent,
    MaintenanceNotificationComponent,
    LanguageSwitcherComponent
  ],
  exports: [
    HeaderComponent,
    ThemeHeaderComponent,
    LayoutComponent,
    ResizeDetectorComponent,
    MyCardSheetComponent,
    AppConsentSheetComponent
  ],
  imports: [
    CommonModule,
    GraphQLModule,
    IonicModule,
    NgxPaginationModule,
    RouterModule,
    SharedModule,
    ModalModule,
    ToastModule,
    PaymentModule,
    SearchModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'nl-NL' },
    { provide: HTTP_INTERCEPTORS, useClass: UmbracoInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    { provide: WINDOW_TOKEN, useFactory: windowFactory },
    { provide: NAVIGATOR_TOKEN, useFactory: navigatorFactory },
    Brightness,
    PaginatePipe,
    provideHttpClient(withInterceptorsFromDi())
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import it in the AppModule only');
    }
  }
}
