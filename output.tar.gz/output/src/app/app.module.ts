import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { ErrorHandler, Injector, LOCALE_ID, NgModule, inject, provideAppInitializer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';
import { AppVersion } from '@awesome-cordova-plugins/app-version/ngx';
import { HTTP } from '@awesome-cordova-plugins/http/ngx';
import { SplashScreen } from '@capacitor/splash-screen';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { Drivers } from '@ionic/storage';
import { IonicStorageModule } from '@ionic/storage-angular';
import { ApplicationinsightsAngularpluginErrorService } from '@microsoft/applicationinsights-angularplugin-js';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { RECAPTCHA_LANGUAGE, RECAPTCHA_SETTINGS, RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module } from 'ng-recaptcha-2';
import { Observable, from } from 'rxjs';
import 'src/app/core/extensions/array.extensions';
import 'src/app/core/extensions/event.extensions';
import 'src/app/core/extensions/form-control.extensions';
import 'src/app/core/extensions/string.extensions';
import { environment } from 'src/environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { ChatService } from './core/services/chat.service';
import { GtmService } from './core/services/gtm.service';
import { InsightsService } from './core/services/insights.service';
import { SiteService } from './core/services/site.service';
import { VwoService } from './core/services/vwo.service';
import { ModalModule } from './features/modal/modal.module';
import { ToastModule } from './features/toasts/toast.module';

// required for AOT compilation
const siteSettings =
  (siteService: SiteService, gtmService: GtmService, insightsService: InsightsService, vwoService: VwoService, chatService: ChatService) =>
  async () => {
    try {
      await siteService.loadSiteSettings();
      gtmService.addSnippet();
      await vwoService.load();
      await insightsService.load();
      await chatService.load();
    } catch {
      void SplashScreen.hide();
      console.warn('Could not load site settings!');
    }
  };

// TypeError: D.animate is not a function
// https://github.com/angular/angular/issues/45016
const disableAnimations =
  !('animate' in document.documentElement) || (navigator && /(iPhone OS|iPad; CPU OS) (8|9|10|11|12|13)_/.test(navigator.userAgent));

class WebpackTranslateLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return from(import(`../assets/i18n/${lang}.json`));
  }
}

@NgModule({
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    ModalModule,
    ToastModule,
    RecaptchaV3Module,
    IonicModule.forRoot({
      statusTap: true,
      scrollAssist: true
    }),
    IonicStorageModule.forRoot({
      name: '_db',
      driverOrder: [Drivers.LocalStorage, Drivers.IndexedDB]
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: WebpackTranslateLoader
      }
    }),
    BrowserAnimationsModule.withConfig({ disableAnimations })
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    { provide: ErrorHandler, useClass: ApplicationinsightsAngularpluginErrorService },
    provideAppInitializer(() => {
      const initializerFn = siteSettings(
        inject(SiteService),
        inject(GtmService),
        inject(InsightsService),
        inject(VwoService),
        inject(ChatService)
      );
      return initializerFn();
    }),
    HTTP,
    AppVersion,
    { provide: RECAPTCHA_V3_SITE_KEY, useValue: environment.reCaptchaSiteKey },
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: { siteKey: environment.alternateReCaptchaSiteKey }
    },
    {
      provide: RECAPTCHA_LANGUAGE,
      useFactory: (locale: string) => locale,
      deps: [LOCALE_ID]
    },
    provideHttpClient(withInterceptorsFromDi())
  ]
})
export class AppModule {
  static appInjector: Injector;

  constructor(private injector: Injector) {
    AppModule.appInjector = this.injector;
  }
}
