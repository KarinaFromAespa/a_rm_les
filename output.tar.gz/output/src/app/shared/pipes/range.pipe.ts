import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'range',
  pure: false,
  standalone: false
})
export class RangePipe implements PipeTransform {
  transform(items: any[], range: number): any {
    items.length = 0;
    for (let i = 0; i < range; i++) {
      items.push(i);
    }
    return items as [];
  }
}
