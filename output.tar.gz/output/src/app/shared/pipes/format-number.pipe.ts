import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatNumber',
  standalone: false
})
export class FormatNumberPipe implements PipeTransform {
  transform(value?: number, absolute = false): string {
    if (value === undefined || value === null) {
      return '';
    }

    if (absolute) {
      value = Math.abs(value);
    }

    return value.toLocaleString('nl-NL');
  }
}
