import { Pipe, PipeTransform } from '@angular/core';
import orderBy from 'lodash-es/orderBy';
import { SortOrder } from 'src/app/core/helpers/sorter.helper';

@Pipe({
  name: 'sortBy',
  pure: false,
  standalone: false
})
export class SortByPipe implements PipeTransform {
  constructor() {}

  transform(value: unknown[], column: string, order = true): unknown[] {
    const orderStr = order ? SortOrder.asc : SortOrder.desc;
    if (!value || !column || column === '') {
      return value;
    }
    if (value.length <= 1) {
      return value;
    }

    return orderBy(value, [column], [orderStr]);
  }
}
