import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'currency',
  standalone: false
})
export class CurrencyPipe implements PipeTransform {
  transform(value: number): string {
    if (value === undefined || value === null) {
      return '';
    }

    return Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' })
      .format(value)
      .replace(',00', '')
      .replace(/\u00a0/, '');
  }
}
