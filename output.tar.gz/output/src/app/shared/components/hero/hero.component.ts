import { AfterViewInit, Component, HostListener, Input, OnInit } from '@angular/core';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { IHero } from 'src/app/core/models/page.response';
import { ResizeService } from 'src/app/core/services/resize.service';
import { SiteService } from 'src/app/core/services/site.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import xss from 'xss';

@Component({
  selector: 'air-hero',
  templateUrl: './hero.component.html',
  standalone: false
})
export class HeroComponent implements OnInit, AfterViewInit {
  @Input() content?: IHero;
  @Input() showPartnersList = false;
  @Input() loading = false;
  @Input() additionalHeroes?: IHero[];
  @Input() accessibleLabel?: string;

  userEventSource = `${UserEventSource.hero}[1]`;
  isInMaintenance = this.siteService.isInMaintenance;
  heroes: IHero[] = [];

  private originalText = '';

  constructor(
    private siteService: SiteService,
    private resizeService: ResizeService,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    const heroes: IHero[] = [];
    if (this.content) {
      heroes.push(this.content);
    }
    if (this.additionalHeroes) {
      heroes.push(...this.additionalHeroes);
    }
    this.heroes = heroes;
  }

  ngAfterViewInit(): void {
    const bodyText = document.querySelector<HTMLElement>('.hero__body-text > p');
    this.originalText = bodyText?.innerText ?? '';
    void this.wrapBodyText();
  }

  @HostListener('window:resize')
  onResize(): void {
    void this.wrapBodyText();
  }

  public onHeroChange(index: number) {
    this.userEventSource = `${UserEventSource.hero}[${index + 1}]`;

    if (this.heroes?.[index]?.title) {
      this.pushUserEvent(UserEventAction.view, this.heroes[index].title);
    }
  }

  private async wrapBodyText(): Promise<void> {
    if (!document.documentElement.classList.contains('theme--shell')) {
      return;
    }

    const bodyText = document.querySelector<HTMLElement>('.hero__body-text > p');
    if (bodyText && this.resizeService.getCurrentSize() > ScreenSize.sm) {
      bodyText.style.visibility = 'hidden';
      await this.recursivelyWrapBodyText(bodyText, this.computeNumberOfLines(bodyText));
      bodyText.style.visibility = 'visible';
    } else if (bodyText) {
      bodyText.innerText = this.originalText ?? '';
    }
  }

  private async recursivelyWrapBodyText(textElement: HTMLElement, numberOfLines: number): Promise<void> {
    if (numberOfLines < 1) {
      return;
    }

    let text = '';
    let height: number | null = null;
    let remainingLines = numberOfLines;
    let heroImageBox: DOMRect | null = null;

    for (const word of this.originalText.split(' ')) {
      const currentText = text;
      text = currentText + ' ' + word;
      const lowestSpanBox = this.setBodyText(textElement, text, remainingLines)?.getBoundingClientRect();
      heroImageBox = heroImageBox ?? document.querySelector<HTMLElement>('.hero__image')?.getBoundingClientRect() ?? null;

      const bodyTextBox = textElement.getBoundingClientRect();
      height = height ?? bodyTextBox.height;

      const leftImageBoundary = heroImageBox && lowestSpanBox ? this.computeLeftImageBoundary(heroImageBox, lowestSpanBox.bottom) : null;
      if ((leftImageBoundary && lowestSpanBox && lowestSpanBox.right > leftImageBoundary) || bodyTextBox.height > height) {
        if (remainingLines > 1) {
          text = currentText + '\n' + word;
          remainingLines -= 1;
        } else {
          await this.recursivelyWrapBodyText(textElement, numberOfLines + 1);
          return;
        }
      }
    }

    this.setBodyText(textElement, text, remainingLines);
  }

  private computeNumberOfLines(element: HTMLElement): number {
    const offsetHeight = +element.offsetHeight;
    const lineHeight = +getComputedStyle(element).getPropertyValue('line-height').replace('px', '');
    return Math.round(offsetHeight / lineHeight);
  }

  private setBodyText(element: HTMLElement, text: string, remainingLines: number): HTMLElement | undefined {
    element.innerHTML = this.textToHtml(text + [...Array<number>(remainingLines - 1)].map(() => '\n').join(''));
    return Array.from(element.querySelectorAll<HTMLElement>('span'))
      .filter((span) => span.innerHTML !== '')
      .at(-1);
  }

  private textToHtml(text: string): string {
    return text
      .split('\n')
      .map((portion) => `<span>${xss(portion)}</span>`)
      .join('<br>');
  }

  private computeLeftImageBoundary(heroImageBox: DOMRect, y: number): number | null {
    const cx = heroImageBox.left + heroImageBox.width / 2;
    const cy = heroImageBox.top + heroImageBox.height / 2;
    const r = heroImageBox.width / 2 + 10;

    if (y < cy - r) {
      return null;
    }

    return cx - r * Math.cos(Math.asin((cy - y) / r));
  }

  private pushUserEvent(action: UserEventAction, label: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, label);
  }
}
