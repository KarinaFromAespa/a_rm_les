import gql from 'graphql-tag';

export const breadcrumbsQuery = gql`
  query GetPageBreadcrumbs($url: String!) {
    content(url: $url) {
      ... on Page {
        title
      }
      ... on PlainPage {
        title
      }
      ... on Product {
        title
      }
      ... on CombinedProduct {
        title
      }
      ... on Campaign {
        title
      }
      ... on Charity {
        title
      }
      ... on Partner {
        title
      }
      ... on Supplier {
        title
      }
      url
      ancestors {
        items {
          ... on Page {
            title
          }
          ... on PlainPage {
            title
          }
          ... on Product {
            title
          }
          ... on CombinedProduct {
            title
          }
          ... on Campaign {
            title
          }
          contentTypeAlias
          url
        }
      }
    }
  }
`;
