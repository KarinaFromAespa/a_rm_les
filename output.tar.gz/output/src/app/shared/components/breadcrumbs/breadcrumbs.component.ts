import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApolloQueryResult } from '@apollo/client/core';
import { Subject, combineLatest, of } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { IBreadcrumbResponse, IPageTheme } from 'src/app/core/models/page.response';
import { IPage, ISimpleLink } from 'src/app/core/models/site.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { SiteService } from 'src/app/core/services/site.service';
import { PageService } from 'src/app/features/page/page.service';
import { breadcrumbsQuery } from './breadcrumbs.query';

@Component({
  selector: 'air-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  standalone: false
})
export class BreadcrumbsComponent implements OnInit, OnDestroy {
  currentPageTitle: string;
  showDots: boolean;
  parent?: ISimpleLink;
  loading: boolean;
  showBreadcrumbs = false;
  userEventSource = UserEventSource.breadcrumb;

  themeData?: IPageTheme;

  destroy$ = new Subject();

  get homePage(): IPage | undefined {
    return this.themeData?.homePage;
  }

  constructor(
    private graphQLService: GraphQLService,
    private siteService: SiteService,
    private router: Router,
    private pageService: PageService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    // If root page, return
    let url = UrlHelper.trimTrailingSlash(this.router.url);
    if (url === '/' || `${url}/` === this.siteService.siteSettings.homePageUrl) {
      return;
    }

    // Get clean url without query params
    url = PageHelper.stripUrl(this.router.url);

    combineLatest([
      this.graphQLService.watchQuery<IBreadcrumbResponse>(breadcrumbsQuery, { url }, true).pipe(
        catchError(() => {
          this.loading = false;
          this.showBreadcrumbs = true;
          return of({ data: null, loading: false } as ApolloQueryResult<null>);
        })
      ),
      this.pageService.pageData$
    ])
      .pipe(takeUntil(this.destroy$))
      .subscribe(([breadcrumbData, pageData]) => {
        if (!breadcrumbData.data || breadcrumbData.data.content === null) {
          return;
        }

        const content = breadcrumbData.data.content;
        const [themeData]: IPageTheme[] = pageData?.pageTheme ? ObjectHelper.wrapFieldToArray(pageData.pageTheme) : [];

        this.themeData = themeData;
        const contentUrl = content.url ? `${UrlHelper.trimTrailingSlash(content.url)}/` : null;
        // Hide if on page not found page or theme homepage

        const homePageUrl = this.homePage?._url;

        if (!contentUrl || contentUrl === this.siteService.siteSettings.errorPageUrl || contentUrl === homePageUrl) {
          return;
        }

        const ancestors: ISimpleLink[] = content.ancestors.items.filter(
          (x: ISimpleLink) => x.url !== homePageUrl && (x.contentTypeAlias === 'page' || x.contentTypeAlias === 'plainPage')
        );
        this.currentPageTitle = content.title;
        this.showDots = ancestors.length > 1;
        this.parent = ancestors.length > 0 ? ancestors[ancestors.length - 1] : undefined;

        this.loading = breadcrumbData.loading;
        this.showBreadcrumbs = true;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
