import { ChangeDetectorRef, Component, ElementRef, HostListener, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { ILink } from 'src/app/core/models/site.response';
import { LinkListComponent } from '../link-list/link-list.component';

@Component({
  selector: 'air-navigation',
  templateUrl: './navigation.component.html',
  standalone: false
})
export class NavigationComponent implements OnInit, OnDestroy {
  @Input() showBackdrop = false;
  @Input() requireLogin = false;
  @ViewChild(LinkListComponent) linkListElement: ElementRef<LinkListComponent>;

  private readonly isOpenSubject = new BehaviorSubject<boolean>(false);
  readonly isOpen$ = this.isOpenSubject.asObservable();

  boundGlobalClickHandler: EventListenerOrEventListenerObject;
  boundNavigationTriggerEnterHandler: EventListenerOrEventListenerObject;
  boundNavigationTriggerLeaveHandler: EventListenerOrEventListenerObject;
  boundNavigationTriggerClickHandler: EventListenerOrEventListenerObject;
  boundNavigationTriggerFocusOutHandler: EventListenerOrEventListenerObject;
  boundNavigationTriggerKeyDownHandler: EventListenerOrEventListenerObject;

  get isOpen(): boolean {
    return this.isOpenSubject.getValue();
  }

  @Input() name = 'default';
  @Input() navClass: string;
  @Input() navigationItems: ILink[];
  @Input() navigationTrigger: Element;
  @Input() userEventSource: string;
  @Input() accessibleLabel: string;

  // Mouse events captures are necessary to enable "closing out" of the :hover state
  @HostListener('mouseover', ['$event'])
  onEnterEvent(): void {
    this.open();
  }
  @HostListener('mouseout', ['$event'])
  onLeaveEvent(): void {
    this.close();
  }

  constructor(
    private element: ElementRef<Node>,
    public cdRef: ChangeDetectorRef,
    private userHelper: UserHelper
  ) {}

  ngOnInit(): void {
    // To fix correct cleanup of bound manual eventListeners, bind them and store in references for correct removal.
    this.boundNavigationTriggerClickHandler = this.onNavigationTriggerClick.bind(this) as EventListenerOrEventListenerObject;
    this.boundNavigationTriggerEnterHandler = this.onNavigationTriggerEnterEvent.bind(this) as EventListenerOrEventListenerObject;
    this.boundNavigationTriggerLeaveHandler = this.onNavigationTriggerLeaveEvent.bind(this) as EventListenerOrEventListenerObject;
    this.boundNavigationTriggerFocusOutHandler = this.onNavigationTriggerFocusOutEvent.bind(this) as EventListenerOrEventListenerObject;
    this.boundNavigationTriggerKeyDownHandler = this.onNavigationKeyDownClick.bind(this) as EventListenerOrEventListenerObject;
    this.boundGlobalClickHandler = this.onGlobalClick.bind(this) as EventListenerOrEventListenerObject;

    // Add here instead of HostListener due to capture phase (true setting).
    document.addEventListener('click', this.boundGlobalClickHandler, true);
    this.element.nativeElement.addEventListener('focusout', this.boundNavigationTriggerFocusOutHandler);

    if (this.navigationTrigger) {
      this.navigationTrigger.addEventListener('mouseover', this.boundNavigationTriggerEnterHandler);
      this.navigationTrigger.addEventListener('mouseout', this.boundNavigationTriggerLeaveHandler);
      this.navigationTrigger.addEventListener('touchend', this.boundNavigationTriggerClickHandler);
      this.navigationTrigger.addEventListener('keydown', this.boundNavigationTriggerKeyDownHandler);
    }
  }

  ngOnDestroy(): void {
    document.removeEventListener('click', this.boundGlobalClickHandler, true);

    if (this.navigationTrigger) {
      this.navigationTrigger.removeEventListener('mouseover', this.boundNavigationTriggerEnterHandler);
      this.navigationTrigger.removeEventListener('mouseout', this.boundNavigationTriggerLeaveHandler);
      this.navigationTrigger.removeEventListener('touchend', this.boundNavigationTriggerClickHandler);
    }
  }

  isInsideNavigation(node: Node): boolean {
    return this.element.nativeElement.contains(node);
  }

  onGlobalClick(event: Event): void {
    // Check if the click target is not a child of this navigation,
    // and there's no navigation trigger or it's not the click target.
    // If that passes, it's a click outside.
    if (
      this.isOpen &&
      !this.element.nativeElement.contains(event.target as Node) &&
      !(this.navigationTrigger && event.target === this.navigationTrigger)
    ) {
      event.stopPropagation();
      event.preventDefault();
      this.close();
    }
  }

  open(): void {
    this.isOpenSubject.next(true);
    this.cdRef.detectChanges();
  }

  close(): void {
    this.onClose();
    this.isOpenSubject.next(false);
    this.cdRef.detectChanges();
  }

  onClose(): void {
    // Close all the remaining open sections as well
    const sections = (this.element.nativeElement as Element).querySelectorAll('.link-list__section');
    Array.from(sections).forEach((section) => {
      section.classList.remove('section--open');
    });
  }

  onNavigationTriggerLeaveEvent(event: Event): void {
    event.stopPropagation();
    event.preventDefault();
    if (!this.isInsideNavigation(event.target as Node)) {
      this.onLeaveEvent();
    }
  }

  onNavigationTriggerFocusOutEvent(): void {
    setTimeout(() => {
      if (!this.element.nativeElement.contains(document.activeElement as Node)) {
        this.close();
      }
    }, 0);
  }

  onNavigationTriggerEnterEvent(): void {
    this.onEnterEvent();
  }

  onNavigationKeyDownClick(event: Event): void {
    const keyboardEvent = event as KeyboardEvent;
    if (keyboardEvent.key === 'Enter' || keyboardEvent.key === ' ') {
      this.onNavigationTriggerClick(event);
    }
  }

  onNavigationTriggerClick(event: Event): void {
    const isLoggedIn = this.userHelper.isLoggedIn;

    if (this.requireLogin && !isLoggedIn) {
      return;
    }

    event.stopPropagation();
    event.preventDefault();
    this.isOpenSubject.next(!this.isOpen);
    this.cdRef.detectChanges();
  }
}
