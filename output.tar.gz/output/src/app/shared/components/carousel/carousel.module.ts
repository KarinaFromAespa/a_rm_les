import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CarouselComponent } from './carousel.component';
import { CarouselSlideDirective } from './carousel.directive';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [CarouselComponent, CarouselSlideDirective],
  imports: [CommonModule, TranslateModule],
  exports: [CarouselComponent, CarouselSlideDirective]
})
export class CarouselModule {}
