import { animate, AnimationBuilder, style } from '@angular/animations';
import {
  AfterContentInit,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  Output,
  QueryList,
  ViewChild
} from '@angular/core';
import AnimationConstants from 'src/app/core/animations/animation.constants';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { CarouselSlideDirective } from './carousel.directive';
import { interval, Subject, Subscription, takeUntil } from 'rxjs';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'carousel',
  templateUrl: './carousel.component.html',
  standalone: false
})
export class CarouselComponent implements AfterContentInit, OnDestroy {
  @ContentChildren(CarouselSlideDirective, { descendants: true }) slides: QueryList<CarouselSlideDirective>;
  @ViewChild('carousel') private carousel: ElementRef;
  @Input() showThumbs = true;
  @Input() list = false;
  @Input() autoSlideInterval?: number;
  @Input() userEventSource: string = UserEventSource.carousel;
  @Output() slideChange = new EventEmitter<number>();

  private _currentSlide: number;
  public get currentSlide(): number {
    return this._currentSlide;
  }

  public set currentSlide(value: number) {
    if (this._currentSlide !== value) {
      this.slideChange.emit(value);
    }

    this._currentSlide = value;
  }

  destroy$ = new Subject<void>();
  slideInterval$: Subscription;
  hasUsedKeyboardFocus = false;
  trackKeyDown = false;

  @HostListener('window:resize')
  onResize(): void {
    this.animateCarousel(true);
  }

  @HostListener('mousedown')
  onKeyDown(): void {
    this.trackKeyDown = true;
  }

  @HostListener('focusin')
  onFocus(): void {
    if (this.trackKeyDown) {
      this.trackKeyDown = false;
      return;
    }

    this.slideInterval$?.unsubscribe();
    this.hasUsedKeyboardFocus = true;
  }

  get hasEnoughSlides(): boolean {
    return this.slides?.length > (this.list ? this.slideCount : 1);
  }

  get slideCount(): number {
    switch (true) {
      case window.innerWidth < 325:
        return 1;
      case window.innerWidth < 768:
        return 3;
      default:
        return 5;
    }
  }

  constructor(
    private animationBuilder: AnimationBuilder,
    private userEventService: UserEventService
  ) {}

  ngAfterContentInit(): void {
    this.currentSlide = 0;
    this.setAutoSlide();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
  }

  previousSlide(): void {
    this.pushUserEvent(UserEventAction.paging, 'previous');

    if (this.currentSlide === 0) {
      this.previousSlideLoop();
      this.setAutoSlide();
      return;
    }

    this.currentSlide = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
    this.animateCarousel();

    this.setAutoSlide();
  }

  nextSlide(): void {
    this.pushUserEvent(UserEventAction.paging, 'next');

    if (this.currentSlide + 1 === this.slides.length) {
      this.nextSlideLoop();
    } else if (this.currentSlide < this.slides.length) {
      this.currentSlide = (this.currentSlide + 1) % this.slides.length;
      this.animateCarousel();
    }

    this.setAutoSlide();
  }

  onThumbClick(event: Event, index: number): void {
    this.pushUserEvent(UserEventAction.paging, (index + 1).toString());
    this.currentSlide = index;
    this.animateCarousel();
    this.setAutoSlide();
  }

  animateCarousel(direct = false): void {
    if (!this.carousel) {
      return;
    }

    const offset = this.currentSlide * this.carousel.nativeElement.children[0].offsetWidth;
    const animationFactory = this.animationBuilder.build([
      style('*'),
      animate(
        `${direct ? 0 : AnimationConstants.baseDuration}ms ${AnimationConstants.baseEasing}`,
        style({
          transform: `translateX(-${offset}px)`
        })
      )
    ]);
    animationFactory.create(this.carousel.nativeElement).play();
  }

  setAutoSlide(): void {
    if (!this.autoSlideInterval || !this.hasEnoughSlides || this.hasUsedKeyboardFocus) {
      return;
    }

    this.slideInterval$?.unsubscribe();

    const interval$ = interval(this.autoSlideInterval);
    this.slideInterval$ = interval$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.currentSlide = (this.currentSlide + 1) % this.slides.length;
      this.animateCarousel(this.currentSlide === 0 && this.list);
    });
  }

  isSlideVisible(index: number): boolean {
    if (!this.list) {
      return index === this.currentSlide;
    }

    return index + 1 >= this.currentSlide && index + 1 <= this.currentSlide + this.slideCount;
  }

  private nextSlideLoop(): void {
    this.currentSlide++;
    this.animateCarousel();

    setTimeout(() => {
      this.currentSlide = 0;
      this.animateCarousel(true);
    }, AnimationConstants.baseDuration + 100);
  }

  private previousSlideLoop(): void {
    this.currentSlide = this.slides.length;
    this.animateCarousel(true);

    this.currentSlide = this.slides.length - 1;
    this.animateCarousel();
  }

  private pushUserEvent(action: UserEventAction, label: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, label);
  }
}
