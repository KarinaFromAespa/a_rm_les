import { Directive, TemplateRef } from '@angular/core';

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[carouselSlide]',
  standalone: false
})
export class CarouselSlideDirective {
  constructor(public template: TemplateRef<unknown>) {}
}
