import { Component, Input } from '@angular/core';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { IActionText } from 'src/app/core/models/content.model';
import { IPageLink } from 'src/app/core/models/site.response';

@Component({
  selector: 'air-action-text',
  templateUrl: './action-text.component.html',
  standalone: false
})
export class ActionTextComponent {
  @Input() actionText: IActionText;
  @Input() userEventSource: string;

  get link(): IPageLink {
    const [pageLink] = ObjectHelper.wrapFieldToArray(this.actionText?.link);
    return pageLink;
  }
}
