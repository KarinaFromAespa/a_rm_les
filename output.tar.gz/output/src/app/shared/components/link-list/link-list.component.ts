import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { Channel } from 'src/app/core/models/content.model';
import { ILink } from 'src/app/core/models/site.response';

@Component({
  selector: 'air-link-list',
  templateUrl: './link-list.component.html',
  standalone: false
})
export class LinkListComponent implements OnInit {
  private _linkLists: ILink[] = [];
  @Input() get linkLists(): ILink[] {
    const channel = PlatformHelper.isNativeMobile ? Channel.app : Channel.web;
    return this._linkLists?.filter((x) => !x.channels?.length || x.channels.includes(channel)) || [];
  }
  set linkLists(value: ILink[]) {
    this._linkLists = value;
  }
  @Input() userEventSource: string;

  @ViewChild('pageLinks') pageLinksRef: TemplateRef<ElementRef>;

  isNavigation = false;

  constructor(private element: ElementRef) {}

  ngOnInit(): void {
    if (this.element.nativeElement.closest('.nav')) {
      this.isNavigation = true;
    }
  }

  onSectionClick(event: Event): void {
    event.stopPropagation();
    const target = (event.currentTarget || event.target) as Element;
    target.classList.toggle('section--open');
    target.setAttribute('aria-expanded', target.classList.contains('section--open').toString());
  }

  onSectionFocusOut(event: FocusEvent): void {
    const target = (event.currentTarget || event.target) as Element;
    const section = target.closest('.link-list__section');
    if (section && !section.contains(event.relatedTarget as Node)) {
      section.classList.remove('section--open');
      target.setAttribute('aria-expanded', 'false');
    }
  }
}
