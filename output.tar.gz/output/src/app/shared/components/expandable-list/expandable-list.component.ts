import { AfterContentInit, Component, ContentChildren, Input, OnDestroy, QueryList } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ExpandableListItemComponent } from './expandable-list-item.component';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'expandable-list',
  templateUrl: './expandable-list.component.html',
  standalone: false
})
export class ExpandableListComponent implements AfterContentInit, OnDestroy {
  @ContentChildren(ExpandableListItemComponent) listItems: QueryList<ExpandableListItemComponent>;
  @Input() userEventSource: string;

  destroy$ = new Subject();
  constructor(private userEventService: UserEventService) {}

  ngAfterContentInit(): void {
    Array.from(this.listItems).forEach((listItem: ExpandableListItemComponent) => {
      // Subscribe to each listItem
      listItem.toggleItem.pipe(takeUntil(this.destroy$)).subscribe(() => {
        this.toggleItem(listItem);
      });
    });
  }

  toggleItem(clickedItem: ExpandableListItemComponent): void {
    this.userEventService.pushEvent(
      this.userEventSource,
      clickedItem.opened ? UserEventAction.close : UserEventAction.open,
      clickedItem.title
    );

    // Toggle the selected panel, and close all the other panels
    Array.from(this.listItems).forEach((listItem) => {
      listItem.opened = listItem === clickedItem ? !listItem.opened : false;
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
