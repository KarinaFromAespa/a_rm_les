import { Location } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { animationExpandCollapse } from 'src/app/core/animations/expand-collapse.animations';
import { RandomHelper } from 'src/app/core/helpers/random.helper';
import { StringHelper } from 'src/app/core/helpers/string.helper';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'expandable-list-item',
  templateUrl: './expandable-list-item.component.html',
  animations: [animationExpandCollapse],
  standalone: false,
  host: {
    '[attr.role]': "'list-item'"
  }
})
export class ExpandableListItemComponent implements OnInit {
  @Input() opened = false;
  @Input() title: string;
  @Output() toggleItem: EventEmitter<void> = new EventEmitter<void>();

  id = RandomHelper.generateRandomId();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private element: ElementRef<HTMLElement>,
    private translateService: TranslateService
  ) {}

  get label(): string {
    return `${this.title} ${this.opened ? this.translateService.instant('general.label.close').toLowerCase() : this.translateService.instant('general.label.open').toLowerCase()}`;
  }

  ngOnInit(): void {
    // Check if the title equals the hash fragment. If so, start opened.
    const safeTitle = StringHelper.toKebabCase(this.title);
    const hash = this.route.snapshot.fragment;
    if (hash && safeTitle === hash.toLowerCase()) {
      this.opened = true;
      // Automatically scroll element in view
      setTimeout(() => {
        this.element.nativeElement.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
      }, 50);
    }
  }

  onItemClick(): void {
    this.toggleItem.emit();

    const url = this.router
      .createUrlTree(['./'], { relativeTo: this.route.parent, fragment: `${StringHelper.toKebabCase(this.title)}` })
      .toString();
    this.location.go(url);
  }
}
