import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { ILink } from 'src/app/core/models/site.response';
import { NavigationComponent } from '../navigation/navigation.component';

@Component({
  selector: 'air-hamburger-navigation',
  templateUrl: './hamburger-navigation.component.html',
  standalone: false
})
export class HamburgerNavigationComponent implements AfterViewInit, OnDestroy {
  @ViewChildren(NavigationComponent, { read: ElementRef }) navigationElements: QueryList<ElementRef>;
  @ViewChild(NavigationComponent) set navigationComponent(component: NavigationComponent) {
    if (component) {
      this.navigationComponentRef = component;
      this.navigationComponentRef.isOpen$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((isOpen) => {
        this.isOpen = isOpen;
      });
    }
  }
  @ViewChild('hamburgerNavigationTrigger') set content(content: Element) {
    this.hamburgerNavigationTrigger = content;
  }
  hamburgerNavigationTrigger: Element;
  @Input() menuLinks: ILink[] = [];
  @Input() userEventSource: string;

  isVisible: boolean;
  isOpen: boolean;
  navigationComponentRef: NavigationComponent;

  destroy$ = new Subject();

  constructor(private cdRef: ChangeDetectorRef) {}

  ngAfterViewInit(): void {
    this.cdRef.detectChanges();
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
