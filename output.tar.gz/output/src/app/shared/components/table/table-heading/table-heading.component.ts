import { Component, EventEmitter, Input, Output, TemplateRef, ViewChild } from '@angular/core';

@Component({
  selector: 'air-table-heading',
  templateUrl: './table-heading.component.html',
  standalone: false
})
export class TableHeadingComponent {
  @Input() sortable: boolean;
  @Input() sortAsc: boolean;
  @Input() sortDesc: boolean;

  @Output() headingClick = new EventEmitter();

  @ViewChild(TemplateRef, { static: true }) template: TemplateRef<any>;

  constructor() {}

  click(): void {
    this.headingClick.emit();
  }
}
