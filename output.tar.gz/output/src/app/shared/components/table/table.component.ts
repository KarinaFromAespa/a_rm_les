import { Component, ContentChildren, Input, QueryList } from '@angular/core';
import { TableHeadingComponent } from './table-heading/table-heading.component';

@Component({
  selector: 'air-table',
  templateUrl: './table.component.html',
  standalone: false
})
export class TableComponent {
  @Input() loading: boolean;
  @ContentChildren(TableHeadingComponent) tableHeadingComponents: QueryList<TableHeadingComponent>;

  constructor() {}
}
