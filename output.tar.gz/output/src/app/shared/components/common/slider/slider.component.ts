import { ChangeContext, Options } from '@angular-slider/ngx-slider';
import { DOCUMENT } from '@angular/common';
import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { StringHelper } from 'src/app/core/helpers/string.helper';
import { ISliderValues, SliderInput, SliderType } from './slider.model';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'air-slider',
  templateUrl: './slider.component.html',
  standalone: false
})
export class SliderComponent implements OnInit {
  @Input() slider: SliderType = SliderType.range;
  @Input() floor = 0;
  @Input() ceil = 10000;
  @Input() step = 1;
  @Input() increment = 1;
  @Input() initSelectedValues: ISliderValues;
  @Input() showInputThresholds = true;
  @Input() showInputSticker = false;
  @Input() ariaLabel = '';

  private _showStepperButtons = false;
  get showStepperButtons() {
    return this._showStepperButtons;
  }
  @Input() set showStepperButtons(value) {
    this._showStepperButtons = value && this.slider === SliderType.single;
  }

  get highValue(): number {
    //Dirty fix for highValue attribute, typing should be optional but the package does not allow it
    return this.slider === SliderType.range ? this.max : (undefined as unknown as number);
  }

  @Output() sliderUpdate: EventEmitter<ISliderValues> = new EventEmitter<ISliderValues>();

  min: number;
  max: number;
  minInput: string;
  maxInput: string;
  options: Options;
  sliderType = SliderType;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private translateService: TranslateService
  ) {}

  ngOnInit(): void {
    this.min = this.initSelectedValues?.min ?? this.floor;
    this.max = this.initSelectedValues?.max ?? this.ceil;
    this.minInput = this.min.toString();
    this.maxInput = this.max.toString();
    this.options = {
      floor: this.floor,
      ceil: this.ceil,
      step: this.step,
      showTicks: false,
      ticksArray: [], //Fixes performance issue, ticks not needed as show ticks is false (https://github.com/danisss9/ngx-slider/issues/5)
      showSelectionBar: true,
      ariaLabel: this.ariaLabel
    };
  }

  onUpdateInput(event: Event): void {
    const { value, name } = event.target as HTMLInputElement;
    let points = value ? StringHelper.convertPositiveInteger(value) : 0;
    // validate and fix min value
    if (name === SliderInput.min) {
      if (points < this.floor || points > this.ceil || points >= this.max) {
        points = this.floor;
      }

      this.minInput = points.toString();

      if (this.min !== points) {
        this.min = points;
      }
    } else if (name === SliderInput.max) {
      if ((this.options.floor && points < this.options.floor) || (this.options.ceil && points > this.options.ceil) || points <= this.min) {
        points = this.ceil;
      }

      this.maxInput = points.toString();

      if (this.max !== points) {
        this.max = points;
      }
    }
    this.emitValues();
  }

  onUpdateSlider(context: ChangeContext, emitValues = true): void {
    // validate and fix min value
    const value = context.value;
    const highValue = context.highValue;
    if (value !== this.min && value !== parseInt(this.minInput, 10)) {
      this.minInput = value.toString();
      this.min = value;
    }
    // validate and fix max value
    if (highValue !== undefined && highValue !== this.max && highValue !== parseInt(this.maxInput, 10)) {
      this.maxInput = highValue.toString();
      this.max = highValue;
    }

    if (emitValues) {
      this.emitValues();
    }
  }

  onIncrement(): void {
    if (this.min === this.ceil) {
      return;
    }

    let value = this.min + this.increment;
    if (value > this.ceil) {
      value = this.ceil;
    }

    this.min = value;
    this.minInput = value.toString();

    this.emitValues();
  }

  onDecrement(): void {
    if (this.min === this.floor) {
      return;
    }

    let value = this.min - this.increment;
    if (value < this.floor) {
      value = this.floor;
    }

    this.min = value;
    this.minInput = value.toString();

    this.emitValues();
  }

  emitValues(): void {
    const values = { min: this.min, max: this.slider === SliderType.range ? this.max : undefined };
    this.sliderUpdate.emit(values);
  }

  onKeyUp(e: KeyboardEvent): void {
    if (e.key === 'Enter') {
      e.preventDefault();
      setTimeout(() => {
        const activeElement = this.document.activeElement;
        (activeElement as HTMLElement)?.blur();
      });
    }
  }
}
