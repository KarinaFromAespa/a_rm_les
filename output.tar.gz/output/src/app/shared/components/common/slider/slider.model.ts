export interface ISliderValues {
  min: number;
  max?: number;
}

export enum SliderInput {
  min = 'min',
  max = 'max'
}

export enum SliderType {
  single = 'single',
  range = 'range'
}
