import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  HostBinding,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges
} from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { IImage } from 'src/app/core/models/site.response';

@Component({
  selector: 'air-focal-image',
  templateUrl: './focal-image.component.html',
  standalone: false
})
export class FocalImageComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @Input() image: IImage;
  @Input() isCropped = false;

  objectPosition: string;
  imageUrl?: string;

  private resize$ = new Subject();
  private destroy$ = new Subject();

  @HostBinding('class') get class(): string {
    this.cdRef.detectChanges();
    return this.isCropped ? 'cropped' : '';
  }

  @HostListener('window:resize')
  onResize(): void {
    this.resize$.next(void 0);
  }

  constructor(
    private elementRef: ElementRef<HTMLElement>,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.objectPosition = `${(this.image.umbracoFile?.focalPoint?.left ?? 0.5) * 100}% ${
      (this.image.umbracoFile?.focalPoint?.top ?? 0.5) * 100
    }%`;
  }

  ngAfterViewInit(): void {
    if (this.isCropped && this.image.umbracoFile?.focalPointUrlTemplate) {
      this.imageUrl = this.image.umbracoFile?.focalPointUrlTemplate
        .replace('{width}', this.elementRef.nativeElement.clientWidth.toString())
        .replace('{height}', this.elementRef.nativeElement.clientHeight.toString());

      this.resize$.pipe(debounceTime(500), takeUntil(this.destroy$)).subscribe(() => {
        this.imageUrl = this.image.umbracoFile?.focalPointUrlTemplate
          .replace('{width}', this.elementRef.nativeElement.clientWidth.toString())
          .replace('{height}', this.elementRef.nativeElement.clientHeight.toString());
      });
    } else {
      this.imageUrl = this.image._url || this.image.url;
    }
    this.cdRef.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.image.currentValue && !changes.image.isFirstChange()) {
      this.imageUrl = this.image._url || this.image.url;
    }
  }
  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
