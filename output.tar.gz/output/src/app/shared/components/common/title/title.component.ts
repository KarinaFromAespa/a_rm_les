import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { ContentBlockRegion } from 'src/app/core/models/content.model';

@Component({
  selector: 'air-title',
  templateUrl: './title.component.html',
  standalone: false
})
export class TitleComponent {
  @ViewChild('controls') controls: ElementRef<HTMLElement>;
  @Input() title?: string;
  @Input() subtitle?: string;
  @Input() region?: ContentBlockRegion;
  @Input() isFirst?: boolean;
  @Input() isCentered?: boolean;

  readonly contentBlockRegion = ContentBlockRegion;

  constructor() {}

  get hasControls(): boolean {
    return this.controls?.nativeElement.children.length > 0;
  }
}
