import { Component, Input } from '@angular/core';
import { ProductHelper } from 'src/app/core/helpers/product.helper';
import { IBaseProduct, ICombinedProduct, IExternalProduct, IProductCost } from 'src/app/core/models/product.model';

@Component({
  selector: 'air-miles-sticker',
  templateUrl: './air-miles-sticker.component.html',
  standalone: false
})
export class AirMilesStickerComponent {
  sizes: string[] = ['sm', 'md'];
  @Input() size?: 'sm' | 'md';
  @Input() product?: IBaseProduct;
  @Input() points?: number | null;
  @Input() price?: number | null;
  @Input() unavailable = false;

  get showStickers(): boolean {
    return this.unavailable || this.points !== undefined || this.price !== undefined || this.product !== undefined;
  }

  get showDonate(): boolean {
    return !!this.product && ProductHelper.isCharity(this.product);
  }

  get isAvailable(): boolean {
    if (!this.product) {
      return false;
    }
    return ProductHelper.isAvailable(this.product);
  }

  get productCost(): IProductCost | null {
    if (!this.product) {
      if (this.price) {
        return {
          price: this.price,
          points: 0
        };
      } else {
        return null;
      }
    }
    return ProductHelper.getLowestCostForProduct(this.product);
  }

  get discount(): number | null {
    return this.product ? (this.product as IExternalProduct).discount : null;
  }

  get discountOnly(): boolean {
    const productCost = this.productCost;
    return !productCost?.points && !productCost?.price && !!this.discount && this.discount > 0;
  }

  get pointsString(): string {
    if (this.points !== null && this.points !== undefined && !isNaN(this.points)) {
      return this.points?.toLocaleString('nl-NL');
    }

    return this.productCost ? this.productCost.points?.toLocaleString('nl-NL') : '-';
  }

  get showTopLabel(): boolean {
    return !!(this.product as ICombinedProduct)?.variants?.length;
  }

  constructor() {}
}
