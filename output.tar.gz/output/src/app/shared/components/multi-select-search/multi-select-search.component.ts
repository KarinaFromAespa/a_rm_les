import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ITransactionFilterItem } from 'src/app/features/content-blocks/recent-transactions/recent-transactions.model';
import { SearchBarInputComponent } from '../search-bar-input/search-bar-input.component';

@Component({
  selector: 'air-multi-select-search',
  templateUrl: './multi-select-search.component.html',
  standalone: false
})
export class MultiSelectSearchComponent implements OnInit {
  @ViewChild(SearchBarInputComponent) searchBarInputComponent: SearchBarInputComponent;
  @Input() id = 'multi-select-search';
  @Input() placeholder?: string;
  @Input() items: string[];
  @Input() selectedItems: string[];
  @Output() selectedItemsChange = new EventEmitter<string[]>();

  searchForm: FormGroup;
  filterItems: ITransactionFilterItem[];
  filteredItems: ITransactionFilterItem[] = [];

  get isCheckedAll(): boolean {
    return this.filteredItems?.every((x) => x.checked);
  }

  get selectAllLabel(): string {
    const isSearching = this.filteredItems.length !== this.filterItems.length;
    const count = isSearching ? `${this.filteredItems.length}/${this.filterItems.length}` : `${this.filterItems.length}`;
    const label = isSearching
      ? (this.translateService.instant('transactions.label.select_all_filtered') as string)
      : (this.translateService.instant('transactions.label.select_all') as string);

    return `${label} (${count})`;
  }

  constructor(private translateService: TranslateService) {}

  ngOnInit(): void {
    this.searchForm = new FormGroup({
      search: new FormControl<string>('', { nonNullable: true })
    });

    this.searchForm.controls.search.valueChanges.subscribe(() => this.searchFilters());
    this.setFilterItems();
    this.searchFilters();
  }

  input(): void {
    this.searchForm.controls.search.setValue(this.searchBarInputComponent.searchForm.value.query);
    this.searchFilters();
  }

  inputKeyDown($event: KeyboardEvent): void {
    if ($event.key !== 'Escape') {
      return;
    }

    (document.activeElement as HTMLInputElement).blur();
    this.inputCancel();
  }

  inputCancel(): void {
    this.searchForm.controls.search.reset();
    this.searchFilters();
  }

  searchFilters(): void {
    const searchValue = (this.searchForm.controls.search.value as string)?.toLocaleLowerCase();
    if (searchValue?.length) {
      this.filteredItems = this.filterItems.filter((x) => x.value.toLocaleLowerCase().includes(searchValue));
    } else {
      this.filteredItems = this.filterItems;
    }
  }

  toggleSelectAll(): void {
    const isCheckedAll = this.isCheckedAll;
    this.filteredItems.map((x) => (x.checked = !isCheckedAll));
    this.setFilters();
  }

  toggleSelect(item: ITransactionFilterItem): void {
    item.checked = !item.checked;
    this.setFilters();
  }

  private setFilterItems(): void {
    this.filterItems = [...new Set(this.items)].map((item) => ({
      value: item,
      checked: this.selectedItems?.includes(item)
    }));
  }

  private setFilters(): void {
    const selectedItems = this.filterItems.filter((x) => x.checked).map((x) => x.value);
    this.selectedItemsChange.emit(selectedItems);
  }
}
