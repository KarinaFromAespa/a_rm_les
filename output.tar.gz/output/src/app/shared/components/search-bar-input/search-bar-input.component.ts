import { Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { UserEventAction, UserEventSource } from 'src/app/core/constants/user-event.constants';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { UserEventService } from 'src/app/core/services/user-event.service';

@Component({
  selector: 'air-search-bar-input',
  templateUrl: './search-bar-input.component.html',
  standalone: false
})
export class SearchBarInputComponent implements OnDestroy {
  @Input() searchDisabled = false;
  @Input() static = false;
  @Input() placeholder?: string;
  @Output() searchFocus = new EventEmitter();
  @Output() searchBlur = new EventEmitter();
  @Output() searchInput = new EventEmitter();
  @Output() searchKeyDown = new EventEmitter<KeyboardEvent>();
  @Output() searchCancel = new EventEmitter();
  @Output() searchClose = new EventEmitter();

  destroy$ = new Subject();
  userEventAction = UserEventAction;
  searchForm = new FormGroup({
    query: new FormControl('', [FormValidatorType.pattern(FormRegex.searchQuery.getRegExp()).getValidator()])
  });

  constructor(private userEventService: UserEventService) {}

  get hasInput(): boolean {
    return !!this.searchForm.value.query?.length;
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  onCancel(pushUserEvent = false): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.cancel);
    }

    this.searchForm.reset();
    this.searchCancel.emit();
  }

  onClose(userEventAction?: UserEventAction): void {
    if (userEventAction) {
      this.pushUserEvent(userEventAction);
    }

    this.searchForm.reset();
    this.searchClose.emit();
  }

  onFocus(): void {
    this.searchFocus.emit();
  }

  onBlur(): void {
    this.searchBlur.emit();
  }

  onInput(): void {
    this.searchInput.emit();
  }

  onKeyDown($event: KeyboardEvent): void {
    this.searchKeyDown.emit($event);
  }

  private pushUserEvent(action: UserEventAction): void {
    this.userEventService.pushEvent(UserEventSource.search, action);
  }
}
