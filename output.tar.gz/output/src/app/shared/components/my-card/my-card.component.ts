import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { BarcodeType } from 'src/app/core/constants/ticket-template.constants';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { ResizeService } from 'src/app/core/services/resize.service';

@Component({
  selector: 'air-my-card',
  templateUrl: './my-card.component.html',
  standalone: false
})
export class MyCardComponent implements OnInit, OnDestroy {
  @Input() barcodeHeight;
  @Input() barcodeWidth;
  barcodeType = BarcodeType;
  currentScreenSize: ScreenSize;
  screenSize = ScreenSize;

  destroy$ = new Subject();

  get currentUser(): IUserLoginData | undefined {
    return this.userHelper.currentUser as IUserLoginData | undefined;
  }

  get ean13CardNumber(): string {
    return `26${this.currentUser?.cardNumber?.padStart(10, '0')}`;
  }

  constructor(
    private userHelper: UserHelper,
    private resizeService: ResizeService
  ) {}

  ngOnInit(): void {
    if (!this.barcodeWidth && !this.barcodeHeight) {
      this.resizeService.onResize$.pipe(takeUntil(this.destroy$)).subscribe((screenSize) => {
        this.currentScreenSize = screenSize;
        switch (this.currentScreenSize) {
          case ScreenSize.xsm:
          case ScreenSize.sm:
            this.barcodeWidth = 2.8;
            this.barcodeHeight = 93;
            break;

          case ScreenSize.md:
            this.barcodeWidth = 3;
            this.barcodeHeight = 91;
            break;

          case ScreenSize.lg:
            this.barcodeWidth = 3.3;
            this.barcodeHeight = 142;
            break;
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
