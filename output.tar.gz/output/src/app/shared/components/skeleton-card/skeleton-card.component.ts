import { Component, Input } from '@angular/core';

@Component({
  selector: 'air-skeleton-card',
  templateUrl: './skeleton-card.component.html',
  standalone: false
})
export class SkeletonCardComponent {
  @Input() isLarge: boolean;
  @Input() hasText = true;
  @Input() additionalClasses: any;
}
