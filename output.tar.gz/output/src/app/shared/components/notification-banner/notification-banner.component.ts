import { Component, Input } from '@angular/core';
import { BannerTheme } from 'src/app/core/constants/banner.constants';

@Component({
  selector: 'air-notification-banner',
  templateUrl: './notification-banner.component.html',
  standalone: false
})
export class NotificationBannerComponent {
  @Input() pageUrl: string;
  @Input() icon: string;
  @Input() action: string;
  @Input() theme: BannerTheme;
  @Input() userEventSource: string;
}
