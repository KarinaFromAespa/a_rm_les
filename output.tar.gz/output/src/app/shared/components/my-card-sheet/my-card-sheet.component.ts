import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Brightness } from '@awesome-cordova-plugins/brightness/ngx';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { AnimationStates, animationSheetUp } from 'src/app/core/animations/sheet.animations';
import { PageHelper } from 'src/app/core/helpers/page.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { SiteService } from 'src/app/core/services/site.service';
import { UserService } from 'src/app/core/services/user.service';
import { ToastOptions, ToastType } from 'src/app/features/toasts/toast.model';
import { ToastService } from 'src/app/features/toasts/toast.service';
import { MyCardSheetService } from './my-card-sheet.service';

@Component({
  selector: 'air-my-card-sheet',
  templateUrl: './my-card-sheet.component.html',
  animations: [animationSheetUp],
  standalone: false
})
export class MyCardSheetComponent implements OnInit, OnDestroy {
  currentBrightness: number;
  isOnline: boolean;
  isLoggedIn: boolean;
  isInMaintenance: boolean;
  isInMobileMaintenance: boolean;
  isCheckingConnection = false;
  shouldReload = false;
  disconnectToast: ToastOptions;
  passbookLoading = false;
  isiOSMobile = false;

  animationState = AnimationStates.closed;
  animationStates = AnimationStates;
  destroy$ = new Subject();

  constructor(
    private myCardSheetService: MyCardSheetService,
    private brightness: Brightness,
    private platformHelper: PlatformHelper,
    private userHelper: UserHelper,
    private translateService: TranslateService,
    private router: Router,
    private toastService: ToastService,
    private siteService: SiteService,
    private cdRef: ChangeDetectorRef,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.isiOSMobile = this.platformHelper.isiOSMobile;
    this.userHelper.isLoggedIn$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((isLoggedIn) => {
      this.isLoggedIn = isLoggedIn;
    });

    this.myCardSheetService.onCardSheetToggle$.pipe(takeUntil(this.destroy$)).subscribe((state: AnimationStates) => {
      if (state === this.animationState) {
        return;
      }

      this.animationState = state as string;
      this.isInMobileMaintenance = this.myCardSheetService.isInMobileMaintenance;
      this.isInMaintenance = this.siteService.isInMaintenance || this.isInMobileMaintenance;

      if (this.isInMaintenance && state === AnimationStates.open) {
        void (async () => {
          await this.setToast();
          this.toastService.show(this.disconnectToast);

          // Make sure the page will reload for mobile, after maintenance ends
          if (this.platformHelper.isMobile) {
            this.shouldReload = true;
          }
        })();
      }

      if (PlatformHelper.isNativeMobile && this.isLoggedIn) {
        if (state === AnimationStates.open) {
          void this.brightness.getBrightness().then((value: number) => {
            this.currentBrightness = value;
            void this.setBrightness(1);
            this.brightness.setKeepScreenOn(true);
          });
        } else {
          void this.setBrightness(this.currentBrightness);
          this.brightness.setKeepScreenOn(false);
        }
      }
      this.cdRef.detectChanges();
    });

    if (this.platformHelper.isMobile) {
      this.platformHelper.onlineState$.pipe(takeUntil(this.destroy$), distinctUntilChanged()).subscribe((isOnline) => {
        // Check if isOnline, and if equal. If so, return and skip.
        // Needed to perform actions if it is recalled with !onLine state,
        // to re-show toast and perform connection check again (via try again button i.e.);
        if (this.isOnline && isOnline) {
          return;
        }

        if (!isOnline) {
          this.toastService.show(this.disconnectToast);
          void this.checkConnection(false);
        }

        this.isOnline = isOnline;
        this.cdRef.detectChanges();
      });
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async setToast(): Promise<void> {
    return Promise.all([
      this.translateService.get('connection_status.label.no_connection').toPromise(),
      this.translateService.get('connection_status.label.cannot_connect_to_server').toPromise(),
      this.translateService.get('connection_status.label.maintenance').toPromise()
    ]).then((results) => {
      const message = this.isInMobileMaintenance
        ? (this.siteService.pageContext.getValue()?.mobileMaintenanceMessage ?? '')
        : this.isInMaintenance
          ? (this.siteService.pageContext.getValue()?.maintenancePage?.mobileMessage ?? '')
          : (results[1] as string);

      this.disconnectToast = new ToastOptions({
        title: this.isInMaintenance ? (results[2] as string) : (results[0] as string),
        type: ToastType.error,
        message,
        autoClose: true,
        id: 'no_connection'
      });
    });
  }

  async checkConnection(forceCheck = true): Promise<void> {
    if (this.isCheckingConnection) {
      return;
    }

    this.isCheckingConnection = true;
    // If siteSettings aren't set, try to fetch them as connection check.
    if (!this.siteService.siteSettings) {
      try {
        const siteSettings = await this.siteService.loadSiteSettings();
        if (!siteSettings) {
          this.isCheckingConnection = false;
          return;
        }
      } catch {
        this.notifyOfflineConnection();
        return console.warn('Could not load site settings, seems offline!');
      }
    }

    // If it does have siteSettings, try to re-fetch pageContext for connection check.
    if (forceCheck) {
      try {
        const pageContext = await this.siteService.loadPageContext(true);
        if (!pageContext) {
          this.isCheckingConnection = false;
          return;
        }

        // Reset maintenance after successful re-fetch pageContext
        this.isInMaintenance = this.siteService.isInMaintenance;
        this.isInMobileMaintenance = false;

        // If after re-fetch pageContext, still in maintenance, re-show toast.
        if (this.isInMaintenance) {
          return this.notifyOfflineConnection();
        }

        // Force re-route on shouldReload
        if (this.shouldReload) {
          window.location.reload();
        }
        void this.router
          .navigate([PageHelper.stripUrl(this.router.url)], {
            // Need to ensure the router triggers navigation events by specifying a 'new' url each time
            queryParams: { reload: Math.random().toString(16).substr(2, 8) },
            queryParamsHandling: 'merge'
          })
          .then(() => {
            this.isCheckingConnection = false;
            this.close();
          })
          .finally(() => {
            this.shouldReload = false;
          });
      } catch {
        this.notifyOfflineConnection();
        return console.warn('Could not load page context, seems offline!');
      }
    } else {
      this.isCheckingConnection = false;
      return;
    }
  }

  close(): void {
    this.myCardSheetService.close();
  }

  async addPassbookToWallet(): Promise<void> {
    this.passbookLoading = true;

    try {
      const passbookUrl = (await this.userService.getPassbook()).url;
      this.passbookLoading = false;
      if (PlatformHelper.isNativeMobile) {
        // If in app open in browser
        window.open(passbookUrl, '_system');
      } else {
        window.location.href = passbookUrl;
      }
    } catch {
      this.passbookLoading = false;
    }
  }

  private notifyOfflineConnection(): void {
    this.isCheckingConnection = false;
    this.toastService.show(this.disconnectToast);
  }

  private setBrightness(value: number): void {
    void this.brightness.setBrightness(value);
  }
}
