import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AnimationStates } from 'src/app/core/animations/sheet.animations';

@Injectable({ providedIn: 'root' })
export class MyCardSheetService {
  isInMobileMaintenance: boolean;

  private readonly cardSheetSubject = new BehaviorSubject<AnimationStates>(AnimationStates.closed);
  readonly onCardSheetToggle$ = this.cardSheetSubject.asObservable();

  open(isInMobileMaintenance = false): void {
    this.isInMobileMaintenance = isInMobileMaintenance;

    document.body.classList.add('sheet--open');
    this.cardSheetSubject.next(AnimationStates.open);
  }

  close(): void {
    document.body.classList.remove('sheet--open');
    this.cardSheetSubject.next(AnimationStates.closed);
  }
}
