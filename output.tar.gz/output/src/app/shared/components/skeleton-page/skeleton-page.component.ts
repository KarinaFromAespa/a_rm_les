import { Component } from '@angular/core';

@Component({
  selector: 'air-skeleton-page',
  templateUrl: './skeleton-page.component.html',
  standalone: false
})
export class SkeletonPageComponent {}
