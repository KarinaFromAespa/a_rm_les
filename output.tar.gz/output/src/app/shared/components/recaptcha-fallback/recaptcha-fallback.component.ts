import { Component, ViewChild } from '@angular/core';
import { RecaptchaComponent } from 'ng-recaptcha-2';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';

@Component({
  selector: 'air-recaptcha-fallback',
  templateUrl: './recaptcha-fallback.component.html',
  standalone: false
})
export class RecaptchaFallbackComponent {
  @ViewChild('reCaptcha')
  reCaptchaComponent?: RecaptchaComponent;

  hasAlternateReCaptchaError = {
    invalid: false,
    expired: false
  };

  constructor(private reCaptchaService: ReCaptchaService) {}

  setAlternateReCaptcha(reCaptchaToken: string | null): void {
    if (this.reCaptchaService) {
      this.reCaptchaService.alternateReCaptchaToken = reCaptchaToken ?? undefined;
    }
    this.hasAlternateReCaptchaError.invalid = this.hasAlternateReCaptchaError.expired = !this.reCaptchaService?.alternateReCaptchaToken;

    if (this.hasAlternateReCaptchaError.expired) {
      setTimeout(() => this.reCaptchaComponent?.reset(), 0);
    }
  }

  setAlternateReCaptchaError(error: unknown): void {
    this.hasAlternateReCaptchaError.invalid = !!error;
    this.hasAlternateReCaptchaError.expired = false;
  }

  onSubmit(): void {
    this.hasAlternateReCaptchaError.invalid = !this.reCaptchaService?.alternateReCaptchaToken;
    this.hasAlternateReCaptchaError.expired = false;
  }

  reset(): void {
    this.reCaptchaComponent?.reset();
  }
}
