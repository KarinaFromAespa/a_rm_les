import { Component, Input } from '@angular/core';
import { ICustomCard } from 'src/app/core/models/custom-card.model';
import { CommerceHighlight } from 'src/app/core/models/user-event.model';

@Component({
  selector: 'air-custom-card',
  templateUrl: './custom-card.component.html',
  standalone: false
})
export class CustomCardComponent {
  @Input() card: ICustomCard;
  @Input() isLarge = false;
  @Input() isDescriptionHidden = false;
  @Input() userEventSource: string;
  @Input() userEventObject: CommerceHighlight;
}
