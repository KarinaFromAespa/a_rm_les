import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ApolloQueryResult } from '@apollo/client/core';
import { Observable, Subject, of, timer } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { ScreenSize } from 'src/app/core/components/resize-detector/resize-detector.model';
import { UserEventSource } from 'src/app/core/constants/user-event.constants';
import { ContentBlockRegion, IContentBlock } from 'src/app/core/models/content.model';
import { IPartner, IPartnerListResponse } from 'src/app/core/models/partner.response';
import { GraphQLService } from 'src/app/core/services/graphql.service';
import { ResizeService } from 'src/app/core/services/resize.service';
import { IContentBlockComponent } from 'src/app/features/content-blocks/content-block-component.model';
import { partnerListQuery } from './partners-list.query';

const partnerAnimation = trigger('partner', [
  state('out', style({ opacity: 0 })),
  state('in', style({ opacity: 1 })),
  transition('* => out', animate('1100ms ease-out')),
  transition('* => in', animate('1100ms ease-in'))
]);

@Component({
  selector: 'air-partners-list',
  templateUrl: './partners-list.component.html',
  animations: [partnerAnimation],
  standalone: false
})
export class PartnersListComponent implements IContentBlockComponent, OnInit, OnDestroy {
  className = 'partner-list';
  region?: ContentBlockRegion;
  content: IContentBlock;
  isFirst?: boolean;
  userEventSource = UserEventSource.partnerLogos;
  partners: IPartner[] = [];
  displayPartners: IPartner[] = [];
  numberOfDisplayPartners = 5;

  loading = true;
  loadingError = false;
  isAnimating = false;

  private interval?: Observable<number>;
  private destroy$ = new Subject();

  @HostListener('window:resize', [])
  onResize(): void {
    this.detectScreenSize();
  }

  constructor(
    private graphQLService: GraphQLService,
    private resizeService: ResizeService
  ) {}

  ngOnInit(): void {
    this.graphQLService
      .watchQuery<IPartnerListResponse>(partnerListQuery, undefined, true)
      .pipe(
        catchError(() => {
          this.loading = false;
          this.loadingError = true;
          return of({ data: null, loading: false } as ApolloQueryResult<null>);
        })
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (!result?.data?.allPartner?.items?.length) {
          return;
        }

        this.partners = this.displayPartners = result.data.allPartner.items.filter((x) => !x.isHidden);
        this.loading = result.loading;
        this.detectScreenSize();
      });
  }

  ngOnDestroy(): void {
    this.interval = undefined;
    this.destroy$.next(void 0);
    this.destroy$.complete();
  }

  private detectScreenSize(): void {
    const size = this.resizeService.getCurrentSize();
    if (size <= ScreenSize.md) {
      this.numberOfDisplayPartners = size === ScreenSize.md ? 7 : 5;

      if (!this.interval) {
        this.setPartnerListAnimationLoop();
      }
    } else {
      this.interval = undefined;
      this.destroy$.next(void 0);
    }
  }

  private setPartnerListAnimationLoop(): void {
    const interval = 5000;
    const animation = 1300;
    const startWith = interval - animation;

    this.interval = timer(startWith, interval).pipe(takeUntil(this.destroy$));
    this.interval.subscribe(() => {
      this.isAnimating = true;
      setTimeout(() => {
        this.setPartnerList();
        this.isAnimating = false;
      }, animation);
    });
  }

  private setPartnerList(): void {
    const partnerList = [...this.displayPartners];
    const movedToEnd = partnerList.splice(0, this.numberOfDisplayPartners);
    this.displayPartners = partnerList.concat(movedToEnd);
  }
}
