import gql from 'graphql-tag';

export const partnerListQuery = gql`
  query GetPartnerList {
    allPartner {
      items {
        ... on Partner {
          title
          logo {
            cropUrl(alias: "Partner Logo")
          }
          url
          isHidden
        }
      }
    }
  }
`;
