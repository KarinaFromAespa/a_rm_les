import { Component, Input, ViewChild } from '@angular/core';
import { NgxBarcode6Component } from 'ngx-barcode6';
import { BarcodeType } from 'src/app/core/constants/ticket-template.constants';

@Component({
  selector: 'air-barcode',
  templateUrl: './barcode.component.html',
  standalone: false
})
export class BarcodeComponent {
  @ViewChild('barcode') barcodeComponent: NgxBarcode6Component;

  @Input() value: string;
  @Input() type: BarcodeType;
  @Input() height = 24;
  @Input() width = 2;
  @Input() displayValue = true;

  barcodeType = BarcodeType;

  get renderBarcodeType(): '' | 'CODE128' | 'EAN13' {
    switch (this.type) {
      case BarcodeType.ean128:
        return 'CODE128';
      case BarcodeType.ean13:
        return 'EAN13';
    }

    return '';
  }

  get isValidBarcode(): boolean {
    if (this.type === BarcodeType.ean13) {
      return this.isValidEAN13();
    }

    return true;
  }

  constructor() {}

  private isValidEAN13(): boolean {
    return /^\d+$/.test(this.value) && this.testChecksum();
  }

  private testChecksum(): boolean {
    if (this.value.length !== 12 && this.value.length !== 13) {
      return false;
    }

    const checkSum = this.value
      .split('')
      .reduce((p, v, i) => (i % 2 === 0 ? (parseInt(p) + 1 * parseInt(v)).toString() : (parseInt(p) + 3 * parseInt(v)).toString()));

    if (this.value.length === 12) {
      const checkDigit = (10 - (parseInt(checkSum) % 10)) % 10;
      this.value = `${this.value}${checkDigit}`;

      return this.testChecksum();
    }

    if (parseInt(checkSum) % 10 !== 0) {
      return false;
    }

    return true;
  }
}
