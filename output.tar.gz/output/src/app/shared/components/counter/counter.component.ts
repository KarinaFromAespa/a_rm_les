import { animate, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import { Subject, interval, lastValueFrom, of } from 'rxjs';
import { delay, takeUntil } from 'rxjs/operators';

const digitAnimation = trigger('digit', [
  transition(
    ':enter',
    [style({ transform: 'translateY(140%)' }), animate('{{speed}}ms ease-out', style({ transform: 'translateY(0%)' }))],
    { params: { speed: 100 } }
  ),
  transition(
    ':leave',
    [
      style({ transform: 'translateY(0%)', position: 'absolute' }),
      animate('{{speed}}ms ease-out', style({ transform: 'translateY(-140%)' }))
    ],
    { params: { speed: 100 } }
  )
]);

@Component({
  selector: 'air-counter',
  templateUrl: './counter.component.html',
  animations: [digitAnimation],
  standalone: false
})
export class CounterComponent implements OnDestroy {
  @Input() label: string;
  @Output() counterUpdated = new EventEmitter<number>();

  badgeNumber?: number;
  badgeLabel?: string;
  digits = Array(8).fill(0);
  resultLength: number;
  availableDigits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  isCountingFast = false;

  private value = 0;
  private lowValue: number;
  private highValue: number;
  private customDuration: number;
  private duration = {
    init: 3000,
    fast: 1000,
    slow: 10000
  };
  private frameRate = 30;
  private destroy$ = new Subject();

  get animationParameters(): unknown {
    return { value: '', params: { speed: this.isCountingFast ? 50 : 500 } };
  }

  get isBadgeVisible() {
    return this.badgeLabel?.length && this.badgeNumber && isFinite(this.badgeNumber);
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
    this.destroy$.complete();
  }

  async setValues(lowValue: number, highValue: number, duration: number): Promise<void> {
    this.destroy$.next(void 0);
    this.lowValue = lowValue;
    this.highValue = highValue;
    this.resultLength = Math.ceil(highValue).toString().length;
    this.customDuration = duration;

    // Fast count
    if (this.value === 0) {
      this.isCountingFast = true;
      await this.setAnimatedValue(this.lowValue, this.duration.init).then(() => (this.isCountingFast = false));
    } else if (this.value !== this.lowValue) {
      this.isCountingFast = true;
      await this.setAnimatedValue(this.lowValue - this.value, this.duration.fast).then(() => (this.isCountingFast = false));
    }

    // Slow count
    await this.setAnimatedValue(this.highValue - this.lowValue, this.customDuration ?? this.duration.slow);
    return;
  }

  private async setAnimatedValue(value: number, duration: number): Promise<unknown> {
    if (duration <= 0) {
      return;
    }

    if (value <= 0) {
      return lastValueFrom(of(void 0).pipe(delay(duration)));
    }

    let currentStep = 0;
    let steps = Math.round(duration / this.frameRate);
    const destroy$ = new Subject();

    // Ensure we can add at least 1 on each step
    if (steps > value) {
      steps = Math.floor(value);
    }

    const discrepancy = value - Math.floor(value / steps) * steps;
    interval(Math.round(duration / steps))
      .pipe(takeUntil(destroy$), takeUntil(this.destroy$))
      .subscribe(() => {
        this.value = Math.min(this.value + Math.floor(value / steps), this.highValue);
        currentStep++;

        if (currentStep === steps) {
          this.value = Math.min(this.value + discrepancy, this.highValue);
          destroy$.next(void 0);
          destroy$.complete();
        }

        if (!this.isCountingFast || currentStep === steps) {
          this.counterUpdated.emit(this.value);
        }

        this.setDigits();
      });

    return lastValueFrom(destroy$);
  }

  private setDigits(): void {
    this.digits = this.value
      .toLocaleString(undefined, { minimumIntegerDigits: 8, useGrouping: false })
      .split('')
      .map((x) => parseInt(x, 10));
  }
}
