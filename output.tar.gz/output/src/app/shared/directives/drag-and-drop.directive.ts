import { Directive, ElementRef, EventEmitter, HostBinding, HostListener, Output } from '@angular/core';

@Directive({
  selector: '[airDragAndDrop]',
  standalone: false
})
export class DragAndDropDirective {
  @HostBinding('class.drag-active') isDragging: boolean;
  @Output() filesDropped = new EventEmitter<FileList>();

  constructor(private element: ElementRef) {}

  @HostListener('dragover', ['$event'])
  onDragOver(e: DragEvent) {
    this.preventEventBubbling(e);
    this.isDragging = true;
  }

  @HostListener('dragleave', ['$event'])
  onDragLeave(e: DragEvent) {
    this.preventEventBubbling(e);

    if (this.element.nativeElement === e.target) {
      this.isDragging = false;
    }
  }

  @HostListener('drop', ['$event'])
  onDrop(e: DragEvent) {
    this.preventEventBubbling(e);
    this.isDragging = false;

    const files = e.dataTransfer?.files;
    if (files?.length) {
      this.filesDropped.emit(files);
    }
  }

  private preventEventBubbling(e: DragEvent): void {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }
}
