import { Directive, ElementRef, HostListener, Input, NgModule, SecurityContext } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { UserEventService } from 'src/app/core/services/user-event.service';

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[internalInnerHtml]',
  standalone: false
})
export class InternalInnerHtmlDirective {
  @Input() userEventSource: string;
  @Input() set internalInnerHtml(html: string | undefined | null) {
    if (!html) {
      this.container.nativeElement.innerHTML = '';
      return;
    }
    this.container.nativeElement.innerHTML =
      this.domSanitizer.sanitize(SecurityContext.HTML, this.domSanitizer.bypassSecurityTrustHtml(html)) ?? '';

    this.container.nativeElement.querySelectorAll('a').forEach((anchorHTMLElement: HTMLAnchorElement) => {
      const href = anchorHTMLElement.getAttribute('href');
      if (href) {
        anchorHTMLElement.setAttribute('href', UrlHelper.insertUserProperties(href, this.userHelper.currentUser));
      }
    });
  }

  @HostListener('click', ['$event'])
  onClick(event: Event): void {
    if (typeof window === 'undefined' || (event.target as HTMLElement)?.tagName !== 'A') {
      return;
    }

    const linkElement = event.target as HTMLAnchorElement;
    this.userEventService.pushEvent(this.userEventSource, UserEventAction.link, linkElement.text, linkElement.href);

    if (linkElement.hostname !== window.location.hostname || linkElement.target === '_blank') {
      return;
    }

    //If route is a absolute url of current domain, convert to relative url
    let href = linkElement.href;
    if (href.includes(location.host)) {
      const url = new URL(href);
      href = url.pathname + url.search;
    }

    event.preventDefault();
    event.stopPropagation();
    void this.router.navigateByUrl(href);
  }

  constructor(
    private readonly container: ElementRef<HTMLElement>,
    private readonly domSanitizer: DomSanitizer,
    private readonly router: Router,
    private userEventService: UserEventService,
    private userHelper: UserHelper
  ) {}
}

@NgModule({
  declarations: [InternalInnerHtmlDirective],
  exports: [InternalInnerHtmlDirective]
})
export class InternalInnerHtmlDirectiveModule {}
