import { Directive, HostListener } from '@angular/core';
import { NavigationService } from 'src/app/core/services/navigation.service';

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[backButton]',
  standalone: false
})
export class BackButtonDirective {
  @HostListener('click', ['$event'])
  onClick(event: MouseEvent): void {
    event.preventDefault();
    event.stopPropagation();

    this.navigationService.back();
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' || event.key === ' ') {
      this.navigationService.back();
    }
  }

  constructor(private navigationService: NavigationService) {}
}
