import { Directive, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';

export enum IntersectionStatus {
  visible = 'Visible',
  pending = 'Pending',
  notVisible = 'NotVisible'
}

export const fromIntersectionObserver = (
  element: HTMLElement,
  config: IntersectionObserverInit,
  debounce = 0,
  singleObservation = false
): Observable<IntersectionStatus> =>
  new Observable<IntersectionStatus>((subscriber) => {
    const subject$ = new Subject<{
      entry: IntersectionObserverEntry;
      observer: IntersectionObserver;
    }>();

    const intersectionObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (isIntersecting(entry) || !singleObservation) {
          subject$.next({ entry, observer });
        }
      });
    }, config);

    subject$.subscribe(() => {
      subscriber.next(IntersectionStatus.pending);
    });

    subject$.pipe(debounceTime(debounce)).subscribe(({ entry, observer }) => {
      void (async () => {
        const isEntryVisible = await isVisible(entry.target as HTMLElement);

        if (isEntryVisible) {
          subscriber.next(IntersectionStatus.visible);
          if (singleObservation) {
            observer.unobserve(entry.target);
          }
        } else {
          subscriber.next(IntersectionStatus.notVisible);
        }
      })();
    });

    intersectionObserver.observe(element);

    if (singleObservation) {
      return () => {
        intersectionObserver.disconnect();
        subject$.unsubscribe();
      };
    }
  });

const isVisible = async (element: HTMLElement): Promise<boolean> =>
  new Promise((resolve) => {
    const observer = new IntersectionObserver(([entry]) => {
      resolve(entry.isIntersecting);
      observer.disconnect();
    });

    observer.observe(element);
  });

const isIntersecting = (entry: IntersectionObserverEntry) => entry.isIntersecting || entry.intersectionRatio > 0;

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[intersectionObserver]',
  standalone: false
})
export class IntersectionObserverDirective implements OnInit, OnDestroy {
  @Input() intersectionDebounce = 0;
  @Input() intersectionRootMargin = '0px';
  @Input() intersectionRoot: HTMLElement;
  @Input() intersectionThreshold: number | number[];
  @Input() singleObservation = false;

  @Output() visibilityChange = new EventEmitter<IntersectionStatus>();

  private destroy$ = new Subject();
  private elementRef: ElementRef;

  constructor(element: ElementRef) {
    this.elementRef = element;
  }

  ngOnInit(): void {
    if (!('IntersectionObserver' in window)) {
      return;
    }

    const config = {
      root: this.intersectionRoot,
      rootMargin: this.intersectionRootMargin,
      threshold: this.intersectionThreshold
    };
    fromIntersectionObserver(this.elementRef.nativeElement, config, this.intersectionDebounce, this.singleObservation)
      .pipe(takeUntil(this.destroy$))
      .subscribe((status) => {
        this.visibilityChange.emit(status);
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }
}
