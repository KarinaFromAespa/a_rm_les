import { Location } from '@angular/common';
import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { UrlHelper } from 'src/app/core/helpers/url.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IPageLink, ITrigger, LinkType, TriggerType } from 'src/app/core/models/site.response';
import { ConsentService } from 'src/app/core/services/consent.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalLoginHelper } from 'src/app/features/modal/modal-login.helper';
import { MyCardSheetService } from '../components/my-card-sheet/my-card-sheet.service';

@Directive({
  selector: '[airLink]',
  standalone: false
})
export class LinkDirective {
  link: IPageLink | ITrigger | string | null | undefined;
  @Input() userEventSource: string;
  @Input() userEventLabel?: string;
  @Input() userEventObject?: unknown;

  @HostListener('click', ['$event'])
  onClick(event: Event): void {
    const element = event.target as HTMLElement;
    const anchorElement = element.closest('a');

    let route = anchorElement?.getAttribute('href');
    const target = anchorElement?.getAttribute('target');
    if (route) {
      this.pushUserEvent(anchorElement?.text, route);

      const isRouterLink = anchorElement?.classList.contains('routerlink');
      if (isRouterLink || PlatformHelper.isNativeMobile) {
        // Only intercept links if is router link or in app
        event.preventDefault();
        event.stopPropagation();
        if (isRouterLink) {
          //If route is a absolute url of current domain, convert to relative url
          if (route.includes(location.host)) {
            const url = new URL(route);
            route = url.pathname + url.search;
          }
          void this.router.navigateByUrl(route);
        } else {
          window.open(route, target ?? '_system');
        }
      }
    }
  }

  @Input() set airLink(link: IPageLink | ITrigger | string | null | undefined) {
    const anchorHTMLElement = this.anchorElement.nativeElement as HTMLAnchorElement;
    if (!anchorHTMLElement) {
      return;
    }

    if (typeof link === 'string') {
      // If link is on current domain, regard as routerLink. If link is external, open as nofollow link
      if (!UrlHelper.isExternalLink(link)) {
        anchorHTMLElement.classList.add('routerlink');
        this.checkActiveClass(anchorHTMLElement, link);
      } else {
        this.renderer.setAttribute(anchorHTMLElement, 'rel', 'nofollow');
      }
      this.renderer.setAttribute(anchorHTMLElement, 'href', link);
    } else {
      switch (link?.contentTypeAlias) {
        case LinkType.pageLink:
        case LinkType.externalLink:
          {
            const pageLink = link as IPageLink;
            const [pageObj] = ObjectHelper.wrapFieldToArray(pageLink?.page);

            const pageUrl = pageObj?._url || pageLink?.url;

            if (!pageUrl) {
              return;
            }

            if (!UrlHelper.isExternalLink(pageUrl) && link.contentTypeAlias !== LinkType.externalLink) {
              this.renderer.setAttribute(anchorHTMLElement, 'href', pageUrl);
              // Add routerlink class to let the host listener on app.component know
              // the navigation click should be handled using the router.
              anchorHTMLElement?.classList.add('routerlink');
              this.checkActiveClass(anchorHTMLElement, pageUrl);
            } else {
              // Treat all external links as external even if on same domain
              this.renderer.setAttribute(anchorHTMLElement, 'href', pageUrl);
              this.renderer.setAttribute(anchorHTMLElement, 'rel', 'nofollow');
              if (pageLink.bypassInAppBrowser === true) {
                this.renderer.setAttribute(anchorHTMLElement, 'target', '_system');
              } else {
                this.renderer.setAttribute(anchorHTMLElement, 'target', '_blank');
              }
            }
          }
          break;
        case LinkType.trigger:
          {
            const trigger = link as ITrigger;

            this.renderer.listen(anchorHTMLElement, 'click', () => {
              this.handleLinkTrigger(anchorHTMLElement, trigger);
            });

            this.renderer.listen(anchorHTMLElement, 'keydown', (event: KeyboardEvent) => {
              if (event.key === 'Enter') {
                this.handleLinkTrigger(anchorHTMLElement, trigger);
              }
            });
          }
          break;
      }
    }

    const href = anchorHTMLElement.getAttribute('href');
    if (href) {
      anchorHTMLElement.setAttribute('href', UrlHelper.insertUserProperties(href, this.userHelper.currentUser));
    }
  }

  constructor(
    private readonly anchorElement: ElementRef,
    private renderer: Renderer2,
    private router: Router,
    private location: Location,
    private modalLoginHelper: ModalLoginHelper,
    private consentService: ConsentService,
    private userEventService: UserEventService,
    private myCardSheetService: MyCardSheetService,
    private userHelper: UserHelper
  ) {}

  checkActiveClass(anchorElement: HTMLElement, url: string): void {
    if (this.location.normalize(this.router.url) === this.location.normalize(url)) {
      anchorElement?.parentElement?.classList.add('active');
    }
  }

  private handleLinkTrigger(anchorHTMLElement: HTMLAnchorElement, trigger: ITrigger): void {
    this.pushUserEvent(anchorHTMLElement.text, trigger.type.toLowerCase());
    switch (trigger.type) {
      case TriggerType.login:
        this.modalLoginHelper.triggerPasswordLoginModal(this.userEventSource);
        break;
      case TriggerType.consent:
        this.consentService.open();
        break;
      case TriggerType.cards:
        this.myCardSheetService.open();
    }
  }

  private pushUserEvent(label?: string, value?: string) {
    if (this.userEventSource) {
      this.userEventService.pushEvent(
        this.userEventSource,
        UserEventAction.link,
        this.userEventLabel ?? (this.link as IPageLink)?.label ?? label,
        value,
        this.userEventObject
      );
    }
  }
}
