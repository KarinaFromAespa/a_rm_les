import { Directive, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[airButtonLoading]',
  standalone: false
})
export class ButtonLoaderDirective implements OnChanges {
  private isLoading: boolean;

  @Input() set airButtonLoading(value: boolean) {
    this.isLoading = value;
  }

  constructor(private readonly button: ElementRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.airButtonLoading.isFirstChange()) {
      return;
    }
    this.showLoader();
  }

  private showLoader(): void {
    if (this.isLoading) {
      (this.button.nativeElement as HTMLElement)?.insertAdjacentHTML('beforeend', '<i class="icon loader--spinner"></i>');
      (this.button.nativeElement as HTMLElement)?.classList.add('button--disabled');
    } else {
      const existingLoaders = (this.button.nativeElement as HTMLElement)?.querySelectorAll('.loader--spinner');
      existingLoaders.forEach((el) => el.remove());
      (this.button.nativeElement as HTMLElement)?.classList.remove('button--disabled');
    }
  }
}
