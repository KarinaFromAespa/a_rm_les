import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { FormFieldName, FormType, FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { ITextControl } from 'src/app/core/models/form.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalService } from 'src/app/features/modal/modal.service';
import { IVerificationCodeValidationRequest, IVerificationModal } from './verification-modal.model';

@Component({
  selector: 'air-verification-modal',
  templateUrl: './verification-modal.component.html',
  standalone: false
})
export class VerificationModalComponent extends BaseFormComponent<IVerificationCodeValidationRequest> implements OnInit {
  @Input() content: IVerificationModal;

  isResendLoading: boolean;
  isResendDisabled: boolean;
  isLoading = true;

  readonly alternateReCaptchaActions = [ReCaptchaAction.createTwoFactorLoginToken];

  get enableVerificationCodeSendAlternateReCaptcha(): boolean {
    return (
      !!this.content.alternateReCaptchaText &&
      (this.reCaptchaService?.enableAlternateReCaptcha?.[ReCaptchaAction.sendEmailAddressVerificationCode] ?? false)
    );
  }

  get enableVerificationCodeValidationAlternateReCaptcha(): boolean {
    return this.reCaptchaService?.enableAlternateReCaptcha?.[ReCaptchaAction.emailAddressVerificationCodeValidation] ?? false;
  }

  get submitLabel(): string {
    return this.enableVerificationCodeSendAlternateReCaptcha
      ? this.translateService.instant('account.label.send_verification_code')
      : this.content.verifyButtonText;
  }

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected reCaptchaService: ReCaptchaService,
    private modalService: ModalService,
    private translateService: TranslateService
  ) {
    super(userEventService, platformHelper);
  }

  async ngOnInit(): Promise<void> {
    super.ngOnInit();
    this.form = [
      {
        controls: [
          {
            type: FormType.numberOnly,
            name: FormFieldName.verificationCode,
            label: this.translateService.instant('account.label.verification_code') as string,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.verification_code.required') as string
              },
              {
                validator: FormValidatorType.pattern(FormRegex.authenticationCode.getRegExp()),
                errorMessage: this.translateService.instant('account.error.verification_code.invalid') as string
              },
              {
                validator: FormValidatorType.verificationCode,
                errorMessage: this.translateService.instant('account.error.verification_code.incorrect') as string
              }
            ]
          } as ITextControl
        ]
      }
    ];

    this.userEventSource = `${this.content?.userEventSource} - ${this.content?.verificationCodeMessageType.toLowerCase()} verification`;
    await this.sendCode().finally(() => {
      this.isLoading = false;
    });

    if (this.content.resendButtonDisabledTimeout && this.content.resendButtonDisabledTimeout > 0) {
      this.isResendDisabled = true;

      setTimeout(() => {
        this.isResendDisabled = false;
      }, this.content.resendButtonDisabledTimeout);
    }
  }

  async submitValues(values: IVerificationCodeValidationRequest): Promise<void> {
    if (this.isSubmitting) {
      return;
    }

    this.isSubmitting = true;
    await this.content
      .verifyAction(values.verificationCode)
      .then(async () => {
        if (!this.content.keepOpenAfterVerify) {
          this.onCloseModal(false, false);
        }

        if (this.content.verifyCallback) {
          await this.content.verifyCallback(values.verificationCode);
        }
      })
      .catch((error: IHttpError) => {
        if ([HttpErrorCodes.forbidden, HttpErrorCodes.invalidVerificationCode].includes(error?.error?.code)) {
          this.formComponent.form.get(FormFieldName.verificationCode)?.setErrors({ [FormValidatorTypeKeys.verificationCode]: true });
        }

        this.formComponent.reCaptchaFallbackComponent?.reset();
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  resendCode(event: Event): Promise<void> {
    if (this.content.prevModal) {
      this.pushUserEvent(UserEventAction.link, event.text(), 'back');

      return this.modalService.openWithOnClose(this.modalService.modalRef?.options, this.content.prevModal, {
        onLoginCallback: this.content.verifyCallback?.bind(this) as () => Promise<void>,
        color: this.content.color
      });
    } else {
      this.pushUserEvent(UserEventAction.submit, event.text());
    }
    void this.sendCode();
    this.disableResend();
    return Promise.resolve();
  }

  async sendCodeAlternateReCaptcha(): Promise<void> {
    this.isSubmitting = true;
    await this.sendCode().finally(() => {
      this.isSubmitting = false;
    });
  }

  onCloseModal(checkCloseCallback = true, pushUserEvent = true): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }

    this.modalService.close(checkCloseCallback);
  }

  private disableResend(): void {
    this.isResendLoading = true;
    setTimeout(() => {
      this.isResendLoading = false;
    }, 30000);
  }

  async sendCode(): Promise<void> {
    await this.content?.sendCodeAction();
  }
}
