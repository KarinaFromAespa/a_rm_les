import { Component, Type } from '@angular/core';
import { IColor, IText, IVerifyContentBlock } from 'src/app/core/models/content.model';

export enum VerificationModalView {
  loading,
  sendVerificationCode,
  twoFactorNotPossible
}

export enum VerificationCodeMessageType {
  email = 'Email',
  sms = 'Sms'
}

export class VerificationCodeRequest {
  constructor(messageType: VerificationCodeMessageType) {
    this.messageType = messageType;
  }

  messageType: VerificationCodeMessageType;
}

export interface IVerificationCodeValidationRequest {
  verificationCode: string;
}

export interface IVerificationModal {
  text: IText;
  alternateReCaptchaText?: IText;
  verifyButtonText: string;
  verificationCodeMessageType: VerificationCodeMessageType;
  keepOpenAfterVerify: boolean;
  sendCodeAction: () => Promise<void>;
  verifyAction: (verificationCode: string) => Promise<void>;
  verifyCallback: (verificationCode: string) => Promise<void>; // Call back on successfully verified
  prevModal?: Type<Component>;
  userEventSource: string;
  resendButtonDisabledTimeout?: number;
  color?: IColor;
}

export interface IVerificationInitializeRequest {
  userEventSource: string;
  content: IVerifyContentBlock;
}

export interface IVerificationRequest {
  verifyType: VerificationCodeMessageType;

  emailAddress?: string;
  phoneNumber?: string;
  keepOpenAfterVerify?: boolean;

  verifyCallback: (verificationCode: string) => Promise<void>;
  closeCallback?: () => void;
}
