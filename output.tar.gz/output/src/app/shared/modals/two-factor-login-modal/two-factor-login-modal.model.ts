import { VerificationCodeMessageType } from '../verification-modal/verification-modal.model';

export enum TwoFactorModalView {
  loading,
  sendVerificationCode,
  twoFactorNotPossible
}

export class TwoFactorAuthorizationCodeRequest {
  constructor(messageType: VerificationCodeMessageType) {
    this.messageType = messageType;
  }

  messageType: VerificationCodeMessageType;
}

export class TwoFactorAuthenticationToken {
  constructor(token: string) {
    this.token = token;
  }

  token: string;
}
