import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { ObjectHelper } from 'src/app/core/helpers/object.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { IColor, IText } from 'src/app/core/models/content.model';
import { TwoFactorLoginRequest } from 'src/app/core/models/login.request';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { UserContactDetails } from 'src/app/core/models/user.model';
import { BiometricsService } from 'src/app/core/services/biometrics.service';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { SiteService } from 'src/app/core/services/site.service';
import { TokenService } from 'src/app/core/services/token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { ModalService } from 'src/app/features/modal/modal.service';
import { VerificationModalComponent } from '../verification-modal/verification-modal.component';
import { IVerificationModal, VerificationCodeMessageType } from '../verification-modal/verification-modal.model';
import { TwoFactorAuthorizationCodeRequest, TwoFactorModalView } from './two-factor-login-modal.model';

@Component({
  selector: 'air-two-factor-login-modal',
  templateUrl: './two-factor-login-modal.component.html',
  standalone: false
})
export class TwoFactorLoginModalComponent implements OnInit, OnDestroy {
  @Input() onLoginCallback?: () => void;
  @Input() userEventSource: string;
  @Input() twoFactorVerification: IText;
  @Input() triggerBiometrics = true;
  @Input() color?: IColor;

  twoFactorModalView = TwoFactorModalView;
  verificationCodeMessageType = VerificationCodeMessageType;

  view = TwoFactorModalView.loading;
  verifyType: VerificationCodeMessageType;
  contactDetails: UserContactDetails;

  twoFactorOptions?: IText;
  twoFactorIncompleteAccount?: IText;
  twoFactorVerificationFormatted: IText;

  sentTo: string;

  destroy$ = new Subject();

  constructor(
    private tokenService: TokenService,
    private userService: UserService,
    private userHelper: UserHelper,
    private modalService: ModalService,
    private translateService: TranslateService,
    private siteService: SiteService,
    private userEventService: UserEventService,
    private reCaptchaService: ReCaptchaService,
    private biometricsService: BiometricsService
  ) {}

  async ngOnInit(): Promise<void> {
    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.twoFactorOptions = data?.twoFactorOptions;
      this.twoFactorIncompleteAccount = data?.twoFactorIncompleteAccount;

      if (this.twoFactorVerification || data?.twoFactorVerification) {
        this.twoFactorVerificationFormatted = ObjectHelper.deepCopy(this.twoFactorVerification || data?.twoFactorVerification) as IText;
      }
    });

    await this.userService.getUserContactDetails().then(async (contactDetails: UserContactDetails) => {
      this.contactDetails = Object.assign(new UserContactDetails(), contactDetails);
      if (!this.contactDetails.emailAddress && !this.contactDetails.phoneNumber) {
        this.view = TwoFactorModalView.twoFactorNotPossible;
        return;
      }

      if (this.contactDetails.emailAddress && this.contactDetails.phoneNumber && !(await this.biometricsService.hasPasswordCredentials())) {
        this.view = TwoFactorModalView.sendVerificationCode;
      } else {
        this.verifyType = this.contactDetails.emailAddress ? VerificationCodeMessageType.email : VerificationCodeMessageType.sms;
        await this.verify(this.verifyType);
      }
    });

    this.userEventSource = this.userEventSource ? `${this.userEventSource} - two-factor login` : 'two-factor login';
  }

  ngOnDestroy(): void {
    this.destroy$.next(void 0);
  }

  async verify(verificationCodeMessageType: VerificationCodeMessageType, event?: Event): Promise<void> {
    if (event) {
      this.pushUserEvent(UserEventAction.link, event, verificationCodeMessageType.toLowerCase());
    }

    this.verifyType = verificationCodeMessageType;
    if (this.twoFactorVerificationFormatted) {
      this.twoFactorVerificationFormatted.body = this.twoFactorVerificationFormatted.body.format([
        verificationCodeMessageType === VerificationCodeMessageType.email
          ? (this.contactDetails.emailAddress ?? '')
          : (this.contactDetails.phoneNumber ?? '')
      ]);
    }

    const verificationModal = {
      text: this.twoFactorVerificationFormatted,
      verifyButtonText: this.translateService.instant('general.label.continue') as string,
      verificationCodeMessageType,
      sendCodeAction: this.sendCode.bind(this) as () => Promise<void>,
      verifyAction: this.verifyCode.bind(this) as () => Promise<void>,
      verifyCallback: this.onLoginCallback?.bind(this) as () => Promise<void>,
      keepOpenAfterVerify: false,
      prevModal: TwoFactorLoginModalComponent,
      userEventSource: this.userEventSource,
      resendButtonDisabledTimeout: 30000,
      color: this.color
    } as IVerificationModal;

    await this.modalService.openWithOnClose(this.modalService.modalRef?.options, VerificationModalComponent, {
      content: verificationModal
    });
  }

  async sendCode(): Promise<void> {
    const request = new TwoFactorAuthorizationCodeRequest(this.verifyType);
    await this.tokenService.createTwoFactorAuthenticationCode(request);
  }

  async verifyCode(verificationCode: string): Promise<void> {
    const request = new TwoFactorLoginRequest(
      this.userHelper.currentUser?.refreshToken,
      verificationCode,
      undefined,
      this.triggerBiometrics
    );
    return this.reCaptchaService.verify<void, TwoFactorLoginRequest>(
      ReCaptchaAction.createTwoFactorLoginToken,
      request,
      this.tokenService.createTwoFactorLoginToken.bind(this.tokenService)
    );
  }

  closeModal(): void {
    this.pushUserEvent(UserEventAction.close);
    this.modalService.close(true);
  }

  private pushUserEvent(action: UserEventAction, event?: Event, value?: string): void {
    this.userEventService.pushEvent(this.userEventSource, action, event?.text(), value);
  }
}
