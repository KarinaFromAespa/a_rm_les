import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { FormFieldName, FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { IColor, IText } from 'src/app/core/models/content.model';
import { FormValidatorType } from 'src/app/core/models/form-validator.model';
import { ITextControl } from 'src/app/core/models/form.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { SiteService } from 'src/app/core/services/site.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { UserService } from 'src/app/core/services/user.service';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalOptions } from 'src/app/features/modal/modal.model';
import { ModalService } from 'src/app/features/modal/modal.service';
import { IPasswordResetModalInputs, UserPasswordResetTokenCreateRequest } from './password-reset-modal.model';

@Component({
  selector: 'air-password-reset-modal',
  templateUrl: './password-reset-modal.component.html',
  standalone: false
})
export class PasswordResetModalComponent extends BaseFormComponent<UserPasswordResetTokenCreateRequest> implements OnInit, OnDestroy {
  @Input() inputs: IPasswordResetModalInputs;
  @Input() modalOptions: ModalOptions;
  @Input() onCloseCallback?: () => void;
  @Input() onSuccessCloseCallback?: () => void;
  @Input() standalone;
  @Input() color?: IColor;

  showResponse = false;
  isSuccess = false;

  passwordResetErrorNoAccount?: IText;
  passwordResetErrorBlockedAccount?: IText;
  passwordResetSuccess?: IText;
  passwordResetMessage?: IText;
  passwordResetBaseUrl?: string;

  preValues: UserPasswordResetTokenCreateRequest;
  readonly reCaptchaAction = ReCaptchaAction.sendPasswordResetToken;

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected reCaptchaService: ReCaptchaService,
    private modalService: ModalService,
    private translateService: TranslateService,
    private userService: UserService,
    private siteService: SiteService
  ) {
    super(userEventService, platformHelper, undefined, reCaptchaService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.preValues = this.inputs?.preValues as UserPasswordResetTokenCreateRequest;

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.passwordResetBaseUrl = data?.passwordResetPageUrl;
      this.passwordResetErrorNoAccount = data?.passwordTokenNoAccount;
      this.passwordResetErrorBlockedAccount = data?.passwordTokenBlockedAccount;
      this.passwordResetSuccess = data?.passwordTokenSuccess;
    });

    this.form = [
      {
        controls: [
          {
            type: FormType.email,
            name: FormFieldName.emailAddress,
            autocomplete: 'email',
            label: this.translateService.instant('account.label.email') as string,
            value: this.preValues && this.preValues.emailAddress ? this.preValues.emailAddress : null,
            placeholder: this.translateService.instant('account.label.your_email') as string,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.email.required') as string
              },
              {
                validator: FormValidatorType.email,
                errorMessage: this.translateService.instant('account.error.email.invalid') as string
              }
            ]
          } as ITextControl
        ]
      }
    ];

    this.userEventSource = `${this.inputs?.userEventSource} - password reset`;
  }

  async submitValues(values: UserPasswordResetTokenCreateRequest): Promise<void> {
    this.isSubmitting = true;
    // Send password reset request
    values.passwordResetBaseUrl = `${this.platformHelper.getCurrentAbsoluteBaseUrl()}${this.passwordResetBaseUrl}`;
    this.isSuccess = false;

    await this.reCaptchaService
      .verify(this.reCaptchaAction, values, this.userService.createPasswordResetToken.bind(this.userService))
      .then(() => {
        // Set close callback to success action
        this.pushUserSuccessEvent();
        if (this.onSuccessCloseCallback) {
          this.modalOptions.onCloseCallback = this.onSuccessCloseCallback;
        }

        this.passwordResetMessage = this.passwordResetSuccess;

        if (this.passwordResetMessage) {
          this.passwordResetMessage.body = this.passwordResetMessage.body.format([values.emailAddress ?? '']);
        }

        this.isSuccess = true;
        this.showResponse = true;
      })
      .catch((error: IHttpError) => {
        switch (error?.error?.code) {
          case HttpErrorCodes.accountNotFound:
            this.passwordResetMessage = this.passwordResetErrorNoAccount;
            this.showResponse = true;
            break;
          case HttpErrorCodes.invalidAccount:
            this.passwordResetMessage = this.passwordResetErrorBlockedAccount;
            this.showResponse = true;
            break;
          default:
            this.showResponse = false;
            break;
        }

        this.formComponent.reCaptchaFallbackComponent?.reset();
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  async back(event: Event): Promise<void> {
    this.pushUserEvent(UserEventAction.link, event.text(), 'back');
    this.modalOptions.onCloseCallback = this.onCloseCallback;
    if (this.inputs?.prevModal) {
      return this.modalService.openWithOnClose(this.modalOptions, this.inputs.prevModal, {
        onCloseCallback: this.modalOptions.onCloseCallback,
        onLoginCallback: this.inputs.prevLoginCallback,
        checkLoginCloseCallback: this.inputs.prevCheckLoginCloseCallback,
        completeProfilePage: this.inputs.prevCompleteProfilePage,
        alternateMode: this.inputs.alternateMode,
        userEventSource: this.inputs.userEventSource,
        loginUsernameNotice: this.inputs.prevLoginUsernameNotice,
        partnerNotice: this.inputs.prevPartnerNotice,
        color: this.inputs.prevColor
      });
    }
    this.closeModal();
  }

  openResetForm(event: Event): void {
    this.pushUserEvent(UserEventAction.link, event.text(), 'retry');
    this.showResponse = false;
  }

  closeModal(pushUserEvent = false, event?: Event): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close, event?.text());
    }

    this.modalService.close();
  }
}
