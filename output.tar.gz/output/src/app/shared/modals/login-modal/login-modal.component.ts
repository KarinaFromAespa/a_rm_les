import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { FormFieldName, FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { IColor } from 'src/app/core/models/content.model';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormControl, IFormSection, IPasswordControl } from 'src/app/core/models/form.model';
import { PasswordLoginRequest } from 'src/app/core/models/login.request';
import { ReCaptchaAction } from 'src/app/core/models/reCaptcha.request';
import { IPage } from 'src/app/core/models/site.response';
import { ReCaptchaService } from 'src/app/core/services/re-captcha.service';
import { SiteService } from 'src/app/core/services/site.service';
import { TokenService } from 'src/app/core/services/token.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalService } from 'src/app/features/modal/modal.service';
import { PasswordResetModalComponent } from '../password-reset-modal/password-reset-modal.component';
import { IPasswordResetModalInputs } from '../password-reset-modal/password-reset-modal.model';
import { LoginFormRequest } from './login-modal.model';
import { LoginModalService } from './login-modal.service';

@Component({
  selector: 'air-login-modal',
  templateUrl: './login-modal.component.html',
  standalone: false
})
export class LoginModalComponent extends BaseFormComponent<LoginFormRequest> implements OnInit, OnDestroy {
  @Input() emailAddress: string;
  @Input() onLoginCallback?: () => void;
  @Input() checkLoginCloseCallback = false;
  @Input() completeProfilePage: IPage;
  @Input() loginSuccessPage?: IPage;
  @Input() alternateMode = false;
  @Input() loginUsernameNotice?: string;
  @Input() partnerNotice?: string;
  @Input() color?: IColor;
  @Input() triggerBiometrics = true;

  userEventSourceInput: string;
  defaultRegistrationPageUrl?: string;
  passwordResetPage: string;

  readonly reCaptchaAction = ReCaptchaAction.createPasswordLoginToken;

  constructor(
    protected reCaptchaService: ReCaptchaService,
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    private loginModalService: LoginModalService,
    private modalService: ModalService,
    private translateService: TranslateService,
    private tokenService: TokenService,
    private siteService: SiteService,
    private router: Router
  ) {
    super(userEventService, platformHelper, undefined, reCaptchaService);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.siteService.pageContext.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.defaultRegistrationPageUrl = data?.defaultRegistrationPageUrl;

      if (!this.loginUsernameNotice?.length) {
        this.loginUsernameNotice = data?.loginUsernameNotice;
      }
      if (!this.partnerNotice?.length) {
        this.partnerNotice = data?.partnerNotice;
      }
      if (!this.color?.color.length) {
        this.color = data?.color;
      }
    });

    this.form = [
      {
        controls: [
          {
            type: FormType.text,
            label: this.translateService.instant('account.label.email') as string,
            description: this.loginUsernameNotice,
            textOnlyDescription: true,
            name: FormFieldName.emailAddress,
            autocomplete: 'email',
            placeholder: this.translateService.instant('account.label.your_email') as string,
            value: this.emailAddress,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.email.required') as string
              },
              {
                validator: FormValidatorType.email,
                errorMessage: this.translateService.instant('account.error.email.invalid') as string
              }
            ],
            updateOn: 'blur',
            trim: true
          } as IFormControl,
          {
            type: FormType.password,
            label: this.translateService.instant('account.label.password') as string,
            name: FormFieldName.password,
            autocomplete: 'current-password',
            placeholder: this.translateService.instant('account.label.your_password') as string,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.password.required') as string
              },
              {
                validator: FormValidatorType.typedPattern('passwordLogin', FormRegex.password)
              }
            ],
            enableShowPassword: true,
            updateOn: 'blur',
            eyeColor: this.color
          } as IPasswordControl
        ]
      } as IFormSection
    ];

    this.userEventSourceInput = this.userEventSource;
    this.userEventSource = this.userEventSource ? `${this.userEventSource} - password login` : 'password login';
  }

  goToRegistrationPage(event: Event): void {
    this.pushUserEvent(UserEventAction.link, event.text(), this.defaultRegistrationPageUrl);
    if (this.defaultRegistrationPageUrl) {
      this.router.navigateByUrl(this.defaultRegistrationPageUrl);
    }
    this.closeModal(false);
  }

  async submitValues(values: LoginFormRequest): Promise<void> {
    this.isSubmitting = true;

    const request: PasswordLoginRequest = new PasswordLoginRequest(values.emailAddress, values.password, this.triggerBiometrics);
    await this.reCaptchaService
      .verify(this.reCaptchaAction, request, this.tokenService.createPasswordLoginToken.bind(this.tokenService))
      .then(() => {
        this.loginModalService.handleLoginCallback(
          this.userEventSource,
          this.completeProfilePage,
          this.loginSuccessPage,
          this.onLoginCallback,
          this.checkLoginCloseCallback
        );
      })
      .catch(() => {
        this.formComponent.reCaptchaFallbackComponent?.reset();
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  submit(event: Event): void {
    // Fix autofill inputs that are not blurred
    if (this.formComponent.formElement) {
      const keys = Object.keys(this.formComponent.form.controls);
      keys.forEach((key) => {
        const inputValue = this.formComponent.formElement?.nativeElement.querySelector<HTMLInputElement>(`input[id='${key}']`)?.value;
        const formValue = this.formComponent.form.get(key)?.value;

        if (inputValue !== formValue) {
          this.formComponent.form.get(key)?.setValue(inputValue);
        }
      });
    }

    super.submit(event);
  }

  closeModal(checkCloseCallback = true, pushUserEvent = false): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }

    this.modalService.close(checkCloseCallback);
  }

  async openPasswordResetModal(event: Event): Promise<void> {
    this.pushUserEvent(UserEventAction.link, event.text(), 'password reset');

    // Pass modal as parameter to avoid circular dependency
    const emailAddress = this.formComponent.form.get(FormFieldName.emailAddress)?.value as string;

    await this.modalService.openWithOnClose(this.modalService.modalRef?.options, PasswordResetModalComponent, {
      inputs: {
        preValues: { emailAddress },
        prevModal: LoginModalComponent,
        prevLoginCallback: this.onLoginCallback,
        prevCheckLoginCloseCallback: this.checkLoginCloseCallback,
        prevCompleteProfilePage: this.completeProfilePage,
        prevLoginUsernameNotice: this.loginUsernameNotice,
        prevPartnerNotice: this.partnerNotice,
        prevColor: this.color,
        alternateMode: this.alternateMode,
        userEventSource: this.userEventSourceInput
      } as IPasswordResetModalInputs,
      modalOptions: this.modalService.modalRef?.options,
      onCloseCallback: this.modalService.modalRef?.options.onCloseCallback,
      color: this.color
    });
  }
}
