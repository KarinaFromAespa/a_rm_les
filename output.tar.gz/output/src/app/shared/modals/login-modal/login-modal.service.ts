import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { InboxHelper } from 'src/app/core/helpers/inbox.helper';
import { PromotionHelper } from 'src/app/core/helpers/promotion.helper';
import { UserHelper } from 'src/app/core/helpers/user.helper';
import { VerificationHelper } from 'src/app/core/helpers/verification.helper';
import { IUserLoginData } from 'src/app/core/models/login.response';
import { IPage } from 'src/app/core/models/site.response';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalService } from 'src/app/features/modal/modal.service';

@Injectable({ providedIn: 'root' })
export class LoginModalService {
  constructor(
    private modalService: ModalService,
    private promotionHelper: PromotionHelper,
    private inboxHelper: InboxHelper,
    private userHelper: UserHelper,
    private verificationHelper: VerificationHelper,
    private router: Router,
    private userEventService: UserEventService
  ) {}

  handleLoginCallback(
    userEventSource: string,
    completeProfilePage?: IPage,
    loginSuccessPage?: IPage,
    onLoginCallback?: () => void,
    checkLoginCloseCallback = false,
    onCloseCallback?: () => void
  ): void {
    void this.promotionHelper.refreshUnactivatedPromotionsCounter();
    void this.inboxHelper.refreshUnreadInboxCount();
    this.userEventService.pushEvent(userEventSource, UserEventAction.success);

    if (onLoginCallback) {
      onLoginCallback();
      return;
    }

    this.addCloseCallbackListeners(loginSuccessPage);

    if (completeProfilePage && !(this.userHelper.currentUser as IUserLoginData)?.hasCompleteProfile) {
      void this.router.navigate([completeProfilePage._url]);
      this.close();
      return;
    }

    this.close(onCloseCallback, checkLoginCloseCallback);
  }

  async handleTwoFactorCallback(onCloseCallback?: () => void, onLoginCallback?: () => Promise<void>): Promise<void> {
    if (onLoginCallback) {
      await onLoginCallback();
      return;
    }

    this.close(onCloseCallback, true);
  }

  private addCloseCallbackListeners(loginSuccessPage?: IPage): void {
    this.userHelper.profileCompleted$.pipe(first()).subscribe(() => {
      const target = loginSuccessPage?._url ?? '/';
      void this.router.navigateByUrl(target);
    });
  }

  private close(onCloseCallback?: () => void, checkCloseCallback = false): void {
    if (checkCloseCallback && onCloseCallback) {
      onCloseCallback();
      return;
    }

    this.modalService.close(checkCloseCallback);
  }
}
