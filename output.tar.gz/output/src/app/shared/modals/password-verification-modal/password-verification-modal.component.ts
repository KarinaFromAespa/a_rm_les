import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorCodes } from 'src/app/core/constants/error.constants';
import { FormFieldName, FormType, FormValidatorTypeKeys } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { FormRegex, FormValidatorType } from 'src/app/core/models/form-validator.model';
import { ITextControl } from 'src/app/core/models/form.model';
import { IHttpError } from 'src/app/core/models/http.model';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalService } from 'src/app/features/modal/modal.service';
import { IPasswordVerificationCodeValidationRequest, IPasswordVerificationModal } from './password-verification-modal.model';

@Component({
  selector: 'air-password-verification-modal',
  templateUrl: './password-verification-modal.component.html',
  standalone: false
})
export class PasswordVerificationModalComponent extends BaseFormComponent<IPasswordVerificationCodeValidationRequest> implements OnInit {
  @Input() content: IPasswordVerificationModal;

  isResendLoading: boolean;
  isResendDisabled: boolean;
  isLoading = true;

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    private modalService: ModalService,
    private translateService: TranslateService
  ) {
    super(userEventService, platformHelper);
  }

  async ngOnInit(): Promise<void> {
    super.ngOnInit();

    this.form = [
      {
        controls: [
          {
            type: FormType.numberOnly,
            name: FormFieldName.verificationCode,
            label: this.translateService.instant('account.label.verification_code') as string,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.verification_code.required') as string
              },
              {
                validator: FormValidatorType.pattern(FormRegex.authenticationCode.getRegExp()),
                errorMessage: this.translateService.instant('account.error.verification_code.invalid') as string
              },
              {
                validator: FormValidatorType.verificationCode,
                errorMessage: this.translateService.instant('account.error.verification_code.incorrect') as string
              }
            ]
          } as ITextControl
        ]
      }
    ];

    this.userEventSource = `${this.content?.userEventSource} - email verification`;
    await this.sendCode().finally(() => {
      this.isLoading = false;
    });

    if (this.content.resendButtonDisabledTimeout && this.content.resendButtonDisabledTimeout > 0) {
      this.isResendDisabled = true;

      setTimeout(() => {
        this.isResendDisabled = false;
      }, this.content.resendButtonDisabledTimeout);
    }
  }

  async submitValues(values: IPasswordVerificationCodeValidationRequest): Promise<void> {
    if (this.isSubmitting) {
      return;
    }

    this.isSubmitting = true;
    await this.verifyAction(values);
  }

  resendCode(event: Event): void {
    this.pushUserEvent(UserEventAction.submit, event.text());
    void this.sendCode();
    this.disableResend();
  }

  onCloseModal(checkCloseCallback = true, pushUserEvent = true): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }
    this.modalService.close(checkCloseCallback);
  }

  private disableResend(): void {
    this.isResendLoading = true;
    setTimeout(() => {
      this.isResendLoading = false;
    }, 30000);
  }

  async sendCode(): Promise<void> {
    await this.content?.sendCode();
  }

  private async verifyAction(values: IPasswordVerificationCodeValidationRequest): Promise<void> {
    await this.content
      .verifyAction(values.verificationCode)
      .then(async () => {
        if (this.content.verifyCallback) {
          this.modalService.close(false);
          await this.content.verifyCallback(values.verificationCode);
        }
      })
      .catch((error: IHttpError) => {
        if ([HttpErrorCodes.forbidden, HttpErrorCodes.invalidPasswordSetVerificationCode].includes(error?.error?.code)) {
          this.formComponent.form.get(FormFieldName.verificationCode)?.setErrors({ [FormValidatorTypeKeys.verificationCode]: true });
        }
      })
      .finally(() => {
        this.isSubmitting = false;
      });
  }
}
