import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { ModalService } from 'src/app/features/modal/modal.service';
import { IConfirmationModal } from './confirmation-modal.model';

@Component({
  selector: 'air-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  standalone: false
})
export class ConfirmationModalComponent implements OnInit {
  @Input() content: IConfirmationModal;

  isLoading = false;
  userEventSource: string;

  constructor(
    private modalService: ModalService,
    private translateService: TranslateService,
    private userEventService: UserEventService
  ) {}

  ngOnInit(): void {
    if (!this.content?.cancelText) {
      this.content.cancelText = this.translateService.instant('general.label.no_cancel') as string;
    }

    if (!this.content?.confirmText) {
      this.content.confirmText = this.translateService.instant('general.label.yes_i_am_sure') as string;
    }

    const modalDescription = this.content.userEventSourceTopic ? `${this.content.userEventSourceTopic} confirmation` : 'confirmation';
    this.userEventSource = `${this.content.userEventSource} - ${modalDescription}`;
  }

  confirmAction(event: Event): void {
    this.pushUserEvent(UserEventAction.confirm, event, this.content.userEventObject);
    if (this.content.closeOnSelection) {
      this.closeModal();
    }

    this.isLoading = true;

    Promise.resolve(this.content?.action()).finally(() => {
      this.isLoading = false;
      if (!this.content.closeOnSelection) {
        this.closeModal();
      }
    });
  }

  cancel(event: Event): void {
    this.pushUserEvent(UserEventAction.cancel, event);
    if (!this.content?.cancelAction || this.content.closeOnSelection) {
      this.closeModal();
    }

    if (this.content?.cancelAction) {
      Promise.resolve(this.content?.cancelAction()).finally(() => {
        if (this.content.closeOnSelection) {
          this.closeModal();
        }
      });
    }
  }

  closeModal(pushUserEvent = false): void {
    if (pushUserEvent) {
      this.pushUserEvent(UserEventAction.close);
    }

    this.modalService.modalRef?.close();
    this.modalService.close();
  }

  private pushUserEvent(action: UserEventAction, event?: Event, object?: object): void {
    this.userEventService.pushEvent(this.userEventSource, action, event?.text(), undefined, object);
  }
}
