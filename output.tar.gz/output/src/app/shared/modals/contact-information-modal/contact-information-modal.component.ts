import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormFieldName, FormType } from 'src/app/core/constants/form.constants';
import { UserEventAction } from 'src/app/core/constants/user-event.constants';
import { PlatformHelper } from 'src/app/core/helpers/platform.helper';
import { ContactFormQuestion, ContactFormRequest, IContactFormValues } from 'src/app/core/models/contact-form.model';
import { FormValidatorType } from 'src/app/core/models/form-validator.model';
import { IFormControl, IFormSection } from 'src/app/core/models/form.model';
import { UserContactDetails } from 'src/app/core/models/user.model';
import { FormsService } from 'src/app/core/services/forms.service';
import { UserEventService } from 'src/app/core/services/user-event.service';
import { BaseFormComponent } from 'src/app/features/form/base-form.component';
import { ModalService } from 'src/app/features/modal/modal.service';
import { ToastService } from 'src/app/features/toasts/toast.service';

@Component({
  selector: 'air-contact-information-modal',
  templateUrl: './contact-information-modal.component.html',
  standalone: false
})
export class ContactInformationModalComponent extends BaseFormComponent<IContactFormValues> implements OnInit {
  @Input() contactFormQuestion: ContactFormQuestion;
  @Input() successPageUrl: string;
  @Input() currentUserDetails: UserContactDetails;
  @Input() userEventSource: string;

  constructor(
    protected userEventService: UserEventService,
    protected platformHelper: PlatformHelper,
    protected toastService: ToastService,
    private translateService: TranslateService,
    private formsService: FormsService,
    private modalService: ModalService,
    private route: Router
  ) {
    super(userEventService, platformHelper, toastService);
  }

  ngOnInit(): void {
    this.form = [
      {
        controls: [
          {
            type: FormType.email,
            label: this.translateService.instant('account.label.email') as string,
            name: FormFieldName.emailAddress,
            autocomplete: 'email',
            placeholder: this.translateService.instant('account.label.your_email') as string,
            value: this.currentUserDetails?.emailAddress,
            validators: [
              {
                validator: FormValidatorType.required,
                errorMessage: this.translateService.instant('account.error.email.required') as string
              },
              {
                validator: FormValidatorType.email,
                errorMessage: this.translateService.instant('account.error.email.invalid') as string
              }
            ]
          } as IFormControl
        ]
      } as IFormSection
    ];

    this.userEventSource = `${this.userEventSource} - contact information`;
  }

  async submitValues(values: IContactFormValues): Promise<void> {
    this.isSubmitting = true;
    values.question = this.contactFormQuestion.question;
    values.uploadedFiles = this.contactFormQuestion.uploadedFiles;

    const request = new ContactFormRequest(values, this.contactFormQuestion.category);
    await this.formsService
      .contact(request)
      .then(() => {
        this.closeModal();
        void this.route.navigate([this.successPageUrl]);
      })
      .catch()
      .finally(() => {
        this.isSubmitting = false;
      });
  }

  closeModal(): void {
    this.pushUserEvent(UserEventAction.close);
    this.modalService.close();
  }
}
