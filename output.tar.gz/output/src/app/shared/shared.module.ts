import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeComponent } from 'angularx-qrcode';
import { NgxBarcode6Module } from 'ngx-barcode6';
import { BannerComponent } from '../features/content-blocks/banner/banner.component';
import { RegistrationFormComponent } from '../features/content-blocks/registration-form/registration-form.component';
import { TypeformComponent } from '../features/content-blocks/typeform/typeform.component';
import { FormModule } from '../features/form/form.module';
import { PasswordResetComponent } from '../features/password-reset/password-reset.component';
import { PasswordSetComponent } from '../features/password-set/password-set.component';
import { ActionTextComponent } from './components/action-text/action-text.component';
import { AirMilesStickerComponent } from './components/air-miles-sticker/air-miles-sticker.component';
import { BarcodeComponent } from './components/barcode/barcode.component';
import { BreadcrumbsComponent } from './components/breadcrumbs/breadcrumbs.component';
import { CarouselModule } from './components/carousel/carousel.module';
import { FocalImageComponent } from './components/common/focal-image/focal-image.component';
import { SelectCountComponent } from './components/common/select-count/select-count.component';
import { SliderComponent } from './components/common/slider/slider.component';
import { TitleComponent } from './components/common/title/title.component';
import { CounterComponent } from './components/counter/counter.component';
import { CustomCardComponent } from './components/custom-card/custom-card.component';
import { ExpandableListItemComponent } from './components/expandable-list/expandable-list-item.component';
import { ExpandableListComponent } from './components/expandable-list/expandable-list.component';
import { HamburgerNavigationComponent } from './components/hamburger-navigation/hamburger-navigation.component';
import { HeroComponent } from './components/hero/hero.component';
import { LinkListComponent } from './components/link-list/link-list.component';
import { MultiSelectSearchComponent } from './components/multi-select-search/multi-select-search.component';
import { MyCardComponent } from './components/my-card/my-card.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { NotificationBannerComponent } from './components/notification-banner/notification-banner.component';
import { PartnersListComponent } from './components/partners-list/partners-list.component';
import { SearchBarInputComponent } from './components/search-bar-input/search-bar-input.component';
import { SkeletonCardComponent } from './components/skeleton-card/skeleton-card.component';
import { SkeletonPageComponent } from './components/skeleton-page/skeleton-page.component';
import { TableHeadingComponent } from './components/table/table-heading/table-heading.component';
import { TableComponent } from './components/table/table.component';
import { BackButtonDirective } from './directives/back-button.directive';
import { ButtonLoaderDirective } from './directives/button-loader.directive';
import { InternalInnerHtmlDirectiveModule } from './directives/internal-inner-html.directive';
import { IntersectionObserverDirective } from './directives/intersection-observer.directive';
import { LinkDirective } from './directives/link.directive';
import { ConfirmationModalComponent } from './modals/confirmation-modal/confirmation-modal.component';
import { ContactInformationModalComponent } from './modals/contact-information-modal/contact-information-modal.component';
import { LoginModalComponent } from './modals/login-modal/login-modal.component';
import { PasswordResetModalComponent } from './modals/password-reset-modal/password-reset-modal.component';
import { PasswordVerificationModalComponent } from './modals/password-verification-modal/password-verification-modal.component';
import { TwoFactorLoginModalComponent } from './modals/two-factor-login-modal/two-factor-login-modal.component';
import { VerificationModalComponent } from './modals/verification-modal/verification-modal.component';
import { CurrencyPipe } from './pipes/currency.pipe';
import { FormatNumberPipe } from './pipes/format-number.pipe';
import { RangePipe } from './pipes/range.pipe';
import { SortByPipe } from './pipes/sort-by.pipe';

@NgModule({
  declarations: [
    HeroComponent,
    BreadcrumbsComponent,
    PartnersListComponent,
    AirMilesStickerComponent,
    FocalImageComponent,
    LinkListComponent,
    ExpandableListComponent,
    ExpandableListItemComponent,
    SelectCountComponent,
    ActionTextComponent,
    TitleComponent,
    ButtonLoaderDirective,
    IntersectionObserverDirective,
    LinkDirective,
    LoginModalComponent,
    RegistrationFormComponent,
    PasswordResetModalComponent,
    PasswordResetComponent,
    PasswordSetComponent,
    BarcodeComponent,
    NavigationComponent,
    HamburgerNavigationComponent,
    FormatNumberPipe,
    MyCardComponent,
    CurrencyPipe,
    SortByPipe,
    BackButtonDirective,
    RangePipe,
    SkeletonPageComponent,
    SkeletonCardComponent,
    ContactInformationModalComponent,
    TableComponent,
    TableHeadingComponent,
    SkeletonCardComponent,
    ConfirmationModalComponent,
    TwoFactorLoginModalComponent,
    CustomCardComponent,
    VerificationModalComponent,
    PasswordVerificationModalComponent,
    CustomCardComponent,
    SliderComponent,
    NotificationBannerComponent,
    CounterComponent,
    BannerComponent,
    SearchBarInputComponent,
    MultiSelectSearchComponent,
    TypeformComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    CarouselModule,
    NgxBarcode6Module,
    FormModule,
    InternalInnerHtmlDirectiveModule,
    NgxSliderModule,
    QRCodeComponent
  ],
  exports: [
    HeroComponent,
    BreadcrumbsComponent,
    PartnersListComponent,
    AirMilesStickerComponent,
    ActionTextComponent,
    TitleComponent,
    FocalImageComponent,
    LinkListComponent,
    ExpandableListComponent,
    ExpandableListItemComponent,
    SelectCountComponent,
    ButtonLoaderDirective,
    LinkDirective,
    LoginModalComponent,
    BarcodeComponent,
    TranslateModule,
    IntersectionObserverDirective,
    FormsModule,
    ReactiveFormsModule,
    RegistrationFormComponent,
    PasswordResetModalComponent,
    PasswordResetComponent,
    PasswordSetComponent,
    NavigationComponent,
    HamburgerNavigationComponent,
    CarouselModule,
    FormatNumberPipe,
    MyCardComponent,
    CurrencyPipe,
    SortByPipe,
    BackButtonDirective,
    SkeletonPageComponent,
    SkeletonCardComponent,
    ContactInformationModalComponent,
    RangePipe,
    TableComponent,
    TableHeadingComponent,
    SkeletonCardComponent,
    ConfirmationModalComponent,
    TwoFactorLoginModalComponent,
    FormModule,
    InternalInnerHtmlDirectiveModule,
    CustomCardComponent,
    VerificationModalComponent,
    PasswordVerificationModalComponent,
    SliderComponent,
    NotificationBannerComponent,
    CounterComponent,
    BannerComponent,
    SearchBarInputComponent,
    MultiSelectSearchComponent
  ]
})
export class SharedModule {}
