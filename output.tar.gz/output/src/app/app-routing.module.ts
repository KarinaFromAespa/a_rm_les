import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { SiteConstants } from './core/constants/site.constants';
import { logoutGuard } from './core/guards/logout.guard';
import { UrlHelper } from './core/helpers/url.helper';
export const routes: Routes = [
  {
    path: 'style-guide',
    pathMatch: 'full',
    loadChildren: () => import('./features/style-guide/style-guide.module').then((m) => m.StyleGuideModule)
  },
  {
    path: 'logout',
    pathMatch: 'prefix',
    canActivate: [logoutGuard],
    children: []
  },
  {
    path: '',
    pathMatch: 'full',
    loadChildren: () => import('./features/page/homepage/homepage.module').then((m) => m.HomepageModule)
  },
  {
    path: UrlHelper.trimLeadingSlash(SiteConstants.rootRoute),
    pathMatch: 'full',
    loadChildren: () => import('./features/page/homepage/homepage.module').then((m) => m.HomepageModule)
  },
  {
    path: `${UrlHelper.trimLeadingSlash(SiteConstants.rootRoute)}/`,
    pathMatch: 'full',
    loadChildren: () => import('./features/page/homepage/homepage.module').then((m) => m.HomepageModule)
  },
  {
    path: '**',
    pathMatch: 'full',
    loadChildren: () => import('./features/page/page.module').then((m) => m.PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, initialNavigation: 'enabledBlocking' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
