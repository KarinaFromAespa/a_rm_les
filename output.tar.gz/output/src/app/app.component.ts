import { Location } from '@angular/common';
import { Component, HostListener, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { HTTP } from '@awesome-cordova-plugins/http/ngx';
import { App, AppState, URLOpenListenerEvent } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import { BundleInfo, CapacitorUpdater } from '@capgo/capacitor-updater';
import { InAppBrowser } from '@capgo/inappbrowser';
import { Platform, ScrollCustomEvent } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { AppTrackingTransparency } from 'capacitor-plugin-app-tracking-transparency';
import { Subject } from 'rxjs';
import semverCoerce from 'semver/functions/coerce';
import semverGt from 'semver/functions/gt';
import { environment } from 'src/environments/environment';
import { SiteConstants } from './core/constants/site.constants';
import { PlatformHelper } from './core/helpers/platform.helper';
import { UrlHelper } from './core/helpers/url.helper';
import { UserHelper } from './core/helpers/user.helper';
import { LayoutComponent } from './core/layout/layout.component';
import { ILiveUpdate } from './core/models/live-update.model';
import { NavigationService } from './core/services/navigation.service';
import { PushMessageService } from './core/services/push-message.service';
import { ScrollService } from './core/services/scroll.service';
import { TokenService } from './core/services/token.service';
import { ModalAnchorDirective } from './features/modal/modal.directive';

@Component({
  selector: 'air-root',
  templateUrl: 'app.component.html',
  standalone: false
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild(LayoutComponent, { static: true }) layout: LayoutComponent;

  boundDocumentClickHandler: EventListenerOrEventListenerObject;
  theme: string;

  private lastTimeBackPress = 0;
  private timePeriodToExit = 2000;
  private bundle?: BundleInfo;
  private destroy$ = new Subject();

  get modalAnchor(): ModalAnchorDirective {
    return this.layout.modalAnchor;
  }

  @HostListener('ionScroll', ['$event'])
  public handleScrollEvent(event: ScrollCustomEvent): void {
    this.scrollService.updateScroll(event.detail.scrollTop);
  }

  @HostListener('window:focus')
  async onFocus(): Promise<void> {
    if (this.userHelper.currentUser && !this.userHelper.isLoggedIn) {
      await this.tokenService.logout();
    }
  }

  constructor(
    private translateService: TranslateService,
    private platform: Platform,
    private platformHelper: PlatformHelper,
    private httpNative: HTTP,
    private location: Location,
    private userHelper: UserHelper,
    private tokenService: TokenService,
    private scrollService: ScrollService,
    private router: Router,
    private zone: NgZone,
    private navigationService: NavigationService,
    private pushMessageService: PushMessageService
  ) {
    this.translateService.setDefaultLang('nl');

    if (PlatformHelper.isNativeMobile) {
      this.initNative();
    }
  }

  ngOnInit(): void {
    if (!PlatformHelper.isNativeMobile) {
      this.handleUmbracoParams();
    }

    // To fix correct cleanup of bound manual eventListeners, bind them and store in references for correct removal.
    this.boundDocumentClickHandler = this.onDocumentClick.bind(this) as EventListenerOrEventListenerObject;
    document.addEventListener('click', this.boundDocumentClickHandler, true);
  }

  ngOnDestroy(): void {
    document.removeEventListener('click', this.boundDocumentClickHandler, true);
    this.destroy$.next(void 0);
  }

  handleUmbracoParams(): void {
    const currentNavigation = this.router.getCurrentNavigation();
    let slug = currentNavigation?.extractedUrl.queryParams.slug as string;
    if (!slug) {
      return;
    }

    const preview = currentNavigation?.extractedUrl.queryParams.preview as boolean;
    if (preview) {
      slug += '?preview=true';
    }

    // Force reload to avoid async issues with components on root
    window.location.href = encodeURI(slug);
  }

  initNative(): void {
    void this.platform.ready().then(() => {
      void StatusBar.setStyle({ style: Style.Light });

      // Notify Capacitor Updater that the current bundle is working (a rollback will occur if this method is not called on app launch)
      void CapacitorUpdater.notifyAppReady();

      void App.addListener('appUrlOpen', (event: URLOpenListenerEvent) => {
        // Navigate to slug if app was launched
        this.zone.run(() => {
          const slug = event.url.split(/^https:\/\/[0-9A-Za-z-.:]+/).pop();
          void this.router.navigateByUrl(slug && slug !== '/' ? slug : SiteConstants.rootRoute);
        });
      });

      void App.addListener('appStateChange', (state) => {
        void this.onCapacitorUpdaterStateChange(state);
      });
      void this.downloadCapacitorUpdaterBundle();

      const openRef = window.open;
      window.open = (url?: string | URL, target?: string, features?: string) => {
        if (target === '_system') {
          openRef(url, target, features);
        } else {
          InAppBrowser.removeAllListeners();
          InAppBrowser.openWebView({ url: url?.toString() ?? '', title: '' });
        }
        return null;
      };

      this.httpNative.setDataSerializer('json');
      void this.httpNative.setServerTrustMode('nocheck');
      void SplashScreen.hide();

      void App.addListener('resume', () => {
        void this.pushMessageService.tryRegisterDevice();
      });

      void this.pushMessageService.tryRegisterDevice();
    });

    this.handleBackButtonEvent();
  }

  handleBackButtonEvent(): void {
    this.platform.backButton.subscribeWithPriority(0, () => {
      if (this.location.isCurrentPathEqualTo('/')) {
        // Require double press of the back button to exit the app
        if (new Date().getTime() - this.lastTimeBackPress >= this.timePeriodToExit) {
          this.lastTimeBackPress = new Date().getTime();
        } else {
          navigator['app'].exitApp();
        }
      } else {
        this.navigationService.back();
      }
    });
  }

  onDocumentClick(event: Event): void {
    if (PlatformHelper.isNativeMobile && event.target instanceof HTMLAnchorElement) {
      const element = event.target;
      let url = element.getAttribute('href');
      if (url && !UrlHelper.isExternalLink(url) && element.target === '_blank') {
        url = `https://${location.hostname}${url}`;
        event.preventDefault();
        event.stopPropagation();
        window.open(url);
      }
    }
  }

  private async onCapacitorUpdaterStateChange(state: AppState): Promise<void> {
    // Check for a new bundle when the app is active to prevent failed download
    if (state.isActive && !this.bundle) {
      await this.downloadCapacitorUpdaterBundle();
    }

    // Switch to the new bundle when the app goes inactive
    if (!state.isActive && this.bundle?.version?.length) {
      //Do not reload for iOS if the uses has not finished the App Tracking Transparency flow
      //App Tracking Transparency popup causes app to be inactive and triggers updater reload, this causes consent sheet to be shown again
      if (this.platformHelper.isiOSNative) {
        const { status } = await AppTrackingTransparency.getStatus();
        if (status === 'notDetermined') {
          return;
        }
      }

      void SplashScreen.show();
      void CapacitorUpdater.set(this.bundle).catch(() => {
        void SplashScreen.hide();
      });
    }
  }

  private async downloadCapacitorUpdaterBundle(): Promise<void> {
    const result = await fetch(environment.liveUpdateUrl);
    if (!result.ok) {
      return;
    }

    let versions = (await result.json()) as ILiveUpdate[];
    if (!versions?.length) {
      return;
    }
    versions = versions.sort((v1, v2) => (semverGt(semverCoerce(v2.bundleVersion) ?? '', semverCoerce(v1.bundleVersion) ?? '') ? 1 : -1));

    void CapacitorUpdater.current().then((current) => {
      const eligible = versions.find((v) => current.native === (this.platformHelper.isAndroidNative ? v.androidVersion : v.iosVersion));
      if (!eligible || current.bundle?.version === eligible.bundleVersion) {
        return;
      }

      void CapacitorUpdater.download({
        version: eligible.bundleVersion,
        url: eligible.url
      }).then((data) => {
        this.bundle = data;
      });
    });
  }
}
