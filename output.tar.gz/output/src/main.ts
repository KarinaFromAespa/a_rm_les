import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

let isBootstrapped = false;

if (environment.production) {
  enableProdMode();
}

document.addEventListener('DOMContentLoaded', () => {
  if (!isBootstrapped) {
    isBootstrapped = true;
    platformBrowserDynamic()
      .bootstrapModule(AppModule)
      .catch((err) => console.log(err));
  }
});
